#include "Top.h"

void Top_t::init ( bool rand_init ) {
  if (rand_init) Top_Queue_22__ram.randomize();
  if (rand_init) Top_Queue_22__enq_ptr.randomize();
  if (rand_init) Top_Queue_22__deq_ptr.randomize();
  if (rand_init) Top_Queue_22__maybe_full.randomize();
  if (rand_init) Top_Queue_21__maybe_full.randomize();
  if (rand_init) Top_Queue_21__ram.randomize();
  if (rand_init) Top_Queue_19__ram.randomize();
  if (rand_init) Top_Queue_19__enq_ptr.randomize();
  if (rand_init) Top_Queue_19__deq_ptr.randomize();
  if (rand_init) Top_Queue_19__maybe_full.randomize();
  if (rand_init) Top_Queue_18__maybe_full.randomize();
  if (rand_init) Top_Queue_18__ram.randomize();
  if (rand_init) Top_Queue_17__enq_ptr.randomize();
  if (rand_init) Top_Queue_17__maybe_full.randomize();
  if (rand_init) Top_Queue_17__deq_ptr.randomize();
  if (rand_init) Top_Queue_17__ram.randomize();
  if (rand_init) Top_Queue_16__ram.randomize();
  if (rand_init) Top_Queue_16__enq_ptr.randomize();
  if (rand_init) Top_Queue_16__deq_ptr.randomize();
  if (rand_init) Top_Queue_16__maybe_full.randomize();
  if (rand_init) Top_Queue_15__enq_ptr.randomize();
  if (rand_init) Top_Queue_15__maybe_full.randomize();
  if (rand_init) Top_Queue_15__deq_ptr.randomize();
  if (rand_init) Top_Queue_15__ram.randomize();
  { Top_SodorTile_cpu_c__micro_code.put(0, 0, 0x3010000L); }
  { Top_SodorTile_cpu_c__micro_code.put(1, 0, 0x68004280L); }
  { Top_SodorTile_cpu_c__micro_code.put(2, 0, 0x6120080L); }
  { Top_SodorTile_cpu_c__micro_code.put(3, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(4, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(5, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(6, 0, 0x6420100L); }
  { Top_SodorTile_cpu_c__micro_code.put(7, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(8, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(9, 0, 0x281b0000L); }
  { Top_SodorTile_cpu_c__micro_code.put(10, 0, 0xe004280L); }
  { Top_SodorTile_cpu_c__micro_code.put(11, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(12, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(13, 0, 0x28800c00L); }
  { Top_SodorTile_cpu_c__micro_code.put(14, 0, 0x281b0000L); }
  { Top_SodorTile_cpu_c__micro_code.put(15, 0, 0x1a00c280L); }
  { Top_SodorTile_cpu_c__micro_code.put(16, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(17, 0, 0xe001500L); }
  { Top_SodorTile_cpu_c__micro_code.put(18, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(19, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(20, 0, 0xe1a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(21, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(22, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(23, 0, 0xe3a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(24, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(25, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(26, 0, 0xe3e0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(27, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(28, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(29, 0, 0xe220100L); }
  { Top_SodorTile_cpu_c__micro_code.put(30, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(31, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(32, 0, 0xe260100L); }
  { Top_SodorTile_cpu_c__micro_code.put(33, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(34, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(35, 0, 0xe2a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(36, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(37, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(38, 0, 0xe2e0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(39, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(40, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(41, 0, 0xe320100L); }
  { Top_SodorTile_cpu_c__micro_code.put(42, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(43, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(44, 0, 0xe360100L); }
  { Top_SodorTile_cpu_c__micro_code.put(45, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(46, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(47, 0, 0xe1a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(48, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(49, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(50, 0, 0xe1e0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(51, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(52, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(53, 0, 0xe3a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(54, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(55, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(56, 0, 0xe3e0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(57, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(58, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(59, 0, 0xe220100L); }
  { Top_SodorTile_cpu_c__micro_code.put(60, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(61, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(62, 0, 0xe260100L); }
  { Top_SodorTile_cpu_c__micro_code.put(63, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(64, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(65, 0, 0xe2a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(66, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(67, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(68, 0, 0xe2e0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(69, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(70, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(71, 0, 0xe320100L); }
  { Top_SodorTile_cpu_c__micro_code.put(72, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(73, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(74, 0, 0xe360100L); }
  { Top_SodorTile_cpu_c__micro_code.put(75, 0, 0x3000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(76, 0, 0x29160000L); }
  { Top_SodorTile_cpu_c__micro_code.put(77, 0, 0x28801c00L); }
  { Top_SodorTile_cpu_c__micro_code.put(78, 0, 0x61a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(79, 0, 0x3000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(80, 0, 0x26020000L); }
  { Top_SodorTile_cpu_c__micro_code.put(81, 0, 0x29160000L); }
  { Top_SodorTile_cpu_c__micro_code.put(82, 0, 0x28801c00L); }
  { Top_SodorTile_cpu_c__micro_code.put(83, 0, 0x61a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(84, 0, 0x3000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(85, 0, 0xe020000L); }
  { Top_SodorTile_cpu_c__micro_code.put(86, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(87, 0, 0x28800400L); }
  { Top_SodorTile_cpu_c__micro_code.put(88, 0, 0x71a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(89, 0, 0x3000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(90, 0, 0xe020100L); }
  { Top_SodorTile_cpu_c__micro_code.put(91, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(92, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(93, 0, 0x281c01f7L); }
  { Top_SodorTile_cpu_c__micro_code.put(94, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(95, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(96, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(97, 0, 0x281c0277L); }
  { Top_SodorTile_cpu_c__micro_code.put(98, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(99, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(100, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(101, 0, 0x293a0000L); }
  { Top_SodorTile_cpu_c__micro_code.put(102, 0, 0x28000277L); }
  { Top_SodorTile_cpu_c__micro_code.put(103, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(104, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(105, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(106, 0, 0x293e0000L); }
  { Top_SodorTile_cpu_c__micro_code.put(107, 0, 0x28000277L); }
  { Top_SodorTile_cpu_c__micro_code.put(108, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(109, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(110, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(111, 0, 0x293a0000L); }
  { Top_SodorTile_cpu_c__micro_code.put(112, 0, 0x280001f7L); }
  { Top_SodorTile_cpu_c__micro_code.put(113, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(114, 0, 0x13000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(115, 0, 0x1a800000L); }
  { Top_SodorTile_cpu_c__micro_code.put(116, 0, 0x293e0000L); }
  { Top_SodorTile_cpu_c__micro_code.put(117, 0, 0x280001f7L); }
  { Top_SodorTile_cpu_c__micro_code.put(118, 0, 0x28000100L); }
  { Top_SodorTile_cpu_c__micro_code.put(119, 0, 0x3000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(120, 0, 0x29160000L); }
  { Top_SodorTile_cpu_c__micro_code.put(121, 0, 0x28802400L); }
  { Top_SodorTile_cpu_c__micro_code.put(122, 0, 0x61a0100L); }
  { Top_SodorTile_cpu_c__micro_code.put(123, 0, 0x1b000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(124, 0, 0x36020000L); }
  { Top_SodorTile_cpu_c__micro_code.put(125, 0, 0xe020100L); }
  { Top_SodorTile_cpu_c__micro_code.put(126, 0, 0x33000000L); }
  { Top_SodorTile_cpu_c__micro_code.put(127, 0, 0xe020100L); }
  if (rand_init) Top_Queue_12__ram.randomize();
  if (rand_init) Top_Queue_12__enq_ptr.randomize();
  if (rand_init) Top_Queue_12__deq_ptr.randomize();
  if (rand_init) Top_Queue_12__maybe_full.randomize();
  if (rand_init) Top_Queue_11__enq_ptr.randomize();
  if (rand_init) Top_Queue_11__maybe_full.randomize();
  if (rand_init) Top_Queue_11__deq_ptr.randomize();
  if (rand_init) Top_Queue_11__ram.randomize();
  if (rand_init) Top_SodorTile_cache_finish_queue__ram.randomize();
  if (rand_init) Top_SodorTile_cache_finish_queue__enq_ptr.randomize();
  if (rand_init) Top_SodorTile_cache_finish_queue__deq_ptr.randomize();
  if (rand_init) Top_SodorTile_cache_finish_queue__maybe_full.randomize();
  if (rand_init) Top_SodorTile_cache_writeback_queue__ram.randomize();
  if (rand_init) Top_SodorTile_cache_writeback_queue__enq_ptr.randomize();
  if (rand_init) Top_SodorTile_cache_writeback_queue__deq_ptr.randomize();
  if (rand_init) Top_SodorTile_cache_writeback_queue__maybe_full.randomize();
  if (rand_init) Top_SodorTile_cache__dirty_array.randomize();
  if (rand_init) Top_SodorTile_cache__valid_array.randomize();
  if (rand_init) Top_SodorTile_cache__tag_array.randomize();
  if (rand_init) Top_SodorTile_cache__performing_flush.randomize();
  if (rand_init) Top_SodorTile_cache__flush_idx.randomize();
  if (rand_init) Top_SodorTile_cache__wb_counter.randomize();
  if (rand_init) Top_SodorTile_cache__data_array.randomize();
  if (rand_init) Top_SodorTile_cache__state.randomize();
  if (rand_init) Top_SodorTile_cache__refill_counter.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_error_mode.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_k1.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_k0.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_cause.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_compare.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_count.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_ebase.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_epc.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_stats.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_tohost.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_fromhost.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_status_im.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_status_vm.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_status_s.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_status_ps.randomize();
  if (rand_init) Top_SodorTile_cpu_d_pcr__reg_status_et.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_0.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_1.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_2.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_3.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_4.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_5.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_6.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_7.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_8.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_9.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_10.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_11.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_12.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_13.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_14.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_15.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_16.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_17.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_18.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_19.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_20.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_21.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_22.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_23.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_24.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_25.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_26.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_27.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_28.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_29.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_30.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_31.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_32.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_33.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_34.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_35.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_36.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_37.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_38.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_39.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_40.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_41.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_42.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_43.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_44.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_45.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_46.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_47.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_48.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_49.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_50.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_51.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_52.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_53.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_54.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_55.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_56.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_57.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_58.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_59.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_60.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_61.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_62.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_63.randomize();
  if (rand_init) Top_SodorTile_cpu_d__regfile_64.randomize();
  if (rand_init) Top_SodorTile_cpu_d__ir.randomize();
  if (rand_init) Top_SodorTile_cpu_d__reg_a.randomize();
  if (rand_init) Top_SodorTile_cpu_d__reg_b.randomize();
  if (rand_init) Top_SodorTile_cpu_d__reg_ma.randomize();
  if (rand_init) Top_SodorTile_cpu_c__upc_state.randomize();
  if (rand_init) Top_Queue_8__enq_ptr.randomize();
  if (rand_init) Top_Queue_8__maybe_full.randomize();
  if (rand_init) Top_Queue_8__deq_ptr.randomize();
  if (rand_init) Top_Queue_8__ram.randomize();
  if (rand_init) Top_Queue_7__ram.randomize();
  if (rand_init) Top_Queue_7__enq_ptr.randomize();
  if (rand_init) Top_Queue_7__deq_ptr.randomize();
  if (rand_init) Top_Queue_7__maybe_full.randomize();
  if (rand_init) Top_hub_Queue_6__ram.randomize();
  if (rand_init) Top_hub_Queue_6__enq_ptr.randomize();
  if (rand_init) Top_hub_Queue_6__deq_ptr.randomize();
  if (rand_init) Top_hub_Queue_6__maybe_full.randomize();
  if (rand_init) Top_hub_Queue_5__ram.randomize();
  if (rand_init) Top_hub_Queue_5__enq_ptr.randomize();
  if (rand_init) Top_hub_Queue_5__deq_ptr.randomize();
  if (rand_init) Top_hub_Queue_5__maybe_full.randomize();
  if (rand_init) Top_hub_mem_req_data_arb__locked_7.randomize();
  if (rand_init) Top_hub_mem_req_data_arb__locked_6.randomize();
  if (rand_init) Top_hub_mem_req_data_arb__locked_5.randomize();
  if (rand_init) Top_hub_mem_req_data_arb__locked_4.randomize();
  if (rand_init) Top_hub_mem_req_data_arb__locked_3.randomize();
  if (rand_init) Top_hub_mem_req_data_arb__locked_2.randomize();
  if (rand_init) Top_hub_mem_req_data_arb__locked_1.randomize();
  if (rand_init) Top_hub_mem_req_data_arb__locked_0.randomize();
  if (rand_init) Top_hub_Queue_4__ram.randomize();
  if (rand_init) Top_hub_Queue_4__enq_ptr.randomize();
  if (rand_init) Top_hub_Queue_4__deq_ptr.randomize();
  if (rand_init) Top_hub_Queue_4__maybe_full.randomize();
  if (rand_init) Top_hub_Queue_3__enq_ptr.randomize();
  if (rand_init) Top_hub_Queue_3__maybe_full.randomize();
  if (rand_init) Top_hub_Queue_3__deq_ptr.randomize();
  if (rand_init) Top_hub_Queue_3__ram.randomize();
  if (rand_init) Top_hub_Queue_2__enq_ptr.randomize();
  if (rand_init) Top_hub_Queue_2__maybe_full.randomize();
  if (rand_init) Top_hub_Queue_2__deq_ptr.randomize();
  if (rand_init) Top_hub_Queue_2__ram.randomize();
  if (rand_init) Top_hub_Queue_1__enq_ptr.randomize();
  if (rand_init) Top_hub_Queue_1__maybe_full.randomize();
  if (rand_init) Top_hub_Queue_1__deq_ptr.randomize();
  if (rand_init) Top_hub_Queue_1__ram.randomize();
  if (rand_init) Top_hub_XactTracker_7__p_rep_count.randomize();
  if (rand_init) Top_hub_XactTracker_7__x_needs_read.randomize();
  if (rand_init) Top_hub_XactTracker_7__addr_.randomize();
  if (rand_init) Top_hub_XactTracker_7__x_type_.randomize();
  if (rand_init) Top_hub_XactTracker_7__tile_xact_id_.randomize();
  if (rand_init) Top_hub_XactTracker_7__p_rep_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_7__x_init_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_7__x_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_7__p_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_7__mem_cnt.randomize();
  if (rand_init) Top_hub_XactTracker_7__init_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_7__state.randomize();
  if (rand_init) Top_hub_XactTracker_7__p_rep_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_6__x_needs_read.randomize();
  if (rand_init) Top_hub_XactTracker_6__p_rep_count.randomize();
  if (rand_init) Top_hub_XactTracker_6__p_rep_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_6__x_init_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_6__x_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_6__addr_.randomize();
  if (rand_init) Top_hub_XactTracker_6__x_type_.randomize();
  if (rand_init) Top_hub_XactTracker_6__tile_xact_id_.randomize();
  if (rand_init) Top_hub_XactTracker_6__init_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_6__mem_cnt.randomize();
  if (rand_init) Top_hub_XactTracker_6__p_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_6__state.randomize();
  if (rand_init) Top_hub_XactTracker_6__p_rep_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_5__p_rep_count.randomize();
  if (rand_init) Top_hub_XactTracker_5__x_needs_read.randomize();
  if (rand_init) Top_hub_XactTracker_5__x_init_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_5__x_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_5__p_rep_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_5__mem_cnt.randomize();
  if (rand_init) Top_hub_XactTracker_5__addr_.randomize();
  if (rand_init) Top_hub_XactTracker_5__x_type_.randomize();
  if (rand_init) Top_hub_XactTracker_5__tile_xact_id_.randomize();
  if (rand_init) Top_hub_XactTracker_5__init_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_5__p_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_5__p_rep_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_5__state.randomize();
  if (rand_init) Top_hub_XactTracker_4__p_rep_count.randomize();
  if (rand_init) Top_hub_XactTracker_4__x_needs_read.randomize();
  if (rand_init) Top_hub_XactTracker_4__x_init_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_4__x_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_4__p_rep_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_4__mem_cnt.randomize();
  if (rand_init) Top_hub_XactTracker_4__addr_.randomize();
  if (rand_init) Top_hub_XactTracker_4__x_type_.randomize();
  if (rand_init) Top_hub_XactTracker_4__tile_xact_id_.randomize();
  if (rand_init) Top_hub_XactTracker_4__init_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_4__p_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_4__p_rep_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_4__state.randomize();
  if (rand_init) Top_hub_XactTracker_3__p_rep_count.randomize();
  if (rand_init) Top_hub_XactTracker_3__x_needs_read.randomize();
  if (rand_init) Top_hub_XactTracker_3__x_init_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_3__x_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_3__p_rep_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_3__mem_cnt.randomize();
  if (rand_init) Top_hub_XactTracker_3__addr_.randomize();
  if (rand_init) Top_hub_XactTracker_3__x_type_.randomize();
  if (rand_init) Top_hub_XactTracker_3__tile_xact_id_.randomize();
  if (rand_init) Top_hub_XactTracker_3__init_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_3__p_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_3__p_rep_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_3__state.randomize();
  if (rand_init) Top_hub_XactTracker_2__p_rep_count.randomize();
  if (rand_init) Top_hub_XactTracker_2__x_needs_read.randomize();
  if (rand_init) Top_hub_XactTracker_2__x_init_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_2__x_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_2__p_rep_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_2__mem_cnt.randomize();
  if (rand_init) Top_hub_XactTracker_2__addr_.randomize();
  if (rand_init) Top_hub_XactTracker_2__x_type_.randomize();
  if (rand_init) Top_hub_XactTracker_2__tile_xact_id_.randomize();
  if (rand_init) Top_hub_XactTracker_2__init_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_2__p_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_2__p_rep_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_2__state.randomize();
  if (rand_init) Top_hub_XactTracker_1__x_init_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_1__x_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_1__addr_.randomize();
  if (rand_init) Top_hub_XactTracker_1__tile_xact_id_.randomize();
  if (rand_init) Top_hub_XactTracker_1__init_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_1__mem_cnt.randomize();
  if (rand_init) Top_hub_XactTracker_1__p_rep_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker_1__p_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker_1__p_rep_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker_1__x_needs_read.randomize();
  if (rand_init) Top_hub_XactTracker_1__x_type_.randomize();
  if (rand_init) Top_hub_XactTracker_1__p_rep_count.randomize();
  if (rand_init) Top_hub_XactTracker_1__state.randomize();
  if (rand_init) Top_hub_XactTracker__x_init_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker__x_w_mem_cmd_sent.randomize();
  if (rand_init) Top_hub_XactTracker__p_rep_data_needs_write.randomize();
  if (rand_init) Top_hub_XactTracker__mem_cnt.randomize();
  if (rand_init) Top_hub_XactTracker__addr_.randomize();
  if (rand_init) Top_hub_XactTracker__tile_xact_id_.randomize();
  if (rand_init) Top_hub_XactTracker__init_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker__p_rep_tile_id_.randomize();
  if (rand_init) Top_hub_XactTracker__x_needs_read.randomize();
  if (rand_init) Top_hub_XactTracker__x_type_.randomize();
  if (rand_init) Top_hub_XactTracker__p_rep_count.randomize();
  if (rand_init) Top_hub_XactTracker__state.randomize();
  if (rand_init) Top_hub_XactTracker__p_w_mem_cmd_sent.randomize();
  if (rand_init) R4697.randomize();
  if (rand_init) Top_hub__abort_state_arr_0.randomize();
  if (rand_init) R4715.randomize();
  if (rand_init) Top_hub__abort_state_arr_1.randomize();
  if (rand_init) Top_htif_x_init__maybe_full.randomize();
  if (rand_init) Top_htif_x_init__ram.randomize();
  if (rand_init) Top_htif__seqno.randomize();
  if (rand_init) R4764.randomize();
  if (rand_init) Top_htif__packet_ram_1.randomize();
  if (rand_init) Top_htif__packet_ram_2.randomize();
  if (rand_init) Top_htif__packet_ram_3.randomize();
  if (rand_init) Top_htif__packet_ram_4.randomize();
  if (rand_init) Top_htif__packet_ram_5.randomize();
  if (rand_init) Top_htif__packet_ram_6.randomize();
  if (rand_init) Top_htif__packet_ram_7.randomize();
  if (rand_init) Top_htif__pos.randomize();
  if (rand_init) Top_htif__mem_acked.randomize();
  if (rand_init) Top_htif__mem_nacked.randomize();
  if (rand_init) Top_htif__mem_needs_ack.randomize();
  if (rand_init) Top_htif__mem_gxid.randomize();
  if (rand_init) Top_htif__mem_cnt.randomize();
  if (rand_init) Top_htif__pcr_wdata.randomize();
  if (rand_init) R4913.randomize();
  if (rand_init) Top_htif__tx_count.randomize();
  if (rand_init) Top_htif__size.randomize();
  if (rand_init) Top_htif__rx_count.randomize();
  if (rand_init) Top_htif__cmd.randomize();
  if (rand_init) Top_htif__state.randomize();
  if (rand_init) Top_htif__rx_shifter.randomize();
  if (rand_init) Top_htif__addr.randomize();
  if (rand_init) R5015.randomize();
  if (rand_init) R5080.randomize();
  if (rand_init) R5081.randomize();
  if (rand_init) R5082.randomize();
  if (rand_init) R5084.randomize();
  if (rand_init) R5086.randomize();
}
void Top_t::clock_lo ( dat_t<1> reset ) {
  { Top_Queue_22__io_enq_bits_data.values[0] = Top_SodorTile__io_tilelink_probe_rep_data_bits_data.values[0]; Top_Queue_22__io_enq_bits_data.values[1] = Top_SodorTile__io_tilelink_probe_rep_data_bits_data.values[1]; }
  { Top_Queue_22__do_flow.values[0] = 0x0L; }
  T1.values[0] = !Top_Queue_22__do_flow.values[0];
  { Top_Queue_22__io_enq_valid.values[0] = Top_SodorTile__io_tilelink_probe_rep_data_valid.values[0]; }
  Top_Queue_22__ptr_match.values[0] = Top_Queue_22__enq_ptr.values[0] == Top_Queue_22__deq_ptr.values[0];
  { Top_Queue_22__full.values[0] = Top_Queue_22__ptr_match.values[0]&&Top_Queue_22__maybe_full.values[0]; }
  T2.values[0] = !Top_Queue_22__full.values[0];
  { Top_Queue_22__io_enq_ready.values[0] = T2.values[0]; }
  { T3.values[0] = Top_Queue_22__io_enq_ready.values[0]&&Top_Queue_22__io_enq_valid.values[0]; }
  { Top_Queue_22__do_enq.values[0] = T3.values[0]&&T1.values[0]; }
  { Top_Queue_22__reset.values[0] = reset.values[0]; }
  { T5.values[0] = Top_Queue_22__enq_ptr.values[0]+0x1L; }
  T5.values[0] = T5.values[0] & 1;
  { val_t __mask = -Top_Queue_22__do_enq.values[0]; T6.values[0] = Top_Queue_22__enq_ptr.values[0] ^ ((Top_Queue_22__enq_ptr.values[0] ^ T5.values[0]) & __mask); }
  { Top_Queue_22__enq_ptr_shadow.values[0] = TERNARY(Top_Queue_22__reset.values[0], 0x0L, T6.values[0]); }
  { T7.values[0] = Top_Queue_22__deq_ptr.values[0]+0x1L; }
  T7.values[0] = T7.values[0] & 1;
  T8.values[0] = !Top_Queue_22__do_flow.values[0];
  T9.values[0] = !Top_Queue_22__maybe_full.values[0];
  { Top_Queue_22__empty.values[0] = Top_Queue_22__ptr_match.values[0]&&T9.values[0]; }
  T10.values[0] = !Top_Queue_22__empty.values[0];
  { Top_Queue_22__io_deq_valid.values[0] = T10.values[0]; }
  { T11.values[0] = Top_hub_XactTracker_7__p_rep_tile_id_.values[0]; }
  T12.values[0] = 0x1L << T11.values[0];
  Top_hub_Queue_6__ptr_match.values[0] = Top_hub_Queue_6__enq_ptr.values[0] == Top_hub_Queue_6__deq_ptr.values[0];
  { Top_hub_Queue_6__full.values[0] = Top_hub_Queue_6__ptr_match.values[0]&&Top_hub_Queue_6__maybe_full.values[0]; }
  T13.values[0] = !Top_hub_Queue_6__full.values[0];
  { Top_hub_Queue_6__io_enq_ready.values[0] = T13.values[0]; }
  { Top_hub_mem_req_data_arb__io_out_ready.values[0] = Top_hub_Queue_6__io_enq_ready.values[0]; }
  { T14.values[0] = Top_hub_mem_req_data_arb__io_out_ready.values[0]&&Top_hub_mem_req_data_arb__locked_0.values[0]; }
  { Top_hub_XactTracker__io_p_rep_tile_id.values[0] = Top_hub_XactTracker__p_rep_tile_id_.values[0]; }
  { T15.values[0] = Top_hub_XactTracker__io_p_rep_tile_id.values[0]; }
  { T16.values[0] = T15.values[0]; }
  T17.values[0] = 0x1L << T16.values[0];
  { T18.values[0] = T17.values[0]; }
  T18.values[0] = T18.values[0] & 3;
  T19.values[0] = (T18.values[0] >> 1) & 1;
  { T20.values[0] = T19.values[0]; }
  { Top_htif__io_mem_probe_rep_data_valid.values[0] = 0x0L; }
  { Top_hub__io_tiles_1_probe_rep_data_valid.values[0] = Top_htif__io_mem_probe_rep_data_valid.values[0]; }
  { T21.values[0] = Top_hub__io_tiles_1_probe_rep_data_valid.values[0]&T20.values[0]; }
  T22.values[0] = (T18.values[0] >> 0) & 1;
  { T23.values[0] = T22.values[0]; }
  { Top_hub__io_tiles_0_probe_rep_data_valid.values[0] = Top_Queue_22__io_deq_valid.values[0]; }
  { T24.values[0] = Top_hub__io_tiles_0_probe_rep_data_valid.values[0]&T23.values[0]; }
  { T25.values[0] = T24.values[0]|T21.values[0]; }
  { Top_hub_XactTracker__io_p_rep_data_valid.values[0] = T25.values[0]; }
  { T26.values[0] = Top_hub_XactTracker__io_p_rep_data_valid.values[0]||Top_hub_XactTracker__p_w_mem_cmd_sent.values[0]; }
  { T27.values[0] = Top_hub_Queue_1__ram.get(Top_hub_Queue_1__deq_ptr.values[0], 0); }
  { T28.values[0] = T27.values[0]; }
  T28.values[0] = T28.values[0] & 7;
  { T29.values[0] = T28.values[0]; }
  T29.values[0] = T29.values[0] & 7;
  { Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] = T29.values[0]; }
  { T30.values[0] = Top_hub_Queue_2__ram.get(Top_hub_Queue_2__deq_ptr.values[0], 0); }
  { T31.values[0] = T30.values[0]; }
  T31.values[0] = T31.values[0] & 7;
  { T32.values[0] = T31.values[0]; }
  T32.values[0] = T32.values[0] & 7;
  { Top_hub_Queue_2__io_deq_bits_global_xact_id.values[0] = T32.values[0]; }
  T33.values[0] = Top_hub_XactTracker__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T33.values[0]; T34.values[0] = Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_2__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T35.values[0] = T34.values[0]; }
  T35.values[0] = T35.values[0] & 7;
  T36.values[0] = Top_hub_XactTracker__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T36.values[0]; T37.values[0] = T35.values[0] ^ ((T35.values[0] ^ Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T38.values[0] = T37.values[0]; }
  T38.values[0] = T38.values[0] & 7;
  { Top_hub_XactTracker__io_p_rep_data_dep_bits_global_xact_id.values[0] = T38.values[0]; }
  T39.values[0] = Top_hub_XactTracker__io_p_rep_data_dep_bits_global_xact_id.values[0] == 0x0L;
  T40.values[0] = !Top_hub_Queue_1__maybe_full.values[0];
  Top_hub_Queue_1__ptr_match.values[0] = Top_hub_Queue_1__enq_ptr.values[0] == Top_hub_Queue_1__deq_ptr.values[0];
  { Top_hub_Queue_1__empty.values[0] = Top_hub_Queue_1__ptr_match.values[0]&&T40.values[0]; }
  T41.values[0] = !Top_hub_Queue_1__empty.values[0];
  { Top_hub_Queue_1__io_deq_valid.values[0] = T41.values[0]; }
  T42.values[0] = !Top_hub_Queue_2__maybe_full.values[0];
  Top_hub_Queue_2__ptr_match.values[0] = Top_hub_Queue_2__enq_ptr.values[0] == Top_hub_Queue_2__deq_ptr.values[0];
  { Top_hub_Queue_2__empty.values[0] = Top_hub_Queue_2__ptr_match.values[0]&&T42.values[0]; }
  T43.values[0] = !Top_hub_Queue_2__empty.values[0];
  { Top_hub_Queue_2__io_deq_valid.values[0] = T43.values[0]; }
  T44.values[0] = Top_hub_XactTracker__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T44.values[0]; T45.values[0] = Top_hub_Queue_1__io_deq_valid.values[0] ^ ((Top_hub_Queue_1__io_deq_valid.values[0] ^ Top_hub_Queue_2__io_deq_valid.values[0]) & __mask); }
  T46.values[0] = Top_hub_XactTracker__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T46.values[0]; T47.values[0] = T45.values[0] ^ ((T45.values[0] ^ Top_hub_Queue_1__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker__io_p_rep_data_dep_valid.values[0] = T47.values[0]; }
  { T48.values[0] = Top_hub_XactTracker__io_p_rep_data_dep_valid.values[0]&&T39.values[0]; }
  T49.values[0] = Top_hub_XactTracker__state.values[0] == 0x2L;
  { T50.values[0] = T49.values[0]&&Top_hub_XactTracker__p_rep_data_needs_write.values[0]; }
  { T51.values[0] = T50.values[0]&&T48.values[0]; }
  { val_t __mask = -T51.values[0]; T52.values[0] = 0x0L ^ ((0x0L ^ T26.values[0]) & __mask); }
  { Top_hub_XactTracker__io_init_tile_id.values[0] = Top_hub_XactTracker__init_tile_id_.values[0]; }
  { T53.values[0] = Top_hub_XactTracker__io_init_tile_id.values[0]; }
  { T54.values[0] = T53.values[0]; }
  T55.values[0] = 0x1L << T54.values[0];
  { T56.values[0] = T55.values[0]; }
  T56.values[0] = T56.values[0] & 3;
  T57.values[0] = (T56.values[0] >> 1) & 1;
  { T58.values[0] = T57.values[0]; }
  T59.values[0] = Top_htif__state.values[0] == 0x4L;
  { Top_htif__io_mem_xact_init_data_valid.values[0] = T59.values[0]; }
  { Top_hub__io_tiles_1_xact_init_data_valid.values[0] = Top_htif__io_mem_xact_init_data_valid.values[0]; }
  { T60.values[0] = Top_hub__io_tiles_1_xact_init_data_valid.values[0]&T58.values[0]; }
  T61.values[0] = (T56.values[0] >> 0) & 1;
  { T62.values[0] = T61.values[0]; }
  T63.values[0] = !Top_Queue_16__maybe_full.values[0];
  Top_Queue_16__ptr_match.values[0] = Top_Queue_16__enq_ptr.values[0] == Top_Queue_16__deq_ptr.values[0];
  { Top_Queue_16__empty.values[0] = Top_Queue_16__ptr_match.values[0]&&T63.values[0]; }
  T64.values[0] = !Top_Queue_16__empty.values[0];
  { Top_Queue_16__io_deq_valid.values[0] = T64.values[0]; }
  { Top_hub__io_tiles_0_xact_init_data_valid.values[0] = Top_Queue_16__io_deq_valid.values[0]; }
  { T65.values[0] = Top_hub__io_tiles_0_xact_init_data_valid.values[0]&T62.values[0]; }
  { T66.values[0] = T65.values[0]|T60.values[0]; }
  { Top_hub_XactTracker__io_x_init_data_valid.values[0] = T66.values[0]; }
  { T67.values[0] = Top_hub_XactTracker__io_x_init_data_valid.values[0]||Top_hub_XactTracker__x_w_mem_cmd_sent.values[0]; }
  { T68.values[0] = Top_hub_Queue_3__ram.get(Top_hub_Queue_3__deq_ptr.values[0], 0); }
  { T69.values[0] = T68.values[0]; }
  T69.values[0] = T69.values[0] & 7;
  { T70.values[0] = T69.values[0]; }
  T70.values[0] = T70.values[0] & 7;
  { Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] = T70.values[0]; }
  { T71.values[0] = Top_hub_Queue_4__ram.get(Top_hub_Queue_4__deq_ptr.values[0], 0); }
  { T72.values[0] = T71.values[0]; }
  T72.values[0] = T72.values[0] & 7;
  { T73.values[0] = T72.values[0]; }
  T73.values[0] = T73.values[0] & 7;
  { Top_hub_Queue_4__io_deq_bits_global_xact_id.values[0] = T73.values[0]; }
  T74.values[0] = Top_hub_XactTracker__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T74.values[0]; T75.values[0] = Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_4__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T76.values[0] = T75.values[0]; }
  T76.values[0] = T76.values[0] & 7;
  T77.values[0] = Top_hub_XactTracker__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T77.values[0]; T78.values[0] = T76.values[0] ^ ((T76.values[0] ^ Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T79.values[0] = T78.values[0]; }
  T79.values[0] = T79.values[0] & 7;
  { Top_hub_XactTracker__io_x_init_data_dep_bits_global_xact_id.values[0] = T79.values[0]; }
  T80.values[0] = Top_hub_XactTracker__io_x_init_data_dep_bits_global_xact_id.values[0] == 0x0L;
  T81.values[0] = !Top_hub_Queue_3__maybe_full.values[0];
  Top_hub_Queue_3__ptr_match.values[0] = Top_hub_Queue_3__enq_ptr.values[0] == Top_hub_Queue_3__deq_ptr.values[0];
  { Top_hub_Queue_3__empty.values[0] = Top_hub_Queue_3__ptr_match.values[0]&&T81.values[0]; }
  T82.values[0] = !Top_hub_Queue_3__empty.values[0];
  { Top_hub_Queue_3__io_deq_valid.values[0] = T82.values[0]; }
  T83.values[0] = !Top_hub_Queue_4__maybe_full.values[0];
  Top_hub_Queue_4__ptr_match.values[0] = Top_hub_Queue_4__enq_ptr.values[0] == Top_hub_Queue_4__deq_ptr.values[0];
  { Top_hub_Queue_4__empty.values[0] = Top_hub_Queue_4__ptr_match.values[0]&&T83.values[0]; }
  T84.values[0] = !Top_hub_Queue_4__empty.values[0];
  { Top_hub_Queue_4__io_deq_valid.values[0] = T84.values[0]; }
  T85.values[0] = Top_hub_XactTracker__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T85.values[0]; T86.values[0] = Top_hub_Queue_3__io_deq_valid.values[0] ^ ((Top_hub_Queue_3__io_deq_valid.values[0] ^ Top_hub_Queue_4__io_deq_valid.values[0]) & __mask); }
  T87.values[0] = Top_hub_XactTracker__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T87.values[0]; T88.values[0] = T86.values[0] ^ ((T86.values[0] ^ Top_hub_Queue_3__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker__io_x_init_data_dep_valid.values[0] = T88.values[0]; }
  { T89.values[0] = Top_hub_XactTracker__io_x_init_data_dep_valid.values[0]&&T80.values[0]; }
  T90.values[0] = !Top_hub_XactTracker__p_rep_data_needs_write.values[0];
  { T91.values[0] = T90.values[0]&&Top_hub_XactTracker__x_init_data_needs_write.values[0]; }
  { T92.values[0] = T49.values[0]&&T91.values[0]; }
  { T93.values[0] = T92.values[0]&&T89.values[0]; }
  { val_t __mask = -T93.values[0]; T94.values[0] = T52.values[0] ^ ((T52.values[0] ^ T67.values[0]) & __mask); }
  { Top_hub_XactTracker__io_mem_req_lock.values[0] = T94.values[0]; }
  { Top_hub_mem_req_data_arb__io_lock_0.values[0] = Top_hub_XactTracker__io_mem_req_lock.values[0]; }
  { Top_hub_XactTracker_1__io_p_rep_tile_id.values[0] = Top_hub_XactTracker_1__p_rep_tile_id_.values[0]; }
  { T95.values[0] = Top_hub_XactTracker_1__io_p_rep_tile_id.values[0]; }
  { T96.values[0] = T95.values[0]; }
  T97.values[0] = 0x1L << T96.values[0];
  { T98.values[0] = T97.values[0]; }
  T98.values[0] = T98.values[0] & 3;
  T99.values[0] = (T98.values[0] >> 1) & 1;
  { T100.values[0] = T99.values[0]; }
  { T101.values[0] = Top_hub__io_tiles_1_probe_rep_data_valid.values[0]&T100.values[0]; }
  T102.values[0] = (T98.values[0] >> 0) & 1;
  { T103.values[0] = T102.values[0]; }
  { T104.values[0] = Top_hub__io_tiles_0_probe_rep_data_valid.values[0]&T103.values[0]; }
  { T105.values[0] = T104.values[0]|T101.values[0]; }
  { Top_hub_XactTracker_1__io_p_rep_data_valid.values[0] = T105.values[0]; }
  { T106.values[0] = Top_hub_XactTracker_1__io_p_rep_data_valid.values[0]||Top_hub_XactTracker_1__p_w_mem_cmd_sent.values[0]; }
  T107.values[0] = Top_hub_XactTracker_1__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T107.values[0]; T108.values[0] = Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_2__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T109.values[0] = T108.values[0]; }
  T109.values[0] = T109.values[0] & 7;
  T110.values[0] = Top_hub_XactTracker_1__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T110.values[0]; T111.values[0] = T109.values[0] ^ ((T109.values[0] ^ Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T112.values[0] = T111.values[0]; }
  T112.values[0] = T112.values[0] & 7;
  { Top_hub_XactTracker_1__io_p_rep_data_dep_bits_global_xact_id.values[0] = T112.values[0]; }
  T113.values[0] = Top_hub_XactTracker_1__io_p_rep_data_dep_bits_global_xact_id.values[0] == 0x1L;
  T114.values[0] = Top_hub_XactTracker_1__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T114.values[0]; T115.values[0] = Top_hub_Queue_1__io_deq_valid.values[0] ^ ((Top_hub_Queue_1__io_deq_valid.values[0] ^ Top_hub_Queue_2__io_deq_valid.values[0]) & __mask); }
  T116.values[0] = Top_hub_XactTracker_1__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T116.values[0]; T117.values[0] = T115.values[0] ^ ((T115.values[0] ^ Top_hub_Queue_1__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_1__io_p_rep_data_dep_valid.values[0] = T117.values[0]; }
  { T118.values[0] = Top_hub_XactTracker_1__io_p_rep_data_dep_valid.values[0]&&T113.values[0]; }
  T119.values[0] = Top_hub_XactTracker_1__state.values[0] == 0x2L;
  { T120.values[0] = T119.values[0]&&Top_hub_XactTracker_1__p_rep_data_needs_write.values[0]; }
  { T121.values[0] = T120.values[0]&&T118.values[0]; }
  { val_t __mask = -T121.values[0]; T122.values[0] = 0x0L ^ ((0x0L ^ T106.values[0]) & __mask); }
  { Top_hub_XactTracker_1__io_init_tile_id.values[0] = Top_hub_XactTracker_1__init_tile_id_.values[0]; }
  { T123.values[0] = Top_hub_XactTracker_1__io_init_tile_id.values[0]; }
  { T124.values[0] = T123.values[0]; }
  T125.values[0] = 0x1L << T124.values[0];
  { T126.values[0] = T125.values[0]; }
  T126.values[0] = T126.values[0] & 3;
  T127.values[0] = (T126.values[0] >> 1) & 1;
  { T128.values[0] = T127.values[0]; }
  { T129.values[0] = Top_hub__io_tiles_1_xact_init_data_valid.values[0]&T128.values[0]; }
  T130.values[0] = (T126.values[0] >> 0) & 1;
  { T131.values[0] = T130.values[0]; }
  { T132.values[0] = Top_hub__io_tiles_0_xact_init_data_valid.values[0]&T131.values[0]; }
  { T133.values[0] = T132.values[0]|T129.values[0]; }
  { Top_hub_XactTracker_1__io_x_init_data_valid.values[0] = T133.values[0]; }
  { T134.values[0] = Top_hub_XactTracker_1__io_x_init_data_valid.values[0]||Top_hub_XactTracker_1__x_w_mem_cmd_sent.values[0]; }
  T135.values[0] = Top_hub_XactTracker_1__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T135.values[0]; T136.values[0] = Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_4__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T137.values[0] = T136.values[0]; }
  T137.values[0] = T137.values[0] & 7;
  T138.values[0] = Top_hub_XactTracker_1__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T138.values[0]; T139.values[0] = T137.values[0] ^ ((T137.values[0] ^ Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T140.values[0] = T139.values[0]; }
  T140.values[0] = T140.values[0] & 7;
  { Top_hub_XactTracker_1__io_x_init_data_dep_bits_global_xact_id.values[0] = T140.values[0]; }
  T141.values[0] = Top_hub_XactTracker_1__io_x_init_data_dep_bits_global_xact_id.values[0] == 0x1L;
  T142.values[0] = Top_hub_XactTracker_1__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T142.values[0]; T143.values[0] = Top_hub_Queue_3__io_deq_valid.values[0] ^ ((Top_hub_Queue_3__io_deq_valid.values[0] ^ Top_hub_Queue_4__io_deq_valid.values[0]) & __mask); }
  T144.values[0] = Top_hub_XactTracker_1__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T144.values[0]; T145.values[0] = T143.values[0] ^ ((T143.values[0] ^ Top_hub_Queue_3__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_1__io_x_init_data_dep_valid.values[0] = T145.values[0]; }
  { T146.values[0] = Top_hub_XactTracker_1__io_x_init_data_dep_valid.values[0]&&T141.values[0]; }
  T147.values[0] = !Top_hub_XactTracker_1__p_rep_data_needs_write.values[0];
  { T148.values[0] = T147.values[0]&&Top_hub_XactTracker_1__x_init_data_needs_write.values[0]; }
  { T149.values[0] = T119.values[0]&&T148.values[0]; }
  { T150.values[0] = T149.values[0]&&T146.values[0]; }
  { val_t __mask = -T150.values[0]; T151.values[0] = T122.values[0] ^ ((T122.values[0] ^ T134.values[0]) & __mask); }
  { Top_hub_XactTracker_1__io_mem_req_lock.values[0] = T151.values[0]; }
  { Top_hub_mem_req_data_arb__io_lock_1.values[0] = Top_hub_XactTracker_1__io_mem_req_lock.values[0]; }
  { Top_hub_XactTracker_2__io_p_rep_tile_id.values[0] = Top_hub_XactTracker_2__p_rep_tile_id_.values[0]; }
  { T152.values[0] = Top_hub_XactTracker_2__io_p_rep_tile_id.values[0]; }
  { T153.values[0] = T152.values[0]; }
  T154.values[0] = 0x1L << T153.values[0];
  { T155.values[0] = T154.values[0]; }
  T155.values[0] = T155.values[0] & 3;
  T156.values[0] = (T155.values[0] >> 1) & 1;
  { T157.values[0] = T156.values[0]; }
  { T158.values[0] = Top_hub__io_tiles_1_probe_rep_data_valid.values[0]&T157.values[0]; }
  T159.values[0] = (T155.values[0] >> 0) & 1;
  { T160.values[0] = T159.values[0]; }
  { T161.values[0] = Top_hub__io_tiles_0_probe_rep_data_valid.values[0]&T160.values[0]; }
  { T162.values[0] = T161.values[0]|T158.values[0]; }
  { Top_hub_XactTracker_2__io_p_rep_data_valid.values[0] = T162.values[0]; }
  { T163.values[0] = Top_hub_XactTracker_2__io_p_rep_data_valid.values[0]||Top_hub_XactTracker_2__p_w_mem_cmd_sent.values[0]; }
  T164.values[0] = Top_hub_XactTracker_2__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T164.values[0]; T165.values[0] = Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_2__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T166.values[0] = T165.values[0]; }
  T166.values[0] = T166.values[0] & 7;
  T167.values[0] = Top_hub_XactTracker_2__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T167.values[0]; T168.values[0] = T166.values[0] ^ ((T166.values[0] ^ Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T169.values[0] = T168.values[0]; }
  T169.values[0] = T169.values[0] & 7;
  { Top_hub_XactTracker_2__io_p_rep_data_dep_bits_global_xact_id.values[0] = T169.values[0]; }
  T170.values[0] = Top_hub_XactTracker_2__io_p_rep_data_dep_bits_global_xact_id.values[0] == 0x2L;
  T171.values[0] = Top_hub_XactTracker_2__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T171.values[0]; T172.values[0] = Top_hub_Queue_1__io_deq_valid.values[0] ^ ((Top_hub_Queue_1__io_deq_valid.values[0] ^ Top_hub_Queue_2__io_deq_valid.values[0]) & __mask); }
  T173.values[0] = Top_hub_XactTracker_2__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T173.values[0]; T174.values[0] = T172.values[0] ^ ((T172.values[0] ^ Top_hub_Queue_1__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_2__io_p_rep_data_dep_valid.values[0] = T174.values[0]; }
  { T175.values[0] = Top_hub_XactTracker_2__io_p_rep_data_dep_valid.values[0]&&T170.values[0]; }
  T176.values[0] = Top_hub_XactTracker_2__state.values[0] == 0x2L;
  { T177.values[0] = T176.values[0]&&Top_hub_XactTracker_2__p_rep_data_needs_write.values[0]; }
  { T178.values[0] = T177.values[0]&&T175.values[0]; }
  { val_t __mask = -T178.values[0]; T179.values[0] = 0x0L ^ ((0x0L ^ T163.values[0]) & __mask); }
  { Top_hub_XactTracker_2__io_init_tile_id.values[0] = Top_hub_XactTracker_2__init_tile_id_.values[0]; }
  { T180.values[0] = Top_hub_XactTracker_2__io_init_tile_id.values[0]; }
  { T181.values[0] = T180.values[0]; }
  T182.values[0] = 0x1L << T181.values[0];
  { T183.values[0] = T182.values[0]; }
  T183.values[0] = T183.values[0] & 3;
  T184.values[0] = (T183.values[0] >> 1) & 1;
  { T185.values[0] = T184.values[0]; }
  { T186.values[0] = Top_hub__io_tiles_1_xact_init_data_valid.values[0]&T185.values[0]; }
  T187.values[0] = (T183.values[0] >> 0) & 1;
  { T188.values[0] = T187.values[0]; }
  { T189.values[0] = Top_hub__io_tiles_0_xact_init_data_valid.values[0]&T188.values[0]; }
  { T190.values[0] = T189.values[0]|T186.values[0]; }
  { Top_hub_XactTracker_2__io_x_init_data_valid.values[0] = T190.values[0]; }
  { T191.values[0] = Top_hub_XactTracker_2__io_x_init_data_valid.values[0]||Top_hub_XactTracker_2__x_w_mem_cmd_sent.values[0]; }
  T192.values[0] = Top_hub_XactTracker_2__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T192.values[0]; T193.values[0] = Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_4__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T194.values[0] = T193.values[0]; }
  T194.values[0] = T194.values[0] & 7;
  T195.values[0] = Top_hub_XactTracker_2__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T195.values[0]; T196.values[0] = T194.values[0] ^ ((T194.values[0] ^ Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T197.values[0] = T196.values[0]; }
  T197.values[0] = T197.values[0] & 7;
  { Top_hub_XactTracker_2__io_x_init_data_dep_bits_global_xact_id.values[0] = T197.values[0]; }
  T198.values[0] = Top_hub_XactTracker_2__io_x_init_data_dep_bits_global_xact_id.values[0] == 0x2L;
  T199.values[0] = Top_hub_XactTracker_2__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T199.values[0]; T200.values[0] = Top_hub_Queue_3__io_deq_valid.values[0] ^ ((Top_hub_Queue_3__io_deq_valid.values[0] ^ Top_hub_Queue_4__io_deq_valid.values[0]) & __mask); }
  T201.values[0] = Top_hub_XactTracker_2__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T201.values[0]; T202.values[0] = T200.values[0] ^ ((T200.values[0] ^ Top_hub_Queue_3__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_2__io_x_init_data_dep_valid.values[0] = T202.values[0]; }
  { T203.values[0] = Top_hub_XactTracker_2__io_x_init_data_dep_valid.values[0]&&T198.values[0]; }
  T204.values[0] = !Top_hub_XactTracker_2__p_rep_data_needs_write.values[0];
  { T205.values[0] = T204.values[0]&&Top_hub_XactTracker_2__x_init_data_needs_write.values[0]; }
  { T206.values[0] = T176.values[0]&&T205.values[0]; }
  { T207.values[0] = T206.values[0]&&T203.values[0]; }
  { val_t __mask = -T207.values[0]; T208.values[0] = T179.values[0] ^ ((T179.values[0] ^ T191.values[0]) & __mask); }
  { Top_hub_XactTracker_2__io_mem_req_lock.values[0] = T208.values[0]; }
  { Top_hub_mem_req_data_arb__io_lock_2.values[0] = Top_hub_XactTracker_2__io_mem_req_lock.values[0]; }
  { Top_hub_XactTracker_3__io_p_rep_tile_id.values[0] = Top_hub_XactTracker_3__p_rep_tile_id_.values[0]; }
  { T209.values[0] = Top_hub_XactTracker_3__io_p_rep_tile_id.values[0]; }
  { T210.values[0] = T209.values[0]; }
  T211.values[0] = 0x1L << T210.values[0];
  { T212.values[0] = T211.values[0]; }
  T212.values[0] = T212.values[0] & 3;
  T213.values[0] = (T212.values[0] >> 1) & 1;
  { T214.values[0] = T213.values[0]; }
  { T215.values[0] = Top_hub__io_tiles_1_probe_rep_data_valid.values[0]&T214.values[0]; }
  T216.values[0] = (T212.values[0] >> 0) & 1;
  { T217.values[0] = T216.values[0]; }
  { T218.values[0] = Top_hub__io_tiles_0_probe_rep_data_valid.values[0]&T217.values[0]; }
  { T219.values[0] = T218.values[0]|T215.values[0]; }
  { Top_hub_XactTracker_3__io_p_rep_data_valid.values[0] = T219.values[0]; }
  { T220.values[0] = Top_hub_XactTracker_3__io_p_rep_data_valid.values[0]||Top_hub_XactTracker_3__p_w_mem_cmd_sent.values[0]; }
  T221.values[0] = Top_hub_XactTracker_3__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T221.values[0]; T222.values[0] = Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_2__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T223.values[0] = T222.values[0]; }
  T223.values[0] = T223.values[0] & 7;
  T224.values[0] = Top_hub_XactTracker_3__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T224.values[0]; T225.values[0] = T223.values[0] ^ ((T223.values[0] ^ Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T226.values[0] = T225.values[0]; }
  T226.values[0] = T226.values[0] & 7;
  { Top_hub_XactTracker_3__io_p_rep_data_dep_bits_global_xact_id.values[0] = T226.values[0]; }
  T227.values[0] = Top_hub_XactTracker_3__io_p_rep_data_dep_bits_global_xact_id.values[0] == 0x3L;
  T228.values[0] = Top_hub_XactTracker_3__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T228.values[0]; T229.values[0] = Top_hub_Queue_1__io_deq_valid.values[0] ^ ((Top_hub_Queue_1__io_deq_valid.values[0] ^ Top_hub_Queue_2__io_deq_valid.values[0]) & __mask); }
  T230.values[0] = Top_hub_XactTracker_3__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T230.values[0]; T231.values[0] = T229.values[0] ^ ((T229.values[0] ^ Top_hub_Queue_1__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_3__io_p_rep_data_dep_valid.values[0] = T231.values[0]; }
  { T232.values[0] = Top_hub_XactTracker_3__io_p_rep_data_dep_valid.values[0]&&T227.values[0]; }
  T233.values[0] = Top_hub_XactTracker_3__state.values[0] == 0x2L;
  { T234.values[0] = T233.values[0]&&Top_hub_XactTracker_3__p_rep_data_needs_write.values[0]; }
  { T235.values[0] = T234.values[0]&&T232.values[0]; }
  { val_t __mask = -T235.values[0]; T236.values[0] = 0x0L ^ ((0x0L ^ T220.values[0]) & __mask); }
  { Top_hub_XactTracker_3__io_init_tile_id.values[0] = Top_hub_XactTracker_3__init_tile_id_.values[0]; }
  { T237.values[0] = Top_hub_XactTracker_3__io_init_tile_id.values[0]; }
  { T238.values[0] = T237.values[0]; }
  T239.values[0] = 0x1L << T238.values[0];
  { T240.values[0] = T239.values[0]; }
  T240.values[0] = T240.values[0] & 3;
  T241.values[0] = (T240.values[0] >> 1) & 1;
  { T242.values[0] = T241.values[0]; }
  { T243.values[0] = Top_hub__io_tiles_1_xact_init_data_valid.values[0]&T242.values[0]; }
  T244.values[0] = (T240.values[0] >> 0) & 1;
  { T245.values[0] = T244.values[0]; }
  { T246.values[0] = Top_hub__io_tiles_0_xact_init_data_valid.values[0]&T245.values[0]; }
  { T247.values[0] = T246.values[0]|T243.values[0]; }
  { Top_hub_XactTracker_3__io_x_init_data_valid.values[0] = T247.values[0]; }
  { T248.values[0] = Top_hub_XactTracker_3__io_x_init_data_valid.values[0]||Top_hub_XactTracker_3__x_w_mem_cmd_sent.values[0]; }
  T249.values[0] = Top_hub_XactTracker_3__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T249.values[0]; T250.values[0] = Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_4__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T251.values[0] = T250.values[0]; }
  T251.values[0] = T251.values[0] & 7;
  T252.values[0] = Top_hub_XactTracker_3__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T252.values[0]; T253.values[0] = T251.values[0] ^ ((T251.values[0] ^ Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T254.values[0] = T253.values[0]; }
  T254.values[0] = T254.values[0] & 7;
  { Top_hub_XactTracker_3__io_x_init_data_dep_bits_global_xact_id.values[0] = T254.values[0]; }
  T255.values[0] = Top_hub_XactTracker_3__io_x_init_data_dep_bits_global_xact_id.values[0] == 0x3L;
  T256.values[0] = Top_hub_XactTracker_3__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T256.values[0]; T257.values[0] = Top_hub_Queue_3__io_deq_valid.values[0] ^ ((Top_hub_Queue_3__io_deq_valid.values[0] ^ Top_hub_Queue_4__io_deq_valid.values[0]) & __mask); }
  T258.values[0] = Top_hub_XactTracker_3__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T258.values[0]; T259.values[0] = T257.values[0] ^ ((T257.values[0] ^ Top_hub_Queue_3__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_3__io_x_init_data_dep_valid.values[0] = T259.values[0]; }
  { T260.values[0] = Top_hub_XactTracker_3__io_x_init_data_dep_valid.values[0]&&T255.values[0]; }
  T261.values[0] = !Top_hub_XactTracker_3__p_rep_data_needs_write.values[0];
  { T262.values[0] = T261.values[0]&&Top_hub_XactTracker_3__x_init_data_needs_write.values[0]; }
  { T263.values[0] = T233.values[0]&&T262.values[0]; }
  { T264.values[0] = T263.values[0]&&T260.values[0]; }
  { val_t __mask = -T264.values[0]; T265.values[0] = T236.values[0] ^ ((T236.values[0] ^ T248.values[0]) & __mask); }
  { Top_hub_XactTracker_3__io_mem_req_lock.values[0] = T265.values[0]; }
  { Top_hub_mem_req_data_arb__io_lock_3.values[0] = Top_hub_XactTracker_3__io_mem_req_lock.values[0]; }
  { Top_hub_XactTracker_4__io_p_rep_tile_id.values[0] = Top_hub_XactTracker_4__p_rep_tile_id_.values[0]; }
  { T266.values[0] = Top_hub_XactTracker_4__io_p_rep_tile_id.values[0]; }
  { T267.values[0] = T266.values[0]; }
  T268.values[0] = 0x1L << T267.values[0];
  { T269.values[0] = T268.values[0]; }
  T269.values[0] = T269.values[0] & 3;
  T270.values[0] = (T269.values[0] >> 1) & 1;
  { T271.values[0] = T270.values[0]; }
  { T272.values[0] = Top_hub__io_tiles_1_probe_rep_data_valid.values[0]&T271.values[0]; }
  T273.values[0] = (T269.values[0] >> 0) & 1;
  { T274.values[0] = T273.values[0]; }
  { T275.values[0] = Top_hub__io_tiles_0_probe_rep_data_valid.values[0]&T274.values[0]; }
  { T276.values[0] = T275.values[0]|T272.values[0]; }
  { Top_hub_XactTracker_4__io_p_rep_data_valid.values[0] = T276.values[0]; }
  { T277.values[0] = Top_hub_XactTracker_4__io_p_rep_data_valid.values[0]||Top_hub_XactTracker_4__p_w_mem_cmd_sent.values[0]; }
  T278.values[0] = Top_hub_XactTracker_4__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T278.values[0]; T279.values[0] = Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_2__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T280.values[0] = T279.values[0]; }
  T280.values[0] = T280.values[0] & 7;
  T281.values[0] = Top_hub_XactTracker_4__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T281.values[0]; T282.values[0] = T280.values[0] ^ ((T280.values[0] ^ Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T283.values[0] = T282.values[0]; }
  T283.values[0] = T283.values[0] & 7;
  { Top_hub_XactTracker_4__io_p_rep_data_dep_bits_global_xact_id.values[0] = T283.values[0]; }
  T284.values[0] = Top_hub_XactTracker_4__io_p_rep_data_dep_bits_global_xact_id.values[0] == 0x4L;
  T285.values[0] = Top_hub_XactTracker_4__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T285.values[0]; T286.values[0] = Top_hub_Queue_1__io_deq_valid.values[0] ^ ((Top_hub_Queue_1__io_deq_valid.values[0] ^ Top_hub_Queue_2__io_deq_valid.values[0]) & __mask); }
  T287.values[0] = Top_hub_XactTracker_4__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T287.values[0]; T288.values[0] = T286.values[0] ^ ((T286.values[0] ^ Top_hub_Queue_1__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_4__io_p_rep_data_dep_valid.values[0] = T288.values[0]; }
  { T289.values[0] = Top_hub_XactTracker_4__io_p_rep_data_dep_valid.values[0]&&T284.values[0]; }
  T290.values[0] = Top_hub_XactTracker_4__state.values[0] == 0x2L;
  { T291.values[0] = T290.values[0]&&Top_hub_XactTracker_4__p_rep_data_needs_write.values[0]; }
  { T292.values[0] = T291.values[0]&&T289.values[0]; }
  { val_t __mask = -T292.values[0]; T293.values[0] = 0x0L ^ ((0x0L ^ T277.values[0]) & __mask); }
  { Top_hub_XactTracker_4__io_init_tile_id.values[0] = Top_hub_XactTracker_4__init_tile_id_.values[0]; }
  { T294.values[0] = Top_hub_XactTracker_4__io_init_tile_id.values[0]; }
  { T295.values[0] = T294.values[0]; }
  T296.values[0] = 0x1L << T295.values[0];
  { T297.values[0] = T296.values[0]; }
  T297.values[0] = T297.values[0] & 3;
  T298.values[0] = (T297.values[0] >> 1) & 1;
  { T299.values[0] = T298.values[0]; }
  { T300.values[0] = Top_hub__io_tiles_1_xact_init_data_valid.values[0]&T299.values[0]; }
  T301.values[0] = (T297.values[0] >> 0) & 1;
  { T302.values[0] = T301.values[0]; }
  { T303.values[0] = Top_hub__io_tiles_0_xact_init_data_valid.values[0]&T302.values[0]; }
  { T304.values[0] = T303.values[0]|T300.values[0]; }
  { Top_hub_XactTracker_4__io_x_init_data_valid.values[0] = T304.values[0]; }
  { T305.values[0] = Top_hub_XactTracker_4__io_x_init_data_valid.values[0]||Top_hub_XactTracker_4__x_w_mem_cmd_sent.values[0]; }
  T306.values[0] = Top_hub_XactTracker_4__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T306.values[0]; T307.values[0] = Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_4__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T308.values[0] = T307.values[0]; }
  T308.values[0] = T308.values[0] & 7;
  T309.values[0] = Top_hub_XactTracker_4__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T309.values[0]; T310.values[0] = T308.values[0] ^ ((T308.values[0] ^ Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T311.values[0] = T310.values[0]; }
  T311.values[0] = T311.values[0] & 7;
  { Top_hub_XactTracker_4__io_x_init_data_dep_bits_global_xact_id.values[0] = T311.values[0]; }
  T312.values[0] = Top_hub_XactTracker_4__io_x_init_data_dep_bits_global_xact_id.values[0] == 0x4L;
  T313.values[0] = Top_hub_XactTracker_4__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T313.values[0]; T314.values[0] = Top_hub_Queue_3__io_deq_valid.values[0] ^ ((Top_hub_Queue_3__io_deq_valid.values[0] ^ Top_hub_Queue_4__io_deq_valid.values[0]) & __mask); }
  T315.values[0] = Top_hub_XactTracker_4__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T315.values[0]; T316.values[0] = T314.values[0] ^ ((T314.values[0] ^ Top_hub_Queue_3__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_4__io_x_init_data_dep_valid.values[0] = T316.values[0]; }
  { T317.values[0] = Top_hub_XactTracker_4__io_x_init_data_dep_valid.values[0]&&T312.values[0]; }
  T318.values[0] = !Top_hub_XactTracker_4__p_rep_data_needs_write.values[0];
  { T319.values[0] = T318.values[0]&&Top_hub_XactTracker_4__x_init_data_needs_write.values[0]; }
  { T320.values[0] = T290.values[0]&&T319.values[0]; }
  { T321.values[0] = T320.values[0]&&T317.values[0]; }
  { val_t __mask = -T321.values[0]; T322.values[0] = T293.values[0] ^ ((T293.values[0] ^ T305.values[0]) & __mask); }
  { Top_hub_XactTracker_4__io_mem_req_lock.values[0] = T322.values[0]; }
  { Top_hub_mem_req_data_arb__io_lock_4.values[0] = Top_hub_XactTracker_4__io_mem_req_lock.values[0]; }
  { Top_hub_XactTracker_5__io_p_rep_tile_id.values[0] = Top_hub_XactTracker_5__p_rep_tile_id_.values[0]; }
  { T323.values[0] = Top_hub_XactTracker_5__io_p_rep_tile_id.values[0]; }
  { T324.values[0] = T323.values[0]; }
  T325.values[0] = 0x1L << T324.values[0];
  { T326.values[0] = T325.values[0]; }
  T326.values[0] = T326.values[0] & 3;
  T327.values[0] = (T326.values[0] >> 1) & 1;
  { T328.values[0] = T327.values[0]; }
  { T329.values[0] = Top_hub__io_tiles_1_probe_rep_data_valid.values[0]&T328.values[0]; }
  T330.values[0] = (T326.values[0] >> 0) & 1;
  { T331.values[0] = T330.values[0]; }
  { T332.values[0] = Top_hub__io_tiles_0_probe_rep_data_valid.values[0]&T331.values[0]; }
  { T333.values[0] = T332.values[0]|T329.values[0]; }
  { Top_hub_XactTracker_5__io_p_rep_data_valid.values[0] = T333.values[0]; }
  { T334.values[0] = Top_hub_XactTracker_5__io_p_rep_data_valid.values[0]||Top_hub_XactTracker_5__p_w_mem_cmd_sent.values[0]; }
  T335.values[0] = Top_hub_XactTracker_5__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T335.values[0]; T336.values[0] = Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_2__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T337.values[0] = T336.values[0]; }
  T337.values[0] = T337.values[0] & 7;
  T338.values[0] = Top_hub_XactTracker_5__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T338.values[0]; T339.values[0] = T337.values[0] ^ ((T337.values[0] ^ Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T340.values[0] = T339.values[0]; }
  T340.values[0] = T340.values[0] & 7;
  { Top_hub_XactTracker_5__io_p_rep_data_dep_bits_global_xact_id.values[0] = T340.values[0]; }
  T341.values[0] = Top_hub_XactTracker_5__io_p_rep_data_dep_bits_global_xact_id.values[0] == 0x5L;
  T342.values[0] = Top_hub_XactTracker_5__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T342.values[0]; T343.values[0] = Top_hub_Queue_1__io_deq_valid.values[0] ^ ((Top_hub_Queue_1__io_deq_valid.values[0] ^ Top_hub_Queue_2__io_deq_valid.values[0]) & __mask); }
  T344.values[0] = Top_hub_XactTracker_5__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T344.values[0]; T345.values[0] = T343.values[0] ^ ((T343.values[0] ^ Top_hub_Queue_1__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_5__io_p_rep_data_dep_valid.values[0] = T345.values[0]; }
  { T346.values[0] = Top_hub_XactTracker_5__io_p_rep_data_dep_valid.values[0]&&T341.values[0]; }
  T347.values[0] = Top_hub_XactTracker_5__state.values[0] == 0x2L;
  { T348.values[0] = T347.values[0]&&Top_hub_XactTracker_5__p_rep_data_needs_write.values[0]; }
  { T349.values[0] = T348.values[0]&&T346.values[0]; }
  { val_t __mask = -T349.values[0]; T350.values[0] = 0x0L ^ ((0x0L ^ T334.values[0]) & __mask); }
  { Top_hub_XactTracker_5__io_init_tile_id.values[0] = Top_hub_XactTracker_5__init_tile_id_.values[0]; }
  { T351.values[0] = Top_hub_XactTracker_5__io_init_tile_id.values[0]; }
  { T352.values[0] = T351.values[0]; }
  T353.values[0] = 0x1L << T352.values[0];
  { T354.values[0] = T353.values[0]; }
  T354.values[0] = T354.values[0] & 3;
  T355.values[0] = (T354.values[0] >> 1) & 1;
  { T356.values[0] = T355.values[0]; }
  { T357.values[0] = Top_hub__io_tiles_1_xact_init_data_valid.values[0]&T356.values[0]; }
  T358.values[0] = (T354.values[0] >> 0) & 1;
  { T359.values[0] = T358.values[0]; }
  { T360.values[0] = Top_hub__io_tiles_0_xact_init_data_valid.values[0]&T359.values[0]; }
  { T361.values[0] = T360.values[0]|T357.values[0]; }
  { Top_hub_XactTracker_5__io_x_init_data_valid.values[0] = T361.values[0]; }
  { T362.values[0] = Top_hub_XactTracker_5__io_x_init_data_valid.values[0]||Top_hub_XactTracker_5__x_w_mem_cmd_sent.values[0]; }
  T363.values[0] = Top_hub_XactTracker_5__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T363.values[0]; T364.values[0] = Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_4__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T365.values[0] = T364.values[0]; }
  T365.values[0] = T365.values[0] & 7;
  T366.values[0] = Top_hub_XactTracker_5__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T366.values[0]; T367.values[0] = T365.values[0] ^ ((T365.values[0] ^ Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T368.values[0] = T367.values[0]; }
  T368.values[0] = T368.values[0] & 7;
  { Top_hub_XactTracker_5__io_x_init_data_dep_bits_global_xact_id.values[0] = T368.values[0]; }
  T369.values[0] = Top_hub_XactTracker_5__io_x_init_data_dep_bits_global_xact_id.values[0] == 0x5L;
  T370.values[0] = Top_hub_XactTracker_5__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T370.values[0]; T371.values[0] = Top_hub_Queue_3__io_deq_valid.values[0] ^ ((Top_hub_Queue_3__io_deq_valid.values[0] ^ Top_hub_Queue_4__io_deq_valid.values[0]) & __mask); }
  T372.values[0] = Top_hub_XactTracker_5__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T372.values[0]; T373.values[0] = T371.values[0] ^ ((T371.values[0] ^ Top_hub_Queue_3__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_5__io_x_init_data_dep_valid.values[0] = T373.values[0]; }
  { T374.values[0] = Top_hub_XactTracker_5__io_x_init_data_dep_valid.values[0]&&T369.values[0]; }
  T375.values[0] = !Top_hub_XactTracker_5__p_rep_data_needs_write.values[0];
  { T376.values[0] = T375.values[0]&&Top_hub_XactTracker_5__x_init_data_needs_write.values[0]; }
  { T377.values[0] = T347.values[0]&&T376.values[0]; }
  { T378.values[0] = T377.values[0]&&T374.values[0]; }
  { val_t __mask = -T378.values[0]; T379.values[0] = T350.values[0] ^ ((T350.values[0] ^ T362.values[0]) & __mask); }
  { Top_hub_XactTracker_5__io_mem_req_lock.values[0] = T379.values[0]; }
  { Top_hub_mem_req_data_arb__io_lock_5.values[0] = Top_hub_XactTracker_5__io_mem_req_lock.values[0]; }
  { Top_hub_XactTracker_6__io_p_rep_tile_id.values[0] = Top_hub_XactTracker_6__p_rep_tile_id_.values[0]; }
  { T380.values[0] = Top_hub_XactTracker_6__io_p_rep_tile_id.values[0]; }
  { T381.values[0] = T380.values[0]; }
  T382.values[0] = 0x1L << T381.values[0];
  { T383.values[0] = T382.values[0]; }
  T383.values[0] = T383.values[0] & 3;
  T384.values[0] = (T383.values[0] >> 1) & 1;
  { T385.values[0] = T384.values[0]; }
  { T386.values[0] = Top_hub__io_tiles_1_probe_rep_data_valid.values[0]&T385.values[0]; }
  T387.values[0] = (T383.values[0] >> 0) & 1;
  { T388.values[0] = T387.values[0]; }
  { T389.values[0] = Top_hub__io_tiles_0_probe_rep_data_valid.values[0]&T388.values[0]; }
  { T390.values[0] = T389.values[0]|T386.values[0]; }
  { Top_hub_XactTracker_6__io_p_rep_data_valid.values[0] = T390.values[0]; }
  { T391.values[0] = Top_hub_XactTracker_6__io_p_rep_data_valid.values[0]||Top_hub_XactTracker_6__p_w_mem_cmd_sent.values[0]; }
  T392.values[0] = Top_hub_XactTracker_6__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T392.values[0]; T393.values[0] = Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_2__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T394.values[0] = T393.values[0]; }
  T394.values[0] = T394.values[0] & 7;
  T395.values[0] = Top_hub_XactTracker_6__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T395.values[0]; T396.values[0] = T394.values[0] ^ ((T394.values[0] ^ Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T397.values[0] = T396.values[0]; }
  T397.values[0] = T397.values[0] & 7;
  { Top_hub_XactTracker_6__io_p_rep_data_dep_bits_global_xact_id.values[0] = T397.values[0]; }
  T398.values[0] = Top_hub_XactTracker_6__io_p_rep_data_dep_bits_global_xact_id.values[0] == 0x6L;
  T399.values[0] = Top_hub_XactTracker_6__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T399.values[0]; T400.values[0] = Top_hub_Queue_1__io_deq_valid.values[0] ^ ((Top_hub_Queue_1__io_deq_valid.values[0] ^ Top_hub_Queue_2__io_deq_valid.values[0]) & __mask); }
  T401.values[0] = Top_hub_XactTracker_6__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T401.values[0]; T402.values[0] = T400.values[0] ^ ((T400.values[0] ^ Top_hub_Queue_1__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_6__io_p_rep_data_dep_valid.values[0] = T402.values[0]; }
  { T403.values[0] = Top_hub_XactTracker_6__io_p_rep_data_dep_valid.values[0]&&T398.values[0]; }
  T404.values[0] = Top_hub_XactTracker_6__state.values[0] == 0x2L;
  { T405.values[0] = T404.values[0]&&Top_hub_XactTracker_6__p_rep_data_needs_write.values[0]; }
  { T406.values[0] = T405.values[0]&&T403.values[0]; }
  { val_t __mask = -T406.values[0]; T407.values[0] = 0x0L ^ ((0x0L ^ T391.values[0]) & __mask); }
  { Top_hub_XactTracker_6__io_init_tile_id.values[0] = Top_hub_XactTracker_6__init_tile_id_.values[0]; }
  { T408.values[0] = Top_hub_XactTracker_6__io_init_tile_id.values[0]; }
  { T409.values[0] = T408.values[0]; }
  T410.values[0] = 0x1L << T409.values[0];
  { T411.values[0] = T410.values[0]; }
  T411.values[0] = T411.values[0] & 3;
  T412.values[0] = (T411.values[0] >> 1) & 1;
  { T413.values[0] = T412.values[0]; }
  { T414.values[0] = Top_hub__io_tiles_1_xact_init_data_valid.values[0]&T413.values[0]; }
  T415.values[0] = (T411.values[0] >> 0) & 1;
  { T416.values[0] = T415.values[0]; }
  { T417.values[0] = Top_hub__io_tiles_0_xact_init_data_valid.values[0]&T416.values[0]; }
  { T418.values[0] = T417.values[0]|T414.values[0]; }
  { Top_hub_XactTracker_6__io_x_init_data_valid.values[0] = T418.values[0]; }
  { T419.values[0] = Top_hub_XactTracker_6__io_x_init_data_valid.values[0]||Top_hub_XactTracker_6__x_w_mem_cmd_sent.values[0]; }
  T420.values[0] = Top_hub_XactTracker_6__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T420.values[0]; T421.values[0] = Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_4__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T422.values[0] = T421.values[0]; }
  T422.values[0] = T422.values[0] & 7;
  T423.values[0] = Top_hub_XactTracker_6__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T423.values[0]; T424.values[0] = T422.values[0] ^ ((T422.values[0] ^ Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T425.values[0] = T424.values[0]; }
  T425.values[0] = T425.values[0] & 7;
  { Top_hub_XactTracker_6__io_x_init_data_dep_bits_global_xact_id.values[0] = T425.values[0]; }
  T426.values[0] = Top_hub_XactTracker_6__io_x_init_data_dep_bits_global_xact_id.values[0] == 0x6L;
  T427.values[0] = Top_hub_XactTracker_6__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T427.values[0]; T428.values[0] = Top_hub_Queue_3__io_deq_valid.values[0] ^ ((Top_hub_Queue_3__io_deq_valid.values[0] ^ Top_hub_Queue_4__io_deq_valid.values[0]) & __mask); }
  T429.values[0] = Top_hub_XactTracker_6__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T429.values[0]; T430.values[0] = T428.values[0] ^ ((T428.values[0] ^ Top_hub_Queue_3__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_6__io_x_init_data_dep_valid.values[0] = T430.values[0]; }
  { T431.values[0] = Top_hub_XactTracker_6__io_x_init_data_dep_valid.values[0]&&T426.values[0]; }
  T432.values[0] = !Top_hub_XactTracker_6__p_rep_data_needs_write.values[0];
  { T433.values[0] = T432.values[0]&&Top_hub_XactTracker_6__x_init_data_needs_write.values[0]; }
  { T434.values[0] = T404.values[0]&&T433.values[0]; }
  { T435.values[0] = T434.values[0]&&T431.values[0]; }
  { val_t __mask = -T435.values[0]; T436.values[0] = T407.values[0] ^ ((T407.values[0] ^ T419.values[0]) & __mask); }
  { Top_hub_XactTracker_6__io_mem_req_lock.values[0] = T436.values[0]; }
  { Top_hub_mem_req_data_arb__io_lock_6.values[0] = Top_hub_XactTracker_6__io_mem_req_lock.values[0]; }
  { Top_hub_XactTracker_7__io_p_rep_tile_id.values[0] = Top_hub_XactTracker_7__p_rep_tile_id_.values[0]; }
  { T437.values[0] = Top_hub_XactTracker_7__io_p_rep_tile_id.values[0]; }
  { T438.values[0] = T437.values[0]; }
  T439.values[0] = 0x1L << T438.values[0];
  { T440.values[0] = T439.values[0]; }
  T440.values[0] = T440.values[0] & 3;
  T441.values[0] = (T440.values[0] >> 1) & 1;
  { T442.values[0] = T441.values[0]; }
  { T443.values[0] = Top_hub__io_tiles_1_probe_rep_data_valid.values[0]&T442.values[0]; }
  T444.values[0] = (T440.values[0] >> 0) & 1;
  { T445.values[0] = T444.values[0]; }
  { T446.values[0] = Top_hub__io_tiles_0_probe_rep_data_valid.values[0]&T445.values[0]; }
  { T447.values[0] = T446.values[0]|T443.values[0]; }
  { Top_hub_XactTracker_7__io_p_rep_data_valid.values[0] = T447.values[0]; }
  { T448.values[0] = Top_hub_XactTracker_7__io_p_rep_data_valid.values[0]||Top_hub_XactTracker_7__p_w_mem_cmd_sent.values[0]; }
  T449.values[0] = Top_hub_XactTracker_7__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T449.values[0]; T450.values[0] = Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_2__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T451.values[0] = T450.values[0]; }
  T451.values[0] = T451.values[0] & 7;
  T452.values[0] = Top_hub_XactTracker_7__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T452.values[0]; T453.values[0] = T451.values[0] ^ ((T451.values[0] ^ Top_hub_Queue_1__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T454.values[0] = T453.values[0]; }
  T454.values[0] = T454.values[0] & 7;
  { Top_hub_XactTracker_7__io_p_rep_data_dep_bits_global_xact_id.values[0] = T454.values[0]; }
  T455.values[0] = Top_hub_XactTracker_7__io_p_rep_data_dep_bits_global_xact_id.values[0] == 0x7L;
  T456.values[0] = Top_hub_XactTracker_7__io_p_rep_tile_id.values[0] == 0x1L;
  { val_t __mask = -T456.values[0]; T457.values[0] = Top_hub_Queue_1__io_deq_valid.values[0] ^ ((Top_hub_Queue_1__io_deq_valid.values[0] ^ Top_hub_Queue_2__io_deq_valid.values[0]) & __mask); }
  T458.values[0] = Top_hub_XactTracker_7__io_p_rep_tile_id.values[0] == 0x0L;
  { val_t __mask = -T458.values[0]; T459.values[0] = T457.values[0] ^ ((T457.values[0] ^ Top_hub_Queue_1__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_7__io_p_rep_data_dep_valid.values[0] = T459.values[0]; }
  { T460.values[0] = Top_hub_XactTracker_7__io_p_rep_data_dep_valid.values[0]&&T455.values[0]; }
  T461.values[0] = Top_hub_XactTracker_7__state.values[0] == 0x2L;
  { T462.values[0] = T461.values[0]&&Top_hub_XactTracker_7__p_rep_data_needs_write.values[0]; }
  { T463.values[0] = T462.values[0]&&T460.values[0]; }
  { val_t __mask = -T463.values[0]; T464.values[0] = 0x0L ^ ((0x0L ^ T448.values[0]) & __mask); }
  { Top_hub_XactTracker_7__io_init_tile_id.values[0] = Top_hub_XactTracker_7__init_tile_id_.values[0]; }
  { T465.values[0] = Top_hub_XactTracker_7__io_init_tile_id.values[0]; }
  { T466.values[0] = T465.values[0]; }
  T467.values[0] = 0x1L << T466.values[0];
  { T468.values[0] = T467.values[0]; }
  T468.values[0] = T468.values[0] & 3;
  T469.values[0] = (T468.values[0] >> 1) & 1;
  { T470.values[0] = T469.values[0]; }
  { T471.values[0] = Top_hub__io_tiles_1_xact_init_data_valid.values[0]&T470.values[0]; }
  T472.values[0] = (T468.values[0] >> 0) & 1;
  { T473.values[0] = T472.values[0]; }
  { T474.values[0] = Top_hub__io_tiles_0_xact_init_data_valid.values[0]&T473.values[0]; }
  { T475.values[0] = T474.values[0]|T471.values[0]; }
  { Top_hub_XactTracker_7__io_x_init_data_valid.values[0] = T475.values[0]; }
  { T476.values[0] = Top_hub_XactTracker_7__io_x_init_data_valid.values[0]||Top_hub_XactTracker_7__x_w_mem_cmd_sent.values[0]; }
  T477.values[0] = Top_hub_XactTracker_7__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T477.values[0]; T478.values[0] = Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ ((Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0] ^ Top_hub_Queue_4__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T479.values[0] = T478.values[0]; }
  T479.values[0] = T479.values[0] & 7;
  T480.values[0] = Top_hub_XactTracker_7__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T480.values[0]; T481.values[0] = T479.values[0] ^ ((T479.values[0] ^ Top_hub_Queue_3__io_deq_bits_global_xact_id.values[0]) & __mask); }
  { T482.values[0] = T481.values[0]; }
  T482.values[0] = T482.values[0] & 7;
  { Top_hub_XactTracker_7__io_x_init_data_dep_bits_global_xact_id.values[0] = T482.values[0]; }
  T483.values[0] = Top_hub_XactTracker_7__io_x_init_data_dep_bits_global_xact_id.values[0] == 0x7L;
  T484.values[0] = Top_hub_XactTracker_7__io_init_tile_id.values[0] == 0x1L;
  { val_t __mask = -T484.values[0]; T485.values[0] = Top_hub_Queue_3__io_deq_valid.values[0] ^ ((Top_hub_Queue_3__io_deq_valid.values[0] ^ Top_hub_Queue_4__io_deq_valid.values[0]) & __mask); }
  T486.values[0] = Top_hub_XactTracker_7__io_init_tile_id.values[0] == 0x0L;
  { val_t __mask = -T486.values[0]; T487.values[0] = T485.values[0] ^ ((T485.values[0] ^ Top_hub_Queue_3__io_deq_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_7__io_x_init_data_dep_valid.values[0] = T487.values[0]; }
  { T488.values[0] = Top_hub_XactTracker_7__io_x_init_data_dep_valid.values[0]&&T483.values[0]; }
  T489.values[0] = !Top_hub_XactTracker_7__p_rep_data_needs_write.values[0];
  { T490.values[0] = T489.values[0]&&Top_hub_XactTracker_7__x_init_data_needs_write.values[0]; }
  { T491.values[0] = T461.values[0]&&T490.values[0]; }
  { T492.values[0] = T491.values[0]&&T488.values[0]; }
  { val_t __mask = -T492.values[0]; T493.values[0] = T464.values[0] ^ ((T464.values[0] ^ T476.values[0]) & __mask); }
  { Top_hub_XactTracker_7__io_mem_req_lock.values[0] = T493.values[0]; }
  { Top_hub_mem_req_data_arb__io_lock_7.values[0] = Top_hub_XactTracker_7__io_mem_req_lock.values[0]; }
  { T494.values[0] = Top_hub_mem_req_data_arb__io_lock_6.values[0] | Top_hub_mem_req_data_arb__io_lock_7.values[0] << 1; }
  { T495.values[0] = Top_hub_mem_req_data_arb__io_lock_5.values[0] | T494.values[0] << 1; }
  { T496.values[0] = Top_hub_mem_req_data_arb__io_lock_4.values[0] | T495.values[0] << 1; }
  { T497.values[0] = Top_hub_mem_req_data_arb__io_lock_3.values[0] | T496.values[0] << 1; }
  { T498.values[0] = Top_hub_mem_req_data_arb__io_lock_2.values[0] | T497.values[0] << 1; }
  { T499.values[0] = Top_hub_mem_req_data_arb__io_lock_1.values[0] | T498.values[0] << 1; }
  { T500.values[0] = Top_hub_mem_req_data_arb__io_lock_0.values[0] | T499.values[0] << 1; }
  { T501.values[0] = Top_hub_mem_req_data_arb__locked_6.values[0] | Top_hub_mem_req_data_arb__locked_7.values[0] << 1; }
  { T502.values[0] = Top_hub_mem_req_data_arb__locked_5.values[0] | T501.values[0] << 1; }
  { T503.values[0] = Top_hub_mem_req_data_arb__locked_4.values[0] | T502.values[0] << 1; }
  { T504.values[0] = Top_hub_mem_req_data_arb__locked_3.values[0] | T503.values[0] << 1; }
  { T505.values[0] = Top_hub_mem_req_data_arb__locked_2.values[0] | T504.values[0] << 1; }
  { T506.values[0] = Top_hub_mem_req_data_arb__locked_1.values[0] | T505.values[0] << 1; }
  { T507.values[0] = Top_hub_mem_req_data_arb__locked_0.values[0] | T506.values[0] << 1; }
  { T508.values[0] = T507.values[0]&T500.values[0]; }
  Top_hub_mem_req_data_arb__any_lock_held.values[0] = (T508.values[0]) != 0;
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T509.values[0] = Top_hub_mem_req_data_arb__io_out_ready.values[0] ^ ((Top_hub_mem_req_data_arb__io_out_ready.values[0] ^ T14.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__io_in_0_ready.values[0] = T509.values[0]; }
  Top_hub_Queue_5__ptr_match.values[0] = Top_hub_Queue_5__enq_ptr.values[0] == Top_hub_Queue_5__deq_ptr.values[0];
  { Top_hub_Queue_5__full.values[0] = Top_hub_Queue_5__ptr_match.values[0]&&Top_hub_Queue_5__maybe_full.values[0]; }
  T510.values[0] = !Top_hub_Queue_5__full.values[0];
  { Top_hub_Queue_5__io_enq_ready.values[0] = T510.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_out_ready.values[0] = Top_hub_Queue_5__io_enq_ready.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_0_ready.values[0] = Top_hub_mem_req_cmd_arb__io_out_ready.values[0]; }
  { Top_hub_XactTracker__io_mem_req_cmd_ready.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_ready.values[0]; }
  { T511.values[0] = Top_hub_XactTracker__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker__p_w_mem_cmd_sent.values[0]; }
  { T512.values[0] = T51.values[0]&&T511.values[0]; }
  { val_t __mask = -T512.values[0]; T513.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker__io_p_rep_data_valid.values[0]) & __mask); }
  { T514.values[0] = Top_hub_XactTracker__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker__x_w_mem_cmd_sent.values[0]; }
  { T515.values[0] = T93.values[0]&&T514.values[0]; }
  { val_t __mask = -T515.values[0]; T516.values[0] = T513.values[0] ^ ((T513.values[0] ^ Top_hub_XactTracker__io_x_init_data_valid.values[0]) & __mask); }
  { Top_hub_XactTracker__io_mem_req_data_valid.values[0] = T516.values[0]; }
  { Top_hub_mem_req_data_arb__io_in_0_valid.values[0] = Top_hub_XactTracker__io_mem_req_data_valid.values[0]; }
  T517.values[0] = !Top_hub_mem_req_data_arb__io_in_0_valid.values[0];
  { T518.values[0] = T517.values[0]&&Top_hub_mem_req_data_arb__io_in_0_ready.values[0]; }
  { T519.values[0] = Top_hub_mem_req_data_arb__io_out_ready.values[0]&&Top_hub_mem_req_data_arb__locked_1.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T520.values[0] = T518.values[0] ^ ((T518.values[0] ^ T519.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__io_in_1_ready.values[0] = T520.values[0]; }
  { Top_hub_XactTracker__io_mem_req_data_ready.values[0] = Top_hub_mem_req_data_arb__io_in_0_ready.values[0]; }
  T521.values[0] = !Top_hub_XactTracker__p_w_mem_cmd_sent.values[0];
  { T522.values[0] = T521.values[0]&&Top_hub_XactTracker__io_mem_req_data_ready.values[0]; }
  { T523.values[0] = T522.values[0]&&Top_hub_XactTracker__io_p_rep_data_valid.values[0]; }
  { val_t __mask = -T51.values[0]; T524.values[0] = 0x0L ^ ((0x0L ^ T523.values[0]) & __mask); }
  T525.values[0] = !Top_hub_XactTracker__x_w_mem_cmd_sent.values[0];
  { T526.values[0] = T525.values[0]&&Top_hub_XactTracker__io_mem_req_data_ready.values[0]; }
  { T527.values[0] = T526.values[0]&&Top_hub_XactTracker__io_x_init_data_valid.values[0]; }
  { val_t __mask = -T93.values[0]; T528.values[0] = T524.values[0] ^ ((T524.values[0] ^ T527.values[0]) & __mask); }
  { T529.values[0] = Top_hub_XactTracker__p_rep_data_needs_write.values[0]||Top_hub_XactTracker__x_init_data_needs_write.values[0]; }
  T530.values[0] = !T529.values[0];
  { T531.values[0] = T530.values[0]&&Top_hub_XactTracker__x_needs_read.values[0]; }
  { T532.values[0] = T49.values[0]&&T531.values[0]; }
  { val_t __mask = -T532.values[0]; T533.values[0] = T528.values[0] ^ ((T528.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker__io_mem_req_cmd_valid.values[0] = T533.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0] = Top_hub_XactTracker__io_mem_req_cmd_valid.values[0]; }
  T534.values[0] = !Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0];
  { T535.values[0] = T534.values[0]&&Top_hub_mem_req_cmd_arb__io_out_ready.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_1_ready.values[0] = T535.values[0]; }
  { Top_hub_XactTracker_1__io_mem_req_cmd_ready.values[0] = Top_hub_mem_req_cmd_arb__io_in_1_ready.values[0]; }
  { T536.values[0] = Top_hub_XactTracker_1__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_1__p_w_mem_cmd_sent.values[0]; }
  { T537.values[0] = T121.values[0]&&T536.values[0]; }
  { val_t __mask = -T537.values[0]; T538.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_1__io_p_rep_data_valid.values[0]) & __mask); }
  { T539.values[0] = Top_hub_XactTracker_1__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_1__x_w_mem_cmd_sent.values[0]; }
  { T540.values[0] = T150.values[0]&&T539.values[0]; }
  { val_t __mask = -T540.values[0]; T541.values[0] = T538.values[0] ^ ((T538.values[0] ^ Top_hub_XactTracker_1__io_x_init_data_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_1__io_mem_req_data_valid.values[0] = T541.values[0]; }
  { Top_hub_mem_req_data_arb__io_in_1_valid.values[0] = Top_hub_XactTracker_1__io_mem_req_data_valid.values[0]; }
  T542.values[0] = !Top_hub_mem_req_data_arb__io_in_1_valid.values[0];
  { T543.values[0] = T542.values[0]&&Top_hub_mem_req_data_arb__io_in_1_ready.values[0]; }
  { T544.values[0] = Top_hub_mem_req_data_arb__io_out_ready.values[0]&&Top_hub_mem_req_data_arb__locked_2.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T545.values[0] = T543.values[0] ^ ((T543.values[0] ^ T544.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__io_in_2_ready.values[0] = T545.values[0]; }
  { Top_hub_XactTracker_1__io_mem_req_data_ready.values[0] = Top_hub_mem_req_data_arb__io_in_1_ready.values[0]; }
  T546.values[0] = !Top_hub_XactTracker_1__p_w_mem_cmd_sent.values[0];
  { T547.values[0] = T546.values[0]&&Top_hub_XactTracker_1__io_mem_req_data_ready.values[0]; }
  { T548.values[0] = T547.values[0]&&Top_hub_XactTracker_1__io_p_rep_data_valid.values[0]; }
  { val_t __mask = -T121.values[0]; T549.values[0] = 0x0L ^ ((0x0L ^ T548.values[0]) & __mask); }
  T550.values[0] = !Top_hub_XactTracker_1__x_w_mem_cmd_sent.values[0];
  { T551.values[0] = T550.values[0]&&Top_hub_XactTracker_1__io_mem_req_data_ready.values[0]; }
  { T552.values[0] = T551.values[0]&&Top_hub_XactTracker_1__io_x_init_data_valid.values[0]; }
  { val_t __mask = -T150.values[0]; T553.values[0] = T549.values[0] ^ ((T549.values[0] ^ T552.values[0]) & __mask); }
  { T554.values[0] = Top_hub_XactTracker_1__p_rep_data_needs_write.values[0]||Top_hub_XactTracker_1__x_init_data_needs_write.values[0]; }
  T555.values[0] = !T554.values[0];
  { T556.values[0] = T555.values[0]&&Top_hub_XactTracker_1__x_needs_read.values[0]; }
  { T557.values[0] = T119.values[0]&&T556.values[0]; }
  { val_t __mask = -T557.values[0]; T558.values[0] = T553.values[0] ^ ((T553.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_1__io_mem_req_cmd_valid.values[0] = T558.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_1_valid.values[0] = Top_hub_XactTracker_1__io_mem_req_cmd_valid.values[0]; }
  { T559.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0]||Top_hub_mem_req_cmd_arb__io_in_1_valid.values[0]; }
  T560.values[0] = !T559.values[0];
  { T561.values[0] = T560.values[0]&&Top_hub_mem_req_cmd_arb__io_out_ready.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_2_ready.values[0] = T561.values[0]; }
  { Top_hub_XactTracker_2__io_mem_req_cmd_ready.values[0] = Top_hub_mem_req_cmd_arb__io_in_2_ready.values[0]; }
  { T562.values[0] = Top_hub_XactTracker_2__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_2__p_w_mem_cmd_sent.values[0]; }
  { T563.values[0] = T178.values[0]&&T562.values[0]; }
  { val_t __mask = -T563.values[0]; T564.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_2__io_p_rep_data_valid.values[0]) & __mask); }
  { T565.values[0] = Top_hub_XactTracker_2__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_2__x_w_mem_cmd_sent.values[0]; }
  { T566.values[0] = T207.values[0]&&T565.values[0]; }
  { val_t __mask = -T566.values[0]; T567.values[0] = T564.values[0] ^ ((T564.values[0] ^ Top_hub_XactTracker_2__io_x_init_data_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_2__io_mem_req_data_valid.values[0] = T567.values[0]; }
  { Top_hub_mem_req_data_arb__io_in_2_valid.values[0] = Top_hub_XactTracker_2__io_mem_req_data_valid.values[0]; }
  T568.values[0] = !Top_hub_mem_req_data_arb__io_in_2_valid.values[0];
  { T569.values[0] = T568.values[0]&&Top_hub_mem_req_data_arb__io_in_2_ready.values[0]; }
  { T570.values[0] = Top_hub_mem_req_data_arb__io_out_ready.values[0]&&Top_hub_mem_req_data_arb__locked_3.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T571.values[0] = T569.values[0] ^ ((T569.values[0] ^ T570.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__io_in_3_ready.values[0] = T571.values[0]; }
  { Top_hub_XactTracker_2__io_mem_req_data_ready.values[0] = Top_hub_mem_req_data_arb__io_in_2_ready.values[0]; }
  T572.values[0] = !Top_hub_XactTracker_2__p_w_mem_cmd_sent.values[0];
  { T573.values[0] = T572.values[0]&&Top_hub_XactTracker_2__io_mem_req_data_ready.values[0]; }
  { T574.values[0] = T573.values[0]&&Top_hub_XactTracker_2__io_p_rep_data_valid.values[0]; }
  { val_t __mask = -T178.values[0]; T575.values[0] = 0x0L ^ ((0x0L ^ T574.values[0]) & __mask); }
  T576.values[0] = !Top_hub_XactTracker_2__x_w_mem_cmd_sent.values[0];
  { T577.values[0] = T576.values[0]&&Top_hub_XactTracker_2__io_mem_req_data_ready.values[0]; }
  { T578.values[0] = T577.values[0]&&Top_hub_XactTracker_2__io_x_init_data_valid.values[0]; }
  { val_t __mask = -T207.values[0]; T579.values[0] = T575.values[0] ^ ((T575.values[0] ^ T578.values[0]) & __mask); }
  { T580.values[0] = Top_hub_XactTracker_2__p_rep_data_needs_write.values[0]||Top_hub_XactTracker_2__x_init_data_needs_write.values[0]; }
  T581.values[0] = !T580.values[0];
  { T582.values[0] = T581.values[0]&&Top_hub_XactTracker_2__x_needs_read.values[0]; }
  { T583.values[0] = T176.values[0]&&T582.values[0]; }
  { val_t __mask = -T583.values[0]; T584.values[0] = T579.values[0] ^ ((T579.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_2__io_mem_req_cmd_valid.values[0] = T584.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_2_valid.values[0] = Top_hub_XactTracker_2__io_mem_req_cmd_valid.values[0]; }
  { T585.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0]||Top_hub_mem_req_cmd_arb__io_in_1_valid.values[0]; }
  { T586.values[0] = T585.values[0]||Top_hub_mem_req_cmd_arb__io_in_2_valid.values[0]; }
  T587.values[0] = !T586.values[0];
  { T588.values[0] = T587.values[0]&&Top_hub_mem_req_cmd_arb__io_out_ready.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_3_ready.values[0] = T588.values[0]; }
  { Top_hub_XactTracker_3__io_mem_req_cmd_ready.values[0] = Top_hub_mem_req_cmd_arb__io_in_3_ready.values[0]; }
  { T589.values[0] = Top_hub_XactTracker_3__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_3__p_w_mem_cmd_sent.values[0]; }
  { T590.values[0] = T235.values[0]&&T589.values[0]; }
  { val_t __mask = -T590.values[0]; T591.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_3__io_p_rep_data_valid.values[0]) & __mask); }
  { T592.values[0] = Top_hub_XactTracker_3__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_3__x_w_mem_cmd_sent.values[0]; }
  { T593.values[0] = T264.values[0]&&T592.values[0]; }
  { val_t __mask = -T593.values[0]; T594.values[0] = T591.values[0] ^ ((T591.values[0] ^ Top_hub_XactTracker_3__io_x_init_data_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_3__io_mem_req_data_valid.values[0] = T594.values[0]; }
  { Top_hub_mem_req_data_arb__io_in_3_valid.values[0] = Top_hub_XactTracker_3__io_mem_req_data_valid.values[0]; }
  T595.values[0] = !Top_hub_mem_req_data_arb__io_in_3_valid.values[0];
  { T596.values[0] = T595.values[0]&&Top_hub_mem_req_data_arb__io_in_3_ready.values[0]; }
  { T597.values[0] = Top_hub_mem_req_data_arb__io_out_ready.values[0]&&Top_hub_mem_req_data_arb__locked_4.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T598.values[0] = T596.values[0] ^ ((T596.values[0] ^ T597.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__io_in_4_ready.values[0] = T598.values[0]; }
  { Top_hub_XactTracker_3__io_mem_req_data_ready.values[0] = Top_hub_mem_req_data_arb__io_in_3_ready.values[0]; }
  T599.values[0] = !Top_hub_XactTracker_3__p_w_mem_cmd_sent.values[0];
  { T600.values[0] = T599.values[0]&&Top_hub_XactTracker_3__io_mem_req_data_ready.values[0]; }
  { T601.values[0] = T600.values[0]&&Top_hub_XactTracker_3__io_p_rep_data_valid.values[0]; }
  { val_t __mask = -T235.values[0]; T602.values[0] = 0x0L ^ ((0x0L ^ T601.values[0]) & __mask); }
  T603.values[0] = !Top_hub_XactTracker_3__x_w_mem_cmd_sent.values[0];
  { T604.values[0] = T603.values[0]&&Top_hub_XactTracker_3__io_mem_req_data_ready.values[0]; }
  { T605.values[0] = T604.values[0]&&Top_hub_XactTracker_3__io_x_init_data_valid.values[0]; }
  { val_t __mask = -T264.values[0]; T606.values[0] = T602.values[0] ^ ((T602.values[0] ^ T605.values[0]) & __mask); }
  { T607.values[0] = Top_hub_XactTracker_3__p_rep_data_needs_write.values[0]||Top_hub_XactTracker_3__x_init_data_needs_write.values[0]; }
  T608.values[0] = !T607.values[0];
  { T609.values[0] = T608.values[0]&&Top_hub_XactTracker_3__x_needs_read.values[0]; }
  { T610.values[0] = T233.values[0]&&T609.values[0]; }
  { val_t __mask = -T610.values[0]; T611.values[0] = T606.values[0] ^ ((T606.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_3__io_mem_req_cmd_valid.values[0] = T611.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_3_valid.values[0] = Top_hub_XactTracker_3__io_mem_req_cmd_valid.values[0]; }
  { T612.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0]||Top_hub_mem_req_cmd_arb__io_in_1_valid.values[0]; }
  { T613.values[0] = T612.values[0]||Top_hub_mem_req_cmd_arb__io_in_2_valid.values[0]; }
  { T614.values[0] = T613.values[0]||Top_hub_mem_req_cmd_arb__io_in_3_valid.values[0]; }
  T615.values[0] = !T614.values[0];
  { T616.values[0] = T615.values[0]&&Top_hub_mem_req_cmd_arb__io_out_ready.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_4_ready.values[0] = T616.values[0]; }
  { Top_hub_XactTracker_4__io_mem_req_cmd_ready.values[0] = Top_hub_mem_req_cmd_arb__io_in_4_ready.values[0]; }
  { T617.values[0] = Top_hub_XactTracker_4__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_4__p_w_mem_cmd_sent.values[0]; }
  { T618.values[0] = T292.values[0]&&T617.values[0]; }
  { val_t __mask = -T618.values[0]; T619.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_4__io_p_rep_data_valid.values[0]) & __mask); }
  { T620.values[0] = Top_hub_XactTracker_4__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_4__x_w_mem_cmd_sent.values[0]; }
  { T621.values[0] = T321.values[0]&&T620.values[0]; }
  { val_t __mask = -T621.values[0]; T622.values[0] = T619.values[0] ^ ((T619.values[0] ^ Top_hub_XactTracker_4__io_x_init_data_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_4__io_mem_req_data_valid.values[0] = T622.values[0]; }
  { Top_hub_mem_req_data_arb__io_in_4_valid.values[0] = Top_hub_XactTracker_4__io_mem_req_data_valid.values[0]; }
  T623.values[0] = !Top_hub_mem_req_data_arb__io_in_4_valid.values[0];
  { T624.values[0] = T623.values[0]&&Top_hub_mem_req_data_arb__io_in_4_ready.values[0]; }
  { T625.values[0] = Top_hub_mem_req_data_arb__io_out_ready.values[0]&&Top_hub_mem_req_data_arb__locked_5.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T626.values[0] = T624.values[0] ^ ((T624.values[0] ^ T625.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__io_in_5_ready.values[0] = T626.values[0]; }
  { Top_hub_XactTracker_4__io_mem_req_data_ready.values[0] = Top_hub_mem_req_data_arb__io_in_4_ready.values[0]; }
  T627.values[0] = !Top_hub_XactTracker_4__p_w_mem_cmd_sent.values[0];
  { T628.values[0] = T627.values[0]&&Top_hub_XactTracker_4__io_mem_req_data_ready.values[0]; }
  { T629.values[0] = T628.values[0]&&Top_hub_XactTracker_4__io_p_rep_data_valid.values[0]; }
  { val_t __mask = -T292.values[0]; T630.values[0] = 0x0L ^ ((0x0L ^ T629.values[0]) & __mask); }
  T631.values[0] = !Top_hub_XactTracker_4__x_w_mem_cmd_sent.values[0];
  { T632.values[0] = T631.values[0]&&Top_hub_XactTracker_4__io_mem_req_data_ready.values[0]; }
  { T633.values[0] = T632.values[0]&&Top_hub_XactTracker_4__io_x_init_data_valid.values[0]; }
  { val_t __mask = -T321.values[0]; T634.values[0] = T630.values[0] ^ ((T630.values[0] ^ T633.values[0]) & __mask); }
  { T635.values[0] = Top_hub_XactTracker_4__p_rep_data_needs_write.values[0]||Top_hub_XactTracker_4__x_init_data_needs_write.values[0]; }
  T636.values[0] = !T635.values[0];
  { T637.values[0] = T636.values[0]&&Top_hub_XactTracker_4__x_needs_read.values[0]; }
  { T638.values[0] = T290.values[0]&&T637.values[0]; }
  { val_t __mask = -T638.values[0]; T639.values[0] = T634.values[0] ^ ((T634.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_4__io_mem_req_cmd_valid.values[0] = T639.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_4_valid.values[0] = Top_hub_XactTracker_4__io_mem_req_cmd_valid.values[0]; }
  { T640.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0]||Top_hub_mem_req_cmd_arb__io_in_1_valid.values[0]; }
  { T641.values[0] = T640.values[0]||Top_hub_mem_req_cmd_arb__io_in_2_valid.values[0]; }
  { T642.values[0] = T641.values[0]||Top_hub_mem_req_cmd_arb__io_in_3_valid.values[0]; }
  { T643.values[0] = T642.values[0]||Top_hub_mem_req_cmd_arb__io_in_4_valid.values[0]; }
  T644.values[0] = !T643.values[0];
  { T645.values[0] = T644.values[0]&&Top_hub_mem_req_cmd_arb__io_out_ready.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_5_ready.values[0] = T645.values[0]; }
  { Top_hub_XactTracker_5__io_mem_req_cmd_ready.values[0] = Top_hub_mem_req_cmd_arb__io_in_5_ready.values[0]; }
  { T646.values[0] = Top_hub_XactTracker_5__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_5__p_w_mem_cmd_sent.values[0]; }
  { T647.values[0] = T349.values[0]&&T646.values[0]; }
  { val_t __mask = -T647.values[0]; T648.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_5__io_p_rep_data_valid.values[0]) & __mask); }
  { T649.values[0] = Top_hub_XactTracker_5__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_5__x_w_mem_cmd_sent.values[0]; }
  { T650.values[0] = T378.values[0]&&T649.values[0]; }
  { val_t __mask = -T650.values[0]; T651.values[0] = T648.values[0] ^ ((T648.values[0] ^ Top_hub_XactTracker_5__io_x_init_data_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_5__io_mem_req_data_valid.values[0] = T651.values[0]; }
  { Top_hub_mem_req_data_arb__io_in_5_valid.values[0] = Top_hub_XactTracker_5__io_mem_req_data_valid.values[0]; }
  T652.values[0] = !Top_hub_mem_req_data_arb__io_in_5_valid.values[0];
  { T653.values[0] = T652.values[0]&&Top_hub_mem_req_data_arb__io_in_5_ready.values[0]; }
  { T654.values[0] = Top_hub_mem_req_data_arb__io_out_ready.values[0]&&Top_hub_mem_req_data_arb__locked_6.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T655.values[0] = T653.values[0] ^ ((T653.values[0] ^ T654.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__io_in_6_ready.values[0] = T655.values[0]; }
  { Top_hub_XactTracker_5__io_mem_req_data_ready.values[0] = Top_hub_mem_req_data_arb__io_in_5_ready.values[0]; }
  T656.values[0] = !Top_hub_XactTracker_5__p_w_mem_cmd_sent.values[0];
  { T657.values[0] = T656.values[0]&&Top_hub_XactTracker_5__io_mem_req_data_ready.values[0]; }
  { T658.values[0] = T657.values[0]&&Top_hub_XactTracker_5__io_p_rep_data_valid.values[0]; }
  { val_t __mask = -T349.values[0]; T659.values[0] = 0x0L ^ ((0x0L ^ T658.values[0]) & __mask); }
  T660.values[0] = !Top_hub_XactTracker_5__x_w_mem_cmd_sent.values[0];
  { T661.values[0] = T660.values[0]&&Top_hub_XactTracker_5__io_mem_req_data_ready.values[0]; }
  { T662.values[0] = T661.values[0]&&Top_hub_XactTracker_5__io_x_init_data_valid.values[0]; }
  { val_t __mask = -T378.values[0]; T663.values[0] = T659.values[0] ^ ((T659.values[0] ^ T662.values[0]) & __mask); }
  { T664.values[0] = Top_hub_XactTracker_5__p_rep_data_needs_write.values[0]||Top_hub_XactTracker_5__x_init_data_needs_write.values[0]; }
  T665.values[0] = !T664.values[0];
  { T666.values[0] = T665.values[0]&&Top_hub_XactTracker_5__x_needs_read.values[0]; }
  { T667.values[0] = T347.values[0]&&T666.values[0]; }
  { val_t __mask = -T667.values[0]; T668.values[0] = T663.values[0] ^ ((T663.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_5__io_mem_req_cmd_valid.values[0] = T668.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_5_valid.values[0] = Top_hub_XactTracker_5__io_mem_req_cmd_valid.values[0]; }
  { T669.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0]||Top_hub_mem_req_cmd_arb__io_in_1_valid.values[0]; }
  { T670.values[0] = T669.values[0]||Top_hub_mem_req_cmd_arb__io_in_2_valid.values[0]; }
  { T671.values[0] = T670.values[0]||Top_hub_mem_req_cmd_arb__io_in_3_valid.values[0]; }
  { T672.values[0] = T671.values[0]||Top_hub_mem_req_cmd_arb__io_in_4_valid.values[0]; }
  { T673.values[0] = T672.values[0]||Top_hub_mem_req_cmd_arb__io_in_5_valid.values[0]; }
  T674.values[0] = !T673.values[0];
  { T675.values[0] = T674.values[0]&&Top_hub_mem_req_cmd_arb__io_out_ready.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_6_ready.values[0] = T675.values[0]; }
  { Top_hub_XactTracker_6__io_mem_req_cmd_ready.values[0] = Top_hub_mem_req_cmd_arb__io_in_6_ready.values[0]; }
  { T676.values[0] = Top_hub_XactTracker_6__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_6__p_w_mem_cmd_sent.values[0]; }
  { T677.values[0] = T406.values[0]&&T676.values[0]; }
  { val_t __mask = -T677.values[0]; T678.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_6__io_p_rep_data_valid.values[0]) & __mask); }
  { T679.values[0] = Top_hub_XactTracker_6__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_6__x_w_mem_cmd_sent.values[0]; }
  { T680.values[0] = T435.values[0]&&T679.values[0]; }
  { val_t __mask = -T680.values[0]; T681.values[0] = T678.values[0] ^ ((T678.values[0] ^ Top_hub_XactTracker_6__io_x_init_data_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_6__io_mem_req_data_valid.values[0] = T681.values[0]; }
  { Top_hub_mem_req_data_arb__io_in_6_valid.values[0] = Top_hub_XactTracker_6__io_mem_req_data_valid.values[0]; }
  T682.values[0] = !Top_hub_mem_req_data_arb__io_in_6_valid.values[0];
  { T683.values[0] = T682.values[0]&&Top_hub_mem_req_data_arb__io_in_6_ready.values[0]; }
  { T684.values[0] = Top_hub_mem_req_data_arb__io_out_ready.values[0]&&Top_hub_mem_req_data_arb__locked_7.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T685.values[0] = T683.values[0] ^ ((T683.values[0] ^ T684.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__io_in_7_ready.values[0] = T685.values[0]; }
  { Top_hub_XactTracker_7__io_mem_req_data_ready.values[0] = Top_hub_mem_req_data_arb__io_in_7_ready.values[0]; }
  { Top_hub_XactTracker_6__io_mem_req_data_ready.values[0] = Top_hub_mem_req_data_arb__io_in_6_ready.values[0]; }
  T686.values[0] = !Top_hub_XactTracker_6__p_w_mem_cmd_sent.values[0];
  { T687.values[0] = T686.values[0]&&Top_hub_XactTracker_6__io_mem_req_data_ready.values[0]; }
  { T688.values[0] = T687.values[0]&&Top_hub_XactTracker_6__io_p_rep_data_valid.values[0]; }
  { val_t __mask = -T406.values[0]; T689.values[0] = 0x0L ^ ((0x0L ^ T688.values[0]) & __mask); }
  T690.values[0] = !Top_hub_XactTracker_6__x_w_mem_cmd_sent.values[0];
  { T691.values[0] = T690.values[0]&&Top_hub_XactTracker_6__io_mem_req_data_ready.values[0]; }
  { T692.values[0] = T691.values[0]&&Top_hub_XactTracker_6__io_x_init_data_valid.values[0]; }
  { val_t __mask = -T435.values[0]; T693.values[0] = T689.values[0] ^ ((T689.values[0] ^ T692.values[0]) & __mask); }
  { T694.values[0] = Top_hub_XactTracker_6__p_rep_data_needs_write.values[0]||Top_hub_XactTracker_6__x_init_data_needs_write.values[0]; }
  T695.values[0] = !T694.values[0];
  { T696.values[0] = T695.values[0]&&Top_hub_XactTracker_6__x_needs_read.values[0]; }
  { T697.values[0] = T404.values[0]&&T696.values[0]; }
  { val_t __mask = -T697.values[0]; T698.values[0] = T693.values[0] ^ ((T693.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_6__io_mem_req_cmd_valid.values[0] = T698.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_6_valid.values[0] = Top_hub_XactTracker_6__io_mem_req_cmd_valid.values[0]; }
  { T699.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0]||Top_hub_mem_req_cmd_arb__io_in_1_valid.values[0]; }
  { T700.values[0] = T699.values[0]||Top_hub_mem_req_cmd_arb__io_in_2_valid.values[0]; }
  { T701.values[0] = T700.values[0]||Top_hub_mem_req_cmd_arb__io_in_3_valid.values[0]; }
  { T702.values[0] = T701.values[0]||Top_hub_mem_req_cmd_arb__io_in_4_valid.values[0]; }
  { T703.values[0] = T702.values[0]||Top_hub_mem_req_cmd_arb__io_in_5_valid.values[0]; }
  { T704.values[0] = T703.values[0]||Top_hub_mem_req_cmd_arb__io_in_6_valid.values[0]; }
  T705.values[0] = !T704.values[0];
  { T706.values[0] = T705.values[0]&&Top_hub_mem_req_cmd_arb__io_out_ready.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_7_ready.values[0] = T706.values[0]; }
  { Top_hub_XactTracker_7__io_mem_req_cmd_ready.values[0] = Top_hub_mem_req_cmd_arb__io_in_7_ready.values[0]; }
  { T707.values[0] = Top_hub_XactTracker_7__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_7__p_w_mem_cmd_sent.values[0]; }
  { T708.values[0] = T463.values[0]&&T707.values[0]; }
  { T709.values[0] = T708.values[0]&&Top_hub_XactTracker_7__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T709.values[0]; T710.values[0] = 0x0L ^ ((0x0L ^ T12.values[0]) & __mask); }
  { T711.values[0] = T710.values[0]; }
  T711.values[0] = T711.values[0] & 3;
  { Top_hub_XactTracker_7__io_pop_p_rep_data.values[0] = T711.values[0]; }
  T712.values[0] = (Top_hub_XactTracker_7__io_pop_p_rep_data.values[0] >> 0) & 1;
  { T713.values[0] = T712.values[0]; }
  { T714.values[0] = Top_hub_XactTracker_6__p_rep_tile_id_.values[0]; }
  T715.values[0] = 0x1L << T714.values[0];
  { T716.values[0] = T677.values[0]&&Top_hub_XactTracker_6__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T716.values[0]; T717.values[0] = 0x0L ^ ((0x0L ^ T715.values[0]) & __mask); }
  { T718.values[0] = T717.values[0]; }
  T718.values[0] = T718.values[0] & 3;
  { Top_hub_XactTracker_6__io_pop_p_rep_data.values[0] = T718.values[0]; }
  T719.values[0] = (Top_hub_XactTracker_6__io_pop_p_rep_data.values[0] >> 0) & 1;
  { T720.values[0] = T719.values[0]; }
  { T721.values[0] = T720.values[0]||T713.values[0]; }
  { T722.values[0] = T721.values[0]; }
  { T723.values[0] = Top_hub_XactTracker_5__p_rep_tile_id_.values[0]; }
  T724.values[0] = 0x1L << T723.values[0];
  { T725.values[0] = T647.values[0]&&Top_hub_XactTracker_5__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T725.values[0]; T726.values[0] = 0x0L ^ ((0x0L ^ T724.values[0]) & __mask); }
  { T727.values[0] = T726.values[0]; }
  T727.values[0] = T727.values[0] & 3;
  { Top_hub_XactTracker_5__io_pop_p_rep_data.values[0] = T727.values[0]; }
  T728.values[0] = (Top_hub_XactTracker_5__io_pop_p_rep_data.values[0] >> 0) & 1;
  { T729.values[0] = T728.values[0]; }
  { T730.values[0] = T729.values[0]||T722.values[0]; }
  { T731.values[0] = T730.values[0]; }
  { T732.values[0] = Top_hub_XactTracker_4__p_rep_tile_id_.values[0]; }
  T733.values[0] = 0x1L << T732.values[0];
  { T734.values[0] = T618.values[0]&&Top_hub_XactTracker_4__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T734.values[0]; T735.values[0] = 0x0L ^ ((0x0L ^ T733.values[0]) & __mask); }
  { T736.values[0] = T735.values[0]; }
  T736.values[0] = T736.values[0] & 3;
  { Top_hub_XactTracker_4__io_pop_p_rep_data.values[0] = T736.values[0]; }
  T737.values[0] = (Top_hub_XactTracker_4__io_pop_p_rep_data.values[0] >> 0) & 1;
  { T738.values[0] = T737.values[0]; }
  { T739.values[0] = T738.values[0]||T731.values[0]; }
  { T740.values[0] = T739.values[0]; }
  { T741.values[0] = Top_hub_XactTracker_3__p_rep_tile_id_.values[0]; }
  T742.values[0] = 0x1L << T741.values[0];
  { T743.values[0] = T590.values[0]&&Top_hub_XactTracker_3__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T743.values[0]; T744.values[0] = 0x0L ^ ((0x0L ^ T742.values[0]) & __mask); }
  { T745.values[0] = T744.values[0]; }
  T745.values[0] = T745.values[0] & 3;
  { Top_hub_XactTracker_3__io_pop_p_rep_data.values[0] = T745.values[0]; }
  T746.values[0] = (Top_hub_XactTracker_3__io_pop_p_rep_data.values[0] >> 0) & 1;
  { T747.values[0] = T746.values[0]; }
  { T748.values[0] = T747.values[0]||T740.values[0]; }
  { T749.values[0] = T748.values[0]; }
  { T750.values[0] = Top_hub_XactTracker_2__p_rep_tile_id_.values[0]; }
  T751.values[0] = 0x1L << T750.values[0];
  { T752.values[0] = T563.values[0]&&Top_hub_XactTracker_2__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T752.values[0]; T753.values[0] = 0x0L ^ ((0x0L ^ T751.values[0]) & __mask); }
  { T754.values[0] = T753.values[0]; }
  T754.values[0] = T754.values[0] & 3;
  { Top_hub_XactTracker_2__io_pop_p_rep_data.values[0] = T754.values[0]; }
  T755.values[0] = (Top_hub_XactTracker_2__io_pop_p_rep_data.values[0] >> 0) & 1;
  { T756.values[0] = T755.values[0]; }
  { T757.values[0] = T756.values[0]||T749.values[0]; }
  { T758.values[0] = T757.values[0]; }
  { T759.values[0] = Top_hub_XactTracker_1__p_rep_tile_id_.values[0]; }
  T760.values[0] = 0x1L << T759.values[0];
  { T761.values[0] = T537.values[0]&&Top_hub_XactTracker_1__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T761.values[0]; T762.values[0] = 0x0L ^ ((0x0L ^ T760.values[0]) & __mask); }
  { T763.values[0] = T762.values[0]; }
  T763.values[0] = T763.values[0] & 3;
  { Top_hub_XactTracker_1__io_pop_p_rep_data.values[0] = T763.values[0]; }
  T764.values[0] = (Top_hub_XactTracker_1__io_pop_p_rep_data.values[0] >> 0) & 1;
  { T765.values[0] = T764.values[0]; }
  { T766.values[0] = T765.values[0]||T758.values[0]; }
  { T767.values[0] = T766.values[0]; }
  { T768.values[0] = Top_hub_XactTracker__p_rep_tile_id_.values[0]; }
  T769.values[0] = 0x1L << T768.values[0];
  { T770.values[0] = T512.values[0]&&Top_hub_XactTracker__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T770.values[0]; T771.values[0] = 0x0L ^ ((0x0L ^ T769.values[0]) & __mask); }
  { T772.values[0] = T771.values[0]; }
  T772.values[0] = T772.values[0] & 3;
  { Top_hub_XactTracker__io_pop_p_rep_data.values[0] = T772.values[0]; }
  T773.values[0] = (Top_hub_XactTracker__io_pop_p_rep_data.values[0] >> 0) & 1;
  { T774.values[0] = T773.values[0]; }
  { T775.values[0] = T774.values[0]||T767.values[0]; }
  { T776.values[0] = T775.values[0]; }
  { Top_hub__io_tiles_0_probe_rep_data_ready.values[0] = T776.values[0]; }
  { Top_Queue_22__io_deq_ready.values[0] = Top_hub__io_tiles_0_probe_rep_data_ready.values[0]; }
  { T777.values[0] = Top_Queue_22__io_deq_ready.values[0]&&Top_Queue_22__io_deq_valid.values[0]; }
  { Top_Queue_22__do_deq.values[0] = T777.values[0]&&T8.values[0]; }
  { val_t __mask = -Top_Queue_22__do_deq.values[0]; T778.values[0] = Top_Queue_22__deq_ptr.values[0] ^ ((Top_Queue_22__deq_ptr.values[0] ^ T7.values[0]) & __mask); }
  { Top_Queue_22__deq_ptr_shadow.values[0] = TERNARY(Top_Queue_22__reset.values[0], 0x0L, T778.values[0]); }
  T779.values[0] = Top_Queue_22__do_enq.values[0] != Top_Queue_22__do_deq.values[0];
  { val_t __mask = -T779.values[0]; T780.values[0] = Top_Queue_22__maybe_full.values[0] ^ ((Top_Queue_22__maybe_full.values[0] ^ Top_Queue_22__do_enq.values[0]) & __mask); }
  { Top_Queue_22__maybe_full_shadow.values[0] = TERNARY(Top_Queue_22__reset.values[0], 0x0L, T780.values[0]); }
  { Top_Queue_21__reset.values[0] = reset.values[0]; }
  { Top_Queue_21__do_flow.values[0] = 0x0L; }
  T781.values[0] = !Top_Queue_21__do_flow.values[0];
  { Top_Queue_21__io_enq_valid.values[0] = Top_SodorTile__io_tilelink_probe_rep_valid.values[0]; }
  T782.values[0] = !Top_Queue_21__maybe_full.values[0];
  { Top_Queue_21__io_enq_ready.values[0] = T782.values[0]; }
  { T783.values[0] = Top_Queue_21__io_enq_ready.values[0]&&Top_Queue_21__io_enq_valid.values[0]; }
  { Top_Queue_21__do_enq.values[0] = T783.values[0]&&T781.values[0]; }
  T784.values[0] = !Top_Queue_21__do_flow.values[0];
  T785.values[0] = !Top_Queue_21__maybe_full.values[0];
  T786.values[0] = !T785.values[0];
  { Top_Queue_21__io_deq_valid.values[0] = T786.values[0]; }
  { Top_hub__io_tiles_0_probe_rep_ready.values[0] = 0x1L; }
  { Top_Queue_21__io_deq_ready.values[0] = Top_hub__io_tiles_0_probe_rep_ready.values[0]; }
  { T787.values[0] = Top_Queue_21__io_deq_ready.values[0]&&Top_Queue_21__io_deq_valid.values[0]; }
  { Top_Queue_21__do_deq.values[0] = T787.values[0]&&T784.values[0]; }
  T788.values[0] = Top_Queue_21__do_enq.values[0] != Top_Queue_21__do_deq.values[0];
  { val_t __mask = -T788.values[0]; T789.values[0] = Top_Queue_21__maybe_full.values[0] ^ ((Top_Queue_21__maybe_full.values[0] ^ Top_Queue_21__do_enq.values[0]) & __mask); }
  { Top_Queue_21__maybe_full_shadow.values[0] = TERNARY(Top_Queue_21__reset.values[0], 0x0L, T789.values[0]); }
  { Top_Queue_21__io_enq_bits_global_xact_id.values[0] = Top_SodorTile__io_tilelink_probe_rep_bits_global_xact_id.values[0]; }
  { Top_Queue_21__io_enq_bits_p_type.values[0] = Top_SodorTile__io_tilelink_probe_rep_bits_p_type.values[0]; }
  { T791.values[0] = Top_Queue_21__io_enq_bits_global_xact_id.values[0] | Top_Queue_21__io_enq_bits_p_type.values[0] << 3; }
  { T794.values[0] = Top_SodorTile_cache_finish_queue__ram.get(Top_SodorTile_cache_finish_queue__deq_ptr.values[0], 0); }
  { T795.values[0] = T794.values[0]; }
  T795.values[0] = T795.values[0] & 7;
  { T796.values[0] = T795.values[0]; }
  T796.values[0] = T796.values[0] & 7;
  { Top_SodorTile_cache_finish_queue__io_deq_bits_global_xact_id.values[0] = T796.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_finish_bits_global_xact_id.values[0] = Top_SodorTile_cache_finish_queue__io_deq_bits_global_xact_id.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_finish_bits_global_xact_id.values[0] = Top_SodorTile_cache__io_mem_xact_finish_bits_global_xact_id.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_finish_bits_global_xact_id.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_finish_bits_global_xact_id.values[0]; }
  { Top_SodorTile__io_tilelink_xact_finish_bits_global_xact_id.values[0] = Top_SodorTile_arbiter__io_mem_xact_finish_bits_global_xact_id.values[0]; }
  { Top_Queue_19__io_enq_bits_global_xact_id.values[0] = Top_SodorTile__io_tilelink_xact_finish_bits_global_xact_id.values[0]; }
  { Top_Queue_19__do_flow.values[0] = 0x0L; }
  T797.values[0] = !Top_Queue_19__do_flow.values[0];
  T798.values[0] = !Top_SodorTile_cache_finish_queue__maybe_full.values[0];
  Top_SodorTile_cache_finish_queue__ptr_match.values[0] = Top_SodorTile_cache_finish_queue__enq_ptr.values[0] == Top_SodorTile_cache_finish_queue__deq_ptr.values[0];
  { Top_SodorTile_cache_finish_queue__empty.values[0] = Top_SodorTile_cache_finish_queue__ptr_match.values[0]&&T798.values[0]; }
  T799.values[0] = !Top_SodorTile_cache_finish_queue__empty.values[0];
  { Top_SodorTile_cache_finish_queue__io_deq_valid.values[0] = T799.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_finish_valid.values[0] = Top_SodorTile_cache_finish_queue__io_deq_valid.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_finish_valid.values[0] = Top_SodorTile_cache__io_mem_xact_finish_valid.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_finish_valid.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_finish_valid.values[0]; }
  { Top_SodorTile__io_tilelink_xact_finish_valid.values[0] = Top_SodorTile_arbiter__io_mem_xact_finish_valid.values[0]; }
  { Top_Queue_19__io_enq_valid.values[0] = Top_SodorTile__io_tilelink_xact_finish_valid.values[0]; }
  Top_Queue_19__ptr_match.values[0] = Top_Queue_19__enq_ptr.values[0] == Top_Queue_19__deq_ptr.values[0];
  { Top_Queue_19__full.values[0] = Top_Queue_19__ptr_match.values[0]&&Top_Queue_19__maybe_full.values[0]; }
  T800.values[0] = !Top_Queue_19__full.values[0];
  { Top_Queue_19__io_enq_ready.values[0] = T800.values[0]; }
  { T801.values[0] = Top_Queue_19__io_enq_ready.values[0]&&Top_Queue_19__io_enq_valid.values[0]; }
  { Top_Queue_19__do_enq.values[0] = T801.values[0]&&T797.values[0]; }
  { Top_Queue_19__reset.values[0] = reset.values[0]; }
  { T803.values[0] = Top_Queue_19__enq_ptr.values[0]+0x1L; }
  T803.values[0] = T803.values[0] & 1;
  { val_t __mask = -Top_Queue_19__do_enq.values[0]; T804.values[0] = Top_Queue_19__enq_ptr.values[0] ^ ((Top_Queue_19__enq_ptr.values[0] ^ T803.values[0]) & __mask); }
  { Top_Queue_19__enq_ptr_shadow.values[0] = TERNARY(Top_Queue_19__reset.values[0], 0x0L, T804.values[0]); }
  { T805.values[0] = Top_Queue_19__deq_ptr.values[0]+0x1L; }
  T805.values[0] = T805.values[0] & 1;
  T806.values[0] = !Top_Queue_19__do_flow.values[0];
  T807.values[0] = !Top_Queue_19__maybe_full.values[0];
  { Top_Queue_19__empty.values[0] = Top_Queue_19__ptr_match.values[0]&&T807.values[0]; }
  T808.values[0] = !Top_Queue_19__empty.values[0];
  { Top_Queue_19__io_deq_valid.values[0] = T808.values[0]; }
  { Top_hub__io_tiles_0_xact_finish_ready.values[0] = 0x1L; }
  { Top_Queue_19__io_deq_ready.values[0] = Top_hub__io_tiles_0_xact_finish_ready.values[0]; }
  { T809.values[0] = Top_Queue_19__io_deq_ready.values[0]&&Top_Queue_19__io_deq_valid.values[0]; }
  { Top_Queue_19__do_deq.values[0] = T809.values[0]&&T806.values[0]; }
  { val_t __mask = -Top_Queue_19__do_deq.values[0]; T810.values[0] = Top_Queue_19__deq_ptr.values[0] ^ ((Top_Queue_19__deq_ptr.values[0] ^ T805.values[0]) & __mask); }
  { Top_Queue_19__deq_ptr_shadow.values[0] = TERNARY(Top_Queue_19__reset.values[0], 0x0L, T810.values[0]); }
  T811.values[0] = Top_Queue_19__do_enq.values[0] != Top_Queue_19__do_deq.values[0];
  { val_t __mask = -T811.values[0]; T812.values[0] = Top_Queue_19__maybe_full.values[0] ^ ((Top_Queue_19__maybe_full.values[0] ^ Top_Queue_19__do_enq.values[0]) & __mask); }
  { Top_Queue_19__maybe_full_shadow.values[0] = TERNARY(Top_Queue_19__reset.values[0], 0x0L, T812.values[0]); }
  { Top_Queue_18__reset.values[0] = reset.values[0]; }
  { Top_Queue_18__do_flow.values[0] = 0x0L; }
  T813.values[0] = !Top_Queue_18__do_flow.values[0];
  { Top_hub__mem_idx.values[0] = R5084.values[0]; }
  { T814.values[0] = Top_hub__mem_idx.values[0]; }
  { T815.values[0] = T814.values[0]; }
  T816.values[0] = 0x1L << T815.values[0];
  { T817.values[0] = T816.values[0]; }
  T817.values[0] = T817.values[0] & 255;
  T818.values[0] = (T817.values[0] >> 7) & 1;
  { T819.values[0] = T818.values[0]; }
  { T820.values[0] = -T819.values[0]; }
  T820.values[0] = T820.values[0] & 3;
  { Top_hub__init_tile_id_arr_7.values[0] = Top_hub_XactTracker_7__io_init_tile_id.values[0]; }
  { T821.values[0] = Top_hub__init_tile_id_arr_7.values[0]&T820.values[0]; }
  T822.values[0] = (T817.values[0] >> 6) & 1;
  { T823.values[0] = T822.values[0]; }
  { T824.values[0] = -T823.values[0]; }
  T824.values[0] = T824.values[0] & 3;
  { Top_hub__init_tile_id_arr_6.values[0] = Top_hub_XactTracker_6__io_init_tile_id.values[0]; }
  { T825.values[0] = Top_hub__init_tile_id_arr_6.values[0]&T824.values[0]; }
  T826.values[0] = (T817.values[0] >> 5) & 1;
  { T827.values[0] = T826.values[0]; }
  { T828.values[0] = -T827.values[0]; }
  T828.values[0] = T828.values[0] & 3;
  { Top_hub__init_tile_id_arr_5.values[0] = Top_hub_XactTracker_5__io_init_tile_id.values[0]; }
  { T829.values[0] = Top_hub__init_tile_id_arr_5.values[0]&T828.values[0]; }
  T830.values[0] = (T817.values[0] >> 4) & 1;
  { T831.values[0] = T830.values[0]; }
  { T832.values[0] = -T831.values[0]; }
  T832.values[0] = T832.values[0] & 3;
  { Top_hub__init_tile_id_arr_4.values[0] = Top_hub_XactTracker_4__io_init_tile_id.values[0]; }
  { T833.values[0] = Top_hub__init_tile_id_arr_4.values[0]&T832.values[0]; }
  T834.values[0] = (T817.values[0] >> 3) & 1;
  { T835.values[0] = T834.values[0]; }
  { T836.values[0] = -T835.values[0]; }
  T836.values[0] = T836.values[0] & 3;
  { Top_hub__init_tile_id_arr_3.values[0] = Top_hub_XactTracker_3__io_init_tile_id.values[0]; }
  { T837.values[0] = Top_hub__init_tile_id_arr_3.values[0]&T836.values[0]; }
  T838.values[0] = (T817.values[0] >> 2) & 1;
  { T839.values[0] = T838.values[0]; }
  { T840.values[0] = -T839.values[0]; }
  T840.values[0] = T840.values[0] & 3;
  { Top_hub__init_tile_id_arr_2.values[0] = Top_hub_XactTracker_2__io_init_tile_id.values[0]; }
  { T841.values[0] = Top_hub__init_tile_id_arr_2.values[0]&T840.values[0]; }
  T842.values[0] = (T817.values[0] >> 1) & 1;
  { T843.values[0] = T842.values[0]; }
  { T844.values[0] = -T843.values[0]; }
  T844.values[0] = T844.values[0] & 3;
  { Top_hub__init_tile_id_arr_1.values[0] = Top_hub_XactTracker_1__io_init_tile_id.values[0]; }
  { T845.values[0] = Top_hub__init_tile_id_arr_1.values[0]&T844.values[0]; }
  T846.values[0] = (T817.values[0] >> 0) & 1;
  { T847.values[0] = T846.values[0]; }
  { T848.values[0] = -T847.values[0]; }
  T848.values[0] = T848.values[0] & 3;
  { Top_hub__init_tile_id_arr_0.values[0] = Top_hub_XactTracker__io_init_tile_id.values[0]; }
  { T849.values[0] = Top_hub__init_tile_id_arr_0.values[0]&T848.values[0]; }
  { T850.values[0] = T849.values[0]|T845.values[0]; }
  { T851.values[0] = T850.values[0]|T841.values[0]; }
  { T852.values[0] = T851.values[0]|T837.values[0]; }
  { T853.values[0] = T852.values[0]|T833.values[0]; }
  { T854.values[0] = T853.values[0]|T829.values[0]; }
  { T855.values[0] = T854.values[0]|T825.values[0]; }
  { T856.values[0] = T855.values[0]|T821.values[0]; }
  T857.values[0] = 0x0L == T856.values[0];
  { Top_hub__io_mem_resp_valid.values[0] = R5082.values[0]; }
  { T858.values[0] = Top_hub__io_mem_resp_valid.values[0]&&T857.values[0]; }
  T859.values[0] = Top_hub_XactTracker__state.values[0] == 0x1L;
  { Top_hub_XactTracker__io_send_x_rep_ack.values[0] = T859.values[0]; }
  { Top_hub__send_x_rep_ack_arr_0.values[0] = Top_hub_XactTracker__io_send_x_rep_ack.values[0]; }
  T860.values[0] = Top_hub_XactTracker_1__state.values[0] == 0x1L;
  { Top_hub_XactTracker_1__io_send_x_rep_ack.values[0] = T860.values[0]; }
  { Top_hub__send_x_rep_ack_arr_1.values[0] = Top_hub_XactTracker_1__io_send_x_rep_ack.values[0]; }
  T861.values[0] = Top_hub_XactTracker_2__state.values[0] == 0x1L;
  { Top_hub_XactTracker_2__io_send_x_rep_ack.values[0] = T861.values[0]; }
  { Top_hub__send_x_rep_ack_arr_2.values[0] = Top_hub_XactTracker_2__io_send_x_rep_ack.values[0]; }
  T862.values[0] = Top_hub_XactTracker_3__state.values[0] == 0x1L;
  { Top_hub_XactTracker_3__io_send_x_rep_ack.values[0] = T862.values[0]; }
  { Top_hub__send_x_rep_ack_arr_3.values[0] = Top_hub_XactTracker_3__io_send_x_rep_ack.values[0]; }
  T863.values[0] = Top_hub_XactTracker_4__state.values[0] == 0x1L;
  { Top_hub_XactTracker_4__io_send_x_rep_ack.values[0] = T863.values[0]; }
  { Top_hub__send_x_rep_ack_arr_4.values[0] = Top_hub_XactTracker_4__io_send_x_rep_ack.values[0]; }
  T864.values[0] = Top_hub_XactTracker_5__state.values[0] == 0x1L;
  { Top_hub_XactTracker_5__io_send_x_rep_ack.values[0] = T864.values[0]; }
  { Top_hub__send_x_rep_ack_arr_5.values[0] = Top_hub_XactTracker_5__io_send_x_rep_ack.values[0]; }
  T865.values[0] = Top_hub_XactTracker_6__state.values[0] == 0x1L;
  { Top_hub_XactTracker_6__io_send_x_rep_ack.values[0] = T865.values[0]; }
  { Top_hub__send_x_rep_ack_arr_6.values[0] = Top_hub_XactTracker_6__io_send_x_rep_ack.values[0]; }
  T866.values[0] = Top_hub_XactTracker_7__state.values[0] == 0x1L;
  { Top_hub_XactTracker_7__io_send_x_rep_ack.values[0] = T866.values[0]; }
  { Top_hub__send_x_rep_ack_arr_7.values[0] = Top_hub_XactTracker_7__io_send_x_rep_ack.values[0]; }
  { T867.values[0] = Top_hub__send_x_rep_ack_arr_6.values[0] | Top_hub__send_x_rep_ack_arr_7.values[0] << 1; }
  { T868.values[0] = Top_hub__send_x_rep_ack_arr_5.values[0] | T867.values[0] << 1; }
  { T869.values[0] = Top_hub__send_x_rep_ack_arr_4.values[0] | T868.values[0] << 1; }
  { T870.values[0] = Top_hub__send_x_rep_ack_arr_3.values[0] | T869.values[0] << 1; }
  { T871.values[0] = Top_hub__send_x_rep_ack_arr_2.values[0] | T870.values[0] << 1; }
  { T872.values[0] = Top_hub__send_x_rep_ack_arr_1.values[0] | T871.values[0] << 1; }
  { T873.values[0] = Top_hub__send_x_rep_ack_arr_0.values[0] | T872.values[0] << 1; }
  T874.values[0] = (T873.values[0]) != 0;
  { T875.values[0] = Top_hub__send_x_rep_ack_arr_6.values[0] | Top_hub__send_x_rep_ack_arr_7.values[0] << 1; }
  { T876.values[0] = Top_hub__send_x_rep_ack_arr_5.values[0] | T875.values[0] << 1; }
  { T877.values[0] = Top_hub__send_x_rep_ack_arr_4.values[0] | T876.values[0] << 1; }
  { T878.values[0] = Top_hub__send_x_rep_ack_arr_3.values[0] | T877.values[0] << 1; }
  { T879.values[0] = Top_hub__send_x_rep_ack_arr_2.values[0] | T878.values[0] << 1; }
  { T880.values[0] = Top_hub__send_x_rep_ack_arr_1.values[0] | T879.values[0] << 1; }
  { T881.values[0] = Top_hub__send_x_rep_ack_arr_0.values[0] | T880.values[0] << 1; }
  T882.values[0] = (T881.values[0] >> 6) & 1;
  { val_t __mask = -T882.values[0]; T883.values[0] = 0x7L ^ ((0x7L ^ 0x6L) & __mask); }
  T884.values[0] = (T881.values[0] >> 5) & 1;
  { val_t __mask = -T884.values[0]; T885.values[0] = T883.values[0] ^ ((T883.values[0] ^ 0x5L) & __mask); }
  T886.values[0] = (T881.values[0] >> 4) & 1;
  { val_t __mask = -T886.values[0]; T887.values[0] = T885.values[0] ^ ((T885.values[0] ^ 0x4L) & __mask); }
  T888.values[0] = (T881.values[0] >> 3) & 1;
  { val_t __mask = -T888.values[0]; T889.values[0] = T887.values[0] ^ ((T887.values[0] ^ 0x3L) & __mask); }
  T890.values[0] = (T881.values[0] >> 2) & 1;
  { val_t __mask = -T890.values[0]; T891.values[0] = T889.values[0] ^ ((T889.values[0] ^ 0x2L) & __mask); }
  T892.values[0] = (T881.values[0] >> 1) & 1;
  { val_t __mask = -T892.values[0]; T893.values[0] = T891.values[0] ^ ((T891.values[0] ^ 0x1L) & __mask); }
  T894.values[0] = (T881.values[0] >> 0) & 1;
  { val_t __mask = -T894.values[0]; Top_hub__ack_idx.values[0] = T893.values[0] ^ ((T893.values[0] ^ 0x0L) & __mask); }
  { T895.values[0] = Top_hub__ack_idx.values[0]; }
  T896.values[0] = 0x1L << T895.values[0];
  { T897.values[0] = T896.values[0]; }
  T897.values[0] = T897.values[0] & 255;
  T898.values[0] = (T897.values[0] >> 7) & 1;
  { T899.values[0] = T898.values[0]; }
  { T900.values[0] = -T899.values[0]; }
  T900.values[0] = T900.values[0] & 3;
  { T901.values[0] = Top_hub__init_tile_id_arr_7.values[0]&T900.values[0]; }
  T902.values[0] = (T897.values[0] >> 6) & 1;
  { T903.values[0] = T902.values[0]; }
  { T904.values[0] = -T903.values[0]; }
  T904.values[0] = T904.values[0] & 3;
  { T905.values[0] = Top_hub__init_tile_id_arr_6.values[0]&T904.values[0]; }
  T906.values[0] = (T897.values[0] >> 5) & 1;
  { T907.values[0] = T906.values[0]; }
  { T908.values[0] = -T907.values[0]; }
  T908.values[0] = T908.values[0] & 3;
  { T909.values[0] = Top_hub__init_tile_id_arr_5.values[0]&T908.values[0]; }
  T910.values[0] = (T897.values[0] >> 4) & 1;
  { T911.values[0] = T910.values[0]; }
  { T912.values[0] = -T911.values[0]; }
  T912.values[0] = T912.values[0] & 3;
  { T913.values[0] = Top_hub__init_tile_id_arr_4.values[0]&T912.values[0]; }
  T914.values[0] = (T897.values[0] >> 3) & 1;
  { T915.values[0] = T914.values[0]; }
  { T916.values[0] = -T915.values[0]; }
  T916.values[0] = T916.values[0] & 3;
  { T917.values[0] = Top_hub__init_tile_id_arr_3.values[0]&T916.values[0]; }
  T918.values[0] = (T897.values[0] >> 2) & 1;
  { T919.values[0] = T918.values[0]; }
  { T920.values[0] = -T919.values[0]; }
  T920.values[0] = T920.values[0] & 3;
  { T921.values[0] = Top_hub__init_tile_id_arr_2.values[0]&T920.values[0]; }
  T922.values[0] = (T897.values[0] >> 1) & 1;
  { T923.values[0] = T922.values[0]; }
  { T924.values[0] = -T923.values[0]; }
  T924.values[0] = T924.values[0] & 3;
  { T925.values[0] = Top_hub__init_tile_id_arr_1.values[0]&T924.values[0]; }
  T926.values[0] = (T897.values[0] >> 0) & 1;
  { T927.values[0] = T926.values[0]; }
  { T928.values[0] = -T927.values[0]; }
  T928.values[0] = T928.values[0] & 3;
  { T929.values[0] = Top_hub__init_tile_id_arr_0.values[0]&T928.values[0]; }
  { T930.values[0] = T929.values[0]|T925.values[0]; }
  { T931.values[0] = T930.values[0]|T921.values[0]; }
  { T932.values[0] = T931.values[0]|T917.values[0]; }
  { T933.values[0] = T932.values[0]|T913.values[0]; }
  { T934.values[0] = T933.values[0]|T909.values[0]; }
  { T935.values[0] = T934.values[0]|T905.values[0]; }
  { T936.values[0] = T935.values[0]|T901.values[0]; }
  T937.values[0] = 0x0L == T936.values[0];
  T938.values[0] = !T858.values[0];
  { T939.values[0] = T938.values[0]&&T937.values[0]; }
  { val_t __mask = -T939.values[0]; T940.values[0] = T858.values[0] ^ ((T858.values[0] ^ T874.values[0]) & __mask); }
  { Top_hub__io_tiles_0_xact_rep_valid.values[0] = T940.values[0]; }
  { Top_Queue_18__io_enq_valid.values[0] = Top_hub__io_tiles_0_xact_rep_valid.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_rep_ready.values[0] = 0x1L; }
  { Top_SodorTile__io_tilelink_xact_rep_ready.values[0] = Top_SodorTile_arbiter__io_mem_xact_rep_ready.values[0]; }
  { Top_Queue_18__io_deq_ready.values[0] = Top_SodorTile__io_tilelink_xact_rep_ready.values[0]; }
  T941.values[0] = !Top_Queue_18__maybe_full.values[0];
  { T942.values[0] = T941.values[0]||Top_Queue_18__io_deq_ready.values[0]; }
  { Top_Queue_18__io_enq_ready.values[0] = T942.values[0]; }
  { T943.values[0] = Top_Queue_18__io_enq_ready.values[0]&&Top_Queue_18__io_enq_valid.values[0]; }
  { Top_Queue_18__do_enq.values[0] = T943.values[0]&&T813.values[0]; }
  T944.values[0] = !Top_Queue_18__do_flow.values[0];
  T945.values[0] = !Top_Queue_18__maybe_full.values[0];
  T946.values[0] = !T945.values[0];
  { Top_Queue_18__io_deq_valid.values[0] = T946.values[0]; }
  { T947.values[0] = Top_Queue_18__io_deq_ready.values[0]&&Top_Queue_18__io_deq_valid.values[0]; }
  { Top_Queue_18__do_deq.values[0] = T947.values[0]&&T944.values[0]; }
  T948.values[0] = Top_Queue_18__do_enq.values[0] != Top_Queue_18__do_deq.values[0];
  { val_t __mask = -T948.values[0]; T949.values[0] = Top_Queue_18__maybe_full.values[0] ^ ((Top_Queue_18__maybe_full.values[0] ^ Top_Queue_18__do_enq.values[0]) & __mask); }
  { Top_Queue_18__maybe_full_shadow.values[0] = TERNARY(Top_Queue_18__reset.values[0], 0x0L, T949.values[0]); }
  { Top_hub__io_tiles_0_xact_rep_bits_require_ack.values[0] = 0x1L; }
  { Top_Queue_18__io_enq_bits_require_ack.values[0] = Top_hub__io_tiles_0_xact_rep_bits_require_ack.values[0]; }
  { val_t __mask = -T858.values[0]; T951.values[0] = 0x0L ^ ((0x0L ^ Top_hub__mem_idx.values[0]) & __mask); }
  { T952.values[0] = Top_hub__ack_idx.values[0] | 0x0L << 3; }
  { val_t __mask = -T938.values[0]; T953.values[0] = T951.values[0] ^ ((T951.values[0] ^ T952.values[0]) & __mask); }
  { T954.values[0] = T953.values[0]; }
  T954.values[0] = T954.values[0] & 7;
  { Top_hub__io_tiles_0_xact_rep_bits_global_xact_id.values[0] = T954.values[0]; }
  { Top_Queue_18__io_enq_bits_global_xact_id.values[0] = Top_hub__io_tiles_0_xact_rep_bits_global_xact_id.values[0]; }
  { T955.values[0] = Top_hub__mem_idx.values[0]; }
  { T956.values[0] = T955.values[0]; }
  T957.values[0] = 0x1L << T956.values[0];
  { T958.values[0] = T957.values[0]; }
  T958.values[0] = T958.values[0] & 255;
  T959.values[0] = (T958.values[0] >> 7) & 1;
  { T960.values[0] = T959.values[0]; }
  { T961.values[0] = -T960.values[0]; }
  T961.values[0] = T961.values[0] & 31;
  { Top_hub_XactTracker_7__io_tile_xact_id.values[0] = Top_hub_XactTracker_7__tile_xact_id_.values[0]; }
  { Top_hub__tile_xact_id_arr_7.values[0] = Top_hub_XactTracker_7__io_tile_xact_id.values[0]; }
  { T962.values[0] = Top_hub__tile_xact_id_arr_7.values[0]&T961.values[0]; }
  T963.values[0] = (T958.values[0] >> 6) & 1;
  { T964.values[0] = T963.values[0]; }
  { T965.values[0] = -T964.values[0]; }
  T965.values[0] = T965.values[0] & 31;
  { Top_hub_XactTracker_6__io_tile_xact_id.values[0] = Top_hub_XactTracker_6__tile_xact_id_.values[0]; }
  { Top_hub__tile_xact_id_arr_6.values[0] = Top_hub_XactTracker_6__io_tile_xact_id.values[0]; }
  { T966.values[0] = Top_hub__tile_xact_id_arr_6.values[0]&T965.values[0]; }
  T967.values[0] = (T958.values[0] >> 5) & 1;
  { T968.values[0] = T967.values[0]; }
  { T969.values[0] = -T968.values[0]; }
  T969.values[0] = T969.values[0] & 31;
  { Top_hub_XactTracker_5__io_tile_xact_id.values[0] = Top_hub_XactTracker_5__tile_xact_id_.values[0]; }
  { Top_hub__tile_xact_id_arr_5.values[0] = Top_hub_XactTracker_5__io_tile_xact_id.values[0]; }
  { T970.values[0] = Top_hub__tile_xact_id_arr_5.values[0]&T969.values[0]; }
  T971.values[0] = (T958.values[0] >> 4) & 1;
  { T972.values[0] = T971.values[0]; }
  { T973.values[0] = -T972.values[0]; }
  T973.values[0] = T973.values[0] & 31;
  { Top_hub_XactTracker_4__io_tile_xact_id.values[0] = Top_hub_XactTracker_4__tile_xact_id_.values[0]; }
  { Top_hub__tile_xact_id_arr_4.values[0] = Top_hub_XactTracker_4__io_tile_xact_id.values[0]; }
  { T974.values[0] = Top_hub__tile_xact_id_arr_4.values[0]&T973.values[0]; }
  T975.values[0] = (T958.values[0] >> 3) & 1;
  { T976.values[0] = T975.values[0]; }
  { T977.values[0] = -T976.values[0]; }
  T977.values[0] = T977.values[0] & 31;
  { Top_hub_XactTracker_3__io_tile_xact_id.values[0] = Top_hub_XactTracker_3__tile_xact_id_.values[0]; }
  { Top_hub__tile_xact_id_arr_3.values[0] = Top_hub_XactTracker_3__io_tile_xact_id.values[0]; }
  { T978.values[0] = Top_hub__tile_xact_id_arr_3.values[0]&T977.values[0]; }
  T979.values[0] = (T958.values[0] >> 2) & 1;
  { T980.values[0] = T979.values[0]; }
  { T981.values[0] = -T980.values[0]; }
  T981.values[0] = T981.values[0] & 31;
  { Top_hub_XactTracker_2__io_tile_xact_id.values[0] = Top_hub_XactTracker_2__tile_xact_id_.values[0]; }
  { Top_hub__tile_xact_id_arr_2.values[0] = Top_hub_XactTracker_2__io_tile_xact_id.values[0]; }
  { T982.values[0] = Top_hub__tile_xact_id_arr_2.values[0]&T981.values[0]; }
  T983.values[0] = (T958.values[0] >> 1) & 1;
  { T984.values[0] = T983.values[0]; }
  { T985.values[0] = -T984.values[0]; }
  T985.values[0] = T985.values[0] & 31;
  { Top_hub_XactTracker_1__io_tile_xact_id.values[0] = Top_hub_XactTracker_1__tile_xact_id_.values[0]; }
  { Top_hub__tile_xact_id_arr_1.values[0] = Top_hub_XactTracker_1__io_tile_xact_id.values[0]; }
  { T986.values[0] = Top_hub__tile_xact_id_arr_1.values[0]&T985.values[0]; }
  T987.values[0] = (T958.values[0] >> 0) & 1;
  { T988.values[0] = T987.values[0]; }
  { T989.values[0] = -T988.values[0]; }
  T989.values[0] = T989.values[0] & 31;
  { Top_hub_XactTracker__io_tile_xact_id.values[0] = Top_hub_XactTracker__tile_xact_id_.values[0]; }
  { Top_hub__tile_xact_id_arr_0.values[0] = Top_hub_XactTracker__io_tile_xact_id.values[0]; }
  { T990.values[0] = Top_hub__tile_xact_id_arr_0.values[0]&T989.values[0]; }
  { T991.values[0] = T990.values[0]|T986.values[0]; }
  { T992.values[0] = T991.values[0]|T982.values[0]; }
  { T993.values[0] = T992.values[0]|T978.values[0]; }
  { T994.values[0] = T993.values[0]|T974.values[0]; }
  { T995.values[0] = T994.values[0]|T970.values[0]; }
  { T996.values[0] = T995.values[0]|T966.values[0]; }
  { T997.values[0] = T996.values[0]|T962.values[0]; }
  { val_t __mask = -T858.values[0]; T998.values[0] = 0x0L ^ ((0x0L ^ T997.values[0]) & __mask); }
  { T999.values[0] = -T899.values[0]; }
  T999.values[0] = T999.values[0] & 31;
  { T1000.values[0] = Top_hub__tile_xact_id_arr_7.values[0]&T999.values[0]; }
  { T1001.values[0] = -T903.values[0]; }
  T1001.values[0] = T1001.values[0] & 31;
  { T1002.values[0] = Top_hub__tile_xact_id_arr_6.values[0]&T1001.values[0]; }
  { T1003.values[0] = -T907.values[0]; }
  T1003.values[0] = T1003.values[0] & 31;
  { T1004.values[0] = Top_hub__tile_xact_id_arr_5.values[0]&T1003.values[0]; }
  { T1005.values[0] = -T911.values[0]; }
  T1005.values[0] = T1005.values[0] & 31;
  { T1006.values[0] = Top_hub__tile_xact_id_arr_4.values[0]&T1005.values[0]; }
  { T1007.values[0] = -T915.values[0]; }
  T1007.values[0] = T1007.values[0] & 31;
  { T1008.values[0] = Top_hub__tile_xact_id_arr_3.values[0]&T1007.values[0]; }
  { T1009.values[0] = -T919.values[0]; }
  T1009.values[0] = T1009.values[0] & 31;
  { T1010.values[0] = Top_hub__tile_xact_id_arr_2.values[0]&T1009.values[0]; }
  { T1011.values[0] = -T923.values[0]; }
  T1011.values[0] = T1011.values[0] & 31;
  { T1012.values[0] = Top_hub__tile_xact_id_arr_1.values[0]&T1011.values[0]; }
  { T1013.values[0] = -T927.values[0]; }
  T1013.values[0] = T1013.values[0] & 31;
  { T1014.values[0] = Top_hub__tile_xact_id_arr_0.values[0]&T1013.values[0]; }
  { T1015.values[0] = T1014.values[0]|T1012.values[0]; }
  { T1016.values[0] = T1015.values[0]|T1010.values[0]; }
  { T1017.values[0] = T1016.values[0]|T1008.values[0]; }
  { T1018.values[0] = T1017.values[0]|T1006.values[0]; }
  { T1019.values[0] = T1018.values[0]|T1004.values[0]; }
  { T1020.values[0] = T1019.values[0]|T1002.values[0]; }
  { T1021.values[0] = T1020.values[0]|T1000.values[0]; }
  { val_t __mask = -T938.values[0]; T1022.values[0] = T998.values[0] ^ ((T998.values[0] ^ T1021.values[0]) & __mask); }
  { Top_hub__io_tiles_0_xact_rep_bits_tile_xact_id.values[0] = T1022.values[0]; }
  { Top_Queue_18__io_enq_bits_tile_xact_id.values[0] = Top_hub__io_tiles_0_xact_rep_bits_tile_xact_id.values[0]; }
  { T1023.values[0] = Top_hub__mem_idx.values[0]; }
  { T1024.values[0] = T1023.values[0]; }
  T1025.values[0] = 0x1L << T1024.values[0];
  { T1026.values[0] = T1025.values[0]; }
  T1026.values[0] = T1026.values[0] & 255;
  T1027.values[0] = (T1026.values[0] >> 7) & 1;
  { T1028.values[0] = T1027.values[0]; }
  { T1029.values[0] = -T1028.values[0]; }
  T1029.values[0] = T1029.values[0] & 3;
  { Top_hub_XactTracker_7__io_x_type.values[0] = Top_hub_XactTracker_7__x_type_.values[0]; }
  { Top_hub__x_type_arr_7.values[0] = Top_hub_XactTracker_7__io_x_type.values[0]; }
  { T1030.values[0] = Top_hub__x_type_arr_7.values[0]&T1029.values[0]; }
  T1031.values[0] = (T1026.values[0] >> 6) & 1;
  { T1032.values[0] = T1031.values[0]; }
  { T1033.values[0] = -T1032.values[0]; }
  T1033.values[0] = T1033.values[0] & 3;
  { Top_hub_XactTracker_6__io_x_type.values[0] = Top_hub_XactTracker_6__x_type_.values[0]; }
  { Top_hub__x_type_arr_6.values[0] = Top_hub_XactTracker_6__io_x_type.values[0]; }
  { T1034.values[0] = Top_hub__x_type_arr_6.values[0]&T1033.values[0]; }
  T1035.values[0] = (T1026.values[0] >> 5) & 1;
  { T1036.values[0] = T1035.values[0]; }
  { T1037.values[0] = -T1036.values[0]; }
  T1037.values[0] = T1037.values[0] & 3;
  { Top_hub_XactTracker_5__io_x_type.values[0] = Top_hub_XactTracker_5__x_type_.values[0]; }
  { Top_hub__x_type_arr_5.values[0] = Top_hub_XactTracker_5__io_x_type.values[0]; }
  { T1038.values[0] = Top_hub__x_type_arr_5.values[0]&T1037.values[0]; }
  T1039.values[0] = (T1026.values[0] >> 4) & 1;
  { T1040.values[0] = T1039.values[0]; }
  { T1041.values[0] = -T1040.values[0]; }
  T1041.values[0] = T1041.values[0] & 3;
  { Top_hub_XactTracker_4__io_x_type.values[0] = Top_hub_XactTracker_4__x_type_.values[0]; }
  { Top_hub__x_type_arr_4.values[0] = Top_hub_XactTracker_4__io_x_type.values[0]; }
  { T1042.values[0] = Top_hub__x_type_arr_4.values[0]&T1041.values[0]; }
  T1043.values[0] = (T1026.values[0] >> 3) & 1;
  { T1044.values[0] = T1043.values[0]; }
  { T1045.values[0] = -T1044.values[0]; }
  T1045.values[0] = T1045.values[0] & 3;
  { Top_hub_XactTracker_3__io_x_type.values[0] = Top_hub_XactTracker_3__x_type_.values[0]; }
  { Top_hub__x_type_arr_3.values[0] = Top_hub_XactTracker_3__io_x_type.values[0]; }
  { T1046.values[0] = Top_hub__x_type_arr_3.values[0]&T1045.values[0]; }
  T1047.values[0] = (T1026.values[0] >> 2) & 1;
  { T1048.values[0] = T1047.values[0]; }
  { T1049.values[0] = -T1048.values[0]; }
  T1049.values[0] = T1049.values[0] & 3;
  { Top_hub_XactTracker_2__io_x_type.values[0] = Top_hub_XactTracker_2__x_type_.values[0]; }
  { Top_hub__x_type_arr_2.values[0] = Top_hub_XactTracker_2__io_x_type.values[0]; }
  { T1050.values[0] = Top_hub__x_type_arr_2.values[0]&T1049.values[0]; }
  T1051.values[0] = (T1026.values[0] >> 1) & 1;
  { T1052.values[0] = T1051.values[0]; }
  { T1053.values[0] = -T1052.values[0]; }
  T1053.values[0] = T1053.values[0] & 3;
  { Top_hub_XactTracker_1__io_x_type.values[0] = Top_hub_XactTracker_1__x_type_.values[0]; }
  { Top_hub__x_type_arr_1.values[0] = Top_hub_XactTracker_1__io_x_type.values[0]; }
  { T1054.values[0] = Top_hub__x_type_arr_1.values[0]&T1053.values[0]; }
  T1055.values[0] = (T1026.values[0] >> 0) & 1;
  { T1056.values[0] = T1055.values[0]; }
  { T1057.values[0] = -T1056.values[0]; }
  T1057.values[0] = T1057.values[0] & 3;
  { Top_hub_XactTracker__io_x_type.values[0] = Top_hub_XactTracker__x_type_.values[0]; }
  { Top_hub__x_type_arr_0.values[0] = Top_hub_XactTracker__io_x_type.values[0]; }
  { T1058.values[0] = Top_hub__x_type_arr_0.values[0]&T1057.values[0]; }
  { T1059.values[0] = T1058.values[0]|T1054.values[0]; }
  { T1060.values[0] = T1059.values[0]|T1050.values[0]; }
  { T1061.values[0] = T1060.values[0]|T1046.values[0]; }
  { T1062.values[0] = T1061.values[0]|T1042.values[0]; }
  { T1063.values[0] = T1062.values[0]|T1038.values[0]; }
  { T1064.values[0] = T1063.values[0]|T1034.values[0]; }
  { T1065.values[0] = T1064.values[0]|T1030.values[0]; }
  { T1066.values[0] = T1065.values[0]; }
  T1067.values[0] = T1066.values[0] == 0x3L;
  { val_t __mask = -T1067.values[0]; T1068.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  T1069.values[0] = T1066.values[0] == 0x2L;
  { val_t __mask = -T1069.values[0]; T1070.values[0] = T1068.values[0] ^ ((T1068.values[0] ^ 0x2L) & __mask); }
  T1071.values[0] = T1066.values[0] == 0x1L;
  { val_t __mask = -T1071.values[0]; T1072.values[0] = T1070.values[0] ^ ((T1070.values[0] ^ 0x1L) & __mask); }
  { T1073.values[0] = Top_hub__mem_idx.values[0]; }
  { T1074.values[0] = T1073.values[0]; }
  T1075.values[0] = 0x1L << T1074.values[0];
  { T1076.values[0] = T1075.values[0]; }
  T1076.values[0] = T1076.values[0] & 255;
  T1077.values[0] = (T1076.values[0] >> 7) & 1;
  { T1078.values[0] = T1077.values[0]; }
  { T1079.values[0] = -T1078.values[0]; }
  T1079.values[0] = T1079.values[0] & 3;
  { Top_hub__sh_count_arr_7.values[0] = 0x2L; }
  { T1080.values[0] = Top_hub__sh_count_arr_7.values[0]&T1079.values[0]; }
  T1081.values[0] = (T1076.values[0] >> 6) & 1;
  { T1082.values[0] = T1081.values[0]; }
  { T1083.values[0] = -T1082.values[0]; }
  T1083.values[0] = T1083.values[0] & 3;
  { Top_hub__sh_count_arr_6.values[0] = 0x2L; }
  { T1084.values[0] = Top_hub__sh_count_arr_6.values[0]&T1083.values[0]; }
  T1085.values[0] = (T1076.values[0] >> 5) & 1;
  { T1086.values[0] = T1085.values[0]; }
  { T1087.values[0] = -T1086.values[0]; }
  T1087.values[0] = T1087.values[0] & 3;
  { Top_hub__sh_count_arr_5.values[0] = 0x2L; }
  { T1088.values[0] = Top_hub__sh_count_arr_5.values[0]&T1087.values[0]; }
  T1089.values[0] = (T1076.values[0] >> 4) & 1;
  { T1090.values[0] = T1089.values[0]; }
  { T1091.values[0] = -T1090.values[0]; }
  T1091.values[0] = T1091.values[0] & 3;
  { Top_hub__sh_count_arr_4.values[0] = 0x2L; }
  { T1092.values[0] = Top_hub__sh_count_arr_4.values[0]&T1091.values[0]; }
  T1093.values[0] = (T1076.values[0] >> 3) & 1;
  { T1094.values[0] = T1093.values[0]; }
  { T1095.values[0] = -T1094.values[0]; }
  T1095.values[0] = T1095.values[0] & 3;
  { Top_hub__sh_count_arr_3.values[0] = 0x2L; }
  { T1096.values[0] = Top_hub__sh_count_arr_3.values[0]&T1095.values[0]; }
  T1097.values[0] = (T1076.values[0] >> 2) & 1;
  { T1098.values[0] = T1097.values[0]; }
  { T1099.values[0] = -T1098.values[0]; }
  T1099.values[0] = T1099.values[0] & 3;
  { Top_hub__sh_count_arr_2.values[0] = 0x2L; }
  { T1100.values[0] = Top_hub__sh_count_arr_2.values[0]&T1099.values[0]; }
  T1101.values[0] = (T1076.values[0] >> 1) & 1;
  { T1102.values[0] = T1101.values[0]; }
  { T1103.values[0] = -T1102.values[0]; }
  T1103.values[0] = T1103.values[0] & 3;
  { Top_hub__sh_count_arr_1.values[0] = 0x2L; }
  { T1104.values[0] = Top_hub__sh_count_arr_1.values[0]&T1103.values[0]; }
  T1105.values[0] = (T1076.values[0] >> 0) & 1;
  { T1106.values[0] = T1105.values[0]; }
  { T1107.values[0] = -T1106.values[0]; }
  T1107.values[0] = T1107.values[0] & 3;
  { Top_hub__sh_count_arr_0.values[0] = 0x2L; }
  { T1108.values[0] = Top_hub__sh_count_arr_0.values[0]&T1107.values[0]; }
  { T1109.values[0] = T1108.values[0]|T1104.values[0]; }
  { T1110.values[0] = T1109.values[0]|T1100.values[0]; }
  { T1111.values[0] = T1110.values[0]|T1096.values[0]; }
  { T1112.values[0] = T1111.values[0]|T1092.values[0]; }
  { T1113.values[0] = T1112.values[0]|T1088.values[0]; }
  { T1114.values[0] = T1113.values[0]|T1084.values[0]; }
  { T1115.values[0] = T1114.values[0]|T1080.values[0]; }
  { T1116.values[0] = T1115.values[0]; }
  T1117.values[0] = T1116.values[0]>0x0L;
  { val_t __mask = -T1117.values[0]; T1118.values[0] = 0x1L ^ ((0x1L ^ 0x0L) & __mask); }
  T1119.values[0] = T1066.values[0] == 0x0L;
  { val_t __mask = -T1119.values[0]; T1120.values[0] = T1072.values[0] ^ ((T1072.values[0] ^ T1118.values[0]) & __mask); }
  { val_t __mask = -T858.values[0]; T1121.values[0] = 0x0L ^ ((0x0L ^ T1120.values[0]) & __mask); }
  { T1122.values[0] = -T899.values[0]; }
  T1122.values[0] = T1122.values[0] & 3;
  { T1123.values[0] = Top_hub__x_type_arr_7.values[0]&T1122.values[0]; }
  { T1124.values[0] = -T903.values[0]; }
  T1124.values[0] = T1124.values[0] & 3;
  { T1125.values[0] = Top_hub__x_type_arr_6.values[0]&T1124.values[0]; }
  { T1126.values[0] = -T907.values[0]; }
  T1126.values[0] = T1126.values[0] & 3;
  { T1127.values[0] = Top_hub__x_type_arr_5.values[0]&T1126.values[0]; }
  { T1128.values[0] = -T911.values[0]; }
  T1128.values[0] = T1128.values[0] & 3;
  { T1129.values[0] = Top_hub__x_type_arr_4.values[0]&T1128.values[0]; }
  { T1130.values[0] = -T915.values[0]; }
  T1130.values[0] = T1130.values[0] & 3;
  { T1131.values[0] = Top_hub__x_type_arr_3.values[0]&T1130.values[0]; }
  { T1132.values[0] = -T919.values[0]; }
  T1132.values[0] = T1132.values[0] & 3;
  { T1133.values[0] = Top_hub__x_type_arr_2.values[0]&T1132.values[0]; }
  { T1134.values[0] = -T923.values[0]; }
  T1134.values[0] = T1134.values[0] & 3;
  { T1135.values[0] = Top_hub__x_type_arr_1.values[0]&T1134.values[0]; }
  { T1136.values[0] = -T927.values[0]; }
  T1136.values[0] = T1136.values[0] & 3;
  { T1137.values[0] = Top_hub__x_type_arr_0.values[0]&T1136.values[0]; }
  { T1138.values[0] = T1137.values[0]|T1135.values[0]; }
  { T1139.values[0] = T1138.values[0]|T1133.values[0]; }
  { T1140.values[0] = T1139.values[0]|T1131.values[0]; }
  { T1141.values[0] = T1140.values[0]|T1129.values[0]; }
  { T1142.values[0] = T1141.values[0]|T1127.values[0]; }
  { T1143.values[0] = T1142.values[0]|T1125.values[0]; }
  { T1144.values[0] = T1143.values[0]|T1123.values[0]; }
  { T1145.values[0] = T1144.values[0]; }
  T1146.values[0] = T1145.values[0] == 0x3L;
  { val_t __mask = -T1146.values[0]; T1147.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  T1148.values[0] = T1145.values[0] == 0x2L;
  { val_t __mask = -T1148.values[0]; T1149.values[0] = T1147.values[0] ^ ((T1147.values[0] ^ 0x2L) & __mask); }
  T1150.values[0] = T1145.values[0] == 0x1L;
  { val_t __mask = -T1150.values[0]; T1151.values[0] = T1149.values[0] ^ ((T1149.values[0] ^ 0x1L) & __mask); }
  { T1152.values[0] = -T899.values[0]; }
  T1152.values[0] = T1152.values[0] & 3;
  { T1153.values[0] = Top_hub__sh_count_arr_7.values[0]&T1152.values[0]; }
  { T1154.values[0] = -T903.values[0]; }
  T1154.values[0] = T1154.values[0] & 3;
  { T1155.values[0] = Top_hub__sh_count_arr_6.values[0]&T1154.values[0]; }
  { T1156.values[0] = -T907.values[0]; }
  T1156.values[0] = T1156.values[0] & 3;
  { T1157.values[0] = Top_hub__sh_count_arr_5.values[0]&T1156.values[0]; }
  { T1158.values[0] = -T911.values[0]; }
  T1158.values[0] = T1158.values[0] & 3;
  { T1159.values[0] = Top_hub__sh_count_arr_4.values[0]&T1158.values[0]; }
  { T1160.values[0] = -T915.values[0]; }
  T1160.values[0] = T1160.values[0] & 3;
  { T1161.values[0] = Top_hub__sh_count_arr_3.values[0]&T1160.values[0]; }
  { T1162.values[0] = -T919.values[0]; }
  T1162.values[0] = T1162.values[0] & 3;
  { T1163.values[0] = Top_hub__sh_count_arr_2.values[0]&T1162.values[0]; }
  { T1164.values[0] = -T923.values[0]; }
  T1164.values[0] = T1164.values[0] & 3;
  { T1165.values[0] = Top_hub__sh_count_arr_1.values[0]&T1164.values[0]; }
  { T1166.values[0] = -T927.values[0]; }
  T1166.values[0] = T1166.values[0] & 3;
  { T1167.values[0] = Top_hub__sh_count_arr_0.values[0]&T1166.values[0]; }
  { T1168.values[0] = T1167.values[0]|T1165.values[0]; }
  { T1169.values[0] = T1168.values[0]|T1163.values[0]; }
  { T1170.values[0] = T1169.values[0]|T1161.values[0]; }
  { T1171.values[0] = T1170.values[0]|T1159.values[0]; }
  { T1172.values[0] = T1171.values[0]|T1157.values[0]; }
  { T1173.values[0] = T1172.values[0]|T1155.values[0]; }
  { T1174.values[0] = T1173.values[0]|T1153.values[0]; }
  { T1175.values[0] = T1174.values[0]; }
  T1176.values[0] = T1175.values[0]>0x0L;
  { val_t __mask = -T1176.values[0]; T1177.values[0] = 0x1L ^ ((0x1L ^ 0x0L) & __mask); }
  T1178.values[0] = T1145.values[0] == 0x0L;
  { val_t __mask = -T1178.values[0]; T1179.values[0] = T1151.values[0] ^ ((T1151.values[0] ^ T1177.values[0]) & __mask); }
  { val_t __mask = -T938.values[0]; T1180.values[0] = T1121.values[0] ^ ((T1121.values[0] ^ T1179.values[0]) & __mask); }
  { Top_hub__io_tiles_0_xact_rep_bits_x_type.values[0] = T1180.values[0]; }
  { Top_Queue_18__io_enq_bits_x_type.values[0] = Top_hub__io_tiles_0_xact_rep_bits_x_type.values[0]; }
  { Top_hub__io_mem_resp_bits_data.values[0] = R5086.values[0]; Top_hub__io_mem_resp_bits_data.values[1] = R5086.values[1]; }
  { Top_hub__io_tiles_0_xact_rep_bits_data.values[0] = Top_hub__io_mem_resp_bits_data.values[0]; Top_hub__io_tiles_0_xact_rep_bits_data.values[1] = Top_hub__io_mem_resp_bits_data.values[1]; }
  { Top_Queue_18__io_enq_bits_data.values[0] = Top_hub__io_tiles_0_xact_rep_bits_data.values[0]; Top_Queue_18__io_enq_bits_data.values[1] = Top_hub__io_tiles_0_xact_rep_bits_data.values[1]; }
  { T1181.values[0] = Top_Queue_18__io_enq_bits_x_type.values[0] | Top_Queue_18__io_enq_bits_data.values[0] << 3; T1181.values[1] = Top_Queue_18__io_enq_bits_data.values[0] >> 61 | Top_Queue_18__io_enq_bits_data.values[1] << 3; T1181.values[2] = Top_Queue_18__io_enq_bits_data.values[1] >> 61; }
  { T1182.values[0] = Top_Queue_18__io_enq_bits_tile_xact_id.values[0] | T1181.values[0] << 5; T1182.values[1] = T1181.values[0] >> 59 | T1181.values[1] << 5; T1182.values[2] = T1181.values[1] >> 59 | T1181.values[2] << 5; }
  { T1183.values[0] = Top_Queue_18__io_enq_bits_global_xact_id.values[0] | T1182.values[0] << 3; T1183.values[1] = T1182.values[0] >> 61 | T1182.values[1] << 3; T1183.values[2] = T1182.values[1] >> 61 | T1182.values[2] << 3; }
  { T1184.values[0] = Top_Queue_18__io_enq_bits_require_ack.values[0] | T1183.values[0] << 1; T1184.values[1] = T1183.values[0] >> 63 | T1183.values[1] << 1; T1184.values[2] = T1183.values[1] >> 63 | T1183.values[2] << 1; }
  { Top_Queue_17__reset.values[0] = reset.values[0]; }
  { T1186.values[0] = Top_Queue_17__enq_ptr.values[0]+0x1L; }
  T1186.values[0] = T1186.values[0] & 1;
  { Top_Queue_17__do_flow.values[0] = 0x0L; }
  T1187.values[0] = !Top_Queue_17__do_flow.values[0];
  T1188.values[0] = Top_hub__abort_state_arr_0.values[0] == 0x2L;
  { Top_hub__io_tiles_0_xact_abort_valid.values[0] = T1188.values[0]; }
  { Top_Queue_17__io_enq_valid.values[0] = Top_hub__io_tiles_0_xact_abort_valid.values[0]; }
  Top_Queue_17__ptr_match.values[0] = Top_Queue_17__enq_ptr.values[0] == Top_Queue_17__deq_ptr.values[0];
  { Top_Queue_17__full.values[0] = Top_Queue_17__ptr_match.values[0]&&Top_Queue_17__maybe_full.values[0]; }
  T1189.values[0] = !Top_Queue_17__full.values[0];
  { Top_Queue_17__io_enq_ready.values[0] = T1189.values[0]; }
  { T1190.values[0] = Top_Queue_17__io_enq_ready.values[0]&&Top_Queue_17__io_enq_valid.values[0]; }
  { Top_Queue_17__do_enq.values[0] = T1190.values[0]&&T1187.values[0]; }
  { val_t __mask = -Top_Queue_17__do_enq.values[0]; T1191.values[0] = Top_Queue_17__enq_ptr.values[0] ^ ((Top_Queue_17__enq_ptr.values[0] ^ T1186.values[0]) & __mask); }
  { Top_Queue_17__enq_ptr_shadow.values[0] = TERNARY(Top_Queue_17__reset.values[0], 0x0L, T1191.values[0]); }
  T1192.values[0] = !Top_Queue_17__do_flow.values[0];
  T1193.values[0] = !Top_Queue_17__maybe_full.values[0];
  { Top_Queue_17__empty.values[0] = Top_Queue_17__ptr_match.values[0]&&T1193.values[0]; }
  T1194.values[0] = !Top_Queue_17__empty.values[0];
  { Top_Queue_17__io_deq_valid.values[0] = T1194.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_abort_ready.values[0] = 0x1L; }
  { Top_SodorTile__io_tilelink_xact_abort_ready.values[0] = Top_SodorTile_arbiter__io_mem_xact_abort_ready.values[0]; }
  { Top_Queue_17__io_deq_ready.values[0] = Top_SodorTile__io_tilelink_xact_abort_ready.values[0]; }
  { T1195.values[0] = Top_Queue_17__io_deq_ready.values[0]&&Top_Queue_17__io_deq_valid.values[0]; }
  { Top_Queue_17__do_deq.values[0] = T1195.values[0]&&T1192.values[0]; }
  T1196.values[0] = Top_Queue_17__do_enq.values[0] != Top_Queue_17__do_deq.values[0];
  { val_t __mask = -T1196.values[0]; T1197.values[0] = Top_Queue_17__maybe_full.values[0] ^ ((Top_Queue_17__maybe_full.values[0] ^ Top_Queue_17__do_enq.values[0]) & __mask); }
  { Top_Queue_17__maybe_full_shadow.values[0] = TERNARY(Top_Queue_17__reset.values[0], 0x0L, T1197.values[0]); }
  { T1198.values[0] = Top_Queue_17__deq_ptr.values[0]+0x1L; }
  T1198.values[0] = T1198.values[0] & 1;
  { val_t __mask = -Top_Queue_17__do_deq.values[0]; T1199.values[0] = Top_Queue_17__deq_ptr.values[0] ^ ((Top_Queue_17__deq_ptr.values[0] ^ T1198.values[0]) & __mask); }
  { Top_Queue_17__deq_ptr_shadow.values[0] = TERNARY(Top_Queue_17__reset.values[0], 0x0L, T1199.values[0]); }
  { T1201.values[0] = Top_Queue_15__ram.get(Top_Queue_15__deq_ptr.values[0], 0); }
  { T1202.values[0] = T1201.values[0]; }
  T1202.values[0] = T1202.values[0] & 17179869183;
  { T1203.values[0] = T1201.values[0] >> 34; }
  T1203.values[0] = T1203.values[0] & 31;
  { T1204.values[0] = T1201.values[0] >> 39; }
  T1204.values[0] = T1204.values[0] & 3;
  { T1205.values[0] = T1203.values[0] | T1204.values[0] << 5; }
  { T1206.values[0] = T1202.values[0] | T1205.values[0] << 34; }
  { T1207.values[0] = T1206.values[0] >> 34; }
  T1207.values[0] = T1207.values[0] & 31;
  { Top_Queue_15__io_deq_bits_tile_xact_id.values[0] = T1207.values[0]; }
  { Top_hub__io_tiles_0_xact_init_bits_tile_xact_id.values[0] = Top_Queue_15__io_deq_bits_tile_xact_id.values[0]; }
  { Top_hub__io_tiles_0_xact_abort_bits_tile_xact_id.values[0] = Top_hub__io_tiles_0_xact_init_bits_tile_xact_id.values[0]; }
  { Top_Queue_17__io_enq_bits_tile_xact_id.values[0] = Top_hub__io_tiles_0_xact_abort_bits_tile_xact_id.values[0]; }
  { T1210.values[0] = Top_SodorTile_cache_writeback_queue__ram.get(Top_SodorTile_cache_writeback_queue__deq_ptr.values[0], 0); T1210.values[1] = Top_SodorTile_cache_writeback_queue__ram.get(Top_SodorTile_cache_writeback_queue__deq_ptr.values[0], 1); }
  { T1211.values[0] = T1210.values[0]; T1211.values[1] = T1210.values[1]; }
  { T1212.values[0] = T1211.values[0]; T1212.values[1] = T1211.values[1]; }
  { Top_SodorTile_cache_writeback_queue__io_deq_bits_data.values[0] = T1212.values[0]; Top_SodorTile_cache_writeback_queue__io_deq_bits_data.values[1] = T1212.values[1]; }
  { Top_SodorTile_cache__io_mem_xact_init_data_bits_data.values[0] = Top_SodorTile_cache_writeback_queue__io_deq_bits_data.values[0]; Top_SodorTile_cache__io_mem_xact_init_data_bits_data.values[1] = Top_SodorTile_cache_writeback_queue__io_deq_bits_data.values[1]; }
  { Top_SodorTile__io_tilelink_xact_init_data_bits_data.values[0] = Top_SodorTile_cache__io_mem_xact_init_data_bits_data.values[0]; Top_SodorTile__io_tilelink_xact_init_data_bits_data.values[1] = Top_SodorTile_cache__io_mem_xact_init_data_bits_data.values[1]; }
  { Top_Queue_16__io_enq_bits_data.values[0] = Top_SodorTile__io_tilelink_xact_init_data_bits_data.values[0]; Top_Queue_16__io_enq_bits_data.values[1] = Top_SodorTile__io_tilelink_xact_init_data_bits_data.values[1]; }
  { Top_Queue_16__do_flow.values[0] = 0x0L; }
  T1213.values[0] = !Top_Queue_16__do_flow.values[0];
  T1214.values[0] = !Top_SodorTile_cache_writeback_queue__maybe_full.values[0];
  Top_SodorTile_cache_writeback_queue__ptr_match.values[0] = Top_SodorTile_cache_writeback_queue__enq_ptr.values[0] == Top_SodorTile_cache_writeback_queue__deq_ptr.values[0];
  { Top_SodorTile_cache_writeback_queue__empty.values[0] = Top_SodorTile_cache_writeback_queue__ptr_match.values[0]&&T1214.values[0]; }
  T1215.values[0] = !Top_SodorTile_cache_writeback_queue__empty.values[0];
  { Top_SodorTile_cache_writeback_queue__io_deq_valid.values[0] = T1215.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_init_data_valid.values[0] = Top_SodorTile_cache_writeback_queue__io_deq_valid.values[0]; }
  { Top_SodorTile__io_tilelink_xact_init_data_valid.values[0] = Top_SodorTile_cache__io_mem_xact_init_data_valid.values[0]; }
  { Top_Queue_16__io_enq_valid.values[0] = Top_SodorTile__io_tilelink_xact_init_data_valid.values[0]; }
  { Top_Queue_16__full.values[0] = Top_Queue_16__ptr_match.values[0]&&Top_Queue_16__maybe_full.values[0]; }
  T1216.values[0] = !Top_Queue_16__full.values[0];
  { Top_Queue_16__io_enq_ready.values[0] = T1216.values[0]; }
  { T1217.values[0] = Top_Queue_16__io_enq_ready.values[0]&&Top_Queue_16__io_enq_valid.values[0]; }
  { Top_Queue_16__do_enq.values[0] = T1217.values[0]&&T1213.values[0]; }
  { Top_Queue_16__reset.values[0] = reset.values[0]; }
  { T1219.values[0] = Top_Queue_16__enq_ptr.values[0]+0x1L; }
  T1219.values[0] = T1219.values[0] & 1;
  { val_t __mask = -Top_Queue_16__do_enq.values[0]; T1220.values[0] = Top_Queue_16__enq_ptr.values[0] ^ ((Top_Queue_16__enq_ptr.values[0] ^ T1219.values[0]) & __mask); }
  { Top_Queue_16__enq_ptr_shadow.values[0] = TERNARY(Top_Queue_16__reset.values[0], 0x0L, T1220.values[0]); }
  { T1221.values[0] = Top_Queue_16__deq_ptr.values[0]+0x1L; }
  T1221.values[0] = T1221.values[0] & 1;
  T1222.values[0] = !Top_Queue_16__do_flow.values[0];
  { T1223.values[0] = Top_hub_XactTracker_7__init_tile_id_.values[0]; }
  T1224.values[0] = 0x1L << T1223.values[0];
  { T1225.values[0] = Top_hub_XactTracker_7__io_mem_req_cmd_ready.values[0]||Top_hub_XactTracker_7__x_w_mem_cmd_sent.values[0]; }
  { T1226.values[0] = T492.values[0]&&T1225.values[0]; }
  { T1227.values[0] = T1226.values[0]&&Top_hub_XactTracker_7__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T1227.values[0]; T1228.values[0] = 0x0L ^ ((0x0L ^ T1224.values[0]) & __mask); }
  { T1229.values[0] = T1228.values[0]; }
  T1229.values[0] = T1229.values[0] & 3;
  { Top_hub_XactTracker_7__io_pop_x_init_data.values[0] = T1229.values[0]; }
  T1230.values[0] = (Top_hub_XactTracker_7__io_pop_x_init_data.values[0] >> 0) & 1;
  { T1231.values[0] = T1230.values[0]; }
  { T1232.values[0] = Top_hub_XactTracker_6__init_tile_id_.values[0]; }
  T1233.values[0] = 0x1L << T1232.values[0];
  { T1234.values[0] = T680.values[0]&&Top_hub_XactTracker_6__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T1234.values[0]; T1235.values[0] = 0x0L ^ ((0x0L ^ T1233.values[0]) & __mask); }
  { T1236.values[0] = T1235.values[0]; }
  T1236.values[0] = T1236.values[0] & 3;
  { Top_hub_XactTracker_6__io_pop_x_init_data.values[0] = T1236.values[0]; }
  T1237.values[0] = (Top_hub_XactTracker_6__io_pop_x_init_data.values[0] >> 0) & 1;
  { T1238.values[0] = T1237.values[0]; }
  { T1239.values[0] = T1238.values[0]||T1231.values[0]; }
  { T1240.values[0] = Top_hub_XactTracker_5__init_tile_id_.values[0]; }
  T1241.values[0] = 0x1L << T1240.values[0];
  { T1242.values[0] = T650.values[0]&&Top_hub_XactTracker_5__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T1242.values[0]; T1243.values[0] = 0x0L ^ ((0x0L ^ T1241.values[0]) & __mask); }
  { T1244.values[0] = T1243.values[0]; }
  T1244.values[0] = T1244.values[0] & 3;
  { Top_hub_XactTracker_5__io_pop_x_init_data.values[0] = T1244.values[0]; }
  T1245.values[0] = (Top_hub_XactTracker_5__io_pop_x_init_data.values[0] >> 0) & 1;
  { T1246.values[0] = T1245.values[0]; }
  { T1247.values[0] = T1246.values[0]||T1239.values[0]; }
  { T1248.values[0] = Top_hub_XactTracker_4__init_tile_id_.values[0]; }
  T1249.values[0] = 0x1L << T1248.values[0];
  { T1250.values[0] = T621.values[0]&&Top_hub_XactTracker_4__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T1250.values[0]; T1251.values[0] = 0x0L ^ ((0x0L ^ T1249.values[0]) & __mask); }
  { T1252.values[0] = T1251.values[0]; }
  T1252.values[0] = T1252.values[0] & 3;
  { Top_hub_XactTracker_4__io_pop_x_init_data.values[0] = T1252.values[0]; }
  T1253.values[0] = (Top_hub_XactTracker_4__io_pop_x_init_data.values[0] >> 0) & 1;
  { T1254.values[0] = T1253.values[0]; }
  { T1255.values[0] = T1254.values[0]||T1247.values[0]; }
  { T1256.values[0] = Top_hub_XactTracker_3__init_tile_id_.values[0]; }
  T1257.values[0] = 0x1L << T1256.values[0];
  { T1258.values[0] = T593.values[0]&&Top_hub_XactTracker_3__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T1258.values[0]; T1259.values[0] = 0x0L ^ ((0x0L ^ T1257.values[0]) & __mask); }
  { T1260.values[0] = T1259.values[0]; }
  T1260.values[0] = T1260.values[0] & 3;
  { Top_hub_XactTracker_3__io_pop_x_init_data.values[0] = T1260.values[0]; }
  T1261.values[0] = (Top_hub_XactTracker_3__io_pop_x_init_data.values[0] >> 0) & 1;
  { T1262.values[0] = T1261.values[0]; }
  { T1263.values[0] = T1262.values[0]||T1255.values[0]; }
  { T1264.values[0] = Top_hub_XactTracker_2__init_tile_id_.values[0]; }
  T1265.values[0] = 0x1L << T1264.values[0];
  { T1266.values[0] = T566.values[0]&&Top_hub_XactTracker_2__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T1266.values[0]; T1267.values[0] = 0x0L ^ ((0x0L ^ T1265.values[0]) & __mask); }
  { T1268.values[0] = T1267.values[0]; }
  T1268.values[0] = T1268.values[0] & 3;
  { Top_hub_XactTracker_2__io_pop_x_init_data.values[0] = T1268.values[0]; }
  T1269.values[0] = (Top_hub_XactTracker_2__io_pop_x_init_data.values[0] >> 0) & 1;
  { T1270.values[0] = T1269.values[0]; }
  { T1271.values[0] = T1270.values[0]||T1263.values[0]; }
  { T1272.values[0] = Top_hub_XactTracker_1__init_tile_id_.values[0]; }
  T1273.values[0] = 0x1L << T1272.values[0];
  { T1274.values[0] = T540.values[0]&&Top_hub_XactTracker_1__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T1274.values[0]; T1275.values[0] = 0x0L ^ ((0x0L ^ T1273.values[0]) & __mask); }
  { T1276.values[0] = T1275.values[0]; }
  T1276.values[0] = T1276.values[0] & 3;
  { Top_hub_XactTracker_1__io_pop_x_init_data.values[0] = T1276.values[0]; }
  T1277.values[0] = (Top_hub_XactTracker_1__io_pop_x_init_data.values[0] >> 0) & 1;
  { T1278.values[0] = T1277.values[0]; }
  { T1279.values[0] = T1278.values[0]||T1271.values[0]; }
  { T1280.values[0] = Top_hub_XactTracker__init_tile_id_.values[0]; }
  T1281.values[0] = 0x1L << T1280.values[0];
  { T1282.values[0] = T515.values[0]&&Top_hub_XactTracker__io_mem_req_data_ready.values[0]; }
  { val_t __mask = -T1282.values[0]; T1283.values[0] = 0x0L ^ ((0x0L ^ T1281.values[0]) & __mask); }
  { T1284.values[0] = T1283.values[0]; }
  T1284.values[0] = T1284.values[0] & 3;
  { Top_hub_XactTracker__io_pop_x_init_data.values[0] = T1284.values[0]; }
  T1285.values[0] = (Top_hub_XactTracker__io_pop_x_init_data.values[0] >> 0) & 1;
  { T1286.values[0] = T1285.values[0]; }
  { T1287.values[0] = T1286.values[0]||T1279.values[0]; }
  T1288.values[0] = Top_hub__abort_state_arr_0.values[0] == 0x1L;
  { T1289.values[0] = T1288.values[0]||T1287.values[0]; }
  { Top_hub__io_tiles_0_xact_init_data_ready.values[0] = T1289.values[0]; }
  { Top_Queue_16__io_deq_ready.values[0] = Top_hub__io_tiles_0_xact_init_data_ready.values[0]; }
  { T1290.values[0] = Top_Queue_16__io_deq_ready.values[0]&&Top_Queue_16__io_deq_valid.values[0]; }
  { Top_Queue_16__do_deq.values[0] = T1290.values[0]&&T1222.values[0]; }
  { val_t __mask = -Top_Queue_16__do_deq.values[0]; T1291.values[0] = Top_Queue_16__deq_ptr.values[0] ^ ((Top_Queue_16__deq_ptr.values[0] ^ T1221.values[0]) & __mask); }
  { Top_Queue_16__deq_ptr_shadow.values[0] = TERNARY(Top_Queue_16__reset.values[0], 0x0L, T1291.values[0]); }
  T1292.values[0] = Top_Queue_16__do_enq.values[0] != Top_Queue_16__do_deq.values[0];
  { val_t __mask = -T1292.values[0]; T1293.values[0] = Top_Queue_16__maybe_full.values[0] ^ ((Top_Queue_16__maybe_full.values[0] ^ Top_Queue_16__do_enq.values[0]) & __mask); }
  { Top_Queue_16__maybe_full_shadow.values[0] = TERNARY(Top_Queue_16__reset.values[0], 0x0L, T1293.values[0]); }
  { Top_Queue_15__reset.values[0] = reset.values[0]; }
  { T1294.values[0] = Top_Queue_15__enq_ptr.values[0]+0x1L; }
  T1294.values[0] = T1294.values[0] & 1;
  { Top_Queue_15__do_flow.values[0] = 0x0L; }
  T1295.values[0] = !Top_Queue_15__do_flow.values[0];
  { Top_SodorTile_cache_finish_queue__full.values[0] = Top_SodorTile_cache_finish_queue__ptr_match.values[0]&&Top_SodorTile_cache_finish_queue__maybe_full.values[0]; }
  T1296.values[0] = !Top_SodorTile_cache_finish_queue__full.values[0];
  { Top_SodorTile_cache_finish_queue__io_enq_ready.values[0] = T1296.values[0]; }
  { T1297.values[0] = Top_SodorTile_cpu_d__reg_ma.values[0]; }
  { Top_SodorTile_cpu_d__io_mem_req_addr.values[0] = T1297.values[0]; }
  { Top_SodorTile_cpu__io_mem_req_addr.values[0] = Top_SodorTile_cpu_d__io_mem_req_addr.values[0]; }
  { Top_SodorTile_cache__io_cpu_req_addr.values[0] = Top_SodorTile_cpu__io_mem_req_addr.values[0]; }
  { Top_SodorTile_cache__req_idx.values[0] = Top_SodorTile_cache__io_cpu_req_addr.values[0] >> 6; }
  Top_SodorTile_cache__req_idx.values[0] = Top_SodorTile_cache__req_idx.values[0] & 1023;
  { val_t __mask = -Top_SodorTile_cache__performing_flush.values[0]; Top_SodorTile_cache__access_idx.values[0] = Top_SodorTile_cache__req_idx.values[0] ^ ((Top_SodorTile_cache__req_idx.values[0] ^ Top_SodorTile_cache__flush_idx.values[0]) & __mask); }
  { val_t __e[16]; __e[0] = Top_SodorTile_cache__valid_array.values[0]; __e[1] = Top_SodorTile_cache__valid_array.values[1]; __e[2] = Top_SodorTile_cache__valid_array.values[2]; __e[3] = Top_SodorTile_cache__valid_array.values[3]; __e[4] = Top_SodorTile_cache__valid_array.values[4]; __e[5] = Top_SodorTile_cache__valid_array.values[5]; __e[6] = Top_SodorTile_cache__valid_array.values[6]; __e[7] = Top_SodorTile_cache__valid_array.values[7]; __e[8] = Top_SodorTile_cache__valid_array.values[8]; __e[9] = Top_SodorTile_cache__valid_array.values[9]; __e[10] = Top_SodorTile_cache__valid_array.values[10]; __e[11] = Top_SodorTile_cache__valid_array.values[11]; __e[12] = Top_SodorTile_cache__valid_array.values[12]; __e[13] = Top_SodorTile_cache__valid_array.values[13]; __e[14] = Top_SodorTile_cache__valid_array.values[14]; __e[15] = Top_SodorTile_cache__valid_array.values[15]; T1298.values[0] = __e[Top_SodorTile_cache__access_idx.values[0]/64] >> (Top_SodorTile_cache__access_idx.values[0]%64) & 1; }
  { T1299.values[0] = T1298.values[0]; }
  { val_t __e[16]; __e[0] = Top_SodorTile_cache__dirty_array.values[0]; __e[1] = Top_SodorTile_cache__dirty_array.values[1]; __e[2] = Top_SodorTile_cache__dirty_array.values[2]; __e[3] = Top_SodorTile_cache__dirty_array.values[3]; __e[4] = Top_SodorTile_cache__dirty_array.values[4]; __e[5] = Top_SodorTile_cache__dirty_array.values[5]; __e[6] = Top_SodorTile_cache__dirty_array.values[6]; __e[7] = Top_SodorTile_cache__dirty_array.values[7]; __e[8] = Top_SodorTile_cache__dirty_array.values[8]; __e[9] = Top_SodorTile_cache__dirty_array.values[9]; __e[10] = Top_SodorTile_cache__dirty_array.values[10]; __e[11] = Top_SodorTile_cache__dirty_array.values[11]; __e[12] = Top_SodorTile_cache__dirty_array.values[12]; __e[13] = Top_SodorTile_cache__dirty_array.values[13]; __e[14] = Top_SodorTile_cache__dirty_array.values[14]; __e[15] = Top_SodorTile_cache__dirty_array.values[15]; T1300.values[0] = __e[Top_SodorTile_cache__access_idx.values[0]/64] >> (Top_SodorTile_cache__access_idx.values[0]%64) & 1; }
  { T1301.values[0] = T1300.values[0]; }
  { Top_SodorTile_cache__line_is_dirty.values[0] = T1301.values[0]&&T1299.values[0]; }
  T1302.values[0] = Top_SodorTile_cache__state.values[0] == 0x7L;
  { T1303.values[0] = T1302.values[0]&&Top_SodorTile_cache__line_is_dirty.values[0]; }
  T1304.values[0] = Top_SodorTile_cache__state.values[0] == 0x2L;
  { T1305.values[0] = T1304.values[0]||T1303.values[0]; }
  { T1306.values[0] = T1305.values[0]&&Top_SodorTile_cache_finish_queue__io_enq_ready.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_init_valid.values[0] = T1306.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_init_valid.values[0] = Top_SodorTile_cache__io_mem_xact_init_valid.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_init_valid.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_init_valid.values[0]; }
  { Top_SodorTile__io_tilelink_xact_init_valid.values[0] = Top_SodorTile_arbiter__io_mem_xact_init_valid.values[0]; }
  { Top_Queue_15__io_enq_valid.values[0] = Top_SodorTile__io_tilelink_xact_init_valid.values[0]; }
  Top_Queue_15__ptr_match.values[0] = Top_Queue_15__enq_ptr.values[0] == Top_Queue_15__deq_ptr.values[0];
  { Top_Queue_15__full.values[0] = Top_Queue_15__ptr_match.values[0]&&Top_Queue_15__maybe_full.values[0]; }
  T1307.values[0] = !Top_Queue_15__full.values[0];
  { Top_Queue_15__io_enq_ready.values[0] = T1307.values[0]; }
  { T1308.values[0] = Top_Queue_15__io_enq_ready.values[0]&&Top_Queue_15__io_enq_valid.values[0]; }
  { Top_Queue_15__do_enq.values[0] = T1308.values[0]&&T1295.values[0]; }
  { val_t __mask = -Top_Queue_15__do_enq.values[0]; T1309.values[0] = Top_Queue_15__enq_ptr.values[0] ^ ((Top_Queue_15__enq_ptr.values[0] ^ T1294.values[0]) & __mask); }
  { Top_Queue_15__enq_ptr_shadow.values[0] = TERNARY(Top_Queue_15__reset.values[0], 0x0L, T1309.values[0]); }
  T1310.values[0] = !Top_Queue_15__do_flow.values[0];
  T1311.values[0] = !Top_Queue_15__maybe_full.values[0];
  { Top_Queue_15__empty.values[0] = Top_Queue_15__ptr_match.values[0]&&T1311.values[0]; }
  T1312.values[0] = !Top_Queue_15__empty.values[0];
  { Top_Queue_15__io_deq_valid.values[0] = T1312.values[0]; }
  { Top_hub_init_arb__io_in_1_bits_tile_id.values[0] = 0x1L; }
  { T1313.values[0] = Top_htif_x_init__ram.get(0x0L, 0); }
  { T1314.values[0] = T1313.values[0]; }
  T1314.values[0] = T1314.values[0] & 17179869183;
  { T1315.values[0] = T1313.values[0] >> 34; }
  T1315.values[0] = T1315.values[0] & 31;
  { T1316.values[0] = T1313.values[0] >> 39; }
  T1316.values[0] = T1316.values[0] & 3;
  { T1317.values[0] = T1315.values[0] | T1316.values[0] << 5; }
  { T1318.values[0] = T1314.values[0] | T1317.values[0] << 34; }
  { T1319.values[0] = T1318.values[0]; }
  T1319.values[0] = T1319.values[0] & 17179869183;
  { Top_htif_x_init__io_deq_bits_address.values[0] = T1319.values[0]; }
  { Top_htif__io_mem_xact_init_bits_address.values[0] = Top_htif_x_init__io_deq_bits_address.values[0]; }
  { Top_hub__io_tiles_1_xact_init_bits_address.values[0] = Top_htif__io_mem_xact_init_bits_address.values[0]; }
  { Top_hub_init_arb__io_in_1_bits_xact_init_address.values[0] = Top_hub__io_tiles_1_xact_init_bits_address.values[0]; }
  { T1320.values[0] = T1318.values[0] >> 34; }
  T1320.values[0] = T1320.values[0] & 31;
  { Top_htif_x_init__io_deq_bits_tile_xact_id.values[0] = T1320.values[0]; }
  { Top_htif__io_mem_xact_init_bits_tile_xact_id.values[0] = Top_htif_x_init__io_deq_bits_tile_xact_id.values[0]; }
  { Top_hub__io_tiles_1_xact_init_bits_tile_xact_id.values[0] = Top_htif__io_mem_xact_init_bits_tile_xact_id.values[0]; }
  { Top_hub_init_arb__io_in_1_bits_xact_init_tile_xact_id.values[0] = Top_hub__io_tiles_1_xact_init_bits_tile_xact_id.values[0]; }
  { T1321.values[0] = T1318.values[0] >> 39; }
  T1321.values[0] = T1321.values[0] & 3;
  { Top_htif_x_init__io_deq_bits_x_type.values[0] = T1321.values[0]; }
  { Top_htif__io_mem_xact_init_bits_x_type.values[0] = Top_htif_x_init__io_deq_bits_x_type.values[0]; }
  { Top_hub__io_tiles_1_xact_init_bits_x_type.values[0] = Top_htif__io_mem_xact_init_bits_x_type.values[0]; }
  { Top_hub_init_arb__io_in_1_bits_xact_init_x_type.values[0] = Top_hub__io_tiles_1_xact_init_bits_x_type.values[0]; }
  { T1322.values[0] = Top_hub_init_arb__io_in_1_bits_xact_init_tile_xact_id.values[0] | Top_hub_init_arb__io_in_1_bits_xact_init_x_type.values[0] << 5; }
  { T1323.values[0] = Top_hub_init_arb__io_in_1_bits_xact_init_address.values[0] | T1322.values[0] << 34; }
  { T1324.values[0] = Top_hub_init_arb__io_in_1_bits_tile_id.values[0] | T1323.values[0] << 2; }
  { Top_hub_init_arb__io_in_0_bits_tile_id.values[0] = 0x0L; }
  { T1325.values[0] = T1206.values[0]; }
  T1325.values[0] = T1325.values[0] & 17179869183;
  { Top_Queue_15__io_deq_bits_address.values[0] = T1325.values[0]; }
  { Top_hub__io_tiles_0_xact_init_bits_address.values[0] = Top_Queue_15__io_deq_bits_address.values[0]; }
  { Top_hub_init_arb__io_in_0_bits_xact_init_address.values[0] = Top_hub__io_tiles_0_xact_init_bits_address.values[0]; }
  { Top_hub_init_arb__io_in_0_bits_xact_init_tile_xact_id.values[0] = Top_hub__io_tiles_0_xact_init_bits_tile_xact_id.values[0]; }
  { T1326.values[0] = T1206.values[0] >> 39; }
  T1326.values[0] = T1326.values[0] & 3;
  { Top_Queue_15__io_deq_bits_x_type.values[0] = T1326.values[0]; }
  { Top_hub__io_tiles_0_xact_init_bits_x_type.values[0] = Top_Queue_15__io_deq_bits_x_type.values[0]; }
  { Top_hub_init_arb__io_in_0_bits_xact_init_x_type.values[0] = Top_hub__io_tiles_0_xact_init_bits_x_type.values[0]; }
  { T1327.values[0] = Top_hub_init_arb__io_in_0_bits_xact_init_tile_xact_id.values[0] | Top_hub_init_arb__io_in_0_bits_xact_init_x_type.values[0] << 5; }
  { T1328.values[0] = Top_hub_init_arb__io_in_0_bits_xact_init_address.values[0] | T1327.values[0] << 34; }
  { T1329.values[0] = Top_hub_init_arb__io_in_0_bits_tile_id.values[0] | T1328.values[0] << 2; }
  { Top_hub__io_tiles_0_xact_init_valid.values[0] = Top_Queue_15__io_deq_valid.values[0]; }
  T1330.values[0] = Top_hub__io_tiles_0_xact_init_bits_x_type.values[0] == 0x3L;
  { Top_hub_Queue_3__full.values[0] = Top_hub_Queue_3__ptr_match.values[0]&&Top_hub_Queue_3__maybe_full.values[0]; }
  T1331.values[0] = !Top_hub_Queue_3__full.values[0];
  { Top_hub_Queue_3__io_enq_ready.values[0] = T1331.values[0]; }
  T1332.values[0] = !Top_hub_Queue_3__io_enq_ready.values[0];
  { T1333.values[0] = T1332.values[0]&&T1330.values[0]; }
  T1334.values[0] = Top_hub_XactTracker__state.values[0] != 0x0L;
  { Top_hub_XactTracker__io_busy.values[0] = T1334.values[0]; }
  { Top_hub__busy_arr_0.values[0] = Top_hub_XactTracker__io_busy.values[0]; }
  T1335.values[0] = Top_hub_XactTracker_1__state.values[0] != 0x0L;
  { Top_hub_XactTracker_1__io_busy.values[0] = T1335.values[0]; }
  { Top_hub__busy_arr_1.values[0] = Top_hub_XactTracker_1__io_busy.values[0]; }
  T1336.values[0] = Top_hub_XactTracker_2__state.values[0] != 0x0L;
  { Top_hub_XactTracker_2__io_busy.values[0] = T1336.values[0]; }
  { Top_hub__busy_arr_2.values[0] = Top_hub_XactTracker_2__io_busy.values[0]; }
  T1337.values[0] = Top_hub_XactTracker_3__state.values[0] != 0x0L;
  { Top_hub_XactTracker_3__io_busy.values[0] = T1337.values[0]; }
  { Top_hub__busy_arr_3.values[0] = Top_hub_XactTracker_3__io_busy.values[0]; }
  T1338.values[0] = Top_hub_XactTracker_4__state.values[0] != 0x0L;
  { Top_hub_XactTracker_4__io_busy.values[0] = T1338.values[0]; }
  { Top_hub__busy_arr_4.values[0] = Top_hub_XactTracker_4__io_busy.values[0]; }
  T1339.values[0] = Top_hub_XactTracker_5__state.values[0] != 0x0L;
  { Top_hub_XactTracker_5__io_busy.values[0] = T1339.values[0]; }
  { Top_hub__busy_arr_5.values[0] = Top_hub_XactTracker_5__io_busy.values[0]; }
  T1340.values[0] = Top_hub_XactTracker_6__state.values[0] != 0x0L;
  { Top_hub_XactTracker_6__io_busy.values[0] = T1340.values[0]; }
  { Top_hub__busy_arr_6.values[0] = Top_hub_XactTracker_6__io_busy.values[0]; }
  T1341.values[0] = Top_hub_XactTracker_7__state.values[0] != 0x0L;
  { Top_hub_XactTracker_7__io_busy.values[0] = T1341.values[0]; }
  { Top_hub__busy_arr_7.values[0] = Top_hub_XactTracker_7__io_busy.values[0]; }
  { T1342.values[0] = Top_hub__busy_arr_6.values[0] | Top_hub__busy_arr_7.values[0] << 1; }
  { T1343.values[0] = Top_hub__busy_arr_5.values[0] | T1342.values[0] << 1; }
  { T1344.values[0] = Top_hub__busy_arr_4.values[0] | T1343.values[0] << 1; }
  { T1345.values[0] = Top_hub__busy_arr_3.values[0] | T1344.values[0] << 1; }
  { T1346.values[0] = Top_hub__busy_arr_2.values[0] | T1345.values[0] << 1; }
  { T1347.values[0] = Top_hub__busy_arr_1.values[0] | T1346.values[0] << 1; }
  { T1348.values[0] = Top_hub__busy_arr_0.values[0] | T1347.values[0] << 1; }
  T1349.values[0] = (T1348.values[0] == 255);
  { Top_hub_XactTracker__io_addr.values[0] = Top_hub_XactTracker__addr_.values[0]; }
  T1350.values[0] = Top_hub_XactTracker__io_addr.values[0] == Top_hub__io_tiles_0_xact_init_bits_address.values[0];
  { T1351.values[0] = Top_hub_XactTracker__io_busy.values[0]&&Top_hub__io_tiles_0_xact_init_valid.values[0]; }
  { T1352.values[0] = T1351.values[0]&&T1350.values[0]; }
  { T1353.values[0] = T1352.values[0]; }
  { Top_hub_XactTracker_1__io_addr.values[0] = Top_hub_XactTracker_1__addr_.values[0]; }
  T1354.values[0] = Top_hub_XactTracker_1__io_addr.values[0] == Top_hub__io_tiles_0_xact_init_bits_address.values[0];
  { T1355.values[0] = Top_hub_XactTracker_1__io_busy.values[0]&&Top_hub__io_tiles_0_xact_init_valid.values[0]; }
  { T1356.values[0] = T1355.values[0]&&T1354.values[0]; }
  { T1357.values[0] = T1356.values[0]; }
  { Top_hub_XactTracker_2__io_addr.values[0] = Top_hub_XactTracker_2__addr_.values[0]; }
  T1358.values[0] = Top_hub_XactTracker_2__io_addr.values[0] == Top_hub__io_tiles_0_xact_init_bits_address.values[0];
  { T1359.values[0] = Top_hub_XactTracker_2__io_busy.values[0]&&Top_hub__io_tiles_0_xact_init_valid.values[0]; }
  { T1360.values[0] = T1359.values[0]&&T1358.values[0]; }
  { T1361.values[0] = T1360.values[0]; }
  { Top_hub_XactTracker_3__io_addr.values[0] = Top_hub_XactTracker_3__addr_.values[0]; }
  T1362.values[0] = Top_hub_XactTracker_3__io_addr.values[0] == Top_hub__io_tiles_0_xact_init_bits_address.values[0];
  { T1363.values[0] = Top_hub_XactTracker_3__io_busy.values[0]&&Top_hub__io_tiles_0_xact_init_valid.values[0]; }
  { T1364.values[0] = T1363.values[0]&&T1362.values[0]; }
  { T1365.values[0] = T1364.values[0]; }
  { Top_hub_XactTracker_4__io_addr.values[0] = Top_hub_XactTracker_4__addr_.values[0]; }
  T1366.values[0] = Top_hub_XactTracker_4__io_addr.values[0] == Top_hub__io_tiles_0_xact_init_bits_address.values[0];
  { T1367.values[0] = Top_hub_XactTracker_4__io_busy.values[0]&&Top_hub__io_tiles_0_xact_init_valid.values[0]; }
  { T1368.values[0] = T1367.values[0]&&T1366.values[0]; }
  { T1369.values[0] = T1368.values[0]; }
  { Top_hub_XactTracker_5__io_addr.values[0] = Top_hub_XactTracker_5__addr_.values[0]; }
  T1370.values[0] = Top_hub_XactTracker_5__io_addr.values[0] == Top_hub__io_tiles_0_xact_init_bits_address.values[0];
  { T1371.values[0] = Top_hub_XactTracker_5__io_busy.values[0]&&Top_hub__io_tiles_0_xact_init_valid.values[0]; }
  { T1372.values[0] = T1371.values[0]&&T1370.values[0]; }
  { T1373.values[0] = T1372.values[0]; }
  { Top_hub_XactTracker_6__io_addr.values[0] = Top_hub_XactTracker_6__addr_.values[0]; }
  T1374.values[0] = Top_hub_XactTracker_6__io_addr.values[0] == Top_hub__io_tiles_0_xact_init_bits_address.values[0];
  { T1375.values[0] = Top_hub_XactTracker_6__io_busy.values[0]&&Top_hub__io_tiles_0_xact_init_valid.values[0]; }
  { T1376.values[0] = T1375.values[0]&&T1374.values[0]; }
  { T1377.values[0] = T1376.values[0]; }
  { Top_hub_XactTracker_7__io_addr.values[0] = Top_hub_XactTracker_7__addr_.values[0]; }
  T1378.values[0] = Top_hub_XactTracker_7__io_addr.values[0] == Top_hub__io_tiles_0_xact_init_bits_address.values[0];
  { T1379.values[0] = Top_hub_XactTracker_7__io_busy.values[0]&&Top_hub__io_tiles_0_xact_init_valid.values[0]; }
  { T1380.values[0] = T1379.values[0]&&T1378.values[0]; }
  { T1381.values[0] = T1380.values[0]; }
  { T1382.values[0] = T1377.values[0] | T1381.values[0] << 1; }
  { T1383.values[0] = T1373.values[0] | T1382.values[0] << 1; }
  { T1384.values[0] = T1369.values[0] | T1383.values[0] << 1; }
  { T1385.values[0] = T1365.values[0] | T1384.values[0] << 1; }
  { T1386.values[0] = T1361.values[0] | T1385.values[0] << 1; }
  { T1387.values[0] = T1357.values[0] | T1386.values[0] << 1; }
  { T1388.values[0] = T1353.values[0] | T1387.values[0] << 1; }
  T1389.values[0] = (T1388.values[0]) != 0;
  { T1390.values[0] = T1389.values[0]||T1349.values[0]; }
  { T1391.values[0] = T1390.values[0]||T1333.values[0]; }
  { T1392.values[0] = Top_hub__io_tiles_0_xact_init_valid.values[0]&&T1391.values[0]; }
  { Top_hub__want_to_abort_arr_0.values[0] = T1392.values[0]; }
  T1393.values[0] = !Top_hub__want_to_abort_arr_0.values[0];
  T1394.values[0] = Top_hub__abort_state_arr_0.values[0] == 0x0L;
  { T1395.values[0] = T1394.values[0]&&T1393.values[0]; }
  { T1396.values[0] = T1395.values[0]&&Top_hub__io_tiles_0_xact_init_valid.values[0]; }
  { Top_hub_init_arb__io_in_0_valid.values[0] = T1396.values[0]; }
  { val_t __mask = -Top_hub_init_arb__io_in_0_valid.values[0]; Top_hub_init_arb__dout.values[0] = T1324.values[0] ^ ((T1324.values[0] ^ T1329.values[0]) & __mask); }
  { T1397.values[0] = Top_hub_init_arb__dout.values[0]; }
  T1397.values[0] = T1397.values[0] & 3;
  { Top_hub_init_arb__io_out_bits_tile_id.values[0] = T1397.values[0]; }
  { Top_hub_XactTracker_7__io_alloc_req_bits_tile_id.values[0] = Top_hub_init_arb__io_out_bits_tile_id.values[0]; }
  { T1398.values[0] = Top_hub_XactTracker_7__io_alloc_req_bits_tile_id.values[0]; }
  T1399.values[0] = 0x1L << T1398.values[0];
  T1400.values[0] = !Top_htif_x_init__maybe_full.values[0];
  T1401.values[0] = !T1400.values[0];
  { Top_htif_x_init__io_deq_valid.values[0] = T1401.values[0]; }
  { Top_htif__io_mem_xact_init_valid.values[0] = Top_htif_x_init__io_deq_valid.values[0]; }
  { Top_hub__io_tiles_1_xact_init_valid.values[0] = Top_htif__io_mem_xact_init_valid.values[0]; }
  T1402.values[0] = Top_hub__io_tiles_1_xact_init_bits_x_type.values[0] == 0x3L;
  { Top_hub_Queue_4__full.values[0] = Top_hub_Queue_4__ptr_match.values[0]&&Top_hub_Queue_4__maybe_full.values[0]; }
  T1403.values[0] = !Top_hub_Queue_4__full.values[0];
  { Top_hub_Queue_4__io_enq_ready.values[0] = T1403.values[0]; }
  T1404.values[0] = !Top_hub_Queue_4__io_enq_ready.values[0];
  { T1405.values[0] = T1404.values[0]&&T1402.values[0]; }
  { T1406.values[0] = Top_hub__busy_arr_6.values[0] | Top_hub__busy_arr_7.values[0] << 1; }
  { T1407.values[0] = Top_hub__busy_arr_5.values[0] | T1406.values[0] << 1; }
  { T1408.values[0] = Top_hub__busy_arr_4.values[0] | T1407.values[0] << 1; }
  { T1409.values[0] = Top_hub__busy_arr_3.values[0] | T1408.values[0] << 1; }
  { T1410.values[0] = Top_hub__busy_arr_2.values[0] | T1409.values[0] << 1; }
  { T1411.values[0] = Top_hub__busy_arr_1.values[0] | T1410.values[0] << 1; }
  { T1412.values[0] = Top_hub__busy_arr_0.values[0] | T1411.values[0] << 1; }
  T1413.values[0] = (T1412.values[0] == 255);
  T1414.values[0] = Top_hub_XactTracker__io_addr.values[0] == Top_hub__io_tiles_1_xact_init_bits_address.values[0];
  { T1415.values[0] = Top_hub_XactTracker__io_busy.values[0]&&Top_hub__io_tiles_1_xact_init_valid.values[0]; }
  { T1416.values[0] = T1415.values[0]&&T1414.values[0]; }
  { T1417.values[0] = T1416.values[0]; }
  T1418.values[0] = Top_hub_XactTracker_1__io_addr.values[0] == Top_hub__io_tiles_1_xact_init_bits_address.values[0];
  { T1419.values[0] = Top_hub_XactTracker_1__io_busy.values[0]&&Top_hub__io_tiles_1_xact_init_valid.values[0]; }
  { T1420.values[0] = T1419.values[0]&&T1418.values[0]; }
  { T1421.values[0] = T1420.values[0]; }
  T1422.values[0] = Top_hub_XactTracker_2__io_addr.values[0] == Top_hub__io_tiles_1_xact_init_bits_address.values[0];
  { T1423.values[0] = Top_hub_XactTracker_2__io_busy.values[0]&&Top_hub__io_tiles_1_xact_init_valid.values[0]; }
  { T1424.values[0] = T1423.values[0]&&T1422.values[0]; }
  { T1425.values[0] = T1424.values[0]; }
  T1426.values[0] = Top_hub_XactTracker_3__io_addr.values[0] == Top_hub__io_tiles_1_xact_init_bits_address.values[0];
  { T1427.values[0] = Top_hub_XactTracker_3__io_busy.values[0]&&Top_hub__io_tiles_1_xact_init_valid.values[0]; }
  { T1428.values[0] = T1427.values[0]&&T1426.values[0]; }
  { T1429.values[0] = T1428.values[0]; }
  T1430.values[0] = Top_hub_XactTracker_4__io_addr.values[0] == Top_hub__io_tiles_1_xact_init_bits_address.values[0];
  { T1431.values[0] = Top_hub_XactTracker_4__io_busy.values[0]&&Top_hub__io_tiles_1_xact_init_valid.values[0]; }
  { T1432.values[0] = T1431.values[0]&&T1430.values[0]; }
  { T1433.values[0] = T1432.values[0]; }
  T1434.values[0] = Top_hub_XactTracker_5__io_addr.values[0] == Top_hub__io_tiles_1_xact_init_bits_address.values[0];
  { T1435.values[0] = Top_hub_XactTracker_5__io_busy.values[0]&&Top_hub__io_tiles_1_xact_init_valid.values[0]; }
  { T1436.values[0] = T1435.values[0]&&T1434.values[0]; }
  { T1437.values[0] = T1436.values[0]; }
  T1438.values[0] = Top_hub_XactTracker_6__io_addr.values[0] == Top_hub__io_tiles_1_xact_init_bits_address.values[0];
  { T1439.values[0] = Top_hub_XactTracker_6__io_busy.values[0]&&Top_hub__io_tiles_1_xact_init_valid.values[0]; }
  { T1440.values[0] = T1439.values[0]&&T1438.values[0]; }
  { T1441.values[0] = T1440.values[0]; }
  T1442.values[0] = Top_hub_XactTracker_7__io_addr.values[0] == Top_hub__io_tiles_1_xact_init_bits_address.values[0];
  { T1443.values[0] = Top_hub_XactTracker_7__io_busy.values[0]&&Top_hub__io_tiles_1_xact_init_valid.values[0]; }
  { T1444.values[0] = T1443.values[0]&&T1442.values[0]; }
  { T1445.values[0] = T1444.values[0]; }
  { T1446.values[0] = T1441.values[0] | T1445.values[0] << 1; }
  { T1447.values[0] = T1437.values[0] | T1446.values[0] << 1; }
  { T1448.values[0] = T1433.values[0] | T1447.values[0] << 1; }
  { T1449.values[0] = T1429.values[0] | T1448.values[0] << 1; }
  { T1450.values[0] = T1425.values[0] | T1449.values[0] << 1; }
  { T1451.values[0] = T1421.values[0] | T1450.values[0] << 1; }
  { T1452.values[0] = T1417.values[0] | T1451.values[0] << 1; }
  T1453.values[0] = (T1452.values[0]) != 0;
  { T1454.values[0] = T1453.values[0]||T1413.values[0]; }
  { T1455.values[0] = T1454.values[0]||T1405.values[0]; }
  { T1456.values[0] = Top_hub__io_tiles_1_xact_init_valid.values[0]&&T1455.values[0]; }
  { Top_hub__want_to_abort_arr_1.values[0] = T1456.values[0]; }
  T1457.values[0] = !Top_hub__want_to_abort_arr_1.values[0];
  T1458.values[0] = Top_hub__abort_state_arr_1.values[0] == 0x0L;
  { T1459.values[0] = T1458.values[0]&&T1457.values[0]; }
  { T1460.values[0] = T1459.values[0]&&Top_hub__io_tiles_1_xact_init_valid.values[0]; }
  { Top_hub_init_arb__io_in_1_valid.values[0] = T1460.values[0]; }
  { T1461.values[0] = Top_hub_init_arb__io_in_0_valid.values[0]||Top_hub_init_arb__io_in_1_valid.values[0]; }
  { Top_hub_init_arb__io_out_valid.values[0] = T1461.values[0]; }
  { Top_hub_alloc_arb__io_out_ready.values[0] = Top_hub_init_arb__io_out_valid.values[0]; }
  T1462.values[0] = !Top_hub_XactTracker_6__io_busy.values[0];
  { Top_hub_alloc_arb__io_in_6_valid.values[0] = T1462.values[0]; }
  T1463.values[0] = !Top_hub_XactTracker_5__io_busy.values[0];
  { Top_hub_alloc_arb__io_in_5_valid.values[0] = T1463.values[0]; }
  T1464.values[0] = !Top_hub_XactTracker_4__io_busy.values[0];
  { Top_hub_alloc_arb__io_in_4_valid.values[0] = T1464.values[0]; }
  T1465.values[0] = !Top_hub_XactTracker_3__io_busy.values[0];
  { Top_hub_alloc_arb__io_in_3_valid.values[0] = T1465.values[0]; }
  T1466.values[0] = !Top_hub_XactTracker_2__io_busy.values[0];
  { Top_hub_alloc_arb__io_in_2_valid.values[0] = T1466.values[0]; }
  T1467.values[0] = !Top_hub_XactTracker_1__io_busy.values[0];
  { Top_hub_alloc_arb__io_in_1_valid.values[0] = T1467.values[0]; }
  T1468.values[0] = !Top_hub_XactTracker__io_busy.values[0];
  { Top_hub_alloc_arb__io_in_0_valid.values[0] = T1468.values[0]; }
  { T1469.values[0] = Top_hub_alloc_arb__io_in_0_valid.values[0]||Top_hub_alloc_arb__io_in_1_valid.values[0]; }
  { T1470.values[0] = T1469.values[0]||Top_hub_alloc_arb__io_in_2_valid.values[0]; }
  { T1471.values[0] = T1470.values[0]||Top_hub_alloc_arb__io_in_3_valid.values[0]; }
  { T1472.values[0] = T1471.values[0]||Top_hub_alloc_arb__io_in_4_valid.values[0]; }
  { T1473.values[0] = T1472.values[0]||Top_hub_alloc_arb__io_in_5_valid.values[0]; }
  { T1474.values[0] = T1473.values[0]||Top_hub_alloc_arb__io_in_6_valid.values[0]; }
  T1475.values[0] = !T1474.values[0];
  { T1476.values[0] = T1475.values[0]&&Top_hub_alloc_arb__io_out_ready.values[0]; }
  { Top_hub_alloc_arb__io_in_7_ready.values[0] = T1476.values[0]; }
  { Top_hub_XactTracker_7__io_can_alloc.values[0] = Top_hub_alloc_arb__io_in_7_ready.values[0]; }
  { Top_hub_XactTracker_7__io_alloc_req_valid.values[0] = Top_hub_init_arb__io_out_valid.values[0]; }
  { T1477.values[0] = Top_hub_XactTracker_7__io_alloc_req_valid.values[0]&&Top_hub_XactTracker_7__io_can_alloc.values[0]; }
  T1478.values[0] = Top_hub_XactTracker_7__state.values[0] == 0x0L;
  { T1479.values[0] = T1478.values[0]&&T1477.values[0]; }
  { val_t __mask = -T1479.values[0]; T1480.values[0] = 0x0L ^ ((0x0L ^ T1399.values[0]) & __mask); }
  { T1481.values[0] = T1480.values[0]; }
  T1481.values[0] = T1481.values[0] & 3;
  { Top_hub_XactTracker_7__io_pop_x_init.values[0] = T1481.values[0]; }
  T1482.values[0] = (Top_hub_XactTracker_7__io_pop_x_init.values[0] >> 0) & 1;
  { T1483.values[0] = T1482.values[0]; }
  { Top_hub_XactTracker_6__io_alloc_req_bits_tile_id.values[0] = Top_hub_init_arb__io_out_bits_tile_id.values[0]; }
  { T1484.values[0] = Top_hub_XactTracker_6__io_alloc_req_bits_tile_id.values[0]; }
  T1485.values[0] = 0x1L << T1484.values[0];
  { T1486.values[0] = Top_hub_alloc_arb__io_in_0_valid.values[0]||Top_hub_alloc_arb__io_in_1_valid.values[0]; }
  { T1487.values[0] = T1486.values[0]||Top_hub_alloc_arb__io_in_2_valid.values[0]; }
  { T1488.values[0] = T1487.values[0]||Top_hub_alloc_arb__io_in_3_valid.values[0]; }
  { T1489.values[0] = T1488.values[0]||Top_hub_alloc_arb__io_in_4_valid.values[0]; }
  { T1490.values[0] = T1489.values[0]||Top_hub_alloc_arb__io_in_5_valid.values[0]; }
  T1491.values[0] = !T1490.values[0];
  { T1492.values[0] = T1491.values[0]&&Top_hub_alloc_arb__io_out_ready.values[0]; }
  { Top_hub_alloc_arb__io_in_6_ready.values[0] = T1492.values[0]; }
  { Top_hub_XactTracker_6__io_can_alloc.values[0] = Top_hub_alloc_arb__io_in_6_ready.values[0]; }
  { Top_hub_XactTracker_6__io_alloc_req_valid.values[0] = Top_hub_init_arb__io_out_valid.values[0]; }
  { T1493.values[0] = Top_hub_XactTracker_6__io_alloc_req_valid.values[0]&&Top_hub_XactTracker_6__io_can_alloc.values[0]; }
  T1494.values[0] = Top_hub_XactTracker_6__state.values[0] == 0x0L;
  { T1495.values[0] = T1494.values[0]&&T1493.values[0]; }
  { val_t __mask = -T1495.values[0]; T1496.values[0] = 0x0L ^ ((0x0L ^ T1485.values[0]) & __mask); }
  { T1497.values[0] = T1496.values[0]; }
  T1497.values[0] = T1497.values[0] & 3;
  { Top_hub_XactTracker_6__io_pop_x_init.values[0] = T1497.values[0]; }
  T1498.values[0] = (Top_hub_XactTracker_6__io_pop_x_init.values[0] >> 0) & 1;
  { T1499.values[0] = T1498.values[0]; }
  { T1500.values[0] = T1499.values[0]||T1483.values[0]; }
  { Top_hub_XactTracker_5__io_alloc_req_bits_tile_id.values[0] = Top_hub_init_arb__io_out_bits_tile_id.values[0]; }
  { T1501.values[0] = Top_hub_XactTracker_5__io_alloc_req_bits_tile_id.values[0]; }
  T1502.values[0] = 0x1L << T1501.values[0];
  { T1503.values[0] = Top_hub_alloc_arb__io_in_0_valid.values[0]||Top_hub_alloc_arb__io_in_1_valid.values[0]; }
  { T1504.values[0] = T1503.values[0]||Top_hub_alloc_arb__io_in_2_valid.values[0]; }
  { T1505.values[0] = T1504.values[0]||Top_hub_alloc_arb__io_in_3_valid.values[0]; }
  { T1506.values[0] = T1505.values[0]||Top_hub_alloc_arb__io_in_4_valid.values[0]; }
  T1507.values[0] = !T1506.values[0];
  { T1508.values[0] = T1507.values[0]&&Top_hub_alloc_arb__io_out_ready.values[0]; }
  { Top_hub_alloc_arb__io_in_5_ready.values[0] = T1508.values[0]; }
  { Top_hub_XactTracker_5__io_can_alloc.values[0] = Top_hub_alloc_arb__io_in_5_ready.values[0]; }
  { Top_hub_XactTracker_5__io_alloc_req_valid.values[0] = Top_hub_init_arb__io_out_valid.values[0]; }
  { T1509.values[0] = Top_hub_XactTracker_5__io_alloc_req_valid.values[0]&&Top_hub_XactTracker_5__io_can_alloc.values[0]; }
  T1510.values[0] = Top_hub_XactTracker_5__state.values[0] == 0x0L;
  { T1511.values[0] = T1510.values[0]&&T1509.values[0]; }
  { val_t __mask = -T1511.values[0]; T1512.values[0] = 0x0L ^ ((0x0L ^ T1502.values[0]) & __mask); }
  { T1513.values[0] = T1512.values[0]; }
  T1513.values[0] = T1513.values[0] & 3;
  { Top_hub_XactTracker_5__io_pop_x_init.values[0] = T1513.values[0]; }
  T1514.values[0] = (Top_hub_XactTracker_5__io_pop_x_init.values[0] >> 0) & 1;
  { T1515.values[0] = T1514.values[0]; }
  { T1516.values[0] = T1515.values[0]||T1500.values[0]; }
  { Top_hub_XactTracker_4__io_alloc_req_bits_tile_id.values[0] = Top_hub_init_arb__io_out_bits_tile_id.values[0]; }
  { T1517.values[0] = Top_hub_XactTracker_4__io_alloc_req_bits_tile_id.values[0]; }
  T1518.values[0] = 0x1L << T1517.values[0];
  { T1519.values[0] = Top_hub_alloc_arb__io_in_0_valid.values[0]||Top_hub_alloc_arb__io_in_1_valid.values[0]; }
  { T1520.values[0] = T1519.values[0]||Top_hub_alloc_arb__io_in_2_valid.values[0]; }
  { T1521.values[0] = T1520.values[0]||Top_hub_alloc_arb__io_in_3_valid.values[0]; }
  T1522.values[0] = !T1521.values[0];
  { T1523.values[0] = T1522.values[0]&&Top_hub_alloc_arb__io_out_ready.values[0]; }
  { Top_hub_alloc_arb__io_in_4_ready.values[0] = T1523.values[0]; }
  { Top_hub_XactTracker_4__io_can_alloc.values[0] = Top_hub_alloc_arb__io_in_4_ready.values[0]; }
  { Top_hub_XactTracker_4__io_alloc_req_valid.values[0] = Top_hub_init_arb__io_out_valid.values[0]; }
  { T1524.values[0] = Top_hub_XactTracker_4__io_alloc_req_valid.values[0]&&Top_hub_XactTracker_4__io_can_alloc.values[0]; }
  T1525.values[0] = Top_hub_XactTracker_4__state.values[0] == 0x0L;
  { T1526.values[0] = T1525.values[0]&&T1524.values[0]; }
  { val_t __mask = -T1526.values[0]; T1527.values[0] = 0x0L ^ ((0x0L ^ T1518.values[0]) & __mask); }
  { T1528.values[0] = T1527.values[0]; }
  T1528.values[0] = T1528.values[0] & 3;
  { Top_hub_XactTracker_4__io_pop_x_init.values[0] = T1528.values[0]; }
  T1529.values[0] = (Top_hub_XactTracker_4__io_pop_x_init.values[0] >> 0) & 1;
  { T1530.values[0] = T1529.values[0]; }
  { T1531.values[0] = T1530.values[0]||T1516.values[0]; }
  { Top_hub_XactTracker_3__io_alloc_req_bits_tile_id.values[0] = Top_hub_init_arb__io_out_bits_tile_id.values[0]; }
  { T1532.values[0] = Top_hub_XactTracker_3__io_alloc_req_bits_tile_id.values[0]; }
  T1533.values[0] = 0x1L << T1532.values[0];
  { T1534.values[0] = Top_hub_alloc_arb__io_in_0_valid.values[0]||Top_hub_alloc_arb__io_in_1_valid.values[0]; }
  { T1535.values[0] = T1534.values[0]||Top_hub_alloc_arb__io_in_2_valid.values[0]; }
  T1536.values[0] = !T1535.values[0];
  { T1537.values[0] = T1536.values[0]&&Top_hub_alloc_arb__io_out_ready.values[0]; }
  { Top_hub_alloc_arb__io_in_3_ready.values[0] = T1537.values[0]; }
  { Top_hub_XactTracker_3__io_can_alloc.values[0] = Top_hub_alloc_arb__io_in_3_ready.values[0]; }
  { Top_hub_XactTracker_3__io_alloc_req_valid.values[0] = Top_hub_init_arb__io_out_valid.values[0]; }
  { T1538.values[0] = Top_hub_XactTracker_3__io_alloc_req_valid.values[0]&&Top_hub_XactTracker_3__io_can_alloc.values[0]; }
  T1539.values[0] = Top_hub_XactTracker_3__state.values[0] == 0x0L;
  { T1540.values[0] = T1539.values[0]&&T1538.values[0]; }
  { val_t __mask = -T1540.values[0]; T1541.values[0] = 0x0L ^ ((0x0L ^ T1533.values[0]) & __mask); }
  { T1542.values[0] = T1541.values[0]; }
  T1542.values[0] = T1542.values[0] & 3;
  { Top_hub_XactTracker_3__io_pop_x_init.values[0] = T1542.values[0]; }
  T1543.values[0] = (Top_hub_XactTracker_3__io_pop_x_init.values[0] >> 0) & 1;
  { T1544.values[0] = T1543.values[0]; }
  { T1545.values[0] = T1544.values[0]||T1531.values[0]; }
  { Top_hub_XactTracker_2__io_alloc_req_bits_tile_id.values[0] = Top_hub_init_arb__io_out_bits_tile_id.values[0]; }
  { T1546.values[0] = Top_hub_XactTracker_2__io_alloc_req_bits_tile_id.values[0]; }
  T1547.values[0] = 0x1L << T1546.values[0];
  { T1548.values[0] = Top_hub_alloc_arb__io_in_0_valid.values[0]||Top_hub_alloc_arb__io_in_1_valid.values[0]; }
  T1549.values[0] = !T1548.values[0];
  { T1550.values[0] = T1549.values[0]&&Top_hub_alloc_arb__io_out_ready.values[0]; }
  { Top_hub_alloc_arb__io_in_2_ready.values[0] = T1550.values[0]; }
  { Top_hub_XactTracker_2__io_can_alloc.values[0] = Top_hub_alloc_arb__io_in_2_ready.values[0]; }
  { Top_hub_XactTracker_2__io_alloc_req_valid.values[0] = Top_hub_init_arb__io_out_valid.values[0]; }
  { T1551.values[0] = Top_hub_XactTracker_2__io_alloc_req_valid.values[0]&&Top_hub_XactTracker_2__io_can_alloc.values[0]; }
  T1552.values[0] = Top_hub_XactTracker_2__state.values[0] == 0x0L;
  { T1553.values[0] = T1552.values[0]&&T1551.values[0]; }
  { val_t __mask = -T1553.values[0]; T1554.values[0] = 0x0L ^ ((0x0L ^ T1547.values[0]) & __mask); }
  { T1555.values[0] = T1554.values[0]; }
  T1555.values[0] = T1555.values[0] & 3;
  { Top_hub_XactTracker_2__io_pop_x_init.values[0] = T1555.values[0]; }
  T1556.values[0] = (Top_hub_XactTracker_2__io_pop_x_init.values[0] >> 0) & 1;
  { T1557.values[0] = T1556.values[0]; }
  { T1558.values[0] = T1557.values[0]||T1545.values[0]; }
  { Top_hub_XactTracker_1__io_alloc_req_bits_tile_id.values[0] = Top_hub_init_arb__io_out_bits_tile_id.values[0]; }
  { T1559.values[0] = Top_hub_XactTracker_1__io_alloc_req_bits_tile_id.values[0]; }
  T1560.values[0] = 0x1L << T1559.values[0];
  T1561.values[0] = !Top_hub_alloc_arb__io_in_0_valid.values[0];
  { T1562.values[0] = T1561.values[0]&&Top_hub_alloc_arb__io_out_ready.values[0]; }
  { Top_hub_alloc_arb__io_in_1_ready.values[0] = T1562.values[0]; }
  { Top_hub_XactTracker_1__io_can_alloc.values[0] = Top_hub_alloc_arb__io_in_1_ready.values[0]; }
  { Top_hub_XactTracker_1__io_alloc_req_valid.values[0] = Top_hub_init_arb__io_out_valid.values[0]; }
  { T1563.values[0] = Top_hub_XactTracker_1__io_alloc_req_valid.values[0]&&Top_hub_XactTracker_1__io_can_alloc.values[0]; }
  T1564.values[0] = Top_hub_XactTracker_1__state.values[0] == 0x0L;
  { T1565.values[0] = T1564.values[0]&&T1563.values[0]; }
  { val_t __mask = -T1565.values[0]; T1566.values[0] = 0x0L ^ ((0x0L ^ T1560.values[0]) & __mask); }
  { T1567.values[0] = T1566.values[0]; }
  T1567.values[0] = T1567.values[0] & 3;
  { Top_hub_XactTracker_1__io_pop_x_init.values[0] = T1567.values[0]; }
  T1568.values[0] = (Top_hub_XactTracker_1__io_pop_x_init.values[0] >> 0) & 1;
  { T1569.values[0] = T1568.values[0]; }
  { T1570.values[0] = T1569.values[0]||T1558.values[0]; }
  { Top_hub_XactTracker__io_alloc_req_bits_tile_id.values[0] = Top_hub_init_arb__io_out_bits_tile_id.values[0]; }
  { T1571.values[0] = Top_hub_XactTracker__io_alloc_req_bits_tile_id.values[0]; }
  T1572.values[0] = 0x1L << T1571.values[0];
  { Top_hub_alloc_arb__io_in_0_ready.values[0] = Top_hub_alloc_arb__io_out_ready.values[0]; }
  { Top_hub_XactTracker__io_can_alloc.values[0] = Top_hub_alloc_arb__io_in_0_ready.values[0]; }
  { Top_hub_XactTracker__io_alloc_req_valid.values[0] = Top_hub_init_arb__io_out_valid.values[0]; }
  { T1573.values[0] = Top_hub_XactTracker__io_alloc_req_valid.values[0]&&Top_hub_XactTracker__io_can_alloc.values[0]; }
  T1574.values[0] = Top_hub_XactTracker__state.values[0] == 0x0L;
  { T1575.values[0] = T1574.values[0]&&T1573.values[0]; }
  { val_t __mask = -T1575.values[0]; T1576.values[0] = 0x0L ^ ((0x0L ^ T1572.values[0]) & __mask); }
  { T1577.values[0] = T1576.values[0]; }
  T1577.values[0] = T1577.values[0] & 3;
  { Top_hub_XactTracker__io_pop_x_init.values[0] = T1577.values[0]; }
  T1578.values[0] = (Top_hub_XactTracker__io_pop_x_init.values[0] >> 0) & 1;
  { T1579.values[0] = T1578.values[0]; }
  { T1580.values[0] = T1579.values[0]||T1570.values[0]; }
  { Top_hub__io_tiles_0_xact_abort_ready.values[0] = Top_Queue_17__io_enq_ready.values[0]; }
  { T1581.values[0] = Top_hub__io_tiles_0_xact_abort_valid.values[0]&&Top_hub__io_tiles_0_xact_abort_ready.values[0]; }
  { T1582.values[0] = T1581.values[0]||T1580.values[0]; }
  { Top_hub__io_tiles_0_xact_init_ready.values[0] = T1582.values[0]; }
  { Top_Queue_15__io_deq_ready.values[0] = Top_hub__io_tiles_0_xact_init_ready.values[0]; }
  { T1583.values[0] = Top_Queue_15__io_deq_ready.values[0]&&Top_Queue_15__io_deq_valid.values[0]; }
  { Top_Queue_15__do_deq.values[0] = T1583.values[0]&&T1310.values[0]; }
  T1584.values[0] = Top_Queue_15__do_enq.values[0] != Top_Queue_15__do_deq.values[0];
  { val_t __mask = -T1584.values[0]; T1585.values[0] = Top_Queue_15__maybe_full.values[0] ^ ((Top_Queue_15__maybe_full.values[0] ^ Top_Queue_15__do_enq.values[0]) & __mask); }
  { Top_Queue_15__maybe_full_shadow.values[0] = TERNARY(Top_Queue_15__reset.values[0], 0x0L, T1585.values[0]); }
  { T1586.values[0] = Top_Queue_15__deq_ptr.values[0]+0x1L; }
  T1586.values[0] = T1586.values[0] & 1;
  { val_t __mask = -Top_Queue_15__do_deq.values[0]; T1587.values[0] = Top_Queue_15__deq_ptr.values[0] ^ ((Top_Queue_15__deq_ptr.values[0] ^ T1586.values[0]) & __mask); }
  { Top_Queue_15__deq_ptr_shadow.values[0] = TERNARY(Top_Queue_15__reset.values[0], 0x0L, T1587.values[0]); }
  { T1589.values[0] = Top_SodorTile_cache__io_cpu_req_addr.values[0] >> 6; }
  T1589.values[0] = T1589.values[0] & 67108863;
  { T1590.values[0] = Top_SodorTile_cache__tag_array.get(Top_SodorTile_cache__access_idx.values[0], 0); }
  { T1591.values[0] = Top_SodorTile_cache__access_idx.values[0] | T1590.values[0] << 10; }
  { val_t __mask = -Top_SodorTile_cache__line_is_dirty.values[0]; T1592.values[0] = T1589.values[0] ^ ((T1589.values[0] ^ T1591.values[0]) & __mask); }
  { T1593.values[0] = T1592.values[0]; }
  { T1594.values[0] = T1593.values[0] | 0x0L << 26; }
  { Top_SodorTile_cache__io_mem_xact_init_bits_address.values[0] = T1594.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_init_bits_address.values[0] = Top_SodorTile_cache__io_mem_xact_init_bits_address.values[0]; }
  { Top_SodorTile_arbiter__xi_bits_address.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_init_bits_address.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_init_bits_address.values[0] = Top_SodorTile_arbiter__xi_bits_address.values[0]; }
  { Top_SodorTile__io_tilelink_xact_init_bits_address.values[0] = Top_SodorTile_arbiter__io_mem_xact_init_bits_address.values[0]; }
  { Top_Queue_15__io_enq_bits_address.values[0] = Top_SodorTile__io_tilelink_xact_init_bits_address.values[0]; }
  { T1595.values[0] = 0x0L | Top_SodorTile_arbiter__io_requestor_0_xact_init_bits_tile_xact_id.values[0] << 1; }
  { T1596.values[0] = T1595.values[0]; }
  T1596.values[0] = T1596.values[0] & 31;
  { Top_SodorTile_arbiter__xi_bits_tile_xact_id.values[0] = T1596.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_init_bits_tile_xact_id.values[0] = Top_SodorTile_arbiter__xi_bits_tile_xact_id.values[0]; }
  { Top_SodorTile__io_tilelink_xact_init_bits_tile_xact_id.values[0] = Top_SodorTile_arbiter__io_mem_xact_init_bits_tile_xact_id.values[0]; }
  { Top_Queue_15__io_enq_bits_tile_xact_id.values[0] = Top_SodorTile__io_tilelink_xact_init_bits_tile_xact_id.values[0]; }
  { val_t __mask = -Top_SodorTile_cache__line_is_dirty.values[0]; T1597.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { Top_SodorTile_cache__io_mem_xact_init_bits_x_type.values[0] = T1597.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_init_bits_x_type.values[0] = Top_SodorTile_cache__io_mem_xact_init_bits_x_type.values[0]; }
  { Top_SodorTile_arbiter__xi_bits_x_type.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_init_bits_x_type.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_init_bits_x_type.values[0] = Top_SodorTile_arbiter__xi_bits_x_type.values[0]; }
  { Top_SodorTile__io_tilelink_xact_init_bits_x_type.values[0] = Top_SodorTile_arbiter__io_mem_xact_init_bits_x_type.values[0]; }
  { Top_Queue_15__io_enq_bits_x_type.values[0] = Top_SodorTile__io_tilelink_xact_init_bits_x_type.values[0]; }
  { T1598.values[0] = Top_Queue_15__io_enq_bits_tile_xact_id.values[0] | Top_Queue_15__io_enq_bits_x_type.values[0] << 5; }
  { T1599.values[0] = Top_Queue_15__io_enq_bits_address.values[0] | T1598.values[0] << 34; }
  { T1602.values[0] = 0x0L | Top_SodorTile_cpu_d_pcr__reg_status_im.values[0] << 7; }
  { T1603.values[0] = Top_SodorTile_cpu_d_pcr__reg_status_vm.values[0] | T1602.values[0] << 1; }
  { T1604.values[0] = 0x0L | T1603.values[0] << 1; }
  { T1605.values[0] = 0x0L | T1604.values[0] << 1; }
  { T1606.values[0] = Top_SodorTile_cpu_d_pcr__reg_status_s.values[0] | T1605.values[0] << 1; }
  { T1607.values[0] = Top_SodorTile_cpu_d_pcr__reg_status_ps.values[0] | T1606.values[0] << 1; }
  { T1608.values[0] = 0x0L | T1607.values[0] << 1; }
  { T1609.values[0] = 0x0L | T1608.values[0] << 1; }
  { T1610.values[0] = 0x0L | T1609.values[0] << 1; }
  { Top_SodorTile_cpu_d_pcr__status.values[0] = Top_SodorTile_cpu_d_pcr__reg_status_et.values[0] | T1610.values[0] << 1; }
  { T1611.values[0] = Top_SodorTile_cpu_d_pcr__status.values[0] | 0x0L << 24; }
  { T1612.values[0] = Top_Queue_11__ram.get(Top_Queue_11__deq_ptr.values[0], 0); T1612.values[1] = Top_Queue_11__ram.get(Top_Queue_11__deq_ptr.values[0], 1); }
  { T1613.values[0] = T1612.values[0]; }
  { T1614.values[0] = T1612.values[1]; }
  T1614.values[0] = T1614.values[0] & 63;
  T1615.values[0] = (T1612.values[1] >> 6) & 1;
  { T1616.values[0] = T1614.values[0] | T1615.values[0] << 6; }
  { T1617.values[0] = T1613.values[0]; T1617.values[1] = T1616.values[0]; }
  { T1618.values[0] = T1617.values[1]; }
  T1618.values[0] = T1618.values[0] & 63;
  { Top_Queue_11__io_deq_bits_addr.values[0] = T1618.values[0]; }
  { Top_SodorTile__io_host_pcr_req_bits_addr.values[0] = Top_Queue_11__io_deq_bits_addr.values[0]; }
  { Top_SodorTile_cpu__io_host_pcr_req_bits_addr.values[0] = Top_SodorTile__io_host_pcr_req_bits_addr.values[0]; }
  { Top_SodorTile_cpu_d__io_host_pcr_req_bits_addr.values[0] = Top_SodorTile_cpu__io_host_pcr_req_bits_addr.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_addr.values[0] = Top_SodorTile_cpu_d__io_host_pcr_req_bits_addr.values[0]; }
  { T1619.values[0] = Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_addr.values[0]; }
  T1619.values[0] = T1619.values[0] & 31;
  { T1620.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 22; }
  T1620.values[0] = T1620.values[0] & 31;
  { Top_SodorTile_cpu_d__rs1.values[0] = T1620.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_r_addr.values[0] = Top_SodorTile_cpu_d__rs1.values[0]; }
  { T1621.values[0] = Top_SodorTile_cpu_c__micro_code.get(Top_SodorTile_cpu_c__upc_state.values[0], 0); }
  { T1622.values[0] = T1621.values[0] >> 27; }
  T1622.values[0] = T1622.values[0] & 7;
  { Top_SodorTile_cpu_c__cs_reg_sel.values[0] = T1622.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_reg_sel.values[0] = Top_SodorTile_cpu_c__cs_reg_sel.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] = Top_SodorTile_cpu_c__io_ctl_reg_sel.values[0]; }
  T1623.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x6L;
  T1624.values[0] = (T1621.values[0] >> 26) & 1;
  { Top_SodorTile_cpu_c__cs_reg_wr.values[0] = T1624.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_reg_wr.values[0] = Top_SodorTile_cpu_c__cs_reg_wr.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_reg_wr.values[0] = Top_SodorTile_cpu_c__io_ctl_reg_wr.values[0]; }
  T1625.values[0] = !Top_SodorTile_cpu_d__io_ctl_reg_wr.values[0];
  T1626.values[0] = (T1621.values[0] >> 25) & 1;
  { Top_SodorTile_cpu_c__cs_en_reg.values[0] = T1626.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_en_reg.values[0] = Top_SodorTile_cpu_c__cs_en_reg.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_en_reg.values[0] = Top_SodorTile_cpu_c__io_ctl_en_reg.values[0]; }
  { T1627.values[0] = Top_SodorTile_cpu_d__io_ctl_en_reg.values[0]&&T1625.values[0]; }
  { T1628.values[0] = T1627.values[0]&&T1623.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_r_en.values[0] = T1628.values[0]; }
  { val_t __mask = -Top_SodorTile_cpu_d_pcr__io_r_en.values[0]; Top_SodorTile_cpu_d_pcr__raddr.values[0] = T1619.values[0] ^ ((T1619.values[0] ^ Top_SodorTile_cpu_d_pcr__io_r_addr.values[0]) & __mask); }
  T1629.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0x1fL;
  { val_t __mask = -T1629.values[0]; T1630.values[0] = T1611.values[0] ^ ((T1611.values[0] ^ Top_SodorTile_cpu_d_pcr__reg_fromhost.values[0]) & __mask); }
  T1631.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0x1eL;
  { val_t __mask = -T1631.values[0]; T1632.values[0] = T1630.values[0] ^ ((T1630.values[0] ^ Top_SodorTile_cpu_d_pcr__reg_tohost.values[0]) & __mask); }
  { T1633.values[0] = Top_SodorTile_cpu_d_pcr__reg_stats.values[0] | 0x0L << 1; }
  T1634.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0xaL;
  { val_t __mask = -T1634.values[0]; T1635.values[0] = T1632.values[0] ^ ((T1632.values[0] ^ T1633.values[0]) & __mask); }
  { T1636.values[0] = Top_SodorTile_cpu_d_pcr__status.values[0] | 0x0L << 24; }
  T1637.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0x0L;
  { val_t __mask = -T1637.values[0]; T1638.values[0] = T1635.values[0] ^ ((T1635.values[0] ^ T1636.values[0]) & __mask); }
  { T1639.values[0] = T1638.values[0] | 0x0L << 32; }
  T1640.values[0] = (Top_SodorTile_cpu_d_pcr__reg_epc.values[0] >> 43) & 1;
  { T1641.values[0] = T1640.values[0] | T1640.values[0] << 1; }
  { T1642.values[0] = T1641.values[0] | T1641.values[0] << 2; }
  { T1643.values[0] = T1642.values[0] | T1642.values[0] << 4; }
  { T1644.values[0] = T1643.values[0] | T1643.values[0] << 8; }
  { T1645.values[0] = T1642.values[0] | T1644.values[0] << 4; }
  { T1646.values[0] = Top_SodorTile_cpu_d_pcr__reg_epc.values[0] | T1645.values[0] << 44; }
  T1647.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0x1L;
  { val_t __mask = -T1647.values[0]; T1648.values[0] = T1639.values[0] ^ ((T1639.values[0] ^ T1646.values[0]) & __mask); }
  T1649.values[0] = (Top_SodorTile_cpu_d_pcr__reg_ebase.values[0] >> 42) & 1;
  { T1650.values[0] = T1649.values[0] | T1649.values[0] << 1; }
  { T1651.values[0] = T1650.values[0] | T1650.values[0] << 2; }
  { T1652.values[0] = T1649.values[0] | T1651.values[0] << 1; }
  { T1653.values[0] = T1651.values[0] | T1651.values[0] << 4; }
  { T1654.values[0] = T1653.values[0] | T1653.values[0] << 8; }
  { T1655.values[0] = T1652.values[0] | T1654.values[0] << 5; }
  { T1656.values[0] = Top_SodorTile_cpu_d_pcr__reg_ebase.values[0] | T1655.values[0] << 43; }
  T1657.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0x3L;
  { val_t __mask = -T1657.values[0]; T1658.values[0] = T1648.values[0] ^ ((T1648.values[0] ^ T1656.values[0]) & __mask); }
  T1659.values[0] = (Top_SodorTile_cpu_d_pcr__reg_count.values[0] >> 31) & 1;
  { T1660.values[0] = T1659.values[0] | T1659.values[0] << 1; }
  { T1661.values[0] = T1660.values[0] | T1660.values[0] << 2; }
  { T1662.values[0] = T1661.values[0] | T1661.values[0] << 4; }
  { T1663.values[0] = T1662.values[0] | T1662.values[0] << 8; }
  { T1664.values[0] = T1663.values[0] | T1663.values[0] << 16; }
  { T1665.values[0] = Top_SodorTile_cpu_d_pcr__reg_count.values[0] | T1664.values[0] << 32; }
  T1666.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0x4L;
  { val_t __mask = -T1666.values[0]; T1667.values[0] = T1658.values[0] ^ ((T1658.values[0] ^ T1665.values[0]) & __mask); }
  T1668.values[0] = (Top_SodorTile_cpu_d_pcr__reg_compare.values[0] >> 31) & 1;
  { T1669.values[0] = T1668.values[0] | T1668.values[0] << 1; }
  { T1670.values[0] = T1669.values[0] | T1669.values[0] << 2; }
  { T1671.values[0] = T1670.values[0] | T1670.values[0] << 4; }
  { T1672.values[0] = T1671.values[0] | T1671.values[0] << 8; }
  { T1673.values[0] = T1672.values[0] | T1672.values[0] << 16; }
  { T1674.values[0] = Top_SodorTile_cpu_d_pcr__reg_compare.values[0] | T1673.values[0] << 32; }
  T1675.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0x5L;
  { val_t __mask = -T1675.values[0]; T1676.values[0] = T1667.values[0] ^ ((T1667.values[0] ^ T1674.values[0]) & __mask); }
  { T1677.values[0] = Top_SodorTile_cpu_d_pcr__reg_cause.values[0]; }
  T1677.values[0] = T1677.values[0] & 31;
  T1678.values[0] = (Top_SodorTile_cpu_d_pcr__reg_cause.values[0] >> 5) & 1;
  { T1679.values[0] = 0x0L | T1678.values[0] << 58; }
  { T1680.values[0] = T1677.values[0] | T1679.values[0] << 5; }
  T1681.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0x6L;
  { val_t __mask = -T1681.values[0]; T1682.values[0] = T1676.values[0] ^ ((T1676.values[0] ^ T1680.values[0]) & __mask); }
  T1683.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0xcL;
  { val_t __mask = -T1683.values[0]; T1684.values[0] = T1682.values[0] ^ ((T1682.values[0] ^ Top_SodorTile_cpu_d_pcr__reg_k0.values[0]) & __mask); }
  T1685.values[0] = Top_SodorTile_cpu_d_pcr__raddr.values[0] == 0xdL;
  { val_t __mask = -T1685.values[0]; T1686.values[0] = T1684.values[0] ^ ((T1684.values[0] ^ Top_SodorTile_cpu_d_pcr__reg_k1.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__rdata.values[0] = T1686.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_host_pcr_rep_bits.values[0] = Top_SodorTile_cpu_d_pcr__rdata.values[0]; }
  { Top_SodorTile_cpu_d__io_host_pcr_rep_bits.values[0] = Top_SodorTile_cpu_d_pcr__io_host_pcr_rep_bits.values[0]; }
  { Top_SodorTile_cpu__io_host_pcr_rep_bits.values[0] = Top_SodorTile_cpu_d__io_host_pcr_rep_bits.values[0]; }
  { Top_SodorTile__io_host_pcr_rep_bits.values[0] = Top_SodorTile_cpu__io_host_pcr_rep_bits.values[0]; }
  { Top_Queue_12__io_enq_bits.values[0] = Top_SodorTile__io_host_pcr_rep_bits.values[0]; }
  { Top_Queue_12__do_flow.values[0] = 0x0L; }
  T1687.values[0] = !Top_Queue_12__do_flow.values[0];
  T1688.values[0] = !Top_Queue_11__maybe_full.values[0];
  Top_Queue_11__ptr_match.values[0] = Top_Queue_11__enq_ptr.values[0] == Top_Queue_11__deq_ptr.values[0];
  { Top_Queue_11__empty.values[0] = Top_Queue_11__ptr_match.values[0]&&T1688.values[0]; }
  T1689.values[0] = !Top_Queue_11__empty.values[0];
  { Top_Queue_11__io_deq_valid.values[0] = T1689.values[0]; }
  { Top_SodorTile__io_host_pcr_req_valid.values[0] = Top_Queue_11__io_deq_valid.values[0]; }
  { Top_SodorTile_cpu__io_host_pcr_req_valid.values[0] = Top_SodorTile__io_host_pcr_req_valid.values[0]; }
  { Top_SodorTile_cpu_d__io_host_pcr_req_valid.values[0] = Top_SodorTile_cpu__io_host_pcr_req_valid.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_host_pcr_req_valid.values[0] = Top_SodorTile_cpu_d__io_host_pcr_req_valid.values[0]; }
  T1690.values[0] = !Top_SodorTile_cpu_d_pcr__io_r_en.values[0];
  T1691.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x6L;
  { T1692.values[0] = Top_SodorTile_cpu_d__io_ctl_en_reg.values[0]&&Top_SodorTile_cpu_d__io_ctl_reg_wr.values[0]; }
  { T1693.values[0] = T1692.values[0]&&T1691.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_w_en.values[0] = T1693.values[0]; }
  T1694.values[0] = !Top_SodorTile_cpu_d_pcr__io_w_en.values[0];
  { T1695.values[0] = T1694.values[0]&&T1690.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_host_pcr_req_ready.values[0] = T1695.values[0]; }
  { T1696.values[0] = Top_SodorTile_cpu_d_pcr__io_host_pcr_req_ready.values[0]&&Top_SodorTile_cpu_d_pcr__io_host_pcr_req_valid.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_host_pcr_rep_valid.values[0] = T1696.values[0]; }
  { Top_SodorTile_cpu_d__io_host_pcr_rep_valid.values[0] = Top_SodorTile_cpu_d_pcr__io_host_pcr_rep_valid.values[0]; }
  { Top_SodorTile_cpu__io_host_pcr_rep_valid.values[0] = Top_SodorTile_cpu_d__io_host_pcr_rep_valid.values[0]; }
  { Top_SodorTile__io_host_pcr_rep_valid.values[0] = Top_SodorTile_cpu__io_host_pcr_rep_valid.values[0]; }
  { Top_Queue_12__io_enq_valid.values[0] = Top_SodorTile__io_host_pcr_rep_valid.values[0]; }
  Top_Queue_12__ptr_match.values[0] = Top_Queue_12__enq_ptr.values[0] == Top_Queue_12__deq_ptr.values[0];
  { Top_Queue_12__full.values[0] = Top_Queue_12__ptr_match.values[0]&&Top_Queue_12__maybe_full.values[0]; }
  T1697.values[0] = !Top_Queue_12__full.values[0];
  { Top_Queue_12__io_enq_ready.values[0] = T1697.values[0]; }
  { T1698.values[0] = Top_Queue_12__io_enq_ready.values[0]&&Top_Queue_12__io_enq_valid.values[0]; }
  { Top_Queue_12__do_enq.values[0] = T1698.values[0]&&T1687.values[0]; }
  { Top_Queue_12__reset.values[0] = reset.values[0]; }
  { T1700.values[0] = Top_Queue_12__enq_ptr.values[0]+0x1L; }
  T1700.values[0] = T1700.values[0] & 1;
  { val_t __mask = -Top_Queue_12__do_enq.values[0]; T1701.values[0] = Top_Queue_12__enq_ptr.values[0] ^ ((Top_Queue_12__enq_ptr.values[0] ^ T1700.values[0]) & __mask); }
  { Top_Queue_12__enq_ptr_shadow.values[0] = TERNARY(Top_Queue_12__reset.values[0], 0x0L, T1701.values[0]); }
  { T1702.values[0] = Top_Queue_12__deq_ptr.values[0]+0x1L; }
  T1702.values[0] = T1702.values[0] & 1;
  T1703.values[0] = !Top_Queue_12__do_flow.values[0];
  T1704.values[0] = !Top_Queue_12__maybe_full.values[0];
  { Top_Queue_12__empty.values[0] = Top_Queue_12__ptr_match.values[0]&&T1704.values[0]; }
  T1705.values[0] = !Top_Queue_12__empty.values[0];
  { Top_Queue_12__io_deq_valid.values[0] = T1705.values[0]; }
  { Top_htif__io_cpu_0_pcr_rep_ready.values[0] = 0x1L; }
  { Top_Queue_12__io_deq_ready.values[0] = Top_htif__io_cpu_0_pcr_rep_ready.values[0]; }
  { T1706.values[0] = Top_Queue_12__io_deq_ready.values[0]&&Top_Queue_12__io_deq_valid.values[0]; }
  { Top_Queue_12__do_deq.values[0] = T1706.values[0]&&T1703.values[0]; }
  { val_t __mask = -Top_Queue_12__do_deq.values[0]; T1707.values[0] = Top_Queue_12__deq_ptr.values[0] ^ ((Top_Queue_12__deq_ptr.values[0] ^ T1702.values[0]) & __mask); }
  { Top_Queue_12__deq_ptr_shadow.values[0] = TERNARY(Top_Queue_12__reset.values[0], 0x0L, T1707.values[0]); }
  T1708.values[0] = Top_Queue_12__do_enq.values[0] != Top_Queue_12__do_deq.values[0];
  { val_t __mask = -T1708.values[0]; T1709.values[0] = Top_Queue_12__maybe_full.values[0] ^ ((Top_Queue_12__maybe_full.values[0] ^ Top_Queue_12__do_enq.values[0]) & __mask); }
  { Top_Queue_12__maybe_full_shadow.values[0] = TERNARY(Top_Queue_12__reset.values[0], 0x0L, T1709.values[0]); }
  { Top_Queue_11__reset.values[0] = reset.values[0]; }
  { T1710.values[0] = Top_Queue_11__enq_ptr.values[0]+0x1L; }
  T1710.values[0] = T1710.values[0] & 1;
  { Top_Queue_11__do_flow.values[0] = 0x0L; }
  T1711.values[0] = !Top_Queue_11__do_flow.values[0];
  { Top_htif__pcr_addr.values[0] = Top_htif__addr.values[0]; }
  Top_htif__pcr_addr.values[0] = Top_htif__pcr_addr.values[0] & 63;
  T1712.values[0] = Top_htif__pcr_addr.values[0] != 0x1dL;
  T1713.values[0] = Top_htif__state.values[0] == 0x1L;
  { T1714.values[0] = T1713.values[0]&&T1712.values[0]; }
  { Top_htif__io_cpu_0_pcr_req_valid.values[0] = T1714.values[0]; }
  { Top_Queue_11__io_enq_valid.values[0] = Top_htif__io_cpu_0_pcr_req_valid.values[0]; }
  { Top_Queue_11__full.values[0] = Top_Queue_11__ptr_match.values[0]&&Top_Queue_11__maybe_full.values[0]; }
  T1715.values[0] = !Top_Queue_11__full.values[0];
  { Top_Queue_11__io_enq_ready.values[0] = T1715.values[0]; }
  { T1716.values[0] = Top_Queue_11__io_enq_ready.values[0]&&Top_Queue_11__io_enq_valid.values[0]; }
  { Top_Queue_11__do_enq.values[0] = T1716.values[0]&&T1711.values[0]; }
  { val_t __mask = -Top_Queue_11__do_enq.values[0]; T1717.values[0] = Top_Queue_11__enq_ptr.values[0] ^ ((Top_Queue_11__enq_ptr.values[0] ^ T1710.values[0]) & __mask); }
  { Top_Queue_11__enq_ptr_shadow.values[0] = TERNARY(Top_Queue_11__reset.values[0], 0x0L, T1717.values[0]); }
  T1718.values[0] = !Top_Queue_11__do_flow.values[0];
  { Top_SodorTile_cpu_d__io_host_pcr_req_ready.values[0] = Top_SodorTile_cpu_d_pcr__io_host_pcr_req_ready.values[0]; }
  { Top_SodorTile_cpu__io_host_pcr_req_ready.values[0] = Top_SodorTile_cpu_d__io_host_pcr_req_ready.values[0]; }
  { Top_SodorTile__io_host_pcr_req_ready.values[0] = Top_SodorTile_cpu__io_host_pcr_req_ready.values[0]; }
  { Top_Queue_11__io_deq_ready.values[0] = Top_SodorTile__io_host_pcr_req_ready.values[0]; }
  { T1719.values[0] = Top_Queue_11__io_deq_ready.values[0]&&Top_Queue_11__io_deq_valid.values[0]; }
  { Top_Queue_11__do_deq.values[0] = T1719.values[0]&&T1718.values[0]; }
  T1720.values[0] = Top_Queue_11__do_enq.values[0] != Top_Queue_11__do_deq.values[0];
  { val_t __mask = -T1720.values[0]; T1721.values[0] = Top_Queue_11__maybe_full.values[0] ^ ((Top_Queue_11__maybe_full.values[0] ^ Top_Queue_11__do_enq.values[0]) & __mask); }
  { Top_Queue_11__maybe_full_shadow.values[0] = TERNARY(Top_Queue_11__reset.values[0], 0x0L, T1721.values[0]); }
  { T1722.values[0] = Top_Queue_11__deq_ptr.values[0]+0x1L; }
  T1722.values[0] = T1722.values[0] & 1;
  { val_t __mask = -Top_Queue_11__do_deq.values[0]; T1723.values[0] = Top_Queue_11__deq_ptr.values[0] ^ ((Top_Queue_11__deq_ptr.values[0] ^ T1722.values[0]) & __mask); }
  { Top_Queue_11__deq_ptr_shadow.values[0] = TERNARY(Top_Queue_11__reset.values[0], 0x0L, T1723.values[0]); }
  { Top_htif__io_cpu_0_pcr_req_bits_data.values[0] = Top_htif__pcr_wdata.values[0]; }
  { Top_Queue_11__io_enq_bits_data.values[0] = Top_htif__io_cpu_0_pcr_req_bits_data.values[0]; }
  { Top_htif__io_cpu_0_pcr_req_bits_addr.values[0] = Top_htif__pcr_addr.values[0]; }
  { Top_Queue_11__io_enq_bits_addr.values[0] = Top_htif__io_cpu_0_pcr_req_bits_addr.values[0]; }
  T1725.values[0] = Top_htif__cmd.values[0] == 0x3L;
  { Top_htif__io_cpu_0_pcr_req_bits_rw.values[0] = T1725.values[0]; }
  { Top_Queue_11__io_enq_bits_rw.values[0] = Top_htif__io_cpu_0_pcr_req_bits_rw.values[0]; }
  { T1726.values[0] = Top_Queue_11__io_enq_bits_addr.values[0] | Top_Queue_11__io_enq_bits_rw.values[0] << 6; }
  { T1727.values[0] = Top_Queue_11__io_enq_bits_data.values[0]; T1727.values[1] = T1726.values[0]; }
  { T1730.values[0] = Top_Queue_18__ram.get(0x0L, 0); T1730.values[1] = Top_Queue_18__ram.get(0x0L, 1); T1730.values[2] = Top_Queue_18__ram.get(0x0L, 2); }
  T1731.values[0] = (T1730.values[0] >> 0) & 1;
  { T1732.values[0] = T1730.values[0] >> 1 | T1730.values[1] << 63; }
  T1732.values[0] = T1732.values[0] & 7;
  { T1733.values[0] = T1730.values[0] >> 4 | T1730.values[1] << 60; }
  T1733.values[0] = T1733.values[0] & 31;
  { T1734.values[0] = T1730.values[0] >> 9 | T1730.values[1] << 55; }
  T1734.values[0] = T1734.values[0] & 7;
  { T1735.values[0] = T1730.values[0] >> 12 | T1730.values[1] << 52; T1735.values[1] = T1730.values[1] >> 12 | T1730.values[2] << 52; }
  { T1736.values[0] = T1734.values[0] | T1735.values[0] << 3; T1736.values[1] = T1735.values[0] >> 61 | T1735.values[1] << 3; T1736.values[2] = T1735.values[1] >> 61; }
  { T1737.values[0] = T1733.values[0] | T1736.values[0] << 5; T1737.values[1] = T1736.values[0] >> 59 | T1736.values[1] << 5; T1737.values[2] = T1736.values[1] >> 59 | T1736.values[2] << 5; }
  { T1738.values[0] = T1732.values[0] | T1737.values[0] << 3; T1738.values[1] = T1737.values[0] >> 61 | T1737.values[1] << 3; T1738.values[2] = T1737.values[1] >> 61 | T1737.values[2] << 3; }
  { T1739.values[0] = T1731.values[0] | T1738.values[0] << 1; T1739.values[1] = T1738.values[0] >> 63 | T1738.values[1] << 1; T1739.values[2] = T1738.values[1] >> 63 | T1738.values[2] << 1; }
  { T1740.values[0] = T1739.values[0] >> 1 | T1739.values[1] << 63; }
  T1740.values[0] = T1740.values[0] & 7;
  { Top_Queue_18__io_deq_bits_global_xact_id.values[0] = T1740.values[0]; }
  { Top_SodorTile__io_tilelink_xact_rep_bits_global_xact_id.values[0] = Top_Queue_18__io_deq_bits_global_xact_id.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_rep_bits_global_xact_id.values[0] = Top_SodorTile__io_tilelink_xact_rep_bits_global_xact_id.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_rep_bits_global_xact_id.values[0] = Top_SodorTile_arbiter__io_mem_xact_rep_bits_global_xact_id.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_rep_bits_global_xact_id.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_rep_bits_global_xact_id.values[0]; }
  { Top_SodorTile_cache_finish_queue__io_enq_bits_global_xact_id.values[0] = Top_SodorTile_cache__io_mem_xact_rep_bits_global_xact_id.values[0]; }
  { Top_SodorTile_cache_finish_queue__do_flow.values[0] = 0x0L; }
  T1741.values[0] = !Top_SodorTile_cache_finish_queue__do_flow.values[0];
  T1742.values[0] = (T1739.values[0] >> 0) & 1;
  { Top_Queue_18__io_deq_bits_require_ack.values[0] = T1742.values[0]; }
  { Top_SodorTile__io_tilelink_xact_rep_bits_require_ack.values[0] = Top_Queue_18__io_deq_bits_require_ack.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_rep_bits_require_ack.values[0] = Top_SodorTile__io_tilelink_xact_rep_bits_require_ack.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_rep_bits_require_ack.values[0] = Top_SodorTile_arbiter__io_mem_xact_rep_bits_require_ack.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_rep_bits_require_ack.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_rep_bits_require_ack.values[0]; }
  T1743.values[0] = (Top_SodorTile_cache__refill_counter.values[0] == 3);
  { T1744.values[0] = T1739.values[0] >> 4 | T1739.values[1] << 60; }
  T1744.values[0] = T1744.values[0] & 31;
  { Top_Queue_18__io_deq_bits_tile_xact_id.values[0] = T1744.values[0]; }
  { Top_SodorTile__io_tilelink_xact_rep_bits_tile_xact_id.values[0] = Top_Queue_18__io_deq_bits_tile_xact_id.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_rep_bits_tile_xact_id.values[0] = Top_SodorTile__io_tilelink_xact_rep_bits_tile_xact_id.values[0]; }
  T1745.values[0] = (Top_SodorTile_arbiter__io_mem_xact_rep_bits_tile_xact_id.values[0] >> 0) & 1;
  T1746.values[0] = T1745.values[0] == 0x0L;
  { Top_SodorTile__io_tilelink_xact_rep_valid.values[0] = Top_Queue_18__io_deq_valid.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_rep_valid.values[0] = Top_SodorTile__io_tilelink_xact_rep_valid.values[0]; }
  { T1747.values[0] = Top_SodorTile_arbiter__io_mem_xact_rep_valid.values[0]&&T1746.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_rep_valid.values[0] = T1747.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_rep_valid.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_rep_valid.values[0]; }
  { Top_SodorTile_cache__refill_we.values[0] = Top_SodorTile_cache__io_mem_xact_rep_valid.values[0]&&T1743.values[0]; }
  T1748.values[0] = Top_SodorTile_cache__state.values[0] == 0x4L;
  { Top_SodorTile_cache__wb_done.values[0] = Top_SodorTile_cache__io_mem_xact_rep_valid.values[0]&&T1748.values[0]; }
  { T1749.values[0] = Top_SodorTile_cache__wb_done.values[0]||Top_SodorTile_cache__refill_we.values[0]; }
  { T1750.values[0] = T1749.values[0]&&Top_SodorTile_cache__io_mem_xact_rep_bits_require_ack.values[0]; }
  { Top_SodorTile_cache_finish_queue__io_enq_valid.values[0] = T1750.values[0]; }
  { T1751.values[0] = Top_SodorTile_cache_finish_queue__io_enq_ready.values[0]&&Top_SodorTile_cache_finish_queue__io_enq_valid.values[0]; }
  { Top_SodorTile_cache_finish_queue__do_enq.values[0] = T1751.values[0]&&T1741.values[0]; }
  { Top_htif__io_cpu_0_reset.values[0] = R4913.values[0]; }
  { Top_SodorTile__reset.values[0] = Top_htif__io_cpu_0_reset.values[0]; }
  { Top_SodorTile_cache__reset.values[0] = Top_SodorTile__reset.values[0]; }
  { Top_SodorTile_cache_finish_queue__reset.values[0] = Top_SodorTile_cache__reset.values[0]; }
  { T1753.values[0] = Top_SodorTile_cache_finish_queue__enq_ptr.values[0]+0x1L; }
  T1753.values[0] = T1753.values[0] & 1;
  { val_t __mask = -Top_SodorTile_cache_finish_queue__do_enq.values[0]; T1754.values[0] = Top_SodorTile_cache_finish_queue__enq_ptr.values[0] ^ ((Top_SodorTile_cache_finish_queue__enq_ptr.values[0] ^ T1753.values[0]) & __mask); }
  { Top_SodorTile_cache_finish_queue__enq_ptr_shadow.values[0] = TERNARY(Top_SodorTile_cache_finish_queue__reset.values[0], 0x0L, T1754.values[0]); }
  { T1755.values[0] = Top_SodorTile_cache_finish_queue__deq_ptr.values[0]+0x1L; }
  T1755.values[0] = T1755.values[0] & 1;
  T1756.values[0] = !Top_SodorTile_cache_finish_queue__do_flow.values[0];
  { Top_SodorTile__io_tilelink_xact_finish_ready.values[0] = Top_Queue_19__io_enq_ready.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_finish_ready.values[0] = Top_SodorTile__io_tilelink_xact_finish_ready.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_finish_ready.values[0] = Top_SodorTile_arbiter__io_mem_xact_finish_ready.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_finish_ready.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_finish_ready.values[0]; }
  { Top_SodorTile_cache_finish_queue__io_deq_ready.values[0] = Top_SodorTile_cache__io_mem_xact_finish_ready.values[0]; }
  { T1757.values[0] = Top_SodorTile_cache_finish_queue__io_deq_ready.values[0]&&Top_SodorTile_cache_finish_queue__io_deq_valid.values[0]; }
  { Top_SodorTile_cache_finish_queue__do_deq.values[0] = T1757.values[0]&&T1756.values[0]; }
  { val_t __mask = -Top_SodorTile_cache_finish_queue__do_deq.values[0]; T1758.values[0] = Top_SodorTile_cache_finish_queue__deq_ptr.values[0] ^ ((Top_SodorTile_cache_finish_queue__deq_ptr.values[0] ^ T1755.values[0]) & __mask); }
  { Top_SodorTile_cache_finish_queue__deq_ptr_shadow.values[0] = TERNARY(Top_SodorTile_cache_finish_queue__reset.values[0], 0x0L, T1758.values[0]); }
  T1759.values[0] = Top_SodorTile_cache_finish_queue__do_enq.values[0] != Top_SodorTile_cache_finish_queue__do_deq.values[0];
  { val_t __mask = -T1759.values[0]; T1760.values[0] = Top_SodorTile_cache_finish_queue__maybe_full.values[0] ^ ((Top_SodorTile_cache_finish_queue__maybe_full.values[0] ^ Top_SodorTile_cache_finish_queue__do_enq.values[0]) & __mask); }
  { Top_SodorTile_cache_finish_queue__maybe_full_shadow.values[0] = TERNARY(Top_SodorTile_cache_finish_queue__reset.values[0], 0x0L, T1760.values[0]); }
  { Top_SodorTile_cache__cpu_rw_idx.values[0] = Top_SodorTile_cache__io_cpu_req_addr.values[0] >> 4; }
  Top_SodorTile_cache__cpu_rw_idx.values[0] = Top_SodorTile_cache__cpu_rw_idx.values[0] & 4095;
  { T1762.values[0] = Top_SodorTile_cache__wb_counter.values[0] | Top_SodorTile_cache__access_idx.values[0] << 2; }
  { Top_SodorTile_cache__wb_idx.values[0] = T1762.values[0]; }
  T1763.values[0] = Top_SodorTile_cache__state.values[0] == 0x3L;
  { val_t __mask = -T1763.values[0]; T1764.values[0] = Top_SodorTile_cache__cpu_rw_idx.values[0] ^ ((Top_SodorTile_cache__cpu_rw_idx.values[0] ^ Top_SodorTile_cache__wb_idx.values[0]) & __mask); }
  { T1765.values[0] = Top_SodorTile_cache__refill_counter.values[0] | Top_SodorTile_cache__access_idx.values[0] << 2; }
  { Top_SodorTile_cache__refill_idx.values[0] = T1765.values[0]; }
  T1766.values[0] = Top_SodorTile_cache__state.values[0] == 0x6L;
  T1767.values[0] = Top_SodorTile_cache__state.values[0] == 0x5L;
  { T1768.values[0] = T1767.values[0]||T1766.values[0]; }
  { val_t __mask = -T1768.values[0]; T1769.values[0] = T1764.values[0] ^ ((T1764.values[0] ^ Top_SodorTile_cache__refill_idx.values[0]) & __mask); }
  { Top_SodorTile_cache__data_idx.values[0] = T1769.values[0]; }
  { T1770.values[0] = Top_SodorTile_cache__data_array.get(Top_SodorTile_cache__data_idx.values[0], 0); T1770.values[1] = Top_SodorTile_cache__data_array.get(Top_SodorTile_cache__data_idx.values[0], 1); }
  { Top_SodorTile_cache_writeback_queue__io_enq_bits_data.values[0] = T1770.values[0]; Top_SodorTile_cache_writeback_queue__io_enq_bits_data.values[1] = T1770.values[1]; }
  { Top_SodorTile_cache_writeback_queue__do_flow.values[0] = 0x0L; }
  T1771.values[0] = !Top_SodorTile_cache_writeback_queue__do_flow.values[0];
  T1772.values[0] = Top_SodorTile_cache__state.values[0] == 0x3L;
  { Top_SodorTile_cache_writeback_queue__io_enq_valid.values[0] = T1772.values[0]; }
  { Top_SodorTile_cache_writeback_queue__full.values[0] = Top_SodorTile_cache_writeback_queue__ptr_match.values[0]&&Top_SodorTile_cache_writeback_queue__maybe_full.values[0]; }
  T1773.values[0] = !Top_SodorTile_cache_writeback_queue__full.values[0];
  { Top_SodorTile_cache_writeback_queue__io_enq_ready.values[0] = T1773.values[0]; }
  { T1774.values[0] = Top_SodorTile_cache_writeback_queue__io_enq_ready.values[0]&&Top_SodorTile_cache_writeback_queue__io_enq_valid.values[0]; }
  { Top_SodorTile_cache_writeback_queue__do_enq.values[0] = T1774.values[0]&&T1771.values[0]; }
  { Top_SodorTile_cache_writeback_queue__reset.values[0] = Top_SodorTile_cache__reset.values[0]; }
  { T1776.values[0] = Top_SodorTile_cache_writeback_queue__enq_ptr.values[0]+0x1L; }
  T1776.values[0] = T1776.values[0] & 3;
  { val_t __mask = -Top_SodorTile_cache_writeback_queue__do_enq.values[0]; T1777.values[0] = Top_SodorTile_cache_writeback_queue__enq_ptr.values[0] ^ ((Top_SodorTile_cache_writeback_queue__enq_ptr.values[0] ^ T1776.values[0]) & __mask); }
  { Top_SodorTile_cache_writeback_queue__enq_ptr_shadow.values[0] = TERNARY(Top_SodorTile_cache_writeback_queue__reset.values[0], 0x0L, T1777.values[0]); }
  { T1778.values[0] = Top_SodorTile_cache_writeback_queue__deq_ptr.values[0]+0x1L; }
  T1778.values[0] = T1778.values[0] & 3;
  T1779.values[0] = !Top_SodorTile_cache_writeback_queue__do_flow.values[0];
  { Top_SodorTile__io_tilelink_xact_init_data_ready.values[0] = Top_Queue_16__io_enq_ready.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_init_data_ready.values[0] = Top_SodorTile__io_tilelink_xact_init_data_ready.values[0]; }
  { Top_SodorTile_cache_writeback_queue__io_deq_ready.values[0] = Top_SodorTile_cache__io_mem_xact_init_data_ready.values[0]; }
  { T1780.values[0] = Top_SodorTile_cache_writeback_queue__io_deq_ready.values[0]&&Top_SodorTile_cache_writeback_queue__io_deq_valid.values[0]; }
  { Top_SodorTile_cache_writeback_queue__do_deq.values[0] = T1780.values[0]&&T1779.values[0]; }
  { val_t __mask = -Top_SodorTile_cache_writeback_queue__do_deq.values[0]; T1781.values[0] = Top_SodorTile_cache_writeback_queue__deq_ptr.values[0] ^ ((Top_SodorTile_cache_writeback_queue__deq_ptr.values[0] ^ T1778.values[0]) & __mask); }
  { Top_SodorTile_cache_writeback_queue__deq_ptr_shadow.values[0] = TERNARY(Top_SodorTile_cache_writeback_queue__reset.values[0], 0x0L, T1781.values[0]); }
  T1782.values[0] = Top_SodorTile_cache_writeback_queue__do_enq.values[0] != Top_SodorTile_cache_writeback_queue__do_deq.values[0];
  { val_t __mask = -T1782.values[0]; T1783.values[0] = Top_SodorTile_cache_writeback_queue__maybe_full.values[0] ^ ((Top_SodorTile_cache_writeback_queue__maybe_full.values[0] ^ Top_SodorTile_cache_writeback_queue__do_enq.values[0]) & __mask); }
  { Top_SodorTile_cache_writeback_queue__maybe_full_shadow.values[0] = TERNARY(Top_SodorTile_cache_writeback_queue__reset.values[0], 0x0L, T1783.values[0]); }
  { T1784.values[0] = Top_SodorTile_cache__access_idx.values[0]; }
  { val_t __x[1]; __x[0] = 0x1L; val_t __c = 0; val_t __w = T1784.values[0] / 64; val_t __s = T1784.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); T1785.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); T1785.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); T1785.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); val_t __v3 = MASK(__x[CLAMP(3-__w,0,0)],3>=__w&&3<__w+1); T1785.values[3] = __v3 << __s | __c; __c = MASK(__v3 >> __r, __s != 0); val_t __v4 = MASK(__x[CLAMP(4-__w,0,0)],4>=__w&&4<__w+1); T1785.values[4] = __v4 << __s | __c; __c = MASK(__v4 >> __r, __s != 0); val_t __v5 = MASK(__x[CLAMP(5-__w,0,0)],5>=__w&&5<__w+1); T1785.values[5] = __v5 << __s | __c; __c = MASK(__v5 >> __r, __s != 0); val_t __v6 = MASK(__x[CLAMP(6-__w,0,0)],6>=__w&&6<__w+1); T1785.values[6] = __v6 << __s | __c; __c = MASK(__v6 >> __r, __s != 0); val_t __v7 = MASK(__x[CLAMP(7-__w,0,0)],7>=__w&&7<__w+1); T1785.values[7] = __v7 << __s | __c; __c = MASK(__v7 >> __r, __s != 0); val_t __v8 = MASK(__x[CLAMP(8-__w,0,0)],8>=__w&&8<__w+1); T1785.values[8] = __v8 << __s | __c; __c = MASK(__v8 >> __r, __s != 0); val_t __v9 = MASK(__x[CLAMP(9-__w,0,0)],9>=__w&&9<__w+1); T1785.values[9] = __v9 << __s | __c; __c = MASK(__v9 >> __r, __s != 0); val_t __v10 = MASK(__x[CLAMP(10-__w,0,0)],10>=__w&&10<__w+1); T1785.values[10] = __v10 << __s | __c; __c = MASK(__v10 >> __r, __s != 0); val_t __v11 = MASK(__x[CLAMP(11-__w,0,0)],11>=__w&&11<__w+1); T1785.values[11] = __v11 << __s | __c; __c = MASK(__v11 >> __r, __s != 0); val_t __v12 = MASK(__x[CLAMP(12-__w,0,0)],12>=__w&&12<__w+1); T1785.values[12] = __v12 << __s | __c; __c = MASK(__v12 >> __r, __s != 0); val_t __v13 = MASK(__x[CLAMP(13-__w,0,0)],13>=__w&&13<__w+1); T1785.values[13] = __v13 << __s | __c; __c = MASK(__v13 >> __r, __s != 0); val_t __v14 = MASK(__x[CLAMP(14-__w,0,0)],14>=__w&&14<__w+1); T1785.values[14] = __v14 << __s | __c; __c = MASK(__v14 >> __r, __s != 0); val_t __v15 = MASK(__x[CLAMP(15-__w,0,0)],15>=__w&&15<__w+1); T1785.values[15] = __v15 << __s | __c; __c = MASK(__v15 >> __r, __s != 0); }
  { T1786.values[0] = Top_SodorTile_cache__access_idx.values[0]; }
  { val_t __x[1]; __x[0] = 0x1L; val_t __c = 0; val_t __w = T1786.values[0] / 64; val_t __s = T1786.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); T1787.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); T1787.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); T1787.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); val_t __v3 = MASK(__x[CLAMP(3-__w,0,0)],3>=__w&&3<__w+1); T1787.values[3] = __v3 << __s | __c; __c = MASK(__v3 >> __r, __s != 0); val_t __v4 = MASK(__x[CLAMP(4-__w,0,0)],4>=__w&&4<__w+1); T1787.values[4] = __v4 << __s | __c; __c = MASK(__v4 >> __r, __s != 0); val_t __v5 = MASK(__x[CLAMP(5-__w,0,0)],5>=__w&&5<__w+1); T1787.values[5] = __v5 << __s | __c; __c = MASK(__v5 >> __r, __s != 0); val_t __v6 = MASK(__x[CLAMP(6-__w,0,0)],6>=__w&&6<__w+1); T1787.values[6] = __v6 << __s | __c; __c = MASK(__v6 >> __r, __s != 0); val_t __v7 = MASK(__x[CLAMP(7-__w,0,0)],7>=__w&&7<__w+1); T1787.values[7] = __v7 << __s | __c; __c = MASK(__v7 >> __r, __s != 0); val_t __v8 = MASK(__x[CLAMP(8-__w,0,0)],8>=__w&&8<__w+1); T1787.values[8] = __v8 << __s | __c; __c = MASK(__v8 >> __r, __s != 0); val_t __v9 = MASK(__x[CLAMP(9-__w,0,0)],9>=__w&&9<__w+1); T1787.values[9] = __v9 << __s | __c; __c = MASK(__v9 >> __r, __s != 0); val_t __v10 = MASK(__x[CLAMP(10-__w,0,0)],10>=__w&&10<__w+1); T1787.values[10] = __v10 << __s | __c; __c = MASK(__v10 >> __r, __s != 0); val_t __v11 = MASK(__x[CLAMP(11-__w,0,0)],11>=__w&&11<__w+1); T1787.values[11] = __v11 << __s | __c; __c = MASK(__v11 >> __r, __s != 0); val_t __v12 = MASK(__x[CLAMP(12-__w,0,0)],12>=__w&&12<__w+1); T1787.values[12] = __v12 << __s | __c; __c = MASK(__v12 >> __r, __s != 0); val_t __v13 = MASK(__x[CLAMP(13-__w,0,0)],13>=__w&&13<__w+1); T1787.values[13] = __v13 << __s | __c; __c = MASK(__v13 >> __r, __s != 0); val_t __v14 = MASK(__x[CLAMP(14-__w,0,0)],14>=__w&&14<__w+1); T1787.values[14] = __v14 << __s | __c; __c = MASK(__v14 >> __r, __s != 0); val_t __v15 = MASK(__x[CLAMP(15-__w,0,0)],15>=__w&&15<__w+1); T1787.values[15] = __v15 << __s | __c; __c = MASK(__v15 >> __r, __s != 0); }
  { T1788.values[0] = ~T1787.values[0]; T1788.values[1] = ~T1787.values[1]; T1788.values[2] = ~T1787.values[2]; T1788.values[3] = ~T1787.values[3]; T1788.values[4] = ~T1787.values[4]; T1788.values[5] = ~T1787.values[5]; T1788.values[6] = ~T1787.values[6]; T1788.values[7] = ~T1787.values[7]; T1788.values[8] = ~T1787.values[8]; T1788.values[9] = ~T1787.values[9]; T1788.values[10] = ~T1787.values[10]; T1788.values[11] = ~T1787.values[11]; T1788.values[12] = ~T1787.values[12]; T1788.values[13] = ~T1787.values[13]; T1788.values[14] = ~T1787.values[14]; T1788.values[15] = ~T1787.values[15]; }
  { T1789.values[0] = Top_SodorTile_cache__dirty_array.values[0]&T1788.values[0]; T1789.values[1] = Top_SodorTile_cache__dirty_array.values[1]&T1788.values[1]; T1789.values[2] = Top_SodorTile_cache__dirty_array.values[2]&T1788.values[2]; T1789.values[3] = Top_SodorTile_cache__dirty_array.values[3]&T1788.values[3]; T1789.values[4] = Top_SodorTile_cache__dirty_array.values[4]&T1788.values[4]; T1789.values[5] = Top_SodorTile_cache__dirty_array.values[5]&T1788.values[5]; T1789.values[6] = Top_SodorTile_cache__dirty_array.values[6]&T1788.values[6]; T1789.values[7] = Top_SodorTile_cache__dirty_array.values[7]&T1788.values[7]; T1789.values[8] = Top_SodorTile_cache__dirty_array.values[8]&T1788.values[8]; T1789.values[9] = Top_SodorTile_cache__dirty_array.values[9]&T1788.values[9]; T1789.values[10] = Top_SodorTile_cache__dirty_array.values[10]&T1788.values[10]; T1789.values[11] = Top_SodorTile_cache__dirty_array.values[11]&T1788.values[11]; T1789.values[12] = Top_SodorTile_cache__dirty_array.values[12]&T1788.values[12]; T1789.values[13] = Top_SodorTile_cache__dirty_array.values[13]&T1788.values[13]; T1789.values[14] = Top_SodorTile_cache__dirty_array.values[14]&T1788.values[14]; T1789.values[15] = Top_SodorTile_cache__dirty_array.values[15]&T1788.values[15]; }
  { T1790.values[0] = T1789.values[0]|T1785.values[0]; T1790.values[1] = T1789.values[1]|T1785.values[1]; T1790.values[2] = T1789.values[2]|T1785.values[2]; T1790.values[3] = T1789.values[3]|T1785.values[3]; T1790.values[4] = T1789.values[4]|T1785.values[4]; T1790.values[5] = T1789.values[5]|T1785.values[5]; T1790.values[6] = T1789.values[6]|T1785.values[6]; T1790.values[7] = T1789.values[7]|T1785.values[7]; T1790.values[8] = T1789.values[8]|T1785.values[8]; T1790.values[9] = T1789.values[9]|T1785.values[9]; T1790.values[10] = T1789.values[10]|T1785.values[10]; T1790.values[11] = T1789.values[11]|T1785.values[11]; T1790.values[12] = T1789.values[12]|T1785.values[12]; T1790.values[13] = T1789.values[13]|T1785.values[13]; T1790.values[14] = T1789.values[14]|T1785.values[14]; T1790.values[15] = T1789.values[15]|T1785.values[15]; }
  { Top_SodorTile_cache__req_tag.values[0] = Top_SodorTile_cache__io_cpu_req_addr.values[0] >> 16; }
  Top_SodorTile_cache__req_tag.values[0] = Top_SodorTile_cache__req_tag.values[0] & 65535;
  { T1791.values[0] = Top_SodorTile_cache__tag_array.get(Top_SodorTile_cache__access_idx.values[0], 0); }
  T1792.values[0] = T1791.values[0] == Top_SodorTile_cache__req_tag.values[0];
  { val_t __e[16]; __e[0] = Top_SodorTile_cache__valid_array.values[0]; __e[1] = Top_SodorTile_cache__valid_array.values[1]; __e[2] = Top_SodorTile_cache__valid_array.values[2]; __e[3] = Top_SodorTile_cache__valid_array.values[3]; __e[4] = Top_SodorTile_cache__valid_array.values[4]; __e[5] = Top_SodorTile_cache__valid_array.values[5]; __e[6] = Top_SodorTile_cache__valid_array.values[6]; __e[7] = Top_SodorTile_cache__valid_array.values[7]; __e[8] = Top_SodorTile_cache__valid_array.values[8]; __e[9] = Top_SodorTile_cache__valid_array.values[9]; __e[10] = Top_SodorTile_cache__valid_array.values[10]; __e[11] = Top_SodorTile_cache__valid_array.values[11]; __e[12] = Top_SodorTile_cache__valid_array.values[12]; __e[13] = Top_SodorTile_cache__valid_array.values[13]; __e[14] = Top_SodorTile_cache__valid_array.values[14]; __e[15] = Top_SodorTile_cache__valid_array.values[15]; T1793.values[0] = __e[Top_SodorTile_cache__access_idx.values[0]/64] >> (Top_SodorTile_cache__access_idx.values[0]%64) & 1; }
  { T1794.values[0] = T1793.values[0]; }
  { T1795.values[0] = T1794.values[0]&&T1792.values[0]; }
  { Top_SodorTile_cache__tag_hit.values[0] = T1795.values[0]; }
  T1796.values[0] = Top_SodorTile_cache__state.values[0] == 0x1L;
  T1797.values[0] = (T1621.values[0] >> 15) & 1;
  { Top_SodorTile_cpu_c__cs_mem_wr.values[0] = T1797.values[0]; }
  T1798.values[0] = (T1621.values[0] >> 14) & 1;
  { Top_SodorTile_cpu_c__cs_en_mem.values[0] = T1798.values[0]; }
  { T1799.values[0] = Top_SodorTile_cpu_c__cs_en_mem.values[0]&&Top_SodorTile_cpu_c__cs_mem_wr.values[0]; }
  { Top_SodorTile_cpu_c__io_mem_req_rw.values[0] = T1799.values[0]; }
  { Top_SodorTile_cpu__io_mem_req_rw.values[0] = Top_SodorTile_cpu_c__io_mem_req_rw.values[0]; }
  { Top_SodorTile_cache__io_cpu_req_rw.values[0] = Top_SodorTile_cpu__io_mem_req_rw.values[0]; }
  { T1800.values[0] = Top_SodorTile_cpu_c__cs_en_mem.values[0]; }
  { Top_SodorTile_cpu_c__io_mem_req_val.values[0] = T1800.values[0]; }
  { Top_SodorTile_cpu__io_mem_req_val.values[0] = Top_SodorTile_cpu_c__io_mem_req_val.values[0]; }
  { Top_SodorTile_cache__io_cpu_req_val.values[0] = Top_SodorTile_cpu__io_mem_req_val.values[0]; }
  { T1801.values[0] = Top_SodorTile_cache__io_cpu_req_val.values[0]&&Top_SodorTile_cache__io_cpu_req_rw.values[0]; }
  { T1802.values[0] = T1801.values[0]&&T1796.values[0]; }
  { T1803.values[0] = T1802.values[0]&&Top_SodorTile_cache__tag_hit.values[0]; }
  { val_t __mask = -T1803.values[0]; T1804.values[0] = Top_SodorTile_cache__dirty_array.values[0] ^ ((Top_SodorTile_cache__dirty_array.values[0] ^ T1790.values[0]) & __mask); T1804.values[1] = Top_SodorTile_cache__dirty_array.values[1] ^ ((Top_SodorTile_cache__dirty_array.values[1] ^ T1790.values[1]) & __mask); T1804.values[2] = Top_SodorTile_cache__dirty_array.values[2] ^ ((Top_SodorTile_cache__dirty_array.values[2] ^ T1790.values[2]) & __mask); T1804.values[3] = Top_SodorTile_cache__dirty_array.values[3] ^ ((Top_SodorTile_cache__dirty_array.values[3] ^ T1790.values[3]) & __mask); T1804.values[4] = Top_SodorTile_cache__dirty_array.values[4] ^ ((Top_SodorTile_cache__dirty_array.values[4] ^ T1790.values[4]) & __mask); T1804.values[5] = Top_SodorTile_cache__dirty_array.values[5] ^ ((Top_SodorTile_cache__dirty_array.values[5] ^ T1790.values[5]) & __mask); T1804.values[6] = Top_SodorTile_cache__dirty_array.values[6] ^ ((Top_SodorTile_cache__dirty_array.values[6] ^ T1790.values[6]) & __mask); T1804.values[7] = Top_SodorTile_cache__dirty_array.values[7] ^ ((Top_SodorTile_cache__dirty_array.values[7] ^ T1790.values[7]) & __mask); T1804.values[8] = Top_SodorTile_cache__dirty_array.values[8] ^ ((Top_SodorTile_cache__dirty_array.values[8] ^ T1790.values[8]) & __mask); T1804.values[9] = Top_SodorTile_cache__dirty_array.values[9] ^ ((Top_SodorTile_cache__dirty_array.values[9] ^ T1790.values[9]) & __mask); T1804.values[10] = Top_SodorTile_cache__dirty_array.values[10] ^ ((Top_SodorTile_cache__dirty_array.values[10] ^ T1790.values[10]) & __mask); T1804.values[11] = Top_SodorTile_cache__dirty_array.values[11] ^ ((Top_SodorTile_cache__dirty_array.values[11] ^ T1790.values[11]) & __mask); T1804.values[12] = Top_SodorTile_cache__dirty_array.values[12] ^ ((Top_SodorTile_cache__dirty_array.values[12] ^ T1790.values[12]) & __mask); T1804.values[13] = Top_SodorTile_cache__dirty_array.values[13] ^ ((Top_SodorTile_cache__dirty_array.values[13] ^ T1790.values[13]) & __mask); T1804.values[14] = Top_SodorTile_cache__dirty_array.values[14] ^ ((Top_SodorTile_cache__dirty_array.values[14] ^ T1790.values[14]) & __mask); T1804.values[15] = Top_SodorTile_cache__dirty_array.values[15] ^ ((Top_SodorTile_cache__dirty_array.values[15] ^ T1790.values[15]) & __mask); }
  { T1805.values[0] = Top_SodorTile_cache__access_idx.values[0]; }
  { val_t __x[1]; __x[0] = 0x0L; val_t __c = 0; val_t __w = T1805.values[0] / 64; val_t __s = T1805.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); T1806.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); T1806.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); T1806.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); val_t __v3 = MASK(__x[CLAMP(3-__w,0,0)],3>=__w&&3<__w+1); T1806.values[3] = __v3 << __s | __c; __c = MASK(__v3 >> __r, __s != 0); val_t __v4 = MASK(__x[CLAMP(4-__w,0,0)],4>=__w&&4<__w+1); T1806.values[4] = __v4 << __s | __c; __c = MASK(__v4 >> __r, __s != 0); val_t __v5 = MASK(__x[CLAMP(5-__w,0,0)],5>=__w&&5<__w+1); T1806.values[5] = __v5 << __s | __c; __c = MASK(__v5 >> __r, __s != 0); val_t __v6 = MASK(__x[CLAMP(6-__w,0,0)],6>=__w&&6<__w+1); T1806.values[6] = __v6 << __s | __c; __c = MASK(__v6 >> __r, __s != 0); val_t __v7 = MASK(__x[CLAMP(7-__w,0,0)],7>=__w&&7<__w+1); T1806.values[7] = __v7 << __s | __c; __c = MASK(__v7 >> __r, __s != 0); val_t __v8 = MASK(__x[CLAMP(8-__w,0,0)],8>=__w&&8<__w+1); T1806.values[8] = __v8 << __s | __c; __c = MASK(__v8 >> __r, __s != 0); val_t __v9 = MASK(__x[CLAMP(9-__w,0,0)],9>=__w&&9<__w+1); T1806.values[9] = __v9 << __s | __c; __c = MASK(__v9 >> __r, __s != 0); val_t __v10 = MASK(__x[CLAMP(10-__w,0,0)],10>=__w&&10<__w+1); T1806.values[10] = __v10 << __s | __c; __c = MASK(__v10 >> __r, __s != 0); val_t __v11 = MASK(__x[CLAMP(11-__w,0,0)],11>=__w&&11<__w+1); T1806.values[11] = __v11 << __s | __c; __c = MASK(__v11 >> __r, __s != 0); val_t __v12 = MASK(__x[CLAMP(12-__w,0,0)],12>=__w&&12<__w+1); T1806.values[12] = __v12 << __s | __c; __c = MASK(__v12 >> __r, __s != 0); val_t __v13 = MASK(__x[CLAMP(13-__w,0,0)],13>=__w&&13<__w+1); T1806.values[13] = __v13 << __s | __c; __c = MASK(__v13 >> __r, __s != 0); val_t __v14 = MASK(__x[CLAMP(14-__w,0,0)],14>=__w&&14<__w+1); T1806.values[14] = __v14 << __s | __c; __c = MASK(__v14 >> __r, __s != 0); val_t __v15 = MASK(__x[CLAMP(15-__w,0,0)],15>=__w&&15<__w+1); T1806.values[15] = __v15 << __s | __c; __c = MASK(__v15 >> __r, __s != 0); }
  { T1807.values[0] = Top_SodorTile_cache__access_idx.values[0]; }
  { val_t __x[1]; __x[0] = 0x1L; val_t __c = 0; val_t __w = T1807.values[0] / 64; val_t __s = T1807.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); T1808.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); T1808.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); T1808.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); val_t __v3 = MASK(__x[CLAMP(3-__w,0,0)],3>=__w&&3<__w+1); T1808.values[3] = __v3 << __s | __c; __c = MASK(__v3 >> __r, __s != 0); val_t __v4 = MASK(__x[CLAMP(4-__w,0,0)],4>=__w&&4<__w+1); T1808.values[4] = __v4 << __s | __c; __c = MASK(__v4 >> __r, __s != 0); val_t __v5 = MASK(__x[CLAMP(5-__w,0,0)],5>=__w&&5<__w+1); T1808.values[5] = __v5 << __s | __c; __c = MASK(__v5 >> __r, __s != 0); val_t __v6 = MASK(__x[CLAMP(6-__w,0,0)],6>=__w&&6<__w+1); T1808.values[6] = __v6 << __s | __c; __c = MASK(__v6 >> __r, __s != 0); val_t __v7 = MASK(__x[CLAMP(7-__w,0,0)],7>=__w&&7<__w+1); T1808.values[7] = __v7 << __s | __c; __c = MASK(__v7 >> __r, __s != 0); val_t __v8 = MASK(__x[CLAMP(8-__w,0,0)],8>=__w&&8<__w+1); T1808.values[8] = __v8 << __s | __c; __c = MASK(__v8 >> __r, __s != 0); val_t __v9 = MASK(__x[CLAMP(9-__w,0,0)],9>=__w&&9<__w+1); T1808.values[9] = __v9 << __s | __c; __c = MASK(__v9 >> __r, __s != 0); val_t __v10 = MASK(__x[CLAMP(10-__w,0,0)],10>=__w&&10<__w+1); T1808.values[10] = __v10 << __s | __c; __c = MASK(__v10 >> __r, __s != 0); val_t __v11 = MASK(__x[CLAMP(11-__w,0,0)],11>=__w&&11<__w+1); T1808.values[11] = __v11 << __s | __c; __c = MASK(__v11 >> __r, __s != 0); val_t __v12 = MASK(__x[CLAMP(12-__w,0,0)],12>=__w&&12<__w+1); T1808.values[12] = __v12 << __s | __c; __c = MASK(__v12 >> __r, __s != 0); val_t __v13 = MASK(__x[CLAMP(13-__w,0,0)],13>=__w&&13<__w+1); T1808.values[13] = __v13 << __s | __c; __c = MASK(__v13 >> __r, __s != 0); val_t __v14 = MASK(__x[CLAMP(14-__w,0,0)],14>=__w&&14<__w+1); T1808.values[14] = __v14 << __s | __c; __c = MASK(__v14 >> __r, __s != 0); val_t __v15 = MASK(__x[CLAMP(15-__w,0,0)],15>=__w&&15<__w+1); T1808.values[15] = __v15 << __s | __c; __c = MASK(__v15 >> __r, __s != 0); }
  { T1809.values[0] = ~T1808.values[0]; T1809.values[1] = ~T1808.values[1]; T1809.values[2] = ~T1808.values[2]; T1809.values[3] = ~T1808.values[3]; T1809.values[4] = ~T1808.values[4]; T1809.values[5] = ~T1808.values[5]; T1809.values[6] = ~T1808.values[6]; T1809.values[7] = ~T1808.values[7]; T1809.values[8] = ~T1808.values[8]; T1809.values[9] = ~T1808.values[9]; T1809.values[10] = ~T1808.values[10]; T1809.values[11] = ~T1808.values[11]; T1809.values[12] = ~T1808.values[12]; T1809.values[13] = ~T1808.values[13]; T1809.values[14] = ~T1808.values[14]; T1809.values[15] = ~T1808.values[15]; }
  { T1810.values[0] = Top_SodorTile_cache__dirty_array.values[0]&T1809.values[0]; T1810.values[1] = Top_SodorTile_cache__dirty_array.values[1]&T1809.values[1]; T1810.values[2] = Top_SodorTile_cache__dirty_array.values[2]&T1809.values[2]; T1810.values[3] = Top_SodorTile_cache__dirty_array.values[3]&T1809.values[3]; T1810.values[4] = Top_SodorTile_cache__dirty_array.values[4]&T1809.values[4]; T1810.values[5] = Top_SodorTile_cache__dirty_array.values[5]&T1809.values[5]; T1810.values[6] = Top_SodorTile_cache__dirty_array.values[6]&T1809.values[6]; T1810.values[7] = Top_SodorTile_cache__dirty_array.values[7]&T1809.values[7]; T1810.values[8] = Top_SodorTile_cache__dirty_array.values[8]&T1809.values[8]; T1810.values[9] = Top_SodorTile_cache__dirty_array.values[9]&T1809.values[9]; T1810.values[10] = Top_SodorTile_cache__dirty_array.values[10]&T1809.values[10]; T1810.values[11] = Top_SodorTile_cache__dirty_array.values[11]&T1809.values[11]; T1810.values[12] = Top_SodorTile_cache__dirty_array.values[12]&T1809.values[12]; T1810.values[13] = Top_SodorTile_cache__dirty_array.values[13]&T1809.values[13]; T1810.values[14] = Top_SodorTile_cache__dirty_array.values[14]&T1809.values[14]; T1810.values[15] = Top_SodorTile_cache__dirty_array.values[15]&T1809.values[15]; }
  { T1811.values[0] = T1810.values[0]|T1806.values[0]; T1811.values[1] = T1810.values[1]|T1806.values[1]; T1811.values[2] = T1810.values[2]|T1806.values[2]; T1811.values[3] = T1810.values[3]|T1806.values[3]; T1811.values[4] = T1810.values[4]|T1806.values[4]; T1811.values[5] = T1810.values[5]|T1806.values[5]; T1811.values[6] = T1810.values[6]|T1806.values[6]; T1811.values[7] = T1810.values[7]|T1806.values[7]; T1811.values[8] = T1810.values[8]|T1806.values[8]; T1811.values[9] = T1810.values[9]|T1806.values[9]; T1811.values[10] = T1810.values[10]|T1806.values[10]; T1811.values[11] = T1810.values[11]|T1806.values[11]; T1811.values[12] = T1810.values[12]|T1806.values[12]; T1811.values[13] = T1810.values[13]|T1806.values[13]; T1811.values[14] = T1810.values[14]|T1806.values[14]; T1811.values[15] = T1810.values[15]|T1806.values[15]; }
  T1812.values[0] = Top_SodorTile_cache__state.values[0] == 0x4L;
  { Top_SodorTile_cache__clr_dirty_bit.values[0] = T1812.values[0]&&Top_SodorTile_cache__io_mem_xact_rep_valid.values[0]; }
  T1813.values[0] = !T1803.values[0];
  { T1814.values[0] = T1813.values[0]&&Top_SodorTile_cache__clr_dirty_bit.values[0]; }
  { val_t __mask = -T1814.values[0]; T1815.values[0] = T1804.values[0] ^ ((T1804.values[0] ^ T1811.values[0]) & __mask); T1815.values[1] = T1804.values[1] ^ ((T1804.values[1] ^ T1811.values[1]) & __mask); T1815.values[2] = T1804.values[2] ^ ((T1804.values[2] ^ T1811.values[2]) & __mask); T1815.values[3] = T1804.values[3] ^ ((T1804.values[3] ^ T1811.values[3]) & __mask); T1815.values[4] = T1804.values[4] ^ ((T1804.values[4] ^ T1811.values[4]) & __mask); T1815.values[5] = T1804.values[5] ^ ((T1804.values[5] ^ T1811.values[5]) & __mask); T1815.values[6] = T1804.values[6] ^ ((T1804.values[6] ^ T1811.values[6]) & __mask); T1815.values[7] = T1804.values[7] ^ ((T1804.values[7] ^ T1811.values[7]) & __mask); T1815.values[8] = T1804.values[8] ^ ((T1804.values[8] ^ T1811.values[8]) & __mask); T1815.values[9] = T1804.values[9] ^ ((T1804.values[9] ^ T1811.values[9]) & __mask); T1815.values[10] = T1804.values[10] ^ ((T1804.values[10] ^ T1811.values[10]) & __mask); T1815.values[11] = T1804.values[11] ^ ((T1804.values[11] ^ T1811.values[11]) & __mask); T1815.values[12] = T1804.values[12] ^ ((T1804.values[12] ^ T1811.values[12]) & __mask); T1815.values[13] = T1804.values[13] ^ ((T1804.values[13] ^ T1811.values[13]) & __mask); T1815.values[14] = T1804.values[14] ^ ((T1804.values[14] ^ T1811.values[14]) & __mask); T1815.values[15] = T1804.values[15] ^ ((T1804.values[15] ^ T1811.values[15]) & __mask); }
  { Top_SodorTile_cache__dirty_array_shadow.values[0] = TERNARY(Top_SodorTile_cache__reset.values[0], 0x0L, T1815.values[0]); Top_SodorTile_cache__dirty_array_shadow.values[1] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[1]); Top_SodorTile_cache__dirty_array_shadow.values[2] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[2]); Top_SodorTile_cache__dirty_array_shadow.values[3] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[3]); Top_SodorTile_cache__dirty_array_shadow.values[4] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[4]); Top_SodorTile_cache__dirty_array_shadow.values[5] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[5]); Top_SodorTile_cache__dirty_array_shadow.values[6] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[6]); Top_SodorTile_cache__dirty_array_shadow.values[7] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[7]); Top_SodorTile_cache__dirty_array_shadow.values[8] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[8]); Top_SodorTile_cache__dirty_array_shadow.values[9] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[9]); Top_SodorTile_cache__dirty_array_shadow.values[10] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[10]); Top_SodorTile_cache__dirty_array_shadow.values[11] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[11]); Top_SodorTile_cache__dirty_array_shadow.values[12] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[12]); Top_SodorTile_cache__dirty_array_shadow.values[13] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[13]); Top_SodorTile_cache__dirty_array_shadow.values[14] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[14]); Top_SodorTile_cache__dirty_array_shadow.values[15] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1815.values[15]); }
  { T1816.values[0] = Top_SodorTile_cache__access_idx.values[0]; }
  { val_t __x[1]; __x[0] = 0x0L; val_t __c = 0; val_t __w = T1816.values[0] / 64; val_t __s = T1816.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); T1817.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); T1817.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); T1817.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); val_t __v3 = MASK(__x[CLAMP(3-__w,0,0)],3>=__w&&3<__w+1); T1817.values[3] = __v3 << __s | __c; __c = MASK(__v3 >> __r, __s != 0); val_t __v4 = MASK(__x[CLAMP(4-__w,0,0)],4>=__w&&4<__w+1); T1817.values[4] = __v4 << __s | __c; __c = MASK(__v4 >> __r, __s != 0); val_t __v5 = MASK(__x[CLAMP(5-__w,0,0)],5>=__w&&5<__w+1); T1817.values[5] = __v5 << __s | __c; __c = MASK(__v5 >> __r, __s != 0); val_t __v6 = MASK(__x[CLAMP(6-__w,0,0)],6>=__w&&6<__w+1); T1817.values[6] = __v6 << __s | __c; __c = MASK(__v6 >> __r, __s != 0); val_t __v7 = MASK(__x[CLAMP(7-__w,0,0)],7>=__w&&7<__w+1); T1817.values[7] = __v7 << __s | __c; __c = MASK(__v7 >> __r, __s != 0); val_t __v8 = MASK(__x[CLAMP(8-__w,0,0)],8>=__w&&8<__w+1); T1817.values[8] = __v8 << __s | __c; __c = MASK(__v8 >> __r, __s != 0); val_t __v9 = MASK(__x[CLAMP(9-__w,0,0)],9>=__w&&9<__w+1); T1817.values[9] = __v9 << __s | __c; __c = MASK(__v9 >> __r, __s != 0); val_t __v10 = MASK(__x[CLAMP(10-__w,0,0)],10>=__w&&10<__w+1); T1817.values[10] = __v10 << __s | __c; __c = MASK(__v10 >> __r, __s != 0); val_t __v11 = MASK(__x[CLAMP(11-__w,0,0)],11>=__w&&11<__w+1); T1817.values[11] = __v11 << __s | __c; __c = MASK(__v11 >> __r, __s != 0); val_t __v12 = MASK(__x[CLAMP(12-__w,0,0)],12>=__w&&12<__w+1); T1817.values[12] = __v12 << __s | __c; __c = MASK(__v12 >> __r, __s != 0); val_t __v13 = MASK(__x[CLAMP(13-__w,0,0)],13>=__w&&13<__w+1); T1817.values[13] = __v13 << __s | __c; __c = MASK(__v13 >> __r, __s != 0); val_t __v14 = MASK(__x[CLAMP(14-__w,0,0)],14>=__w&&14<__w+1); T1817.values[14] = __v14 << __s | __c; __c = MASK(__v14 >> __r, __s != 0); val_t __v15 = MASK(__x[CLAMP(15-__w,0,0)],15>=__w&&15<__w+1); T1817.values[15] = __v15 << __s | __c; __c = MASK(__v15 >> __r, __s != 0); }
  { T1818.values[0] = Top_SodorTile_cache__access_idx.values[0]; }
  { val_t __x[1]; __x[0] = 0x1L; val_t __c = 0; val_t __w = T1818.values[0] / 64; val_t __s = T1818.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); T1819.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); T1819.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); T1819.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); val_t __v3 = MASK(__x[CLAMP(3-__w,0,0)],3>=__w&&3<__w+1); T1819.values[3] = __v3 << __s | __c; __c = MASK(__v3 >> __r, __s != 0); val_t __v4 = MASK(__x[CLAMP(4-__w,0,0)],4>=__w&&4<__w+1); T1819.values[4] = __v4 << __s | __c; __c = MASK(__v4 >> __r, __s != 0); val_t __v5 = MASK(__x[CLAMP(5-__w,0,0)],5>=__w&&5<__w+1); T1819.values[5] = __v5 << __s | __c; __c = MASK(__v5 >> __r, __s != 0); val_t __v6 = MASK(__x[CLAMP(6-__w,0,0)],6>=__w&&6<__w+1); T1819.values[6] = __v6 << __s | __c; __c = MASK(__v6 >> __r, __s != 0); val_t __v7 = MASK(__x[CLAMP(7-__w,0,0)],7>=__w&&7<__w+1); T1819.values[7] = __v7 << __s | __c; __c = MASK(__v7 >> __r, __s != 0); val_t __v8 = MASK(__x[CLAMP(8-__w,0,0)],8>=__w&&8<__w+1); T1819.values[8] = __v8 << __s | __c; __c = MASK(__v8 >> __r, __s != 0); val_t __v9 = MASK(__x[CLAMP(9-__w,0,0)],9>=__w&&9<__w+1); T1819.values[9] = __v9 << __s | __c; __c = MASK(__v9 >> __r, __s != 0); val_t __v10 = MASK(__x[CLAMP(10-__w,0,0)],10>=__w&&10<__w+1); T1819.values[10] = __v10 << __s | __c; __c = MASK(__v10 >> __r, __s != 0); val_t __v11 = MASK(__x[CLAMP(11-__w,0,0)],11>=__w&&11<__w+1); T1819.values[11] = __v11 << __s | __c; __c = MASK(__v11 >> __r, __s != 0); val_t __v12 = MASK(__x[CLAMP(12-__w,0,0)],12>=__w&&12<__w+1); T1819.values[12] = __v12 << __s | __c; __c = MASK(__v12 >> __r, __s != 0); val_t __v13 = MASK(__x[CLAMP(13-__w,0,0)],13>=__w&&13<__w+1); T1819.values[13] = __v13 << __s | __c; __c = MASK(__v13 >> __r, __s != 0); val_t __v14 = MASK(__x[CLAMP(14-__w,0,0)],14>=__w&&14<__w+1); T1819.values[14] = __v14 << __s | __c; __c = MASK(__v14 >> __r, __s != 0); val_t __v15 = MASK(__x[CLAMP(15-__w,0,0)],15>=__w&&15<__w+1); T1819.values[15] = __v15 << __s | __c; __c = MASK(__v15 >> __r, __s != 0); }
  { T1820.values[0] = ~T1819.values[0]; T1820.values[1] = ~T1819.values[1]; T1820.values[2] = ~T1819.values[2]; T1820.values[3] = ~T1819.values[3]; T1820.values[4] = ~T1819.values[4]; T1820.values[5] = ~T1819.values[5]; T1820.values[6] = ~T1819.values[6]; T1820.values[7] = ~T1819.values[7]; T1820.values[8] = ~T1819.values[8]; T1820.values[9] = ~T1819.values[9]; T1820.values[10] = ~T1819.values[10]; T1820.values[11] = ~T1819.values[11]; T1820.values[12] = ~T1819.values[12]; T1820.values[13] = ~T1819.values[13]; T1820.values[14] = ~T1819.values[14]; T1820.values[15] = ~T1819.values[15]; }
  { T1821.values[0] = Top_SodorTile_cache__valid_array.values[0]&T1820.values[0]; T1821.values[1] = Top_SodorTile_cache__valid_array.values[1]&T1820.values[1]; T1821.values[2] = Top_SodorTile_cache__valid_array.values[2]&T1820.values[2]; T1821.values[3] = Top_SodorTile_cache__valid_array.values[3]&T1820.values[3]; T1821.values[4] = Top_SodorTile_cache__valid_array.values[4]&T1820.values[4]; T1821.values[5] = Top_SodorTile_cache__valid_array.values[5]&T1820.values[5]; T1821.values[6] = Top_SodorTile_cache__valid_array.values[6]&T1820.values[6]; T1821.values[7] = Top_SodorTile_cache__valid_array.values[7]&T1820.values[7]; T1821.values[8] = Top_SodorTile_cache__valid_array.values[8]&T1820.values[8]; T1821.values[9] = Top_SodorTile_cache__valid_array.values[9]&T1820.values[9]; T1821.values[10] = Top_SodorTile_cache__valid_array.values[10]&T1820.values[10]; T1821.values[11] = Top_SodorTile_cache__valid_array.values[11]&T1820.values[11]; T1821.values[12] = Top_SodorTile_cache__valid_array.values[12]&T1820.values[12]; T1821.values[13] = Top_SodorTile_cache__valid_array.values[13]&T1820.values[13]; T1821.values[14] = Top_SodorTile_cache__valid_array.values[14]&T1820.values[14]; T1821.values[15] = Top_SodorTile_cache__valid_array.values[15]&T1820.values[15]; }
  { T1822.values[0] = T1821.values[0]|T1817.values[0]; T1822.values[1] = T1821.values[1]|T1817.values[1]; T1822.values[2] = T1821.values[2]|T1817.values[2]; T1822.values[3] = T1821.values[3]|T1817.values[3]; T1822.values[4] = T1821.values[4]|T1817.values[4]; T1822.values[5] = T1821.values[5]|T1817.values[5]; T1822.values[6] = T1821.values[6]|T1817.values[6]; T1822.values[7] = T1821.values[7]|T1817.values[7]; T1822.values[8] = T1821.values[8]|T1817.values[8]; T1822.values[9] = T1821.values[9]|T1817.values[9]; T1822.values[10] = T1821.values[10]|T1817.values[10]; T1822.values[11] = T1821.values[11]|T1817.values[11]; T1822.values[12] = T1821.values[12]|T1817.values[12]; T1822.values[13] = T1821.values[13]|T1817.values[13]; T1822.values[14] = T1821.values[14]|T1817.values[14]; T1822.values[15] = T1821.values[15]|T1817.values[15]; }
  T1823.values[0] = Top_SodorTile_cache__state.values[0] == 0x8L;
  { Top_SodorTile_cache__flush_success.values[0] = T1823.values[0]; }
  { val_t __mask = -Top_SodorTile_cache__flush_success.values[0]; T1824.values[0] = Top_SodorTile_cache__valid_array.values[0] ^ ((Top_SodorTile_cache__valid_array.values[0] ^ T1822.values[0]) & __mask); T1824.values[1] = Top_SodorTile_cache__valid_array.values[1] ^ ((Top_SodorTile_cache__valid_array.values[1] ^ T1822.values[1]) & __mask); T1824.values[2] = Top_SodorTile_cache__valid_array.values[2] ^ ((Top_SodorTile_cache__valid_array.values[2] ^ T1822.values[2]) & __mask); T1824.values[3] = Top_SodorTile_cache__valid_array.values[3] ^ ((Top_SodorTile_cache__valid_array.values[3] ^ T1822.values[3]) & __mask); T1824.values[4] = Top_SodorTile_cache__valid_array.values[4] ^ ((Top_SodorTile_cache__valid_array.values[4] ^ T1822.values[4]) & __mask); T1824.values[5] = Top_SodorTile_cache__valid_array.values[5] ^ ((Top_SodorTile_cache__valid_array.values[5] ^ T1822.values[5]) & __mask); T1824.values[6] = Top_SodorTile_cache__valid_array.values[6] ^ ((Top_SodorTile_cache__valid_array.values[6] ^ T1822.values[6]) & __mask); T1824.values[7] = Top_SodorTile_cache__valid_array.values[7] ^ ((Top_SodorTile_cache__valid_array.values[7] ^ T1822.values[7]) & __mask); T1824.values[8] = Top_SodorTile_cache__valid_array.values[8] ^ ((Top_SodorTile_cache__valid_array.values[8] ^ T1822.values[8]) & __mask); T1824.values[9] = Top_SodorTile_cache__valid_array.values[9] ^ ((Top_SodorTile_cache__valid_array.values[9] ^ T1822.values[9]) & __mask); T1824.values[10] = Top_SodorTile_cache__valid_array.values[10] ^ ((Top_SodorTile_cache__valid_array.values[10] ^ T1822.values[10]) & __mask); T1824.values[11] = Top_SodorTile_cache__valid_array.values[11] ^ ((Top_SodorTile_cache__valid_array.values[11] ^ T1822.values[11]) & __mask); T1824.values[12] = Top_SodorTile_cache__valid_array.values[12] ^ ((Top_SodorTile_cache__valid_array.values[12] ^ T1822.values[12]) & __mask); T1824.values[13] = Top_SodorTile_cache__valid_array.values[13] ^ ((Top_SodorTile_cache__valid_array.values[13] ^ T1822.values[13]) & __mask); T1824.values[14] = Top_SodorTile_cache__valid_array.values[14] ^ ((Top_SodorTile_cache__valid_array.values[14] ^ T1822.values[14]) & __mask); T1824.values[15] = Top_SodorTile_cache__valid_array.values[15] ^ ((Top_SodorTile_cache__valid_array.values[15] ^ T1822.values[15]) & __mask); }
  { T1825.values[0] = Top_SodorTile_cache__access_idx.values[0]; }
  { val_t __x[1]; __x[0] = 0x1L; val_t __c = 0; val_t __w = T1825.values[0] / 64; val_t __s = T1825.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); T1826.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); T1826.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); T1826.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); val_t __v3 = MASK(__x[CLAMP(3-__w,0,0)],3>=__w&&3<__w+1); T1826.values[3] = __v3 << __s | __c; __c = MASK(__v3 >> __r, __s != 0); val_t __v4 = MASK(__x[CLAMP(4-__w,0,0)],4>=__w&&4<__w+1); T1826.values[4] = __v4 << __s | __c; __c = MASK(__v4 >> __r, __s != 0); val_t __v5 = MASK(__x[CLAMP(5-__w,0,0)],5>=__w&&5<__w+1); T1826.values[5] = __v5 << __s | __c; __c = MASK(__v5 >> __r, __s != 0); val_t __v6 = MASK(__x[CLAMP(6-__w,0,0)],6>=__w&&6<__w+1); T1826.values[6] = __v6 << __s | __c; __c = MASK(__v6 >> __r, __s != 0); val_t __v7 = MASK(__x[CLAMP(7-__w,0,0)],7>=__w&&7<__w+1); T1826.values[7] = __v7 << __s | __c; __c = MASK(__v7 >> __r, __s != 0); val_t __v8 = MASK(__x[CLAMP(8-__w,0,0)],8>=__w&&8<__w+1); T1826.values[8] = __v8 << __s | __c; __c = MASK(__v8 >> __r, __s != 0); val_t __v9 = MASK(__x[CLAMP(9-__w,0,0)],9>=__w&&9<__w+1); T1826.values[9] = __v9 << __s | __c; __c = MASK(__v9 >> __r, __s != 0); val_t __v10 = MASK(__x[CLAMP(10-__w,0,0)],10>=__w&&10<__w+1); T1826.values[10] = __v10 << __s | __c; __c = MASK(__v10 >> __r, __s != 0); val_t __v11 = MASK(__x[CLAMP(11-__w,0,0)],11>=__w&&11<__w+1); T1826.values[11] = __v11 << __s | __c; __c = MASK(__v11 >> __r, __s != 0); val_t __v12 = MASK(__x[CLAMP(12-__w,0,0)],12>=__w&&12<__w+1); T1826.values[12] = __v12 << __s | __c; __c = MASK(__v12 >> __r, __s != 0); val_t __v13 = MASK(__x[CLAMP(13-__w,0,0)],13>=__w&&13<__w+1); T1826.values[13] = __v13 << __s | __c; __c = MASK(__v13 >> __r, __s != 0); val_t __v14 = MASK(__x[CLAMP(14-__w,0,0)],14>=__w&&14<__w+1); T1826.values[14] = __v14 << __s | __c; __c = MASK(__v14 >> __r, __s != 0); val_t __v15 = MASK(__x[CLAMP(15-__w,0,0)],15>=__w&&15<__w+1); T1826.values[15] = __v15 << __s | __c; __c = MASK(__v15 >> __r, __s != 0); }
  { T1827.values[0] = Top_SodorTile_cache__access_idx.values[0]; }
  { val_t __x[1]; __x[0] = 0x1L; val_t __c = 0; val_t __w = T1827.values[0] / 64; val_t __s = T1827.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); T1828.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); T1828.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); T1828.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); val_t __v3 = MASK(__x[CLAMP(3-__w,0,0)],3>=__w&&3<__w+1); T1828.values[3] = __v3 << __s | __c; __c = MASK(__v3 >> __r, __s != 0); val_t __v4 = MASK(__x[CLAMP(4-__w,0,0)],4>=__w&&4<__w+1); T1828.values[4] = __v4 << __s | __c; __c = MASK(__v4 >> __r, __s != 0); val_t __v5 = MASK(__x[CLAMP(5-__w,0,0)],5>=__w&&5<__w+1); T1828.values[5] = __v5 << __s | __c; __c = MASK(__v5 >> __r, __s != 0); val_t __v6 = MASK(__x[CLAMP(6-__w,0,0)],6>=__w&&6<__w+1); T1828.values[6] = __v6 << __s | __c; __c = MASK(__v6 >> __r, __s != 0); val_t __v7 = MASK(__x[CLAMP(7-__w,0,0)],7>=__w&&7<__w+1); T1828.values[7] = __v7 << __s | __c; __c = MASK(__v7 >> __r, __s != 0); val_t __v8 = MASK(__x[CLAMP(8-__w,0,0)],8>=__w&&8<__w+1); T1828.values[8] = __v8 << __s | __c; __c = MASK(__v8 >> __r, __s != 0); val_t __v9 = MASK(__x[CLAMP(9-__w,0,0)],9>=__w&&9<__w+1); T1828.values[9] = __v9 << __s | __c; __c = MASK(__v9 >> __r, __s != 0); val_t __v10 = MASK(__x[CLAMP(10-__w,0,0)],10>=__w&&10<__w+1); T1828.values[10] = __v10 << __s | __c; __c = MASK(__v10 >> __r, __s != 0); val_t __v11 = MASK(__x[CLAMP(11-__w,0,0)],11>=__w&&11<__w+1); T1828.values[11] = __v11 << __s | __c; __c = MASK(__v11 >> __r, __s != 0); val_t __v12 = MASK(__x[CLAMP(12-__w,0,0)],12>=__w&&12<__w+1); T1828.values[12] = __v12 << __s | __c; __c = MASK(__v12 >> __r, __s != 0); val_t __v13 = MASK(__x[CLAMP(13-__w,0,0)],13>=__w&&13<__w+1); T1828.values[13] = __v13 << __s | __c; __c = MASK(__v13 >> __r, __s != 0); val_t __v14 = MASK(__x[CLAMP(14-__w,0,0)],14>=__w&&14<__w+1); T1828.values[14] = __v14 << __s | __c; __c = MASK(__v14 >> __r, __s != 0); val_t __v15 = MASK(__x[CLAMP(15-__w,0,0)],15>=__w&&15<__w+1); T1828.values[15] = __v15 << __s | __c; __c = MASK(__v15 >> __r, __s != 0); }
  { T1829.values[0] = ~T1828.values[0]; T1829.values[1] = ~T1828.values[1]; T1829.values[2] = ~T1828.values[2]; T1829.values[3] = ~T1828.values[3]; T1829.values[4] = ~T1828.values[4]; T1829.values[5] = ~T1828.values[5]; T1829.values[6] = ~T1828.values[6]; T1829.values[7] = ~T1828.values[7]; T1829.values[8] = ~T1828.values[8]; T1829.values[9] = ~T1828.values[9]; T1829.values[10] = ~T1828.values[10]; T1829.values[11] = ~T1828.values[11]; T1829.values[12] = ~T1828.values[12]; T1829.values[13] = ~T1828.values[13]; T1829.values[14] = ~T1828.values[14]; T1829.values[15] = ~T1828.values[15]; }
  { T1830.values[0] = Top_SodorTile_cache__valid_array.values[0]&T1829.values[0]; T1830.values[1] = Top_SodorTile_cache__valid_array.values[1]&T1829.values[1]; T1830.values[2] = Top_SodorTile_cache__valid_array.values[2]&T1829.values[2]; T1830.values[3] = Top_SodorTile_cache__valid_array.values[3]&T1829.values[3]; T1830.values[4] = Top_SodorTile_cache__valid_array.values[4]&T1829.values[4]; T1830.values[5] = Top_SodorTile_cache__valid_array.values[5]&T1829.values[5]; T1830.values[6] = Top_SodorTile_cache__valid_array.values[6]&T1829.values[6]; T1830.values[7] = Top_SodorTile_cache__valid_array.values[7]&T1829.values[7]; T1830.values[8] = Top_SodorTile_cache__valid_array.values[8]&T1829.values[8]; T1830.values[9] = Top_SodorTile_cache__valid_array.values[9]&T1829.values[9]; T1830.values[10] = Top_SodorTile_cache__valid_array.values[10]&T1829.values[10]; T1830.values[11] = Top_SodorTile_cache__valid_array.values[11]&T1829.values[11]; T1830.values[12] = Top_SodorTile_cache__valid_array.values[12]&T1829.values[12]; T1830.values[13] = Top_SodorTile_cache__valid_array.values[13]&T1829.values[13]; T1830.values[14] = Top_SodorTile_cache__valid_array.values[14]&T1829.values[14]; T1830.values[15] = Top_SodorTile_cache__valid_array.values[15]&T1829.values[15]; }
  { T1831.values[0] = T1830.values[0]|T1826.values[0]; T1831.values[1] = T1830.values[1]|T1826.values[1]; T1831.values[2] = T1830.values[2]|T1826.values[2]; T1831.values[3] = T1830.values[3]|T1826.values[3]; T1831.values[4] = T1830.values[4]|T1826.values[4]; T1831.values[5] = T1830.values[5]|T1826.values[5]; T1831.values[6] = T1830.values[6]|T1826.values[6]; T1831.values[7] = T1830.values[7]|T1826.values[7]; T1831.values[8] = T1830.values[8]|T1826.values[8]; T1831.values[9] = T1830.values[9]|T1826.values[9]; T1831.values[10] = T1830.values[10]|T1826.values[10]; T1831.values[11] = T1830.values[11]|T1826.values[11]; T1831.values[12] = T1830.values[12]|T1826.values[12]; T1831.values[13] = T1830.values[13]|T1826.values[13]; T1831.values[14] = T1830.values[14]|T1826.values[14]; T1831.values[15] = T1830.values[15]|T1826.values[15]; }
  T1832.values[0] = !Top_SodorTile_cache__flush_success.values[0];
  { T1833.values[0] = T1832.values[0]&&Top_SodorTile_cache__refill_we.values[0]; }
  { val_t __mask = -T1833.values[0]; T1834.values[0] = T1824.values[0] ^ ((T1824.values[0] ^ T1831.values[0]) & __mask); T1834.values[1] = T1824.values[1] ^ ((T1824.values[1] ^ T1831.values[1]) & __mask); T1834.values[2] = T1824.values[2] ^ ((T1824.values[2] ^ T1831.values[2]) & __mask); T1834.values[3] = T1824.values[3] ^ ((T1824.values[3] ^ T1831.values[3]) & __mask); T1834.values[4] = T1824.values[4] ^ ((T1824.values[4] ^ T1831.values[4]) & __mask); T1834.values[5] = T1824.values[5] ^ ((T1824.values[5] ^ T1831.values[5]) & __mask); T1834.values[6] = T1824.values[6] ^ ((T1824.values[6] ^ T1831.values[6]) & __mask); T1834.values[7] = T1824.values[7] ^ ((T1824.values[7] ^ T1831.values[7]) & __mask); T1834.values[8] = T1824.values[8] ^ ((T1824.values[8] ^ T1831.values[8]) & __mask); T1834.values[9] = T1824.values[9] ^ ((T1824.values[9] ^ T1831.values[9]) & __mask); T1834.values[10] = T1824.values[10] ^ ((T1824.values[10] ^ T1831.values[10]) & __mask); T1834.values[11] = T1824.values[11] ^ ((T1824.values[11] ^ T1831.values[11]) & __mask); T1834.values[12] = T1824.values[12] ^ ((T1824.values[12] ^ T1831.values[12]) & __mask); T1834.values[13] = T1824.values[13] ^ ((T1824.values[13] ^ T1831.values[13]) & __mask); T1834.values[14] = T1824.values[14] ^ ((T1824.values[14] ^ T1831.values[14]) & __mask); T1834.values[15] = T1824.values[15] ^ ((T1824.values[15] ^ T1831.values[15]) & __mask); }
  { Top_SodorTile_cache__valid_array_shadow.values[0] = TERNARY(Top_SodorTile_cache__reset.values[0], 0x0L, T1834.values[0]); Top_SodorTile_cache__valid_array_shadow.values[1] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[1]); Top_SodorTile_cache__valid_array_shadow.values[2] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[2]); Top_SodorTile_cache__valid_array_shadow.values[3] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[3]); Top_SodorTile_cache__valid_array_shadow.values[4] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[4]); Top_SodorTile_cache__valid_array_shadow.values[5] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[5]); Top_SodorTile_cache__valid_array_shadow.values[6] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[6]); Top_SodorTile_cache__valid_array_shadow.values[7] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[7]); Top_SodorTile_cache__valid_array_shadow.values[8] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[8]); Top_SodorTile_cache__valid_array_shadow.values[9] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[9]); Top_SodorTile_cache__valid_array_shadow.values[10] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[10]); Top_SodorTile_cache__valid_array_shadow.values[11] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[11]); Top_SodorTile_cache__valid_array_shadow.values[12] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[12]); Top_SodorTile_cache__valid_array_shadow.values[13] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[13]); Top_SodorTile_cache__valid_array_shadow.values[14] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[14]); Top_SodorTile_cache__valid_array_shadow.values[15] = TERNARY(Top_SodorTile_cache__reset.values[0], 0L, T1834.values[15]); }
  { val_t __mask = -Top_SodorTile_cache__io_cpu_flush.values[0]; T1838.values[0] = Top_SodorTile_cache__performing_flush.values[0] ^ ((Top_SodorTile_cache__performing_flush.values[0] ^ 0x1L) & __mask); }
  T1839.values[0] = (Top_SodorTile_cache__flush_idx.values[0] == 1023);
  { T1840.values[0] = T1839.values[0]&&Top_SodorTile_cache__flush_success.values[0]; }
  T1841.values[0] = !Top_SodorTile_cache__io_cpu_flush.values[0];
  { T1842.values[0] = T1841.values[0]&&T1840.values[0]; }
  { val_t __mask = -T1842.values[0]; T1843.values[0] = T1838.values[0] ^ ((T1838.values[0] ^ 0x0L) & __mask); }
  { Top_SodorTile_cache__performing_flush_shadow.values[0] = TERNARY(Top_SodorTile_cache__reset.values[0], 0x0L, T1843.values[0]); }
  { val_t __mask = -Top_SodorTile_cache__io_cpu_flush.values[0]; T1844.values[0] = Top_SodorTile_cache__flush_idx.values[0] ^ ((Top_SodorTile_cache__flush_idx.values[0] ^ 0x0L) & __mask); }
  { T1845.values[0] = Top_SodorTile_cache__flush_idx.values[0]+0x1L; }
  T1845.values[0] = T1845.values[0] & 1023;
  { T1846.values[0] = Top_SodorTile_cache__performing_flush.values[0]&&Top_SodorTile_cache__flush_success.values[0]; }
  T1847.values[0] = !Top_SodorTile_cache__io_cpu_flush.values[0];
  { T1848.values[0] = T1847.values[0]&&T1846.values[0]; }
  { val_t __mask = -T1848.values[0]; T1849.values[0] = T1844.values[0] ^ ((T1844.values[0] ^ T1845.values[0]) & __mask); }
  { Top_SodorTile_cache__flush_idx_shadow.values[0] = TERNARY(Top_SodorTile_cache__reset.values[0], 0x0L, T1849.values[0]); }
  T1850.values[0] = Top_SodorTile_cache__state.values[0] == 0x7L;
  T1851.values[0] = Top_SodorTile_cache__state.values[0] == 0x2L;
  { T1852.values[0] = T1851.values[0]||T1850.values[0]; }
  { val_t __mask = -T1852.values[0]; T1853.values[0] = Top_SodorTile_cache__wb_counter.values[0] ^ ((Top_SodorTile_cache__wb_counter.values[0] ^ 0x0L) & __mask); }
  { T1854.values[0] = Top_SodorTile_cache__wb_counter.values[0]+0x1L; }
  T1854.values[0] = T1854.values[0] & 3;
  T1855.values[0] = Top_SodorTile_cache__state.values[0] == 0x3L;
  T1856.values[0] = !T1852.values[0];
  { T1857.values[0] = T1856.values[0]&&T1855.values[0]; }
  { val_t __mask = -T1857.values[0]; T1858.values[0] = T1853.values[0] ^ ((T1853.values[0] ^ T1854.values[0]) & __mask); }
  { Top_SodorTile_cache__wb_counter_shadow.values[0] = TERNARY(Top_SodorTile_cache__reset.values[0], 0x0L, T1858.values[0]); }
  { Top_SodorTile_cache__byte_shift_amt.values[0] = Top_SodorTile_cache__io_cpu_req_addr.values[0]; }
  Top_SodorTile_cache__byte_shift_amt.values[0] = Top_SodorTile_cache__byte_shift_amt.values[0] & 15;
  { T1859.values[0] = 0x0L | Top_SodorTile_cache__byte_shift_amt.values[0] << 3; }
  { Top_SodorTile_cache__bit_shift_amt.values[0] = T1859.values[0]; }
  { T1860.values[0] = Top_SodorTile_cache__bit_shift_amt.values[0]; }
  { val_t __x[1]; __x[0] = 0xffffffffL; val_t __c = 0; val_t __w = T1860.values[0] / 64; val_t __s = T1860.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); Top_SodorTile_cache__wmask.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); Top_SodorTile_cache__wmask.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); Top_SodorTile_cache__wmask.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); }
  Top_SodorTile_cache__wmask.values[2] = Top_SodorTile_cache__wmask.values[2] & 2147483647;
  { T1861.values[0] = Top_SodorTile_cache__wmask.values[0]; T1861.values[1] = Top_SodorTile_cache__wmask.values[1]; }
  { T1862.values[0] = Top_SodorTile_cache__bit_shift_amt.values[0]; }
  { T1863.values[0] = Top_SodorTile_cpu_d_pcr__rdata.values[0]; }
  T1863.values[0] = T1863.values[0] & 4294967295;
  { Top_SodorTile_cpu_d_pcr__io_r_data.values[0] = T1863.values[0]; }
  { Top_SodorTile_cpu_d__pcr_rdata.values[0] = Top_SodorTile_cpu_d_pcr__io_r_data.values[0]; }
  T1864.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x6L;
  { T1865.values[0] = ~Top_SodorTile_cpu_d__io_ctl_reg_wr.values[0]; }
  T1865.values[0] = T1865.values[0] & 1;
  { T1866.values[0] = Top_SodorTile_cpu_d__io_ctl_en_reg.values[0]&T1865.values[0]; }
  { T1867.values[0] = T1866.values[0]&T1864.values[0]; }
  { val_t __mask = -T1867.values[0]; T1868.values[0] = 0x0L ^ ((0x0L ^ Top_SodorTile_cpu_d__pcr_rdata.values[0]) & __mask); }
  { T1869.values[0] = Top_SodorTile_cache__bit_shift_amt.values[0]; }
  { val_t __x[2]; __x[0] = T1770.values[0]; __x[1] = T1770.values[1]; val_t __c = 0; val_t __w = T1869.values[0] / 64; val_t __s = T1869.values[0] % 64; val_t __r = 64 - __s; val_t __v1 = MASK(__x[CLAMP(1+__w,0,1)],__w+1<2); T1870.values[1] = __v1 >> __s | __c; __c = MASK(__v1 << __r, __s != 0); val_t __v0 = MASK(__x[CLAMP(0+__w,0,1)],__w+0<2); T1870.values[0] = __v0 >> __s | __c; __c = MASK(__v0 << __r, __s != 0); }
  { Top_SodorTile_cache__rdata_out.values[0] = T1870.values[0]; }
  Top_SodorTile_cache__rdata_out.values[0] = Top_SodorTile_cache__rdata_out.values[0] & 4294967295;
  { Top_SodorTile_cache__io_cpu_resp_data.values[0] = Top_SodorTile_cache__rdata_out.values[0]; }
  { Top_SodorTile_cpu__io_mem_resp_data.values[0] = Top_SodorTile_cache__io_cpu_resp_data.values[0]; }
  { Top_SodorTile_cpu_d__io_mem_resp_data.values[0] = Top_SodorTile_cpu__io_mem_resp_data.values[0]; }
  { T1871.values[0] = Top_SodorTile_cpu_d__io_mem_resp_data.values[0]; }
  T1871.values[0] = T1871.values[0] & 4294967295;
  { Top_SodorTile_cpu_c__io_ctl_mem_wr.values[0] = Top_SodorTile_cpu_c__cs_mem_wr.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_mem_wr.values[0] = Top_SodorTile_cpu_c__io_ctl_mem_wr.values[0]; }
  { T1872.values[0] = ~Top_SodorTile_cpu_d__io_ctl_mem_wr.values[0]; }
  T1872.values[0] = T1872.values[0] & 1;
  { Top_SodorTile_cpu_c__io_ctl_en_mem.values[0] = Top_SodorTile_cpu_c__cs_en_mem.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_en_mem.values[0] = Top_SodorTile_cpu_c__io_ctl_en_mem.values[0]; }
  { T1873.values[0] = Top_SodorTile_cpu_d__io_ctl_en_mem.values[0]&T1872.values[0]; }
  { val_t __mask = -T1873.values[0]; T1874.values[0] = T1868.values[0] ^ ((T1868.values[0] ^ T1871.values[0]) & __mask); }
  { T1875.values[0] = Top_SodorTile_cpu_d__rs1.values[0] | 0x0L << 5; }
  { T1876.values[0] = T1875.values[0]+0x21L; }
  T1876.values[0] = T1876.values[0] & 63;
  T1877.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x6L;
  { val_t __mask = -T1877.values[0]; T1878.values[0] = 0x0L ^ ((0x0L ^ T1876.values[0]) & __mask); }
  T1879.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x5L;
  { val_t __mask = -T1879.values[0]; T1880.values[0] = T1878.values[0] ^ ((T1878.values[0] ^ 0x0L) & __mask); }
  T1881.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x4L;
  { val_t __mask = -T1881.values[0]; T1882.values[0] = T1880.values[0] ^ ((T1880.values[0] ^ 0x1L) & __mask); }
  { T1883.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 17; }
  T1883.values[0] = T1883.values[0] & 31;
  { Top_SodorTile_cpu_d__rs2.values[0] = T1883.values[0]; }
  { T1884.values[0] = Top_SodorTile_cpu_d__rs2.values[0] | 0x0L << 5; }
  T1885.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x3L;
  { val_t __mask = -T1885.values[0]; T1886.values[0] = T1882.values[0] ^ ((T1882.values[0] ^ T1884.values[0]) & __mask); }
  { T1887.values[0] = Top_SodorTile_cpu_d__rs1.values[0] | 0x0L << 5; }
  T1888.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x2L;
  { val_t __mask = -T1888.values[0]; T1889.values[0] = T1886.values[0] ^ ((T1886.values[0] ^ T1887.values[0]) & __mask); }
  { T1890.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 27; }
  T1890.values[0] = T1890.values[0] & 31;
  { Top_SodorTile_cpu_d__rd.values[0] = T1890.values[0]; }
  { T1891.values[0] = Top_SodorTile_cpu_d__rd.values[0] | 0x0L << 5; }
  T1892.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x1L;
  { val_t __mask = -T1892.values[0]; T1893.values[0] = T1889.values[0] ^ ((T1889.values[0] ^ T1891.values[0]) & __mask); }
  T1894.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] == 0x0L;
  { val_t __mask = -T1894.values[0]; Top_SodorTile_cpu_d__reg_addr.values[0] = T1893.values[0] ^ ((T1893.values[0] ^ 0x20L) & __mask); }
  { T1895.values[0] = Top_SodorTile_cpu_d__reg_addr.values[0]; }
  { val_t __x[2]; __x[0] = 0x1L; __x[1] = 0L; val_t __c = 0; val_t __w = T1895.values[0] / 64; val_t __s = T1895.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,1)],0>=__w&&0<__w+2); T1896.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,1)],1>=__w&&1<__w+2); T1896.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); }
  { T1897.values[0] = T1896.values[0]; T1897.values[1] = T1896.values[1]; }
  T1897.values[1] = T1897.values[1] & 1;
  T1898.values[0] = (T1897.values[1] >> 0) & 1;
  { T1899.values[0] = T1898.values[0]; }
  { T1900.values[0] = -T1899.values[0]; }
  T1900.values[0] = T1900.values[0] & 4294967295;
  { T1901.values[0] = Top_SodorTile_cpu_d__regfile_64.values[0]&T1900.values[0]; }
  T1902.values[0] = (T1897.values[0] >> 63) & 1;
  { T1903.values[0] = T1902.values[0]; }
  { T1904.values[0] = -T1903.values[0]; }
  T1904.values[0] = T1904.values[0] & 4294967295;
  { T1905.values[0] = Top_SodorTile_cpu_d__regfile_63.values[0]&T1904.values[0]; }
  T1906.values[0] = (T1897.values[0] >> 62) & 1;
  { T1907.values[0] = T1906.values[0]; }
  { T1908.values[0] = -T1907.values[0]; }
  T1908.values[0] = T1908.values[0] & 4294967295;
  { T1909.values[0] = Top_SodorTile_cpu_d__regfile_62.values[0]&T1908.values[0]; }
  T1910.values[0] = (T1897.values[0] >> 61) & 1;
  { T1911.values[0] = T1910.values[0]; }
  { T1912.values[0] = -T1911.values[0]; }
  T1912.values[0] = T1912.values[0] & 4294967295;
  { T1913.values[0] = Top_SodorTile_cpu_d__regfile_61.values[0]&T1912.values[0]; }
  T1914.values[0] = (T1897.values[0] >> 60) & 1;
  { T1915.values[0] = T1914.values[0]; }
  { T1916.values[0] = -T1915.values[0]; }
  T1916.values[0] = T1916.values[0] & 4294967295;
  { T1917.values[0] = Top_SodorTile_cpu_d__regfile_60.values[0]&T1916.values[0]; }
  T1918.values[0] = (T1897.values[0] >> 59) & 1;
  { T1919.values[0] = T1918.values[0]; }
  { T1920.values[0] = -T1919.values[0]; }
  T1920.values[0] = T1920.values[0] & 4294967295;
  { T1921.values[0] = Top_SodorTile_cpu_d__regfile_59.values[0]&T1920.values[0]; }
  T1922.values[0] = (T1897.values[0] >> 58) & 1;
  { T1923.values[0] = T1922.values[0]; }
  { T1924.values[0] = -T1923.values[0]; }
  T1924.values[0] = T1924.values[0] & 4294967295;
  { T1925.values[0] = Top_SodorTile_cpu_d__regfile_58.values[0]&T1924.values[0]; }
  T1926.values[0] = (T1897.values[0] >> 57) & 1;
  { T1927.values[0] = T1926.values[0]; }
  { T1928.values[0] = -T1927.values[0]; }
  T1928.values[0] = T1928.values[0] & 4294967295;
  { T1929.values[0] = Top_SodorTile_cpu_d__regfile_57.values[0]&T1928.values[0]; }
  T1930.values[0] = (T1897.values[0] >> 56) & 1;
  { T1931.values[0] = T1930.values[0]; }
  { T1932.values[0] = -T1931.values[0]; }
  T1932.values[0] = T1932.values[0] & 4294967295;
  { T1933.values[0] = Top_SodorTile_cpu_d__regfile_56.values[0]&T1932.values[0]; }
  T1934.values[0] = (T1897.values[0] >> 55) & 1;
  { T1935.values[0] = T1934.values[0]; }
  { T1936.values[0] = -T1935.values[0]; }
  T1936.values[0] = T1936.values[0] & 4294967295;
  { T1937.values[0] = Top_SodorTile_cpu_d__regfile_55.values[0]&T1936.values[0]; }
  T1938.values[0] = (T1897.values[0] >> 54) & 1;
  { T1939.values[0] = T1938.values[0]; }
  { T1940.values[0] = -T1939.values[0]; }
  T1940.values[0] = T1940.values[0] & 4294967295;
  { T1941.values[0] = Top_SodorTile_cpu_d__regfile_54.values[0]&T1940.values[0]; }
  T1942.values[0] = (T1897.values[0] >> 53) & 1;
  { T1943.values[0] = T1942.values[0]; }
  { T1944.values[0] = -T1943.values[0]; }
  T1944.values[0] = T1944.values[0] & 4294967295;
  { T1945.values[0] = Top_SodorTile_cpu_d__regfile_53.values[0]&T1944.values[0]; }
  T1946.values[0] = (T1897.values[0] >> 52) & 1;
  { T1947.values[0] = T1946.values[0]; }
  { T1948.values[0] = -T1947.values[0]; }
  T1948.values[0] = T1948.values[0] & 4294967295;
  { T1949.values[0] = Top_SodorTile_cpu_d__regfile_52.values[0]&T1948.values[0]; }
  T1950.values[0] = (T1897.values[0] >> 51) & 1;
  { T1951.values[0] = T1950.values[0]; }
  { T1952.values[0] = -T1951.values[0]; }
  T1952.values[0] = T1952.values[0] & 4294967295;
  { T1953.values[0] = Top_SodorTile_cpu_d__regfile_51.values[0]&T1952.values[0]; }
  T1954.values[0] = (T1897.values[0] >> 50) & 1;
  { T1955.values[0] = T1954.values[0]; }
  { T1956.values[0] = -T1955.values[0]; }
  T1956.values[0] = T1956.values[0] & 4294967295;
  { T1957.values[0] = Top_SodorTile_cpu_d__regfile_50.values[0]&T1956.values[0]; }
  T1958.values[0] = (T1897.values[0] >> 49) & 1;
  { T1959.values[0] = T1958.values[0]; }
  { T1960.values[0] = -T1959.values[0]; }
  T1960.values[0] = T1960.values[0] & 4294967295;
  { T1961.values[0] = Top_SodorTile_cpu_d__regfile_49.values[0]&T1960.values[0]; }
  T1962.values[0] = (T1897.values[0] >> 48) & 1;
  { T1963.values[0] = T1962.values[0]; }
  { T1964.values[0] = -T1963.values[0]; }
  T1964.values[0] = T1964.values[0] & 4294967295;
  { T1965.values[0] = Top_SodorTile_cpu_d__regfile_48.values[0]&T1964.values[0]; }
  T1966.values[0] = (T1897.values[0] >> 47) & 1;
  { T1967.values[0] = T1966.values[0]; }
  { T1968.values[0] = -T1967.values[0]; }
  T1968.values[0] = T1968.values[0] & 4294967295;
  { T1969.values[0] = Top_SodorTile_cpu_d__regfile_47.values[0]&T1968.values[0]; }
  T1970.values[0] = (T1897.values[0] >> 46) & 1;
  { T1971.values[0] = T1970.values[0]; }
  { T1972.values[0] = -T1971.values[0]; }
  T1972.values[0] = T1972.values[0] & 4294967295;
  { T1973.values[0] = Top_SodorTile_cpu_d__regfile_46.values[0]&T1972.values[0]; }
  T1974.values[0] = (T1897.values[0] >> 45) & 1;
  { T1975.values[0] = T1974.values[0]; }
  { T1976.values[0] = -T1975.values[0]; }
  T1976.values[0] = T1976.values[0] & 4294967295;
  { T1977.values[0] = Top_SodorTile_cpu_d__regfile_45.values[0]&T1976.values[0]; }
  T1978.values[0] = (T1897.values[0] >> 44) & 1;
  { T1979.values[0] = T1978.values[0]; }
  { T1980.values[0] = -T1979.values[0]; }
  T1980.values[0] = T1980.values[0] & 4294967295;
  { T1981.values[0] = Top_SodorTile_cpu_d__regfile_44.values[0]&T1980.values[0]; }
  T1982.values[0] = (T1897.values[0] >> 43) & 1;
  { T1983.values[0] = T1982.values[0]; }
  { T1984.values[0] = -T1983.values[0]; }
  T1984.values[0] = T1984.values[0] & 4294967295;
  { T1985.values[0] = Top_SodorTile_cpu_d__regfile_43.values[0]&T1984.values[0]; }
  T1986.values[0] = (T1897.values[0] >> 42) & 1;
  { T1987.values[0] = T1986.values[0]; }
  { T1988.values[0] = -T1987.values[0]; }
  T1988.values[0] = T1988.values[0] & 4294967295;
  { T1989.values[0] = Top_SodorTile_cpu_d__regfile_42.values[0]&T1988.values[0]; }
  T1990.values[0] = (T1897.values[0] >> 41) & 1;
  { T1991.values[0] = T1990.values[0]; }
  { T1992.values[0] = -T1991.values[0]; }
  T1992.values[0] = T1992.values[0] & 4294967295;
  { T1993.values[0] = Top_SodorTile_cpu_d__regfile_41.values[0]&T1992.values[0]; }
  T1994.values[0] = (T1897.values[0] >> 40) & 1;
  { T1995.values[0] = T1994.values[0]; }
  { T1996.values[0] = -T1995.values[0]; }
  T1996.values[0] = T1996.values[0] & 4294967295;
  { T1997.values[0] = Top_SodorTile_cpu_d__regfile_40.values[0]&T1996.values[0]; }
  T1998.values[0] = (T1897.values[0] >> 39) & 1;
  { T1999.values[0] = T1998.values[0]; }
  { T2000.values[0] = -T1999.values[0]; }
  T2000.values[0] = T2000.values[0] & 4294967295;
  { T2001.values[0] = Top_SodorTile_cpu_d__regfile_39.values[0]&T2000.values[0]; }
  T2002.values[0] = (T1897.values[0] >> 38) & 1;
  { T2003.values[0] = T2002.values[0]; }
  { T2004.values[0] = -T2003.values[0]; }
  T2004.values[0] = T2004.values[0] & 4294967295;
  { T2005.values[0] = Top_SodorTile_cpu_d__regfile_38.values[0]&T2004.values[0]; }
  T2006.values[0] = (T1897.values[0] >> 37) & 1;
  { T2007.values[0] = T2006.values[0]; }
  { T2008.values[0] = -T2007.values[0]; }
  T2008.values[0] = T2008.values[0] & 4294967295;
  { T2009.values[0] = Top_SodorTile_cpu_d__regfile_37.values[0]&T2008.values[0]; }
  T2010.values[0] = (T1897.values[0] >> 36) & 1;
  { T2011.values[0] = T2010.values[0]; }
  { T2012.values[0] = -T2011.values[0]; }
  T2012.values[0] = T2012.values[0] & 4294967295;
  { T2013.values[0] = Top_SodorTile_cpu_d__regfile_36.values[0]&T2012.values[0]; }
  T2014.values[0] = (T1897.values[0] >> 35) & 1;
  { T2015.values[0] = T2014.values[0]; }
  { T2016.values[0] = -T2015.values[0]; }
  T2016.values[0] = T2016.values[0] & 4294967295;
  { T2017.values[0] = Top_SodorTile_cpu_d__regfile_35.values[0]&T2016.values[0]; }
  T2018.values[0] = (T1897.values[0] >> 34) & 1;
  { T2019.values[0] = T2018.values[0]; }
  { T2020.values[0] = -T2019.values[0]; }
  T2020.values[0] = T2020.values[0] & 4294967295;
  { T2021.values[0] = Top_SodorTile_cpu_d__regfile_34.values[0]&T2020.values[0]; }
  T2022.values[0] = (T1897.values[0] >> 33) & 1;
  { T2023.values[0] = T2022.values[0]; }
  { T2024.values[0] = -T2023.values[0]; }
  T2024.values[0] = T2024.values[0] & 4294967295;
  { T2025.values[0] = Top_SodorTile_cpu_d__regfile_33.values[0]&T2024.values[0]; }
  T2026.values[0] = (T1897.values[0] >> 32) & 1;
  { T2027.values[0] = T2026.values[0]; }
  { T2028.values[0] = -T2027.values[0]; }
  T2028.values[0] = T2028.values[0] & 4294967295;
  { T2029.values[0] = Top_SodorTile_cpu_d__regfile_32.values[0]&T2028.values[0]; }
  T2030.values[0] = (T1897.values[0] >> 31) & 1;
  { T2031.values[0] = T2030.values[0]; }
  { T2032.values[0] = -T2031.values[0]; }
  T2032.values[0] = T2032.values[0] & 4294967295;
  { T2033.values[0] = Top_SodorTile_cpu_d__regfile_31.values[0]&T2032.values[0]; }
  T2034.values[0] = (T1897.values[0] >> 30) & 1;
  { T2035.values[0] = T2034.values[0]; }
  { T2036.values[0] = -T2035.values[0]; }
  T2036.values[0] = T2036.values[0] & 4294967295;
  { T2037.values[0] = Top_SodorTile_cpu_d__regfile_30.values[0]&T2036.values[0]; }
  T2038.values[0] = (T1897.values[0] >> 29) & 1;
  { T2039.values[0] = T2038.values[0]; }
  { T2040.values[0] = -T2039.values[0]; }
  T2040.values[0] = T2040.values[0] & 4294967295;
  { T2041.values[0] = Top_SodorTile_cpu_d__regfile_29.values[0]&T2040.values[0]; }
  T2042.values[0] = (T1897.values[0] >> 28) & 1;
  { T2043.values[0] = T2042.values[0]; }
  { T2044.values[0] = -T2043.values[0]; }
  T2044.values[0] = T2044.values[0] & 4294967295;
  { T2045.values[0] = Top_SodorTile_cpu_d__regfile_28.values[0]&T2044.values[0]; }
  T2046.values[0] = (T1897.values[0] >> 27) & 1;
  { T2047.values[0] = T2046.values[0]; }
  { T2048.values[0] = -T2047.values[0]; }
  T2048.values[0] = T2048.values[0] & 4294967295;
  { T2049.values[0] = Top_SodorTile_cpu_d__regfile_27.values[0]&T2048.values[0]; }
  T2050.values[0] = (T1897.values[0] >> 26) & 1;
  { T2051.values[0] = T2050.values[0]; }
  { T2052.values[0] = -T2051.values[0]; }
  T2052.values[0] = T2052.values[0] & 4294967295;
  { T2053.values[0] = Top_SodorTile_cpu_d__regfile_26.values[0]&T2052.values[0]; }
  T2054.values[0] = (T1897.values[0] >> 25) & 1;
  { T2055.values[0] = T2054.values[0]; }
  { T2056.values[0] = -T2055.values[0]; }
  T2056.values[0] = T2056.values[0] & 4294967295;
  { T2057.values[0] = Top_SodorTile_cpu_d__regfile_25.values[0]&T2056.values[0]; }
  T2058.values[0] = (T1897.values[0] >> 24) & 1;
  { T2059.values[0] = T2058.values[0]; }
  { T2060.values[0] = -T2059.values[0]; }
  T2060.values[0] = T2060.values[0] & 4294967295;
  { T2061.values[0] = Top_SodorTile_cpu_d__regfile_24.values[0]&T2060.values[0]; }
  T2062.values[0] = (T1897.values[0] >> 23) & 1;
  { T2063.values[0] = T2062.values[0]; }
  { T2064.values[0] = -T2063.values[0]; }
  T2064.values[0] = T2064.values[0] & 4294967295;
  { T2065.values[0] = Top_SodorTile_cpu_d__regfile_23.values[0]&T2064.values[0]; }
  T2066.values[0] = (T1897.values[0] >> 22) & 1;
  { T2067.values[0] = T2066.values[0]; }
  { T2068.values[0] = -T2067.values[0]; }
  T2068.values[0] = T2068.values[0] & 4294967295;
  { T2069.values[0] = Top_SodorTile_cpu_d__regfile_22.values[0]&T2068.values[0]; }
  T2070.values[0] = (T1897.values[0] >> 21) & 1;
  { T2071.values[0] = T2070.values[0]; }
  { T2072.values[0] = -T2071.values[0]; }
  T2072.values[0] = T2072.values[0] & 4294967295;
  { T2073.values[0] = Top_SodorTile_cpu_d__regfile_21.values[0]&T2072.values[0]; }
  T2074.values[0] = (T1897.values[0] >> 20) & 1;
  { T2075.values[0] = T2074.values[0]; }
  { T2076.values[0] = -T2075.values[0]; }
  T2076.values[0] = T2076.values[0] & 4294967295;
  { T2077.values[0] = Top_SodorTile_cpu_d__regfile_20.values[0]&T2076.values[0]; }
  T2078.values[0] = (T1897.values[0] >> 19) & 1;
  { T2079.values[0] = T2078.values[0]; }
  { T2080.values[0] = -T2079.values[0]; }
  T2080.values[0] = T2080.values[0] & 4294967295;
  { T2081.values[0] = Top_SodorTile_cpu_d__regfile_19.values[0]&T2080.values[0]; }
  T2082.values[0] = (T1897.values[0] >> 18) & 1;
  { T2083.values[0] = T2082.values[0]; }
  { T2084.values[0] = -T2083.values[0]; }
  T2084.values[0] = T2084.values[0] & 4294967295;
  { T2085.values[0] = Top_SodorTile_cpu_d__regfile_18.values[0]&T2084.values[0]; }
  T2086.values[0] = (T1897.values[0] >> 17) & 1;
  { T2087.values[0] = T2086.values[0]; }
  { T2088.values[0] = -T2087.values[0]; }
  T2088.values[0] = T2088.values[0] & 4294967295;
  { T2089.values[0] = Top_SodorTile_cpu_d__regfile_17.values[0]&T2088.values[0]; }
  T2090.values[0] = (T1897.values[0] >> 16) & 1;
  { T2091.values[0] = T2090.values[0]; }
  { T2092.values[0] = -T2091.values[0]; }
  T2092.values[0] = T2092.values[0] & 4294967295;
  { T2093.values[0] = Top_SodorTile_cpu_d__regfile_16.values[0]&T2092.values[0]; }
  T2094.values[0] = (T1897.values[0] >> 15) & 1;
  { T2095.values[0] = T2094.values[0]; }
  { T2096.values[0] = -T2095.values[0]; }
  T2096.values[0] = T2096.values[0] & 4294967295;
  { T2097.values[0] = Top_SodorTile_cpu_d__regfile_15.values[0]&T2096.values[0]; }
  T2098.values[0] = (T1897.values[0] >> 14) & 1;
  { T2099.values[0] = T2098.values[0]; }
  { T2100.values[0] = -T2099.values[0]; }
  T2100.values[0] = T2100.values[0] & 4294967295;
  { T2101.values[0] = Top_SodorTile_cpu_d__regfile_14.values[0]&T2100.values[0]; }
  T2102.values[0] = (T1897.values[0] >> 13) & 1;
  { T2103.values[0] = T2102.values[0]; }
  { T2104.values[0] = -T2103.values[0]; }
  T2104.values[0] = T2104.values[0] & 4294967295;
  { T2105.values[0] = Top_SodorTile_cpu_d__regfile_13.values[0]&T2104.values[0]; }
  T2106.values[0] = (T1897.values[0] >> 12) & 1;
  { T2107.values[0] = T2106.values[0]; }
  { T2108.values[0] = -T2107.values[0]; }
  T2108.values[0] = T2108.values[0] & 4294967295;
  { T2109.values[0] = Top_SodorTile_cpu_d__regfile_12.values[0]&T2108.values[0]; }
  T2110.values[0] = (T1897.values[0] >> 11) & 1;
  { T2111.values[0] = T2110.values[0]; }
  { T2112.values[0] = -T2111.values[0]; }
  T2112.values[0] = T2112.values[0] & 4294967295;
  { T2113.values[0] = Top_SodorTile_cpu_d__regfile_11.values[0]&T2112.values[0]; }
  T2114.values[0] = (T1897.values[0] >> 10) & 1;
  { T2115.values[0] = T2114.values[0]; }
  { T2116.values[0] = -T2115.values[0]; }
  T2116.values[0] = T2116.values[0] & 4294967295;
  { T2117.values[0] = Top_SodorTile_cpu_d__regfile_10.values[0]&T2116.values[0]; }
  T2118.values[0] = (T1897.values[0] >> 9) & 1;
  { T2119.values[0] = T2118.values[0]; }
  { T2120.values[0] = -T2119.values[0]; }
  T2120.values[0] = T2120.values[0] & 4294967295;
  { T2121.values[0] = Top_SodorTile_cpu_d__regfile_9.values[0]&T2120.values[0]; }
  T2122.values[0] = (T1897.values[0] >> 8) & 1;
  { T2123.values[0] = T2122.values[0]; }
  { T2124.values[0] = -T2123.values[0]; }
  T2124.values[0] = T2124.values[0] & 4294967295;
  { T2125.values[0] = Top_SodorTile_cpu_d__regfile_8.values[0]&T2124.values[0]; }
  T2126.values[0] = (T1897.values[0] >> 7) & 1;
  { T2127.values[0] = T2126.values[0]; }
  { T2128.values[0] = -T2127.values[0]; }
  T2128.values[0] = T2128.values[0] & 4294967295;
  { T2129.values[0] = Top_SodorTile_cpu_d__regfile_7.values[0]&T2128.values[0]; }
  T2130.values[0] = (T1897.values[0] >> 6) & 1;
  { T2131.values[0] = T2130.values[0]; }
  { T2132.values[0] = -T2131.values[0]; }
  T2132.values[0] = T2132.values[0] & 4294967295;
  { T2133.values[0] = Top_SodorTile_cpu_d__regfile_6.values[0]&T2132.values[0]; }
  T2134.values[0] = (T1897.values[0] >> 5) & 1;
  { T2135.values[0] = T2134.values[0]; }
  { T2136.values[0] = -T2135.values[0]; }
  T2136.values[0] = T2136.values[0] & 4294967295;
  { T2137.values[0] = Top_SodorTile_cpu_d__regfile_5.values[0]&T2136.values[0]; }
  T2138.values[0] = (T1897.values[0] >> 4) & 1;
  { T2139.values[0] = T2138.values[0]; }
  { T2140.values[0] = -T2139.values[0]; }
  T2140.values[0] = T2140.values[0] & 4294967295;
  { T2141.values[0] = Top_SodorTile_cpu_d__regfile_4.values[0]&T2140.values[0]; }
  T2142.values[0] = (T1897.values[0] >> 3) & 1;
  { T2143.values[0] = T2142.values[0]; }
  { T2144.values[0] = -T2143.values[0]; }
  T2144.values[0] = T2144.values[0] & 4294967295;
  { T2145.values[0] = Top_SodorTile_cpu_d__regfile_3.values[0]&T2144.values[0]; }
  T2146.values[0] = (T1897.values[0] >> 2) & 1;
  { T2147.values[0] = T2146.values[0]; }
  { T2148.values[0] = -T2147.values[0]; }
  T2148.values[0] = T2148.values[0] & 4294967295;
  { T2149.values[0] = Top_SodorTile_cpu_d__regfile_2.values[0]&T2148.values[0]; }
  T2150.values[0] = (T1897.values[0] >> 1) & 1;
  { T2151.values[0] = T2150.values[0]; }
  { T2152.values[0] = -T2151.values[0]; }
  T2152.values[0] = T2152.values[0] & 4294967295;
  { T2153.values[0] = Top_SodorTile_cpu_d__regfile_1.values[0]&T2152.values[0]; }
  T2154.values[0] = (T1897.values[0] >> 0) & 1;
  { T2155.values[0] = T2154.values[0]; }
  { T2156.values[0] = -T2155.values[0]; }
  T2156.values[0] = T2156.values[0] & 4294967295;
  { T2157.values[0] = Top_SodorTile_cpu_d__regfile_0.values[0]&T2156.values[0]; }
  { T2158.values[0] = T2157.values[0]|T2153.values[0]; }
  { T2159.values[0] = T2158.values[0]|T2149.values[0]; }
  { T2160.values[0] = T2159.values[0]|T2145.values[0]; }
  { T2161.values[0] = T2160.values[0]|T2141.values[0]; }
  { T2162.values[0] = T2161.values[0]|T2137.values[0]; }
  { T2163.values[0] = T2162.values[0]|T2133.values[0]; }
  { T2164.values[0] = T2163.values[0]|T2129.values[0]; }
  { T2165.values[0] = T2164.values[0]|T2125.values[0]; }
  { T2166.values[0] = T2165.values[0]|T2121.values[0]; }
  { T2167.values[0] = T2166.values[0]|T2117.values[0]; }
  { T2168.values[0] = T2167.values[0]|T2113.values[0]; }
  { T2169.values[0] = T2168.values[0]|T2109.values[0]; }
  { T2170.values[0] = T2169.values[0]|T2105.values[0]; }
  { T2171.values[0] = T2170.values[0]|T2101.values[0]; }
  { T2172.values[0] = T2171.values[0]|T2097.values[0]; }
  { T2173.values[0] = T2172.values[0]|T2093.values[0]; }
  { T2174.values[0] = T2173.values[0]|T2089.values[0]; }
  { T2175.values[0] = T2174.values[0]|T2085.values[0]; }
  { T2176.values[0] = T2175.values[0]|T2081.values[0]; }
  { T2177.values[0] = T2176.values[0]|T2077.values[0]; }
  { T2178.values[0] = T2177.values[0]|T2073.values[0]; }
  { T2179.values[0] = T2178.values[0]|T2069.values[0]; }
  { T2180.values[0] = T2179.values[0]|T2065.values[0]; }
  { T2181.values[0] = T2180.values[0]|T2061.values[0]; }
  { T2182.values[0] = T2181.values[0]|T2057.values[0]; }
  { T2183.values[0] = T2182.values[0]|T2053.values[0]; }
  { T2184.values[0] = T2183.values[0]|T2049.values[0]; }
  { T2185.values[0] = T2184.values[0]|T2045.values[0]; }
  { T2186.values[0] = T2185.values[0]|T2041.values[0]; }
  { T2187.values[0] = T2186.values[0]|T2037.values[0]; }
  { T2188.values[0] = T2187.values[0]|T2033.values[0]; }
  { T2189.values[0] = T2188.values[0]|T2029.values[0]; }
  { T2190.values[0] = T2189.values[0]|T2025.values[0]; }
  { T2191.values[0] = T2190.values[0]|T2021.values[0]; }
  { T2192.values[0] = T2191.values[0]|T2017.values[0]; }
  { T2193.values[0] = T2192.values[0]|T2013.values[0]; }
  { T2194.values[0] = T2193.values[0]|T2009.values[0]; }
  { T2195.values[0] = T2194.values[0]|T2005.values[0]; }
  { T2196.values[0] = T2195.values[0]|T2001.values[0]; }
  { T2197.values[0] = T2196.values[0]|T1997.values[0]; }
  { T2198.values[0] = T2197.values[0]|T1993.values[0]; }
  { T2199.values[0] = T2198.values[0]|T1989.values[0]; }
  { T2200.values[0] = T2199.values[0]|T1985.values[0]; }
  { T2201.values[0] = T2200.values[0]|T1981.values[0]; }
  { T2202.values[0] = T2201.values[0]|T1977.values[0]; }
  { T2203.values[0] = T2202.values[0]|T1973.values[0]; }
  { T2204.values[0] = T2203.values[0]|T1969.values[0]; }
  { T2205.values[0] = T2204.values[0]|T1965.values[0]; }
  { T2206.values[0] = T2205.values[0]|T1961.values[0]; }
  { T2207.values[0] = T2206.values[0]|T1957.values[0]; }
  { T2208.values[0] = T2207.values[0]|T1953.values[0]; }
  { T2209.values[0] = T2208.values[0]|T1949.values[0]; }
  { T2210.values[0] = T2209.values[0]|T1945.values[0]; }
  { T2211.values[0] = T2210.values[0]|T1941.values[0]; }
  { T2212.values[0] = T2211.values[0]|T1937.values[0]; }
  { T2213.values[0] = T2212.values[0]|T1933.values[0]; }
  { T2214.values[0] = T2213.values[0]|T1929.values[0]; }
  { T2215.values[0] = T2214.values[0]|T1925.values[0]; }
  { T2216.values[0] = T2215.values[0]|T1921.values[0]; }
  { T2217.values[0] = T2216.values[0]|T1917.values[0]; }
  { T2218.values[0] = T2217.values[0]|T1913.values[0]; }
  { T2219.values[0] = T2218.values[0]|T1909.values[0]; }
  { T2220.values[0] = T2219.values[0]|T1905.values[0]; }
  { T2221.values[0] = T2220.values[0]|T1901.values[0]; }
  T2222.values[0] = Top_SodorTile_cpu_d__reg_addr.values[0] == 0x0L;
  { val_t __mask = -T2222.values[0]; T2223.values[0] = T2221.values[0] ^ ((T2221.values[0] ^ 0x0L) & __mask); }
  { Top_SodorTile_cpu_d__reg_rdata.values[0] = T2223.values[0]; }
  { T2224.values[0] = Top_SodorTile_cpu_d__reg_rdata.values[0]; }
  T2224.values[0] = T2224.values[0] & 4294967295;
  T2225.values[0] = Top_SodorTile_cpu_d__io_ctl_reg_sel.values[0] != 0x6L;
  { T2226.values[0] = ~Top_SodorTile_cpu_d__io_ctl_reg_wr.values[0]; }
  T2226.values[0] = T2226.values[0] & 1;
  { T2227.values[0] = Top_SodorTile_cpu_d__io_ctl_en_reg.values[0]&T2226.values[0]; }
  { T2228.values[0] = T2227.values[0]&T2225.values[0]; }
  { val_t __mask = -T2228.values[0]; T2229.values[0] = T1874.values[0] ^ ((T1874.values[0] ^ T2224.values[0]) & __mask); }
  { T2230.values[0] = T1621.values[0] >> 18; }
  T2230.values[0] = T2230.values[0] & 31;
  { Top_SodorTile_cpu_c__cs_alu_op.values[0] = T2230.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_alu_op.values[0] = Top_SodorTile_cpu_c__cs_alu_op.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] = Top_SodorTile_cpu_c__io_ctl_alu_op.values[0]; }
  T2231.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x10L;
  { val_t __mask = -T2231.values[0]; T2232.values[0] = 0x0L ^ ((0x0L ^ 0x2000L) & __mask); }
  { T2233.values[0] = Top_SodorTile_cpu_d__reg_b.values[0]; }
  { T2234.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  T2235.values[0] = T2234.values[0]<T2233.values[0];
  { T2236.values[0] = T2235.values[0] | 0x0L << 1; }
  T2237.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0xfL;
  { val_t __mask = -T2237.values[0]; T2238.values[0] = T2232.values[0] ^ ((T2232.values[0] ^ T2236.values[0]) & __mask); }
  { T2239.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  T2240.values[0] = (T2239.values[0] >> 31) & 1;
  { T2241.values[0] = Top_SodorTile_cpu_d__reg_b.values[0]; }
  { T2242.values[0] = T2239.values[0]; }
  T2243.values[0] = T2242.values[0]<T2241.values[0];
  T2244.values[0] = (T2241.values[0] >> 31) & 1;
  T2245.values[0] = T2240.values[0] == T2244.values[0];
  { val_t __mask = -T2245.values[0]; T2246.values[0] = T2240.values[0] ^ ((T2240.values[0] ^ T2243.values[0]) & __mask); }
  { T2247.values[0] = T2246.values[0] | 0x0L << 1; }
  T2248.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0xeL;
  { val_t __mask = -T2248.values[0]; T2249.values[0] = T2238.values[0] ^ ((T2238.values[0] ^ T2247.values[0]) & __mask); }
  { T2250.values[0] = T2249.values[0] | 0x0L << 14; }
  { T2251.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]^Top_SodorTile_cpu_d__reg_b.values[0]; }
  T2252.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0xdL;
  { val_t __mask = -T2252.values[0]; T2253.values[0] = T2250.values[0] ^ ((T2250.values[0] ^ T2251.values[0]) & __mask); }
  { T2254.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]|Top_SodorTile_cpu_d__reg_b.values[0]; }
  T2255.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0xcL;
  { val_t __mask = -T2255.values[0]; T2256.values[0] = T2253.values[0] ^ ((T2253.values[0] ^ T2254.values[0]) & __mask); }
  { T2257.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]&Top_SodorTile_cpu_d__reg_b.values[0]; }
  T2258.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0xbL;
  { val_t __mask = -T2258.values[0]; T2259.values[0] = T2256.values[0] ^ ((T2256.values[0] ^ T2257.values[0]) & __mask); }
  { T2260.values[0] = Top_SodorTile_cpu_d__reg_b.values[0]; }
  T2260.values[0] = T2260.values[0] & 31;
  { Top_SodorTile_cpu_d__alu_shamt.values[0] = T2260.values[0]; }
  { T2261.values[0] = Top_SodorTile_cpu_d__alu_shamt.values[0]; }
  { T2262.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  T2263.values[0] = (sval_t)(T2262.values[0] << 32) >> (32 + T2261.values[0]);
  T2263.values[0] = T2263.values[0] & 4294967295;
  T2264.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0xaL;
  { val_t __mask = -T2264.values[0]; T2265.values[0] = T2259.values[0] ^ ((T2259.values[0] ^ T2263.values[0]) & __mask); }
  { T2266.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  T2267.values[0] = T2266.values[0] >> Top_SodorTile_cpu_d__alu_shamt.values[0];
  T2268.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x9L;
  { val_t __mask = -T2268.values[0]; T2269.values[0] = T2265.values[0] ^ ((T2265.values[0] ^ T2267.values[0]) & __mask); }
  { T2270.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  T2271.values[0] = T2270.values[0] << Top_SodorTile_cpu_d__alu_shamt.values[0];
  { T2272.values[0] = T2271.values[0]; }
  T2272.values[0] = T2272.values[0] & 4294967295;
  T2273.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x8L;
  { val_t __mask = -T2273.values[0]; T2274.values[0] = T2269.values[0] ^ ((T2269.values[0] ^ T2272.values[0]) & __mask); }
  { T2275.values[0] = Top_SodorTile_cpu_d__reg_b.values[0]; }
  { T2276.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  { T2277.values[0] = T2276.values[0]-T2275.values[0]; }
  T2277.values[0] = T2277.values[0] & 4294967295;
  T2278.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x7L;
  { val_t __mask = -T2278.values[0]; T2279.values[0] = T2274.values[0] ^ ((T2274.values[0] ^ T2277.values[0]) & __mask); }
  { T2280.values[0] = Top_SodorTile_cpu_d__reg_b.values[0]; }
  { T2281.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  { T2282.values[0] = T2281.values[0]+T2280.values[0]; }
  T2282.values[0] = T2282.values[0] & 4294967295;
  T2283.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x6L;
  { val_t __mask = -T2283.values[0]; T2284.values[0] = T2279.values[0] ^ ((T2279.values[0] ^ T2282.values[0]) & __mask); }
  { T2285.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  { T2286.values[0] = T2285.values[0]-0x4L; }
  T2286.values[0] = T2286.values[0] & 4294967295;
  T2287.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x5L;
  { val_t __mask = -T2287.values[0]; T2288.values[0] = T2284.values[0] ^ ((T2284.values[0] ^ T2286.values[0]) & __mask); }
  { T2289.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  { T2290.values[0] = T2289.values[0]+0x4L; }
  T2290.values[0] = T2290.values[0] & 4294967295;
  T2291.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x4L;
  { val_t __mask = -T2291.values[0]; T2292.values[0] = T2288.values[0] ^ ((T2288.values[0] ^ T2290.values[0]) & __mask); }
  { T2293.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  { T2294.values[0] = T2293.values[0]-0x1L; }
  T2294.values[0] = T2294.values[0] & 4294967295;
  T2295.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x3L;
  { val_t __mask = -T2295.values[0]; T2296.values[0] = T2292.values[0] ^ ((T2292.values[0] ^ T2294.values[0]) & __mask); }
  { T2297.values[0] = Top_SodorTile_cpu_d__reg_a.values[0]; }
  { T2298.values[0] = T2297.values[0]+0x1L; }
  T2298.values[0] = T2298.values[0] & 4294967295;
  T2299.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x2L;
  { val_t __mask = -T2299.values[0]; T2300.values[0] = T2296.values[0] ^ ((T2296.values[0] ^ T2298.values[0]) & __mask); }
  T2301.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x1L;
  { val_t __mask = -T2301.values[0]; T2302.values[0] = T2300.values[0] ^ ((T2300.values[0] ^ Top_SodorTile_cpu_d__reg_b.values[0]) & __mask); }
  T2303.values[0] = Top_SodorTile_cpu_d__io_ctl_alu_op.values[0] == 0x0L;
  { val_t __mask = -T2303.values[0]; T2304.values[0] = T2302.values[0] ^ ((T2302.values[0] ^ Top_SodorTile_cpu_d__reg_a.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__alu.values[0] = T2304.values[0]; }
  { T2305.values[0] = Top_SodorTile_cpu_d__alu.values[0]; }
  T2305.values[0] = T2305.values[0] & 4294967295;
  T2306.values[0] = (T1621.values[0] >> 17) & 1;
  { Top_SodorTile_cpu_c__cs_en_alu.values[0] = T2306.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_en_alu.values[0] = Top_SodorTile_cpu_c__cs_en_alu.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_en_alu.values[0] = Top_SodorTile_cpu_c__io_ctl_en_alu.values[0]; }
  { val_t __mask = -Top_SodorTile_cpu_d__io_ctl_en_alu.values[0]; T2307.values[0] = T2229.values[0] ^ ((T2229.values[0] ^ T2305.values[0]) & __mask); }
  { T2308.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 10; }
  T2308.values[0] = T2308.values[0] & 127;
  { T2309.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 27; }
  T2309.values[0] = T2309.values[0] & 31;
  T2310.values[0] = (Top_SodorTile_cpu_d__ir.values[0] >> 31) & 1;
  { T2311.values[0] = T2310.values[0] | T2310.values[0] << 1; }
  { T2312.values[0] = T2310.values[0] | T2311.values[0] << 1; }
  { T2313.values[0] = T2311.values[0] | T2311.values[0] << 2; }
  { T2314.values[0] = T2313.values[0] | T2313.values[0] << 4; }
  { T2315.values[0] = T2314.values[0] | T2314.values[0] << 8; }
  { T2316.values[0] = T2312.values[0] | T2315.values[0] << 3; }
  { T2317.values[0] = T2309.values[0] | T2316.values[0] << 5; }
  { T2318.values[0] = T2308.values[0] | T2317.values[0] << 7; }
  { T2319.values[0] = 0x0L | T2318.values[0] << 1; }
  { T2320.values[0] = T1621.values[0] >> 11; }
  T2320.values[0] = T2320.values[0] & 7;
  { Top_SodorTile_cpu_c__cs_is_sel.values[0] = T2320.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_is_sel.values[0] = Top_SodorTile_cpu_c__cs_is_sel.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_is_sel.values[0] = Top_SodorTile_cpu_c__io_ctl_is_sel.values[0]; }
  T2321.values[0] = Top_SodorTile_cpu_d__io_ctl_is_sel.values[0] == 0x4L;
  { val_t __mask = -T2321.values[0]; T2322.values[0] = 0x0L ^ ((0x0L ^ T2319.values[0]) & __mask); }
  { T2323.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 7; }
  T2323.values[0] = T2323.values[0] & 33554431;
  T2324.values[0] = (Top_SodorTile_cpu_d__ir.values[0] >> 31) & 1;
  { T2325.values[0] = T2324.values[0] | T2324.values[0] << 1; }
  { T2326.values[0] = T2325.values[0] | T2325.values[0] << 2; }
  { T2327.values[0] = T2325.values[0] | T2326.values[0] << 2; }
  { T2328.values[0] = T2323.values[0] | T2327.values[0] << 25; }
  { T2329.values[0] = 0x0L | T2328.values[0] << 1; }
  T2330.values[0] = Top_SodorTile_cpu_d__io_ctl_is_sel.values[0] == 0x3L;
  { val_t __mask = -T2330.values[0]; T2331.values[0] = T2322.values[0] ^ ((T2322.values[0] ^ T2329.values[0]) & __mask); }
  { T2332.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 7; }
  T2332.values[0] = T2332.values[0] & 1048575;
  { T2333.values[0] = 0x0L | T2332.values[0] << 12; }
  T2334.values[0] = Top_SodorTile_cpu_d__io_ctl_is_sel.values[0] == 0x2L;
  { val_t __mask = -T2334.values[0]; T2335.values[0] = T2331.values[0] ^ ((T2331.values[0] ^ T2333.values[0]) & __mask); }
  { T2336.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 10; }
  T2336.values[0] = T2336.values[0] & 127;
  { T2337.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 27; }
  T2337.values[0] = T2337.values[0] & 31;
  T2338.values[0] = (Top_SodorTile_cpu_d__ir.values[0] >> 31) & 1;
  { T2339.values[0] = T2338.values[0] | T2338.values[0] << 1; }
  { T2340.values[0] = T2339.values[0] | T2339.values[0] << 2; }
  { T2341.values[0] = T2340.values[0] | T2340.values[0] << 4; }
  { T2342.values[0] = T2341.values[0] | T2341.values[0] << 8; }
  { T2343.values[0] = T2340.values[0] | T2342.values[0] << 4; }
  { T2344.values[0] = T2337.values[0] | T2343.values[0] << 5; }
  { T2345.values[0] = T2336.values[0] | T2344.values[0] << 7; }
  T2346.values[0] = Top_SodorTile_cpu_d__io_ctl_is_sel.values[0] == 0x1L;
  { val_t __mask = -T2346.values[0]; T2347.values[0] = T2335.values[0] ^ ((T2335.values[0] ^ T2345.values[0]) & __mask); }
  { T2348.values[0] = Top_SodorTile_cpu_d__ir.values[0] >> 10; }
  T2348.values[0] = T2348.values[0] & 4095;
  T2349.values[0] = (Top_SodorTile_cpu_d__ir.values[0] >> 21) & 1;
  { T2350.values[0] = T2349.values[0] | T2349.values[0] << 1; }
  { T2351.values[0] = T2350.values[0] | T2350.values[0] << 2; }
  { T2352.values[0] = T2351.values[0] | T2351.values[0] << 4; }
  { T2353.values[0] = T2352.values[0] | T2352.values[0] << 8; }
  { T2354.values[0] = T2351.values[0] | T2353.values[0] << 4; }
  { T2355.values[0] = T2348.values[0] | T2354.values[0] << 12; }
  T2356.values[0] = Top_SodorTile_cpu_d__io_ctl_is_sel.values[0] == 0x0L;
  { val_t __mask = -T2356.values[0]; T2357.values[0] = T2347.values[0] ^ ((T2347.values[0] ^ T2355.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__imm.values[0] = T2357.values[0]; }
  { T2358.values[0] = Top_SodorTile_cpu_d__imm.values[0]; }
  T2358.values[0] = T2358.values[0] & 4294967295;
  T2359.values[0] = (T1621.values[0] >> 10) & 1;
  { Top_SodorTile_cpu_c__cs_en_imm.values[0] = T2359.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_en_imm.values[0] = Top_SodorTile_cpu_c__cs_en_imm.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_en_imm.values[0] = Top_SodorTile_cpu_c__io_ctl_en_imm.values[0]; }
  { val_t __mask = -Top_SodorTile_cpu_d__io_ctl_en_imm.values[0]; Top_SodorTile_cpu_d__bus.values[0] = T2307.values[0] ^ ((T2307.values[0] ^ T2358.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__io_mem_req_wdata.values[0] = Top_SodorTile_cpu_d__bus.values[0]; }
  { Top_SodorTile_cpu__io_mem_req_wdata.values[0] = Top_SodorTile_cpu_d__io_mem_req_wdata.values[0]; }
  { Top_SodorTile_cache__io_cpu_req_wdata.values[0] = Top_SodorTile_cpu__io_mem_req_wdata.values[0]; }
  { val_t __x[1]; __x[0] = Top_SodorTile_cache__io_cpu_req_wdata.values[0]; val_t __c = 0; val_t __w = T1862.values[0] / 64; val_t __s = T1862.values[0] % 64; val_t __r = 64 - __s; val_t __v0 = MASK(__x[CLAMP(0-__w,0,0)],0>=__w&&0<__w+1); Top_SodorTile_cache__wdata.values[0] = __v0 << __s | __c; __c = MASK(__v0 >> __r, __s != 0); val_t __v1 = MASK(__x[CLAMP(1-__w,0,0)],1>=__w&&1<__w+1); Top_SodorTile_cache__wdata.values[1] = __v1 << __s | __c; __c = MASK(__v1 >> __r, __s != 0); val_t __v2 = MASK(__x[CLAMP(2-__w,0,0)],2>=__w&&2<__w+1); Top_SodorTile_cache__wdata.values[2] = __v2 << __s | __c; __c = MASK(__v2 >> __r, __s != 0); }
  Top_SodorTile_cache__wdata.values[2] = Top_SodorTile_cache__wdata.values[2] & 2147483647;
  { T2360.values[0] = Top_SodorTile_cache__wdata.values[0]; T2360.values[1] = Top_SodorTile_cache__wdata.values[1]; T2360.values[2] = Top_SodorTile_cache__wdata.values[2]; }
  { T2361.values[0] = T2360.values[0]; T2361.values[1] = T2360.values[1]; }
  { T2362.values[0] = Top_SodorTile_cache__io_cpu_req_val.values[0]&&Top_SodorTile_cache__io_cpu_req_rw.values[0]; }
  { T2363.values[0] = T2362.values[0]&&Top_SodorTile_cache__tag_hit.values[0]; }
  T2364.values[0] = Top_SodorTile_cache__state.values[0] == 0x5L;
  T2365.values[0] = Top_SodorTile_cache__state.values[0] == 0x6L;
  { T2366.values[0] = T2365.values[0]||T2364.values[0]; }
  { T2367.values[0] = Top_SodorTile_cache__io_mem_xact_rep_valid.values[0]&&T2366.values[0]; }
  T2368.values[0] = !T2367.values[0];
  { T2369.values[0] = T2368.values[0]&&T2363.values[0]; }
  { T2371.values[0] = T1739.values[0] >> 12 | T1739.values[1] << 52; T2371.values[1] = T1739.values[1] >> 12 | T1739.values[2] << 52; }
  { Top_Queue_18__io_deq_bits_data.values[0] = T2371.values[0]; Top_Queue_18__io_deq_bits_data.values[1] = T2371.values[1]; }
  { Top_SodorTile__io_tilelink_xact_rep_bits_data.values[0] = Top_Queue_18__io_deq_bits_data.values[0]; Top_SodorTile__io_tilelink_xact_rep_bits_data.values[1] = Top_Queue_18__io_deq_bits_data.values[1]; }
  { Top_SodorTile_arbiter__io_mem_xact_rep_bits_data.values[0] = Top_SodorTile__io_tilelink_xact_rep_bits_data.values[0]; Top_SodorTile_arbiter__io_mem_xact_rep_bits_data.values[1] = Top_SodorTile__io_tilelink_xact_rep_bits_data.values[1]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_rep_bits_data.values[0] = Top_SodorTile_arbiter__io_mem_xact_rep_bits_data.values[0]; Top_SodorTile_arbiter__io_requestor_0_xact_rep_bits_data.values[1] = Top_SodorTile_arbiter__io_mem_xact_rep_bits_data.values[1]; }
  { Top_SodorTile_cache__io_mem_xact_rep_bits_data.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_rep_bits_data.values[0]; Top_SodorTile_cache__io_mem_xact_rep_bits_data.values[1] = Top_SodorTile_arbiter__io_requestor_0_xact_rep_bits_data.values[1]; }
  T2373.values[0] = Top_SodorTile_cache__state.values[0] == 0x0L;
  { val_t __mask = -T2373.values[0]; T2374.values[0] = Top_SodorTile_cache__state.values[0] ^ ((Top_SodorTile_cache__state.values[0] ^ 0x1L) & __mask); }
  T2375.values[0] = Top_SodorTile_cache__state.values[0] == 0x1L;
  { T2376.values[0] = T2375.values[0]&&Top_SodorTile_cache__io_cpu_flush.values[0]; }
  { val_t __mask = -T2376.values[0]; T2377.values[0] = T2374.values[0] ^ ((T2374.values[0] ^ 0x7L) & __mask); }
  T2378.values[0] = !Top_SodorTile_cache__tag_hit.values[0];
  { T2379.values[0] = Top_SodorTile_cache__io_cpu_req_val.values[0]&&T2378.values[0]; }
  T2380.values[0] = !Top_SodorTile_cache__io_cpu_flush.values[0];
  { T2381.values[0] = T2380.values[0]&&T2379.values[0]; }
  { T2382.values[0] = T2375.values[0]&&T2381.values[0]; }
  { val_t __mask = -T2382.values[0]; T2383.values[0] = T2377.values[0] ^ ((T2377.values[0] ^ 0x2L) & __mask); }
  T2384.values[0] = !Top_SodorTile_cache__line_is_dirty.values[0];
  { Top_SodorTile__io_tilelink_xact_init_ready.values[0] = Top_Queue_15__io_enq_ready.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_init_ready.values[0] = Top_SodorTile__io_tilelink_xact_init_ready.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_init_ready.values[0] = Top_SodorTile_arbiter__io_mem_xact_init_ready.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_init_ready.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_init_ready.values[0]; }
  { T2385.values[0] = Top_SodorTile_cache__io_mem_xact_init_ready.values[0]&&Top_SodorTile_cache_finish_queue__io_enq_ready.values[0]; }
  { T2386.values[0] = T2385.values[0]&&T2384.values[0]; }
  T2387.values[0] = Top_SodorTile_cache__state.values[0] == 0x2L;
  { T2388.values[0] = T2387.values[0]&&T2386.values[0]; }
  { val_t __mask = -T2388.values[0]; T2389.values[0] = T2383.values[0] ^ ((T2383.values[0] ^ 0x5L) & __mask); }
  { T2390.values[0] = Top_SodorTile_cache__io_mem_xact_init_ready.values[0]&&Top_SodorTile_cache_finish_queue__io_enq_ready.values[0]; }
  { T2391.values[0] = T2390.values[0]&&Top_SodorTile_cache__line_is_dirty.values[0]; }
  { T2392.values[0] = T2387.values[0]&&T2391.values[0]; }
  { val_t __mask = -T2392.values[0]; T2393.values[0] = T2389.values[0] ^ ((T2389.values[0] ^ 0x3L) & __mask); }
  T2394.values[0] = !Top_SodorTile_cache__line_is_dirty.values[0];
  T2395.values[0] = Top_SodorTile_cache__state.values[0] == 0x7L;
  { T2396.values[0] = T2395.values[0]&&T2394.values[0]; }
  { val_t __mask = -T2396.values[0]; T2397.values[0] = T2393.values[0] ^ ((T2393.values[0] ^ 0x8L) & __mask); }
  { T2398.values[0] = Top_SodorTile_cache__io_mem_xact_init_ready.values[0]&&Top_SodorTile_cache_finish_queue__io_enq_ready.values[0]; }
  { T2399.values[0] = T2398.values[0]&&Top_SodorTile_cache__line_is_dirty.values[0]; }
  T2400.values[0] = !T2394.values[0];
  { T2401.values[0] = T2400.values[0]&&T2399.values[0]; }
  { T2402.values[0] = T2395.values[0]&&T2401.values[0]; }
  { val_t __mask = -T2402.values[0]; T2403.values[0] = T2397.values[0] ^ ((T2397.values[0] ^ 0x3L) & __mask); }
  T2404.values[0] = (Top_SodorTile_cache__flush_idx.values[0] == 1023);
  T2405.values[0] = Top_SodorTile_cache__state.values[0] == 0x8L;
  { T2406.values[0] = T2405.values[0]&&T2404.values[0]; }
  { val_t __mask = -T2406.values[0]; T2407.values[0] = T2403.values[0] ^ ((T2403.values[0] ^ 0x1L) & __mask); }
  T2408.values[0] = !T2404.values[0];
  { T2409.values[0] = T2405.values[0]&&T2408.values[0]; }
  { val_t __mask = -T2409.values[0]; T2410.values[0] = T2407.values[0] ^ ((T2407.values[0] ^ 0x7L) & __mask); }
  T2411.values[0] = Top_SodorTile_cache__wb_counter.values[0]>=0x3L;
  T2412.values[0] = Top_SodorTile_cache__state.values[0] == 0x3L;
  { T2413.values[0] = T2412.values[0]&&T2411.values[0]; }
  { val_t __mask = -T2413.values[0]; T2414.values[0] = T2410.values[0] ^ ((T2410.values[0] ^ 0x4L) & __mask); }
  { T2415.values[0] = Top_SodorTile_cache__performing_flush.values[0]&&Top_SodorTile_cache__io_mem_xact_rep_valid.values[0]; }
  T2416.values[0] = Top_SodorTile_cache__state.values[0] == 0x4L;
  { T2417.values[0] = T2416.values[0]&&T2415.values[0]; }
  { val_t __mask = -T2417.values[0]; T2418.values[0] = T2414.values[0] ^ ((T2414.values[0] ^ 0x8L) & __mask); }
  { T2419.values[0] = Top_Queue_17__ram.get(Top_Queue_17__deq_ptr.values[0], 0); }
  { T2420.values[0] = T2419.values[0]; }
  T2420.values[0] = T2420.values[0] & 31;
  { T2421.values[0] = T2420.values[0]; }
  T2421.values[0] = T2421.values[0] & 31;
  { Top_Queue_17__io_deq_bits_tile_xact_id.values[0] = T2421.values[0]; }
  { Top_SodorTile__io_tilelink_xact_abort_bits_tile_xact_id.values[0] = Top_Queue_17__io_deq_bits_tile_xact_id.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_abort_bits_tile_xact_id.values[0] = Top_SodorTile__io_tilelink_xact_abort_bits_tile_xact_id.values[0]; }
  T2422.values[0] = (Top_SodorTile_arbiter__io_mem_xact_abort_bits_tile_xact_id.values[0] >> 0) & 1;
  T2423.values[0] = T2422.values[0] == 0x0L;
  { Top_SodorTile__io_tilelink_xact_abort_valid.values[0] = Top_Queue_17__io_deq_valid.values[0]; }
  { Top_SodorTile_arbiter__io_mem_xact_abort_valid.values[0] = Top_SodorTile__io_tilelink_xact_abort_valid.values[0]; }
  { T2424.values[0] = Top_SodorTile_arbiter__io_mem_xact_abort_valid.values[0]&&T2423.values[0]; }
  { Top_SodorTile_arbiter__io_requestor_0_xact_abort_valid.values[0] = T2424.values[0]; }
  { Top_SodorTile_cache__io_mem_xact_abort_valid.values[0] = Top_SodorTile_arbiter__io_requestor_0_xact_abort_valid.values[0]; }
  { T2425.values[0] = Top_SodorTile_cache__performing_flush.values[0]&&Top_SodorTile_cache__io_mem_xact_abort_valid.values[0]; }
  T2426.values[0] = !T2415.values[0];
  { T2427.values[0] = T2426.values[0]&&T2425.values[0]; }
  { T2428.values[0] = T2416.values[0]&&T2427.values[0]; }
  { val_t __mask = -T2428.values[0]; T2429.values[0] = T2418.values[0] ^ ((T2418.values[0] ^ 0x7L) & __mask); }
  { T2430.values[0] = Top_SodorTile_cache__io_mem_xact_rep_valid.values[0]||Top_SodorTile_cache__io_mem_xact_abort_valid.values[0]; }
  { T2431.values[0] = T2415.values[0]||T2425.values[0]; }
  T2432.values[0] = !T2431.values[0];
  { T2433.values[0] = T2432.values[0]&&T2430.values[0]; }
  { T2434.values[0] = T2416.values[0]&&T2433.values[0]; }
  { val_t __mask = -T2434.values[0]; T2435.values[0] = T2429.values[0] ^ ((T2429.values[0] ^ 0x2L) & __mask); }
  T2436.values[0] = Top_SodorTile_cache__state.values[0] == 0x5L;
  { T2437.values[0] = T2436.values[0]&&Top_SodorTile_cache__io_mem_xact_abort_valid.values[0]; }
  { val_t __mask = -T2437.values[0]; T2438.values[0] = T2435.values[0] ^ ((T2435.values[0] ^ 0x2L) & __mask); }
  { T2439.values[0] = T2436.values[0]&&Top_SodorTile_cache__io_mem_xact_rep_valid.values[0]; }
  { val_t __mask = -T2439.values[0]; T2440.values[0] = T2438.values[0] ^ ((T2438.values[0] ^ 0x6L) & __mask); }
  T2441.values[0] = Top_SodorTile_cache__state.values[0] == 0x6L;
  { T2442.values[0] = T2441.values[0]&&Top_SodorTile_cache__refill_we.values[0]; }
  { val_t __mask = -T2442.values[0]; T2443.values[0] = T2440.values[0] ^ ((T2440.values[0] ^ 0x1L) & __mask); }
  { Top_SodorTile_cache__state_shadow.values[0] = TERNARY(Top_SodorTile_cache__reset.values[0], 0x0L, T2443.values[0]); }
  { T2444.values[0] = Top_SodorTile_cache__refill_counter.values[0]+0x1L; }
  T2444.values[0] = T2444.values[0] & 3;
  T2445.values[0] = Top_SodorTile_cache__state.values[0] == 0x6L;
  T2446.values[0] = Top_SodorTile_cache__state.values[0] == 0x5L;
  { T2447.values[0] = T2446.values[0]||T2445.values[0]; }
  { T2448.values[0] = Top_SodorTile_cache__io_mem_xact_rep_valid.values[0]&&T2447.values[0]; }
  { val_t __mask = -T2448.values[0]; T2449.values[0] = Top_SodorTile_cache__refill_counter.values[0] ^ ((Top_SodorTile_cache__refill_counter.values[0] ^ T2444.values[0]) & __mask); }
  { Top_SodorTile_cache__refill_counter_shadow.values[0] = TERNARY(Top_SodorTile_cache__reset.values[0], 0x0L, T2449.values[0]); }
  { Top_SodorTile__io_host_reset.values[0] = R5081.values[0]; }
  { Top_SodorTile_cpu__reset.values[0] = Top_SodorTile__io_host_reset.values[0]; }
  { Top_SodorTile_cpu_d__reset.values[0] = Top_SodorTile_cpu__reset.values[0]; }
  { Top_SodorTile_cpu_d_pcr__reset.values[0] = Top_SodorTile_cpu_d__reset.values[0]; }
  T2450.values[0] = !Top_SodorTile_cpu_d_pcr__reg_status_et.values[0];
  { T2451.values[0] = Top_SodorTile_cpu_d_pcr__io_exception.values[0]&&T2450.values[0]; }
  { val_t __mask = -T2451.values[0]; T2452.values[0] = Top_SodorTile_cpu_d_pcr__reg_error_mode.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_error_mode.values[0] ^ 0x1L) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_error_mode_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d_pcr__reset.values[0], 0x0L, T2452.values[0]); }
  { T2453.values[0] = T1617.values[0]; }
  { Top_Queue_11__io_deq_bits_data.values[0] = T2453.values[0]; }
  { Top_SodorTile__io_host_pcr_req_bits_data.values[0] = Top_Queue_11__io_deq_bits_data.values[0]; }
  { Top_SodorTile_cpu__io_host_pcr_req_bits_data.values[0] = Top_SodorTile__io_host_pcr_req_bits_data.values[0]; }
  { Top_SodorTile_cpu_d__io_host_pcr_req_bits_data.values[0] = Top_SodorTile_cpu__io_host_pcr_req_bits_data.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_data.values[0] = Top_SodorTile_cpu_d__io_host_pcr_req_bits_data.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_w_data.values[0] = Top_SodorTile_cpu_d__bus.values[0]; }
  { T2454.values[0] = Top_SodorTile_cpu_d_pcr__io_w_data.values[0] | 0x0L << 32; }
  { val_t __mask = -Top_SodorTile_cpu_d_pcr__io_w_en.values[0]; Top_SodorTile_cpu_d_pcr__wdata.values[0] = Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_data.values[0] ^ ((Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_data.values[0] ^ T2454.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__io_w_addr.values[0] = Top_SodorTile_cpu_d__rs1.values[0]; }
  { T2455.values[0] = Top_SodorTile_cpu_d_pcr__io_w_addr.values[0] | 0x0L << 5; }
  { val_t __mask = -Top_SodorTile_cpu_d_pcr__io_w_en.values[0]; Top_SodorTile_cpu_d_pcr__waddr.values[0] = Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_addr.values[0] ^ ((Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_addr.values[0] ^ T2455.values[0]) & __mask); }
  T2456.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0xdL;
  T2457.values[0] = (T1617.values[1] >> 6) & 1;
  { Top_Queue_11__io_deq_bits_rw.values[0] = T2457.values[0]; }
  { Top_SodorTile__io_host_pcr_req_bits_rw.values[0] = Top_Queue_11__io_deq_bits_rw.values[0]; }
  { Top_SodorTile_cpu__io_host_pcr_req_bits_rw.values[0] = Top_SodorTile__io_host_pcr_req_bits_rw.values[0]; }
  { Top_SodorTile_cpu_d__io_host_pcr_req_bits_rw.values[0] = Top_SodorTile_cpu__io_host_pcr_req_bits_rw.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_rw.values[0] = Top_SodorTile_cpu_d__io_host_pcr_req_bits_rw.values[0]; }
  T2458.values[0] = !Top_SodorTile_cpu_d_pcr__io_r_en.values[0];
  { T2459.values[0] = T2458.values[0]&&Top_SodorTile_cpu_d_pcr__io_host_pcr_req_valid.values[0]; }
  { T2460.values[0] = T2459.values[0]&&Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_rw.values[0]; }
  { Top_SodorTile_cpu_d_pcr__wen.values[0] = Top_SodorTile_cpu_d_pcr__io_w_en.values[0]||T2460.values[0]; }
  { T2461.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2456.values[0]; }
  { val_t __mask = -T2461.values[0]; T2462.values[0] = Top_SodorTile_cpu_d_pcr__reg_k1.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_k1.values[0] ^ Top_SodorTile_cpu_d_pcr__wdata.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_k1_shadow.values[0] = T2462.values[0]; }
  T2463.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0xcL;
  { T2464.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2463.values[0]; }
  { val_t __mask = -T2464.values[0]; T2465.values[0] = Top_SodorTile_cpu_d_pcr__reg_k0.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_k0.values[0] ^ Top_SodorTile_cpu_d_pcr__wdata.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_k0_shadow.values[0] = T2465.values[0]; }
  T2466.values[0] = !T2450.values[0];
  { T2467.values[0] = Top_SodorTile_cpu_d_pcr__io_exception.values[0]&&T2466.values[0]; }
  { val_t __mask = -T2467.values[0]; T2468.values[0] = Top_SodorTile_cpu_d_pcr__reg_cause.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_cause.values[0] ^ Top_SodorTile_cpu_d_pcr__io_exc_cause.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_cause_shadow.values[0] = T2468.values[0]; }
  { T2469.values[0] = Top_SodorTile_cpu_d_pcr__wdata.values[0]; }
  T2469.values[0] = T2469.values[0] & 4294967295;
  { T2470.values[0] = T2469.values[0]; }
  T2471.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0x5L;
  { T2472.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2471.values[0]; }
  { val_t __mask = -T2472.values[0]; T2473.values[0] = Top_SodorTile_cpu_d_pcr__reg_compare.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_compare.values[0] ^ T2470.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_compare_shadow.values[0] = T2473.values[0]; }
  { T2474.values[0] = Top_SodorTile_cpu_d_pcr__reg_count.values[0]+0x1L; }
  T2474.values[0] = T2474.values[0] & 4294967295;
  { T2475.values[0] = Top_SodorTile_cpu_d_pcr__wdata.values[0]; }
  T2475.values[0] = T2475.values[0] & 4294967295;
  { T2476.values[0] = T2475.values[0]; }
  T2477.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0x4L;
  { T2478.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2477.values[0]; }
  { val_t __mask = -T2478.values[0]; T2479.values[0] = T2474.values[0] ^ ((T2474.values[0] ^ T2476.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_count_shadow.values[0] = T2479.values[0]; }
  { T2480.values[0] = Top_SodorTile_cpu_d_pcr__wdata.values[0]; }
  T2480.values[0] = T2480.values[0] & 8796093022207;
  { T2481.values[0] = T2480.values[0]; }
  T2482.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0x3L;
  { T2483.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2482.values[0]; }
  { val_t __mask = -T2483.values[0]; T2484.values[0] = Top_SodorTile_cpu_d_pcr__reg_ebase.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_ebase.values[0] ^ T2481.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_ebase_shadow.values[0] = T2484.values[0]; }
  { T2485.values[0] = Top_SodorTile_cpu_d_pcr__io_pc.values[0] | 0x0L << 32; }
  { val_t __mask = -T2467.values[0]; T2486.values[0] = Top_SodorTile_cpu_d_pcr__reg_epc.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_epc.values[0] ^ T2485.values[0]) & __mask); }
  { T2487.values[0] = Top_SodorTile_cpu_d_pcr__wdata.values[0]; }
  T2487.values[0] = T2487.values[0] & 17592186044415;
  { T2488.values[0] = T2487.values[0]; }
  T2489.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0x1L;
  { T2490.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2489.values[0]; }
  { val_t __mask = -T2490.values[0]; T2491.values[0] = T2486.values[0] ^ ((T2486.values[0] ^ T2488.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_epc_shadow.values[0] = T2491.values[0]; }
  T2492.values[0] = (Top_SodorTile_cpu_d_pcr__wdata.values[0] >> 0) & 1;
  { T2493.values[0] = T2492.values[0]; }
  T2494.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0xaL;
  { T2495.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2494.values[0]; }
  { val_t __mask = -T2495.values[0]; T2496.values[0] = Top_SodorTile_cpu_d_pcr__reg_stats.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_stats.values[0] ^ T2493.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_stats_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d_pcr__reset.values[0], 0x0L, T2496.values[0]); }
  T2497.values[0] = Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_addr.values[0] == 0x1eL;
  T2498.values[0] = !Top_SodorTile_cpu_d_pcr__io_host_pcr_req_bits_rw.values[0];
  { T2499.values[0] = Top_SodorTile_cpu_d_pcr__io_host_pcr_req_ready.values[0]&&Top_SodorTile_cpu_d_pcr__io_host_pcr_req_valid.values[0]; }
  { T2500.values[0] = T2499.values[0]&&T2498.values[0]; }
  { T2501.values[0] = T2500.values[0]&&T2497.values[0]; }
  { val_t __mask = -T2501.values[0]; T2502.values[0] = Top_SodorTile_cpu_d_pcr__reg_tohost.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_tohost.values[0] ^ 0x0L) & __mask); }
  { T2503.values[0] = T2502.values[0] | 0x0L << 32; }
  T2504.values[0] = Top_SodorTile_cpu_d_pcr__reg_tohost.values[0] == 0x0L;
  T2505.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0x1eL;
  { T2506.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2505.values[0]; }
  { T2507.values[0] = T2506.values[0]&&T2504.values[0]; }
  { val_t __mask = -T2507.values[0]; T2508.values[0] = T2503.values[0] ^ ((T2503.values[0] ^ Top_SodorTile_cpu_d_pcr__wdata.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_tohost_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d_pcr__reset.values[0], 0x0L, T2508.values[0]); }
  { T2509.values[0] = Top_SodorTile_cpu_d_pcr__reg_fromhost.values[0] | 0x0L << 32; }
  T2510.values[0] = Top_SodorTile_cpu_d_pcr__reg_fromhost.values[0] == 0x0L;
  { T2511.values[0] = T2510.values[0]||Top_SodorTile_cpu_d_pcr__io_w_en.values[0]; }
  T2512.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0x1fL;
  { T2513.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2512.values[0]; }
  { T2514.values[0] = T2513.values[0]&&T2511.values[0]; }
  { val_t __mask = -T2514.values[0]; T2515.values[0] = T2509.values[0] ^ ((T2509.values[0] ^ Top_SodorTile_cpu_d_pcr__wdata.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_fromhost_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d_pcr__reset.values[0], 0x0L, T2515.values[0]); }
  { T2516.values[0] = Top_SodorTile_cpu_d_pcr__reg_status_im.values[0] | 0x0L << 8; }
  { T2517.values[0] = Top_SodorTile_cpu_d_pcr__wdata.values[0] >> 16; }
  T2517.values[0] = T2517.values[0] & 511;
  T2518.values[0] = Top_SodorTile_cpu_d_pcr__waddr.values[0] == 0x0L;
  { T2519.values[0] = Top_SodorTile_cpu_d_pcr__wen.values[0]&&T2518.values[0]; }
  { val_t __mask = -T2519.values[0]; T2520.values[0] = T2516.values[0] ^ ((T2516.values[0] ^ T2517.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_status_im_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d_pcr__reset.values[0], 0x0L, T2520.values[0]); }
  T2521.values[0] = (Top_SodorTile_cpu_d_pcr__wdata.values[0] >> 8) & 1;
  { T2522.values[0] = T2521.values[0]; }
  { val_t __mask = -T2519.values[0]; T2523.values[0] = Top_SodorTile_cpu_d_pcr__reg_status_vm.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_status_vm.values[0] ^ T2522.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_status_vm_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d_pcr__reset.values[0], 0x0L, T2523.values[0]); }
  { val_t __mask = -T2467.values[0]; T2524.values[0] = Top_SodorTile_cpu_d_pcr__reg_status_s.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_status_s.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -Top_SodorTile_cpu_d_pcr__io_eret.values[0]; T2525.values[0] = T2524.values[0] ^ ((T2524.values[0] ^ Top_SodorTile_cpu_d_pcr__reg_status_ps.values[0]) & __mask); }
  T2526.values[0] = (Top_SodorTile_cpu_d_pcr__wdata.values[0] >> 5) & 1;
  { T2527.values[0] = T2526.values[0]; }
  { val_t __mask = -T2519.values[0]; T2528.values[0] = T2525.values[0] ^ ((T2525.values[0] ^ T2527.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_status_s_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d_pcr__reset.values[0], 0x1L, T2528.values[0]); }
  { val_t __mask = -T2467.values[0]; T2529.values[0] = Top_SodorTile_cpu_d_pcr__reg_status_ps.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_status_ps.values[0] ^ Top_SodorTile_cpu_d_pcr__reg_status_s.values[0]) & __mask); }
  T2530.values[0] = (Top_SodorTile_cpu_d_pcr__wdata.values[0] >> 4) & 1;
  { T2531.values[0] = T2530.values[0]; }
  { val_t __mask = -T2519.values[0]; T2532.values[0] = T2529.values[0] ^ ((T2529.values[0] ^ T2531.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_status_ps_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d_pcr__reset.values[0], 0x0L, T2532.values[0]); }
  { val_t __mask = -T2467.values[0]; T2533.values[0] = Top_SodorTile_cpu_d_pcr__reg_status_et.values[0] ^ ((Top_SodorTile_cpu_d_pcr__reg_status_et.values[0] ^ 0x0L) & __mask); }
  { val_t __mask = -Top_SodorTile_cpu_d_pcr__io_eret.values[0]; T2534.values[0] = T2533.values[0] ^ ((T2533.values[0] ^ 0x1L) & __mask); }
  T2535.values[0] = (Top_SodorTile_cpu_d_pcr__wdata.values[0] >> 0) & 1;
  { T2536.values[0] = T2535.values[0]; }
  { val_t __mask = -T2519.values[0]; T2537.values[0] = T2534.values[0] ^ ((T2534.values[0] ^ T2536.values[0]) & __mask); }
  { Top_SodorTile_cpu_d_pcr__reg_status_et_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d_pcr__reset.values[0], 0x0L, T2537.values[0]); }
  T2538.values[0] = Top_SodorTile_cpu_d__reg_addr.values[0] != 0x0L;
  { T2539.values[0] = Top_SodorTile_cpu_d__io_ctl_en_reg.values[0]&Top_SodorTile_cpu_d__io_ctl_reg_wr.values[0]; }
  { T2540.values[0] = T2539.values[0]&T2538.values[0]; }
  { T2541.values[0] = T2540.values[0]&&T2155.values[0]; }
  { val_t __mask = -T2541.values[0]; T2542.values[0] = Top_SodorTile_cpu_d__regfile_0.values[0] ^ ((Top_SodorTile_cpu_d__regfile_0.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_0_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2542.values[0]); }
  { T2543.values[0] = T2540.values[0]&&T2151.values[0]; }
  { val_t __mask = -T2543.values[0]; T2544.values[0] = Top_SodorTile_cpu_d__regfile_1.values[0] ^ ((Top_SodorTile_cpu_d__regfile_1.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_1_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2544.values[0]); }
  { T2545.values[0] = T2540.values[0]&&T2147.values[0]; }
  { val_t __mask = -T2545.values[0]; T2546.values[0] = Top_SodorTile_cpu_d__regfile_2.values[0] ^ ((Top_SodorTile_cpu_d__regfile_2.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_2_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2546.values[0]); }
  { T2547.values[0] = T2540.values[0]&&T2143.values[0]; }
  { val_t __mask = -T2547.values[0]; T2548.values[0] = Top_SodorTile_cpu_d__regfile_3.values[0] ^ ((Top_SodorTile_cpu_d__regfile_3.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_3_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2548.values[0]); }
  { T2549.values[0] = T2540.values[0]&&T2139.values[0]; }
  { val_t __mask = -T2549.values[0]; T2550.values[0] = Top_SodorTile_cpu_d__regfile_4.values[0] ^ ((Top_SodorTile_cpu_d__regfile_4.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_4_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2550.values[0]); }
  { T2551.values[0] = T2540.values[0]&&T2135.values[0]; }
  { val_t __mask = -T2551.values[0]; T2552.values[0] = Top_SodorTile_cpu_d__regfile_5.values[0] ^ ((Top_SodorTile_cpu_d__regfile_5.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_5_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2552.values[0]); }
  { T2553.values[0] = T2540.values[0]&&T2131.values[0]; }
  { val_t __mask = -T2553.values[0]; T2554.values[0] = Top_SodorTile_cpu_d__regfile_6.values[0] ^ ((Top_SodorTile_cpu_d__regfile_6.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_6_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2554.values[0]); }
  { T2555.values[0] = T2540.values[0]&&T2127.values[0]; }
  { val_t __mask = -T2555.values[0]; T2556.values[0] = Top_SodorTile_cpu_d__regfile_7.values[0] ^ ((Top_SodorTile_cpu_d__regfile_7.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_7_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2556.values[0]); }
  { T2557.values[0] = T2540.values[0]&&T2123.values[0]; }
  { val_t __mask = -T2557.values[0]; T2558.values[0] = Top_SodorTile_cpu_d__regfile_8.values[0] ^ ((Top_SodorTile_cpu_d__regfile_8.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_8_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2558.values[0]); }
  { T2559.values[0] = T2540.values[0]&&T2119.values[0]; }
  { val_t __mask = -T2559.values[0]; T2560.values[0] = Top_SodorTile_cpu_d__regfile_9.values[0] ^ ((Top_SodorTile_cpu_d__regfile_9.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_9_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2560.values[0]); }
  { T2561.values[0] = T2540.values[0]&&T2115.values[0]; }
  { val_t __mask = -T2561.values[0]; T2562.values[0] = Top_SodorTile_cpu_d__regfile_10.values[0] ^ ((Top_SodorTile_cpu_d__regfile_10.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_10_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2562.values[0]); }
  { T2563.values[0] = T2540.values[0]&&T2111.values[0]; }
  { val_t __mask = -T2563.values[0]; T2564.values[0] = Top_SodorTile_cpu_d__regfile_11.values[0] ^ ((Top_SodorTile_cpu_d__regfile_11.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_11_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2564.values[0]); }
  { T2565.values[0] = T2540.values[0]&&T2107.values[0]; }
  { val_t __mask = -T2565.values[0]; T2566.values[0] = Top_SodorTile_cpu_d__regfile_12.values[0] ^ ((Top_SodorTile_cpu_d__regfile_12.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_12_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2566.values[0]); }
  { T2567.values[0] = T2540.values[0]&&T2103.values[0]; }
  { val_t __mask = -T2567.values[0]; T2568.values[0] = Top_SodorTile_cpu_d__regfile_13.values[0] ^ ((Top_SodorTile_cpu_d__regfile_13.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_13_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2568.values[0]); }
  { T2569.values[0] = T2540.values[0]&&T2099.values[0]; }
  { val_t __mask = -T2569.values[0]; T2570.values[0] = Top_SodorTile_cpu_d__regfile_14.values[0] ^ ((Top_SodorTile_cpu_d__regfile_14.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_14_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2570.values[0]); }
  { T2571.values[0] = T2540.values[0]&&T2095.values[0]; }
  { val_t __mask = -T2571.values[0]; T2572.values[0] = Top_SodorTile_cpu_d__regfile_15.values[0] ^ ((Top_SodorTile_cpu_d__regfile_15.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_15_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2572.values[0]); }
  { T2573.values[0] = T2540.values[0]&&T2091.values[0]; }
  { val_t __mask = -T2573.values[0]; T2574.values[0] = Top_SodorTile_cpu_d__regfile_16.values[0] ^ ((Top_SodorTile_cpu_d__regfile_16.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_16_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2574.values[0]); }
  { T2575.values[0] = T2540.values[0]&&T2087.values[0]; }
  { val_t __mask = -T2575.values[0]; T2576.values[0] = Top_SodorTile_cpu_d__regfile_17.values[0] ^ ((Top_SodorTile_cpu_d__regfile_17.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_17_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2576.values[0]); }
  { T2577.values[0] = T2540.values[0]&&T2083.values[0]; }
  { val_t __mask = -T2577.values[0]; T2578.values[0] = Top_SodorTile_cpu_d__regfile_18.values[0] ^ ((Top_SodorTile_cpu_d__regfile_18.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_18_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2578.values[0]); }
  { T2579.values[0] = T2540.values[0]&&T2079.values[0]; }
  { val_t __mask = -T2579.values[0]; T2580.values[0] = Top_SodorTile_cpu_d__regfile_19.values[0] ^ ((Top_SodorTile_cpu_d__regfile_19.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_19_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2580.values[0]); }
  { T2581.values[0] = T2540.values[0]&&T2075.values[0]; }
  { val_t __mask = -T2581.values[0]; T2582.values[0] = Top_SodorTile_cpu_d__regfile_20.values[0] ^ ((Top_SodorTile_cpu_d__regfile_20.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_20_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2582.values[0]); }
  { T2583.values[0] = T2540.values[0]&&T2071.values[0]; }
  { val_t __mask = -T2583.values[0]; T2584.values[0] = Top_SodorTile_cpu_d__regfile_21.values[0] ^ ((Top_SodorTile_cpu_d__regfile_21.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_21_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2584.values[0]); }
  { T2585.values[0] = T2540.values[0]&&T2067.values[0]; }
  { val_t __mask = -T2585.values[0]; T2586.values[0] = Top_SodorTile_cpu_d__regfile_22.values[0] ^ ((Top_SodorTile_cpu_d__regfile_22.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_22_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2586.values[0]); }
  { T2587.values[0] = T2540.values[0]&&T2063.values[0]; }
  { val_t __mask = -T2587.values[0]; T2588.values[0] = Top_SodorTile_cpu_d__regfile_23.values[0] ^ ((Top_SodorTile_cpu_d__regfile_23.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_23_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2588.values[0]); }
  { T2589.values[0] = T2540.values[0]&&T2059.values[0]; }
  { val_t __mask = -T2589.values[0]; T2590.values[0] = Top_SodorTile_cpu_d__regfile_24.values[0] ^ ((Top_SodorTile_cpu_d__regfile_24.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_24_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2590.values[0]); }
  { T2591.values[0] = T2540.values[0]&&T2055.values[0]; }
  { val_t __mask = -T2591.values[0]; T2592.values[0] = Top_SodorTile_cpu_d__regfile_25.values[0] ^ ((Top_SodorTile_cpu_d__regfile_25.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_25_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2592.values[0]); }
  { T2593.values[0] = T2540.values[0]&&T2051.values[0]; }
  { val_t __mask = -T2593.values[0]; T2594.values[0] = Top_SodorTile_cpu_d__regfile_26.values[0] ^ ((Top_SodorTile_cpu_d__regfile_26.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_26_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2594.values[0]); }
  { T2595.values[0] = T2540.values[0]&&T2047.values[0]; }
  { val_t __mask = -T2595.values[0]; T2596.values[0] = Top_SodorTile_cpu_d__regfile_27.values[0] ^ ((Top_SodorTile_cpu_d__regfile_27.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_27_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2596.values[0]); }
  { T2597.values[0] = T2540.values[0]&&T2043.values[0]; }
  { val_t __mask = -T2597.values[0]; T2598.values[0] = Top_SodorTile_cpu_d__regfile_28.values[0] ^ ((Top_SodorTile_cpu_d__regfile_28.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_28_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2598.values[0]); }
  { T2599.values[0] = T2540.values[0]&&T2039.values[0]; }
  { val_t __mask = -T2599.values[0]; T2600.values[0] = Top_SodorTile_cpu_d__regfile_29.values[0] ^ ((Top_SodorTile_cpu_d__regfile_29.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_29_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2600.values[0]); }
  { T2601.values[0] = T2540.values[0]&&T2035.values[0]; }
  { val_t __mask = -T2601.values[0]; T2602.values[0] = Top_SodorTile_cpu_d__regfile_30.values[0] ^ ((Top_SodorTile_cpu_d__regfile_30.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_30_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2602.values[0]); }
  { T2603.values[0] = T2540.values[0]&&T2031.values[0]; }
  { val_t __mask = -T2603.values[0]; T2604.values[0] = Top_SodorTile_cpu_d__regfile_31.values[0] ^ ((Top_SodorTile_cpu_d__regfile_31.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_31_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2604.values[0]); }
  { T2605.values[0] = T2540.values[0]&&T2027.values[0]; }
  { val_t __mask = -T2605.values[0]; T2606.values[0] = Top_SodorTile_cpu_d__regfile_32.values[0] ^ ((Top_SodorTile_cpu_d__regfile_32.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_32_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2606.values[0]); }
  { T2607.values[0] = T2540.values[0]&&T2023.values[0]; }
  { val_t __mask = -T2607.values[0]; T2608.values[0] = Top_SodorTile_cpu_d__regfile_33.values[0] ^ ((Top_SodorTile_cpu_d__regfile_33.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_33_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2608.values[0]); }
  { T2609.values[0] = T2540.values[0]&&T2019.values[0]; }
  { val_t __mask = -T2609.values[0]; T2610.values[0] = Top_SodorTile_cpu_d__regfile_34.values[0] ^ ((Top_SodorTile_cpu_d__regfile_34.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_34_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2610.values[0]); }
  { T2611.values[0] = T2540.values[0]&&T2015.values[0]; }
  { val_t __mask = -T2611.values[0]; T2612.values[0] = Top_SodorTile_cpu_d__regfile_35.values[0] ^ ((Top_SodorTile_cpu_d__regfile_35.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_35_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2612.values[0]); }
  { T2613.values[0] = T2540.values[0]&&T2011.values[0]; }
  { val_t __mask = -T2613.values[0]; T2614.values[0] = Top_SodorTile_cpu_d__regfile_36.values[0] ^ ((Top_SodorTile_cpu_d__regfile_36.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_36_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2614.values[0]); }
  { T2615.values[0] = T2540.values[0]&&T2007.values[0]; }
  { val_t __mask = -T2615.values[0]; T2616.values[0] = Top_SodorTile_cpu_d__regfile_37.values[0] ^ ((Top_SodorTile_cpu_d__regfile_37.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_37_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2616.values[0]); }
  { T2617.values[0] = T2540.values[0]&&T2003.values[0]; }
  { val_t __mask = -T2617.values[0]; T2618.values[0] = Top_SodorTile_cpu_d__regfile_38.values[0] ^ ((Top_SodorTile_cpu_d__regfile_38.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_38_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2618.values[0]); }
  { T2619.values[0] = T2540.values[0]&&T1999.values[0]; }
  { val_t __mask = -T2619.values[0]; T2620.values[0] = Top_SodorTile_cpu_d__regfile_39.values[0] ^ ((Top_SodorTile_cpu_d__regfile_39.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_39_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2620.values[0]); }
  { T2621.values[0] = T2540.values[0]&&T1995.values[0]; }
  { val_t __mask = -T2621.values[0]; T2622.values[0] = Top_SodorTile_cpu_d__regfile_40.values[0] ^ ((Top_SodorTile_cpu_d__regfile_40.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_40_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2622.values[0]); }
  { T2623.values[0] = T2540.values[0]&&T1991.values[0]; }
  { val_t __mask = -T2623.values[0]; T2624.values[0] = Top_SodorTile_cpu_d__regfile_41.values[0] ^ ((Top_SodorTile_cpu_d__regfile_41.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_41_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2624.values[0]); }
  { T2625.values[0] = T2540.values[0]&&T1987.values[0]; }
  { val_t __mask = -T2625.values[0]; T2626.values[0] = Top_SodorTile_cpu_d__regfile_42.values[0] ^ ((Top_SodorTile_cpu_d__regfile_42.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_42_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2626.values[0]); }
  { T2627.values[0] = T2540.values[0]&&T1983.values[0]; }
  { val_t __mask = -T2627.values[0]; T2628.values[0] = Top_SodorTile_cpu_d__regfile_43.values[0] ^ ((Top_SodorTile_cpu_d__regfile_43.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_43_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2628.values[0]); }
  { T2629.values[0] = T2540.values[0]&&T1979.values[0]; }
  { val_t __mask = -T2629.values[0]; T2630.values[0] = Top_SodorTile_cpu_d__regfile_44.values[0] ^ ((Top_SodorTile_cpu_d__regfile_44.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_44_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2630.values[0]); }
  { T2631.values[0] = T2540.values[0]&&T1975.values[0]; }
  { val_t __mask = -T2631.values[0]; T2632.values[0] = Top_SodorTile_cpu_d__regfile_45.values[0] ^ ((Top_SodorTile_cpu_d__regfile_45.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_45_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2632.values[0]); }
  { T2633.values[0] = T2540.values[0]&&T1971.values[0]; }
  { val_t __mask = -T2633.values[0]; T2634.values[0] = Top_SodorTile_cpu_d__regfile_46.values[0] ^ ((Top_SodorTile_cpu_d__regfile_46.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_46_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2634.values[0]); }
  { T2635.values[0] = T2540.values[0]&&T1967.values[0]; }
  { val_t __mask = -T2635.values[0]; T2636.values[0] = Top_SodorTile_cpu_d__regfile_47.values[0] ^ ((Top_SodorTile_cpu_d__regfile_47.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_47_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2636.values[0]); }
  { T2637.values[0] = T2540.values[0]&&T1963.values[0]; }
  { val_t __mask = -T2637.values[0]; T2638.values[0] = Top_SodorTile_cpu_d__regfile_48.values[0] ^ ((Top_SodorTile_cpu_d__regfile_48.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_48_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2638.values[0]); }
  { T2639.values[0] = T2540.values[0]&&T1959.values[0]; }
  { val_t __mask = -T2639.values[0]; T2640.values[0] = Top_SodorTile_cpu_d__regfile_49.values[0] ^ ((Top_SodorTile_cpu_d__regfile_49.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_49_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2640.values[0]); }
  { T2641.values[0] = T2540.values[0]&&T1955.values[0]; }
  { val_t __mask = -T2641.values[0]; T2642.values[0] = Top_SodorTile_cpu_d__regfile_50.values[0] ^ ((Top_SodorTile_cpu_d__regfile_50.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_50_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2642.values[0]); }
  { T2643.values[0] = T2540.values[0]&&T1951.values[0]; }
  { val_t __mask = -T2643.values[0]; T2644.values[0] = Top_SodorTile_cpu_d__regfile_51.values[0] ^ ((Top_SodorTile_cpu_d__regfile_51.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_51_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2644.values[0]); }
  { T2645.values[0] = T2540.values[0]&&T1947.values[0]; }
  { val_t __mask = -T2645.values[0]; T2646.values[0] = Top_SodorTile_cpu_d__regfile_52.values[0] ^ ((Top_SodorTile_cpu_d__regfile_52.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_52_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2646.values[0]); }
  { T2647.values[0] = T2540.values[0]&&T1943.values[0]; }
  { val_t __mask = -T2647.values[0]; T2648.values[0] = Top_SodorTile_cpu_d__regfile_53.values[0] ^ ((Top_SodorTile_cpu_d__regfile_53.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_53_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2648.values[0]); }
  { T2649.values[0] = T2540.values[0]&&T1939.values[0]; }
  { val_t __mask = -T2649.values[0]; T2650.values[0] = Top_SodorTile_cpu_d__regfile_54.values[0] ^ ((Top_SodorTile_cpu_d__regfile_54.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_54_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2650.values[0]); }
  { T2651.values[0] = T2540.values[0]&&T1935.values[0]; }
  { val_t __mask = -T2651.values[0]; T2652.values[0] = Top_SodorTile_cpu_d__regfile_55.values[0] ^ ((Top_SodorTile_cpu_d__regfile_55.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_55_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2652.values[0]); }
  { T2653.values[0] = T2540.values[0]&&T1931.values[0]; }
  { val_t __mask = -T2653.values[0]; T2654.values[0] = Top_SodorTile_cpu_d__regfile_56.values[0] ^ ((Top_SodorTile_cpu_d__regfile_56.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_56_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2654.values[0]); }
  { T2655.values[0] = T2540.values[0]&&T1927.values[0]; }
  { val_t __mask = -T2655.values[0]; T2656.values[0] = Top_SodorTile_cpu_d__regfile_57.values[0] ^ ((Top_SodorTile_cpu_d__regfile_57.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_57_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2656.values[0]); }
  { T2657.values[0] = T2540.values[0]&&T1923.values[0]; }
  { val_t __mask = -T2657.values[0]; T2658.values[0] = Top_SodorTile_cpu_d__regfile_58.values[0] ^ ((Top_SodorTile_cpu_d__regfile_58.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_58_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2658.values[0]); }
  { T2659.values[0] = T2540.values[0]&&T1919.values[0]; }
  { val_t __mask = -T2659.values[0]; T2660.values[0] = Top_SodorTile_cpu_d__regfile_59.values[0] ^ ((Top_SodorTile_cpu_d__regfile_59.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_59_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2660.values[0]); }
  { T2661.values[0] = T2540.values[0]&&T1915.values[0]; }
  { val_t __mask = -T2661.values[0]; T2662.values[0] = Top_SodorTile_cpu_d__regfile_60.values[0] ^ ((Top_SodorTile_cpu_d__regfile_60.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_60_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2662.values[0]); }
  { T2663.values[0] = T2540.values[0]&&T1911.values[0]; }
  { val_t __mask = -T2663.values[0]; T2664.values[0] = Top_SodorTile_cpu_d__regfile_61.values[0] ^ ((Top_SodorTile_cpu_d__regfile_61.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_61_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2664.values[0]); }
  { T2665.values[0] = T2540.values[0]&&T1907.values[0]; }
  { val_t __mask = -T2665.values[0]; T2666.values[0] = Top_SodorTile_cpu_d__regfile_62.values[0] ^ ((Top_SodorTile_cpu_d__regfile_62.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_62_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2666.values[0]); }
  { T2667.values[0] = T2540.values[0]&&T1903.values[0]; }
  { val_t __mask = -T2667.values[0]; T2668.values[0] = Top_SodorTile_cpu_d__regfile_63.values[0] ^ ((Top_SodorTile_cpu_d__regfile_63.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_63_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2668.values[0]); }
  { T2669.values[0] = T2540.values[0]&&T1899.values[0]; }
  { val_t __mask = -T2669.values[0]; T2670.values[0] = Top_SodorTile_cpu_d__regfile_64.values[0] ^ ((Top_SodorTile_cpu_d__regfile_64.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__regfile_64_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2670.values[0]); }
  T2671.values[0] = (T1621.values[0] >> 30) & 1;
  { Top_SodorTile_cpu_c__cs_ld_ir.values[0] = T2671.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_ld_ir.values[0] = Top_SodorTile_cpu_c__cs_ld_ir.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_ld_ir.values[0] = Top_SodorTile_cpu_c__io_ctl_ld_ir.values[0]; }
  { val_t __mask = -Top_SodorTile_cpu_d__io_ctl_ld_ir.values[0]; T2672.values[0] = Top_SodorTile_cpu_d__ir.values[0] ^ ((Top_SodorTile_cpu_d__ir.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__ir_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x0L, T2672.values[0]); }
  T2673.values[0] = (T1621.values[0] >> 24) & 1;
  { Top_SodorTile_cpu_c__cs_ld_a.values[0] = T2673.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_ld_a.values[0] = Top_SodorTile_cpu_c__cs_ld_a.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_ld_a.values[0] = Top_SodorTile_cpu_c__io_ctl_ld_a.values[0]; }
  { val_t __mask = -Top_SodorTile_cpu_d__io_ctl_ld_a.values[0]; T2674.values[0] = Top_SodorTile_cpu_d__reg_a.values[0] ^ ((Top_SodorTile_cpu_d__reg_a.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__reg_a_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0x96L, T2674.values[0]); }
  T2675.values[0] = (T1621.values[0] >> 23) & 1;
  { Top_SodorTile_cpu_c__cs_ld_b.values[0] = T2675.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_ld_b.values[0] = Top_SodorTile_cpu_c__cs_ld_b.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_ld_b.values[0] = Top_SodorTile_cpu_c__io_ctl_ld_b.values[0]; }
  { val_t __mask = -Top_SodorTile_cpu_d__io_ctl_ld_b.values[0]; T2676.values[0] = Top_SodorTile_cpu_d__reg_b.values[0] ^ ((Top_SodorTile_cpu_d__reg_b.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__reg_b_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0xa5L, T2676.values[0]); }
  T2677.values[0] = (T1621.values[0] >> 16) & 1;
  { Top_SodorTile_cpu_c__cs_ld_ma.values[0] = T2677.values[0]; }
  { Top_SodorTile_cpu_c__io_ctl_ld_ma.values[0] = Top_SodorTile_cpu_c__cs_ld_ma.values[0]; }
  { Top_SodorTile_cpu_d__io_ctl_ld_ma.values[0] = Top_SodorTile_cpu_c__io_ctl_ld_ma.values[0]; }
  { val_t __mask = -Top_SodorTile_cpu_d__io_ctl_ld_ma.values[0]; T2678.values[0] = Top_SodorTile_cpu_d__reg_ma.values[0] ^ ((Top_SodorTile_cpu_d__reg_ma.values[0] ^ Top_SodorTile_cpu_d__bus.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__reg_ma_shadow.values[0] = TERNARY(Top_SodorTile_cpu_d__reset.values[0], 0xd2L, T2678.values[0]); }
  { Top_SodorTile_cpu_c__reset.values[0] = Top_SodorTile_cpu__reset.values[0]; }
  T2679.values[0] = Top_SodorTile_cache__state.values[0] == 0x1L;
  { T2680.values[0] = T2679.values[0]&&Top_SodorTile_cache__io_cpu_req_val.values[0]; }
  { T2681.values[0] = T2680.values[0]&&Top_SodorTile_cache__tag_hit.values[0]; }
  { Top_SodorTile_cache__io_cpu_resp_val.values[0] = T2681.values[0]; }
  { Top_SodorTile_cpu__io_mem_resp_val.values[0] = Top_SodorTile_cache__io_cpu_resp_val.values[0]; }
  { Top_SodorTile_cpu_c__io_mem_resp_val.values[0] = Top_SodorTile_cpu__io_mem_resp_val.values[0]; }
  Top_SodorTile_cpu_c__mem_is_busy.values[0] = !Top_SodorTile_cpu_c__io_mem_resp_val.values[0];
  { val_t __mask = -Top_SodorTile_cpu_c__mem_is_busy.values[0]; T2682.values[0] = 0x0L ^ ((0x0L ^ 0x2L) & __mask); }
  { T2683.values[0] = T1621.values[0] >> 7; }
  T2683.values[0] = T2683.values[0] & 7;
  { Top_SodorTile_cpu_c__cs_ubr.values[0] = T2683.values[0]; }
  T2684.values[0] = Top_SodorTile_cpu_c__cs_ubr.values[0] == 0x5L;
  { val_t __mask = -T2684.values[0]; T2685.values[0] = 0x2L ^ ((0x2L ^ T2682.values[0]) & __mask); }
  T2686.values[0] = Top_SodorTile_cpu_d__alu.values[0] == 0x0L;
  { Top_SodorTile_cpu_d__io_dat_alu_zero.values[0] = T2686.values[0]; }
  { Top_SodorTile_cpu_c__io_dat_alu_zero.values[0] = Top_SodorTile_cpu_d__io_dat_alu_zero.values[0]; }
  { T2687.values[0] = ~Top_SodorTile_cpu_c__io_dat_alu_zero.values[0]; }
  T2687.values[0] = T2687.values[0] & 1;
  T2688.values[0] = (T2687.values[0] >> 0) & 1;
  { T2689.values[0] = T2688.values[0] | 0x0L << 1; }
  T2690.values[0] = Top_SodorTile_cpu_c__cs_ubr.values[0] == 0x4L;
  { val_t __mask = -T2690.values[0]; T2691.values[0] = T2685.values[0] ^ ((T2685.values[0] ^ T2689.values[0]) & __mask); }
  T2692.values[0] = (Top_SodorTile_cpu_c__io_dat_alu_zero.values[0] >> 0) & 1;
  { T2693.values[0] = T2692.values[0] | 0x0L << 1; }
  T2694.values[0] = Top_SodorTile_cpu_c__cs_ubr.values[0] == 0x3L;
  { val_t __mask = -T2694.values[0]; T2695.values[0] = T2691.values[0] ^ ((T2691.values[0] ^ T2693.values[0]) & __mask); }
  T2696.values[0] = Top_SodorTile_cpu_c__cs_ubr.values[0] == 0x2L;
  { val_t __mask = -T2696.values[0]; T2697.values[0] = T2695.values[0] ^ ((T2695.values[0] ^ 0x1L) & __mask); }
  T2698.values[0] = Top_SodorTile_cpu_c__cs_ubr.values[0] == 0x1L;
  { val_t __mask = -T2698.values[0]; T2699.values[0] = T2697.values[0] ^ ((T2697.values[0] ^ 0x3L) & __mask); }
  T2700.values[0] = Top_SodorTile_cpu_c__cs_ubr.values[0] == 0x0L;
  { val_t __mask = -T2700.values[0]; Top_SodorTile_cpu_c__upc_sel.values[0] = T2699.values[0] ^ ((T2699.values[0] ^ 0x0L) & __mask); }
  T2701.values[0] = Top_SodorTile_cpu_c__upc_sel.values[0] == 0x2L;
  { val_t __mask = -T2701.values[0]; T2702.values[0] = Top_SodorTile_cpu_c__upc_state.values[0] ^ ((Top_SodorTile_cpu_c__upc_state.values[0] ^ Top_SodorTile_cpu_c__upc_state.values[0]) & __mask); }
  { T2703.values[0] = Top_SodorTile_cpu_c__upc_state.values[0]+0x1L; }
  T2703.values[0] = T2703.values[0] & 127;
  T2704.values[0] = Top_SodorTile_cpu_c__upc_sel.values[0] == 0x0L;
  { val_t __mask = -T2704.values[0]; T2705.values[0] = T2702.values[0] ^ ((T2702.values[0] ^ T2703.values[0]) & __mask); }
  { T2706.values[0] = T1621.values[0]; }
  T2706.values[0] = T2706.values[0] & 127;
  { Top_SodorTile_cpu_c__cs_upc_rom_target.values[0] = T2706.values[0]; }
  T2707.values[0] = Top_SodorTile_cpu_c__upc_sel.values[0] == 0x1L;
  { val_t __mask = -T2707.values[0]; T2708.values[0] = T2705.values[0] ^ ((T2705.values[0] ^ Top_SodorTile_cpu_c__cs_upc_rom_target.values[0]) & __mask); }
  { Top_SodorTile_cpu_d__io_dat_inst.values[0] = Top_SodorTile_cpu_d__ir.values[0]; }
  { Top_SodorTile_cpu_c__io_dat_inst.values[0] = Top_SodorTile_cpu_d__io_dat_inst.values[0]; }
  { T2709.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2710.values[0] = T2709.values[0] == 0x133L;
  { val_t __mask = -T2710.values[0]; T2711.values[0] = 0x4L ^ ((0x4L ^ 0x33L) & __mask); }
  { T2712.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2713.values[0] = T2712.values[0] == 0x6bL;
  { val_t __mask = -T2713.values[0]; T2714.values[0] = T2711.values[0] ^ ((T2711.values[0] ^ 0x54L) & __mask); }
  { T2715.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2716.values[0] = T2715.values[0] == 0x213L;
  { val_t __mask = -T2716.values[0]; T2717.values[0] = T2714.values[0] ^ ((T2714.values[0] ^ 0x2aL) & __mask); }
  { T2718.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3f03ffL; }
  T2719.values[0] = T2718.values[0] == 0x10293L;
  { val_t __mask = -T2719.values[0]; T2720.values[0] = T2717.values[0] ^ ((T2717.values[0] ^ 0x21L) & __mask); }
  { T2721.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3fffffL; }
  T2722.values[0] = T2721.values[0] == 0x17bL;
  { val_t __mask = -T2722.values[0]; T2723.values[0] = T2720.values[0] ^ ((T2720.values[0] ^ 0x7eL) & __mask); }
  { T2724.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2725.values[0] = T2724.values[0] == 0x103L;
  { val_t __mask = -T2725.values[0]; T2726.values[0] = T2723.values[0] ^ ((T2723.values[0] ^ 0x7L) & __mask); }
  { T2727.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2728.values[0] = T2727.values[0] == 0x1b3L;
  { val_t __mask = -T2728.values[0]; T2729.values[0] = T2726.values[0] ^ ((T2726.values[0] ^ 0x36L) & __mask); }
  { T2730.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2731.values[0] = T2730.values[0] == 0xb3L;
  { val_t __mask = -T2731.values[0]; T2732.values[0] = T2729.values[0] ^ ((T2729.values[0] ^ 0x39L) & __mask); }
  { T2733.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2734.values[0] = T2733.values[0] == 0x1fbL;
  { val_t __mask = -T2734.values[0]; T2735.values[0] = T2732.values[0] ^ ((T2732.values[0] ^ 0x7bL) & __mask); }
  { T2736.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2737.values[0] = T2736.values[0] == 0x113L;
  { val_t __mask = -T2737.values[0]; T2738.values[0] = T2735.values[0] ^ ((T2735.values[0] ^ 0x15L) & __mask); }
  { T2739.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2740.values[0] = T2739.values[0] == 0x63L;
  { val_t __mask = -T2740.values[0]; T2741.values[0] = T2738.values[0] ^ ((T2738.values[0] ^ 0x5bL) & __mask); }
  { T2742.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2743.values[0] = T2742.values[0] == 0x102b3L;
  { val_t __mask = -T2743.values[0]; T2744.values[0] = T2741.values[0] ^ ((T2741.values[0] ^ 0x3fL) & __mask); }
  { T2745.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2746.values[0] = T2745.values[0] == 0x3b3L;
  { val_t __mask = -T2746.values[0]; T2747.values[0] = T2744.values[0] ^ ((T2744.values[0] ^ 0x42L) & __mask); }
  T2748.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0] == 0x13L;
  { val_t __mask = -T2748.values[0]; T2749.values[0] = T2747.values[0] ^ ((T2747.values[0] ^ 0x3L) & __mask); }
  { T2750.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2751.values[0] = T2750.values[0] == 0x193L;
  { val_t __mask = -T2751.values[0]; T2752.values[0] = T2749.values[0] ^ ((T2749.values[0] ^ 0x18L) & __mask); }
  { T2753.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x7fL; }
  T2754.values[0] = T2753.values[0] == 0x37L;
  { val_t __mask = -T2754.values[0]; T2755.values[0] = T2752.values[0] ^ ((T2752.values[0] ^ 0x11L) & __mask); }
  { T2756.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2757.values[0] = T2756.values[0] == 0x3e3L;
  { val_t __mask = -T2757.values[0]; T2758.values[0] = T2755.values[0] ^ ((T2755.values[0] ^ 0x72L) & __mask); }
  { T2759.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2760.values[0] = T2759.values[0] == 0x13L;
  { val_t __mask = -T2760.values[0]; T2761.values[0] = T2758.values[0] ^ ((T2758.values[0] ^ 0x12L) & __mask); }
  { T2762.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2763.values[0] = T2762.values[0] == 0x16bL;
  { val_t __mask = -T2763.values[0]; T2764.values[0] = T2761.values[0] ^ ((T2761.values[0] ^ 0x54L) & __mask); }
  { T2765.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2766.values[0] = T2765.values[0] == 0x313L;
  { val_t __mask = -T2766.values[0]; T2767.values[0] = T2764.values[0] ^ ((T2764.values[0] ^ 0x27L) & __mask); }
  { T2768.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2769.values[0] = T2768.values[0] == 0x2e3L;
  { val_t __mask = -T2769.values[0]; T2770.values[0] = T2767.values[0] ^ ((T2767.values[0] ^ 0x6dL) & __mask); }
  { T2771.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2772.values[0] = T2771.values[0] == 0x363L;
  { val_t __mask = -T2772.values[0]; T2773.values[0] = T2770.values[0] ^ ((T2770.values[0] ^ 0x68L) & __mask); }
  { T2774.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x7ffffffL; }
  T2775.values[0] = T2774.values[0] == 0x26bL;
  { val_t __mask = -T2775.values[0]; T2776.values[0] = T2773.values[0] ^ ((T2773.values[0] ^ 0x59L) & __mask); }
  { T2777.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2778.values[0] = T2777.values[0] == 0x393L;
  { val_t __mask = -T2778.values[0]; T2779.values[0] = T2776.values[0] ^ ((T2776.values[0] ^ 0x24L) & __mask); }
  { T2780.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2781.values[0] = T2780.values[0] == 0x123L;
  { val_t __mask = -T2781.values[0]; T2782.values[0] = T2779.values[0] ^ ((T2779.values[0] ^ 0xcL) & __mask); }
  { T2783.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2784.values[0] = T2783.values[0] == 0xebL;
  { val_t __mask = -T2784.values[0]; T2785.values[0] = T2782.values[0] ^ ((T2782.values[0] ^ 0x54L) & __mask); }
  { T2786.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x7fL; }
  T2787.values[0] = T2786.values[0] == 0x67L;
  { val_t __mask = -T2787.values[0]; T2788.values[0] = T2785.values[0] ^ ((T2785.values[0] ^ 0x4bL) & __mask); }
  { T2789.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2790.values[0] = T2789.values[0] == 0x2b3L;
  { val_t __mask = -T2790.values[0]; T2791.values[0] = T2788.values[0] ^ ((T2788.values[0] ^ 0x3cL) & __mask); }
  { T2792.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2793.values[0] = T2792.values[0] == 0x333L;
  { val_t __mask = -T2793.values[0]; T2794.values[0] = T2791.values[0] ^ ((T2791.values[0] ^ 0x45L) & __mask); }
  { T2795.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2796.values[0] = T2795.values[0] == 0x10033L;
  { val_t __mask = -T2796.values[0]; T2797.values[0] = T2794.values[0] ^ ((T2794.values[0] ^ 0x30L) & __mask); }
  { T2798.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3f03ffL; }
  T2799.values[0] = T2798.values[0] == 0x293L;
  { val_t __mask = -T2799.values[0]; T2800.values[0] = T2797.values[0] ^ ((T2797.values[0] ^ 0x1eL) & __mask); }
  { T2801.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3f03ffL; }
  T2802.values[0] = T2801.values[0] == 0x93L;
  { val_t __mask = -T2802.values[0]; T2803.values[0] = T2800.values[0] ^ ((T2800.values[0] ^ 0x1bL) & __mask); }
  { T2804.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x7fL; }
  T2805.values[0] = T2804.values[0] == 0x6fL;
  { val_t __mask = -T2805.values[0]; T2806.values[0] = T2803.values[0] ^ ((T2803.values[0] ^ 0x4fL) & __mask); }
  { T2807.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2808.values[0] = T2807.values[0] == 0x33L;
  { val_t __mask = -T2808.values[0]; T2809.values[0] = T2806.values[0] ^ ((T2806.values[0] ^ 0x2dL) & __mask); }
  { T2810.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x1ffffL; }
  T2811.values[0] = T2810.values[0] == 0x233L;
  { val_t __mask = -T2811.values[0]; T2812.values[0] = T2809.values[0] ^ ((T2809.values[0] ^ 0x48L) & __mask); }
  { T2813.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2814.values[0] = T2813.values[0] == 0x263L;
  { val_t __mask = -T2814.values[0]; T2815.values[0] = T2812.values[0] ^ ((T2812.values[0] ^ 0x63L) & __mask); }
  { T2816.values[0] = Top_SodorTile_cpu_c__io_dat_inst.values[0]&0x3ffL; }
  T2817.values[0] = T2816.values[0] == 0xe3L;
  { val_t __mask = -T2817.values[0]; Top_SodorTile_cpu_c__upc_opgroup_target.values[0] = T2815.values[0] ^ ((T2815.values[0] ^ 0x5fL) & __mask); }
  T2818.values[0] = Top_SodorTile_cpu_c__upc_sel.values[0] == 0x3L;
  { val_t __mask = -T2818.values[0]; T2819.values[0] = T2708.values[0] ^ ((T2708.values[0] ^ Top_SodorTile_cpu_c__upc_opgroup_target.values[0]) & __mask); }
  { Top_SodorTile_cpu_c__upc_state_next.values[0] = T2819.values[0]; }
  { Top_SodorTile_cpu_c__upc_state_shadow.values[0] = TERNARY(Top_SodorTile_cpu_c__reset.values[0], 0x6L, Top_SodorTile_cpu_c__upc_state_next.values[0]); }
  { Top_Queue_8__reset.values[0] = reset.values[0]; }
  { T2820.values[0] = Top_Queue_8__enq_ptr.values[0]+0x1L; }
  T2820.values[0] = T2820.values[0] & 3;
  { Top_Queue_8__do_flow.values[0] = 0x0L; }
  T2821.values[0] = !Top_Queue_8__do_flow.values[0];
  T2822.values[0] = !Top_hub_Queue_6__maybe_full.values[0];
  { Top_hub_Queue_6__empty.values[0] = Top_hub_Queue_6__ptr_match.values[0]&&T2822.values[0]; }
  T2823.values[0] = !Top_hub_Queue_6__empty.values[0];
  { Top_hub_Queue_6__io_deq_valid.values[0] = T2823.values[0]; }
  { Top_hub__io_mem_req_data_valid.values[0] = Top_hub_Queue_6__io_deq_valid.values[0]; }
  { Top_Queue_8__io_enq_valid.values[0] = Top_hub__io_mem_req_data_valid.values[0]; }
  Top_Queue_8__ptr_match.values[0] = Top_Queue_8__enq_ptr.values[0] == Top_Queue_8__deq_ptr.values[0];
  { Top_Queue_8__full.values[0] = Top_Queue_8__ptr_match.values[0]&&Top_Queue_8__maybe_full.values[0]; }
  T2824.values[0] = !Top_Queue_8__full.values[0];
  { Top_Queue_8__io_enq_ready.values[0] = T2824.values[0]; }
  { T2825.values[0] = Top_Queue_8__io_enq_ready.values[0]&&Top_Queue_8__io_enq_valid.values[0]; }
  { Top_Queue_8__do_enq.values[0] = T2825.values[0]&&T2821.values[0]; }
  { val_t __mask = -Top_Queue_8__do_enq.values[0]; T2826.values[0] = Top_Queue_8__enq_ptr.values[0] ^ ((Top_Queue_8__enq_ptr.values[0] ^ T2820.values[0]) & __mask); }
  { Top_Queue_8__enq_ptr_shadow.values[0] = TERNARY(Top_Queue_8__reset.values[0], 0x0L, T2826.values[0]); }
  T2827.values[0] = !Top_Queue_8__do_flow.values[0];
  T2828.values[0] = !Top_Queue_8__maybe_full.values[0];
  { Top_Queue_8__empty.values[0] = Top_Queue_8__ptr_match.values[0]&&T2828.values[0]; }
  T2829.values[0] = !Top_Queue_8__empty.values[0];
  { Top_Queue_8__io_deq_valid.values[0] = T2829.values[0]; }
  { Top_Queue_8__io_deq_ready.values[0] = Top__io_mem_req_data_ready.values[0]; }
  { T2830.values[0] = Top_Queue_8__io_deq_ready.values[0]&&Top_Queue_8__io_deq_valid.values[0]; }
  { Top_Queue_8__do_deq.values[0] = T2830.values[0]&&T2827.values[0]; }
  T2831.values[0] = Top_Queue_8__do_enq.values[0] != Top_Queue_8__do_deq.values[0];
  { val_t __mask = -T2831.values[0]; T2832.values[0] = Top_Queue_8__maybe_full.values[0] ^ ((Top_Queue_8__maybe_full.values[0] ^ Top_Queue_8__do_enq.values[0]) & __mask); }
  { Top_Queue_8__maybe_full_shadow.values[0] = TERNARY(Top_Queue_8__reset.values[0], 0x0L, T2832.values[0]); }
  { T2833.values[0] = Top_Queue_8__deq_ptr.values[0]+0x1L; }
  T2833.values[0] = T2833.values[0] & 3;
  { val_t __mask = -Top_Queue_8__do_deq.values[0]; T2834.values[0] = Top_Queue_8__deq_ptr.values[0] ^ ((Top_Queue_8__deq_ptr.values[0] ^ T2833.values[0]) & __mask); }
  { Top_Queue_8__deq_ptr_shadow.values[0] = TERNARY(Top_Queue_8__reset.values[0], 0x0L, T2834.values[0]); }
  { T2836.values[0] = Top_hub_Queue_6__ram.get(Top_hub_Queue_6__deq_ptr.values[0], 0); T2836.values[1] = Top_hub_Queue_6__ram.get(Top_hub_Queue_6__deq_ptr.values[0], 1); }
  { T2837.values[0] = T2836.values[0]; T2837.values[1] = T2836.values[1]; }
  { T2838.values[0] = T2837.values[0]; T2838.values[1] = T2837.values[1]; }
  { Top_hub_Queue_6__io_deq_bits_data.values[0] = T2838.values[0]; Top_hub_Queue_6__io_deq_bits_data.values[1] = T2838.values[1]; }
  { Top_hub__io_mem_req_data_bits_data.values[0] = Top_hub_Queue_6__io_deq_bits_data.values[0]; Top_hub__io_mem_req_data_bits_data.values[1] = Top_hub_Queue_6__io_deq_bits_data.values[1]; }
  { Top_Queue_8__io_enq_bits_data.values[0] = Top_hub__io_mem_req_data_bits_data.values[0]; Top_Queue_8__io_enq_bits_data.values[1] = Top_hub__io_mem_req_data_bits_data.values[1]; }
  { T2841.values[0] = Top_hub_Queue_5__ram.get(Top_hub_Queue_5__deq_ptr.values[0], 0); }
  { T2842.values[0] = T2841.values[0]; }
  T2842.values[0] = T2842.values[0] & 31;
  { T2843.values[0] = T2841.values[0] >> 5; }
  T2843.values[0] = T2843.values[0] & 17179869183;
  T2844.values[0] = (T2841.values[0] >> 39) & 1;
  { T2845.values[0] = T2843.values[0] | T2844.values[0] << 34; }
  { T2846.values[0] = T2842.values[0] | T2845.values[0] << 5; }
  { T2847.values[0] = T2846.values[0]; }
  T2847.values[0] = T2847.values[0] & 31;
  { Top_hub_Queue_5__io_deq_bits_tag.values[0] = T2847.values[0]; }
  { Top_hub__io_mem_req_cmd_bits_tag.values[0] = Top_hub_Queue_5__io_deq_bits_tag.values[0]; }
  { Top_Queue_7__io_enq_bits_tag.values[0] = Top_hub__io_mem_req_cmd_bits_tag.values[0]; }
  { T2848.values[0] = T2846.values[0] >> 5; }
  T2848.values[0] = T2848.values[0] & 17179869183;
  { Top_hub_Queue_5__io_deq_bits_addr.values[0] = T2848.values[0]; }
  { Top_hub__io_mem_req_cmd_bits_addr.values[0] = Top_hub_Queue_5__io_deq_bits_addr.values[0]; }
  { Top_Queue_7__io_enq_bits_addr.values[0] = Top_hub__io_mem_req_cmd_bits_addr.values[0]; }
  T2849.values[0] = (T2846.values[0] >> 39) & 1;
  { Top_hub_Queue_5__io_deq_bits_rw.values[0] = T2849.values[0]; }
  { Top_hub__io_mem_req_cmd_bits_rw.values[0] = Top_hub_Queue_5__io_deq_bits_rw.values[0]; }
  { Top_Queue_7__io_enq_bits_rw.values[0] = Top_hub__io_mem_req_cmd_bits_rw.values[0]; }
  { T2850.values[0] = Top_Queue_7__io_enq_bits_addr.values[0] | Top_Queue_7__io_enq_bits_rw.values[0] << 34; }
  { T2851.values[0] = Top_Queue_7__io_enq_bits_tag.values[0] | T2850.values[0] << 5; }
  { Top_Queue_7__do_flow.values[0] = 0x0L; }
  T2852.values[0] = !Top_Queue_7__do_flow.values[0];
  T2853.values[0] = !Top_hub_Queue_5__maybe_full.values[0];
  { Top_hub_Queue_5__empty.values[0] = Top_hub_Queue_5__ptr_match.values[0]&&T2853.values[0]; }
  T2854.values[0] = !Top_hub_Queue_5__empty.values[0];
  { Top_hub_Queue_5__io_deq_valid.values[0] = T2854.values[0]; }
  { Top_hub__io_mem_req_cmd_valid.values[0] = Top_hub_Queue_5__io_deq_valid.values[0]; }
  { Top_Queue_7__io_enq_valid.values[0] = Top_hub__io_mem_req_cmd_valid.values[0]; }
  Top_Queue_7__ptr_match.values[0] = Top_Queue_7__enq_ptr.values[0] == Top_Queue_7__deq_ptr.values[0];
  { Top_Queue_7__full.values[0] = Top_Queue_7__ptr_match.values[0]&&Top_Queue_7__maybe_full.values[0]; }
  T2855.values[0] = !Top_Queue_7__full.values[0];
  { Top_Queue_7__io_enq_ready.values[0] = T2855.values[0]; }
  { T2856.values[0] = Top_Queue_7__io_enq_ready.values[0]&&Top_Queue_7__io_enq_valid.values[0]; }
  { Top_Queue_7__do_enq.values[0] = T2856.values[0]&&T2852.values[0]; }
  { Top_Queue_7__reset.values[0] = reset.values[0]; }
  { T2858.values[0] = Top_Queue_7__enq_ptr.values[0]+0x1L; }
  T2858.values[0] = T2858.values[0] & 1;
  { val_t __mask = -Top_Queue_7__do_enq.values[0]; T2859.values[0] = Top_Queue_7__enq_ptr.values[0] ^ ((Top_Queue_7__enq_ptr.values[0] ^ T2858.values[0]) & __mask); }
  { Top_Queue_7__enq_ptr_shadow.values[0] = TERNARY(Top_Queue_7__reset.values[0], 0x0L, T2859.values[0]); }
  { T2860.values[0] = Top_Queue_7__deq_ptr.values[0]+0x1L; }
  T2860.values[0] = T2860.values[0] & 1;
  T2861.values[0] = !Top_Queue_7__do_flow.values[0];
  T2862.values[0] = !Top_Queue_7__maybe_full.values[0];
  { Top_Queue_7__empty.values[0] = Top_Queue_7__ptr_match.values[0]&&T2862.values[0]; }
  T2863.values[0] = !Top_Queue_7__empty.values[0];
  { Top_Queue_7__io_deq_valid.values[0] = T2863.values[0]; }
  { Top_Queue_7__io_deq_ready.values[0] = Top__io_mem_req_cmd_ready.values[0]; }
  { T2864.values[0] = Top_Queue_7__io_deq_ready.values[0]&&Top_Queue_7__io_deq_valid.values[0]; }
  { Top_Queue_7__do_deq.values[0] = T2864.values[0]&&T2861.values[0]; }
  { val_t __mask = -Top_Queue_7__do_deq.values[0]; T2865.values[0] = Top_Queue_7__deq_ptr.values[0] ^ ((Top_Queue_7__deq_ptr.values[0] ^ T2860.values[0]) & __mask); }
  { Top_Queue_7__deq_ptr_shadow.values[0] = TERNARY(Top_Queue_7__reset.values[0], 0x0L, T2865.values[0]); }
  T2866.values[0] = Top_Queue_7__do_enq.values[0] != Top_Queue_7__do_deq.values[0];
  { val_t __mask = -T2866.values[0]; T2867.values[0] = Top_Queue_7__maybe_full.values[0] ^ ((Top_Queue_7__maybe_full.values[0] ^ Top_Queue_7__do_enq.values[0]) & __mask); }
  { Top_Queue_7__maybe_full_shadow.values[0] = TERNARY(Top_Queue_7__reset.values[0], 0x0L, T2867.values[0]); }
  { T2869.values[0] = Top_hub_XactTracker_7__io_p_rep_tile_id.values[0]; }
  { T2870.values[0] = T2869.values[0]; }
  T2871.values[0] = 0x1L << T2870.values[0];
  { T2872.values[0] = T2871.values[0]; }
  T2872.values[0] = T2872.values[0] & 3;
  T2873.values[0] = (T2872.values[0] >> 1) & 1;
  { T2874.values[0] = T2873.values[0]; }
  { T2875.values[0] = -T2874.values[0]; T2875.values[1] = -T2874.values[0]; }
  { T2876.values[0] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[0]&T2875.values[0]; T2876.values[1] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[1]&T2875.values[1]; }
  T2877.values[0] = (T2872.values[0] >> 0) & 1;
  { T2878.values[0] = T2877.values[0]; }
  { T2879.values[0] = -T2878.values[0]; T2879.values[1] = -T2878.values[0]; }
  { T2880.values[0] = Top_Queue_22__ram.get(Top_Queue_22__deq_ptr.values[0], 0); T2880.values[1] = Top_Queue_22__ram.get(Top_Queue_22__deq_ptr.values[0], 1); }
  { T2881.values[0] = T2880.values[0]; T2881.values[1] = T2880.values[1]; }
  { T2882.values[0] = T2881.values[0]; T2882.values[1] = T2881.values[1]; }
  { Top_Queue_22__io_deq_bits_data.values[0] = T2882.values[0]; Top_Queue_22__io_deq_bits_data.values[1] = T2882.values[1]; }
  { Top_hub__io_tiles_0_probe_rep_data_bits_data.values[0] = Top_Queue_22__io_deq_bits_data.values[0]; Top_hub__io_tiles_0_probe_rep_data_bits_data.values[1] = Top_Queue_22__io_deq_bits_data.values[1]; }
  { T2883.values[0] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[0]&T2879.values[0]; T2883.values[1] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[1]&T2879.values[1]; }
  { T2884.values[0] = T2883.values[0]|T2876.values[0]; T2884.values[1] = T2883.values[1]|T2876.values[1]; }
  { Top_hub_XactTracker_7__io_p_rep_data_bits_data.values[0] = T2884.values[0]; Top_hub_XactTracker_7__io_p_rep_data_bits_data.values[1] = T2884.values[1]; }
  { val_t __mask = -T462.values[0]; T2885.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_7__io_p_rep_data_bits_data.values[0]) & __mask); T2885.values[1] = 0L ^ ((0L ^ Top_hub_XactTracker_7__io_p_rep_data_bits_data.values[1]) & __mask); }
  { T2886.values[0] = Top_hub_XactTracker_7__io_init_tile_id.values[0]; }
  { T2887.values[0] = T2886.values[0]; }
  T2888.values[0] = 0x1L << T2887.values[0];
  { T2889.values[0] = T2888.values[0]; }
  T2889.values[0] = T2889.values[0] & 3;
  T2890.values[0] = (T2889.values[0] >> 1) & 1;
  { T2891.values[0] = T2890.values[0]; }
  { T2892.values[0] = -T2891.values[0]; T2892.values[1] = -T2891.values[0]; }
  { T2893.values[0] = 0x0L | Top_htif__mem_cnt.values[0] << 1; }
  { T2894.values[0] = T2893.values[0]; }
  { T2895.values[0] = T2894.values[0]; }
  T2896.values[0] = 0x1L << T2895.values[0];
  { T2897.values[0] = T2896.values[0]; }
  T2897.values[0] = T2897.values[0] & 255;
  T2898.values[0] = (T2897.values[0] >> 7) & 1;
  { T2899.values[0] = T2898.values[0]; }
  { T2900.values[0] = -T2899.values[0]; }
  { T2901.values[0] = Top_htif__packet_ram_7.values[0]&T2900.values[0]; }
  T2902.values[0] = (T2897.values[0] >> 6) & 1;
  { T2903.values[0] = T2902.values[0]; }
  { T2904.values[0] = -T2903.values[0]; }
  { T2905.values[0] = Top_htif__packet_ram_6.values[0]&T2904.values[0]; }
  T2906.values[0] = (T2897.values[0] >> 5) & 1;
  { T2907.values[0] = T2906.values[0]; }
  { T2908.values[0] = -T2907.values[0]; }
  { T2909.values[0] = Top_htif__packet_ram_5.values[0]&T2908.values[0]; }
  T2910.values[0] = (T2897.values[0] >> 4) & 1;
  { T2911.values[0] = T2910.values[0]; }
  { T2912.values[0] = -T2911.values[0]; }
  { T2913.values[0] = Top_htif__packet_ram_4.values[0]&T2912.values[0]; }
  T2914.values[0] = (T2897.values[0] >> 3) & 1;
  { T2915.values[0] = T2914.values[0]; }
  { T2916.values[0] = -T2915.values[0]; }
  { T2917.values[0] = Top_htif__packet_ram_3.values[0]&T2916.values[0]; }
  T2918.values[0] = (T2897.values[0] >> 2) & 1;
  { T2919.values[0] = T2918.values[0]; }
  { T2920.values[0] = -T2919.values[0]; }
  { T2921.values[0] = Top_htif__packet_ram_2.values[0]&T2920.values[0]; }
  T2922.values[0] = (T2897.values[0] >> 1) & 1;
  { T2923.values[0] = T2922.values[0]; }
  { T2924.values[0] = -T2923.values[0]; }
  { T2925.values[0] = Top_htif__packet_ram_1.values[0]&T2924.values[0]; }
  T2926.values[0] = (T2897.values[0] >> 0) & 1;
  { T2927.values[0] = T2926.values[0]; }
  { T2928.values[0] = -T2927.values[0]; }
  { T2929.values[0] = Top_htif__pcr_wdata.values[0]&T2928.values[0]; }
  { T2930.values[0] = T2929.values[0]|T2925.values[0]; }
  { T2931.values[0] = T2930.values[0]|T2921.values[0]; }
  { T2932.values[0] = T2931.values[0]|T2917.values[0]; }
  { T2933.values[0] = T2932.values[0]|T2913.values[0]; }
  { T2934.values[0] = T2933.values[0]|T2909.values[0]; }
  { T2935.values[0] = T2934.values[0]|T2905.values[0]; }
  { T2936.values[0] = T2935.values[0]|T2901.values[0]; }
  { T2937.values[0] = 0x1L | Top_htif__mem_cnt.values[0] << 1; }
  { T2938.values[0] = T2937.values[0]; }
  { T2939.values[0] = T2938.values[0]; }
  T2940.values[0] = 0x1L << T2939.values[0];
  { T2941.values[0] = T2940.values[0]; }
  T2941.values[0] = T2941.values[0] & 255;
  T2942.values[0] = (T2941.values[0] >> 7) & 1;
  { T2943.values[0] = T2942.values[0]; }
  { T2944.values[0] = -T2943.values[0]; }
  { T2945.values[0] = Top_htif__packet_ram_7.values[0]&T2944.values[0]; }
  T2946.values[0] = (T2941.values[0] >> 6) & 1;
  { T2947.values[0] = T2946.values[0]; }
  { T2948.values[0] = -T2947.values[0]; }
  { T2949.values[0] = Top_htif__packet_ram_6.values[0]&T2948.values[0]; }
  T2950.values[0] = (T2941.values[0] >> 5) & 1;
  { T2951.values[0] = T2950.values[0]; }
  { T2952.values[0] = -T2951.values[0]; }
  { T2953.values[0] = Top_htif__packet_ram_5.values[0]&T2952.values[0]; }
  T2954.values[0] = (T2941.values[0] >> 4) & 1;
  { T2955.values[0] = T2954.values[0]; }
  { T2956.values[0] = -T2955.values[0]; }
  { T2957.values[0] = Top_htif__packet_ram_4.values[0]&T2956.values[0]; }
  T2958.values[0] = (T2941.values[0] >> 3) & 1;
  { T2959.values[0] = T2958.values[0]; }
  { T2960.values[0] = -T2959.values[0]; }
  { T2961.values[0] = Top_htif__packet_ram_3.values[0]&T2960.values[0]; }
  T2962.values[0] = (T2941.values[0] >> 2) & 1;
  { T2963.values[0] = T2962.values[0]; }
  { T2964.values[0] = -T2963.values[0]; }
  { T2965.values[0] = Top_htif__packet_ram_2.values[0]&T2964.values[0]; }
  T2966.values[0] = (T2941.values[0] >> 1) & 1;
  { T2967.values[0] = T2966.values[0]; }
  { T2968.values[0] = -T2967.values[0]; }
  { T2969.values[0] = Top_htif__packet_ram_1.values[0]&T2968.values[0]; }
  T2970.values[0] = (T2941.values[0] >> 0) & 1;
  { T2971.values[0] = T2970.values[0]; }
  { T2972.values[0] = -T2971.values[0]; }
  { T2973.values[0] = Top_htif__pcr_wdata.values[0]&T2972.values[0]; }
  { T2974.values[0] = T2973.values[0]|T2969.values[0]; }
  { T2975.values[0] = T2974.values[0]|T2965.values[0]; }
  { T2976.values[0] = T2975.values[0]|T2961.values[0]; }
  { T2977.values[0] = T2976.values[0]|T2957.values[0]; }
  { T2978.values[0] = T2977.values[0]|T2953.values[0]; }
  { T2979.values[0] = T2978.values[0]|T2949.values[0]; }
  { T2980.values[0] = T2979.values[0]|T2945.values[0]; }
  { Top_htif__mem_req_data.values[0] = T2936.values[0]; Top_htif__mem_req_data.values[1] = T2980.values[0]; }
  { Top_htif__io_mem_xact_init_data_bits_data.values[0] = Top_htif__mem_req_data.values[0]; Top_htif__io_mem_xact_init_data_bits_data.values[1] = Top_htif__mem_req_data.values[1]; }
  { Top_hub__io_tiles_1_xact_init_data_bits_data.values[0] = Top_htif__io_mem_xact_init_data_bits_data.values[0]; Top_hub__io_tiles_1_xact_init_data_bits_data.values[1] = Top_htif__io_mem_xact_init_data_bits_data.values[1]; }
  { T2981.values[0] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[0]&T2892.values[0]; T2981.values[1] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[1]&T2892.values[1]; }
  T2982.values[0] = (T2889.values[0] >> 0) & 1;
  { T2983.values[0] = T2982.values[0]; }
  { T2984.values[0] = -T2983.values[0]; T2984.values[1] = -T2983.values[0]; }
  { T2985.values[0] = Top_Queue_16__ram.get(Top_Queue_16__deq_ptr.values[0], 0); T2985.values[1] = Top_Queue_16__ram.get(Top_Queue_16__deq_ptr.values[0], 1); }
  { T2986.values[0] = T2985.values[0]; T2986.values[1] = T2985.values[1]; }
  { T2987.values[0] = T2986.values[0]; T2987.values[1] = T2986.values[1]; }
  { Top_Queue_16__io_deq_bits_data.values[0] = T2987.values[0]; Top_Queue_16__io_deq_bits_data.values[1] = T2987.values[1]; }
  { Top_hub__io_tiles_0_xact_init_data_bits_data.values[0] = Top_Queue_16__io_deq_bits_data.values[0]; Top_hub__io_tiles_0_xact_init_data_bits_data.values[1] = Top_Queue_16__io_deq_bits_data.values[1]; }
  { T2988.values[0] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[0]&T2984.values[0]; T2988.values[1] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[1]&T2984.values[1]; }
  { T2989.values[0] = T2988.values[0]|T2981.values[0]; T2989.values[1] = T2988.values[1]|T2981.values[1]; }
  { Top_hub_XactTracker_7__io_x_init_data_bits_data.values[0] = T2989.values[0]; Top_hub_XactTracker_7__io_x_init_data_bits_data.values[1] = T2989.values[1]; }
  { val_t __mask = -T491.values[0]; T2990.values[0] = T2885.values[0] ^ ((T2885.values[0] ^ Top_hub_XactTracker_7__io_x_init_data_bits_data.values[0]) & __mask); T2990.values[1] = T2885.values[1] ^ ((T2885.values[1] ^ Top_hub_XactTracker_7__io_x_init_data_bits_data.values[1]) & __mask); }
  { Top_hub_XactTracker_7__io_mem_req_data_bits_data.values[0] = T2990.values[0]; Top_hub_XactTracker_7__io_mem_req_data_bits_data.values[1] = T2990.values[1]; }
  { Top_hub_mem_req_data_arb__io_in_7_bits_data.values[0] = Top_hub_XactTracker_7__io_mem_req_data_bits_data.values[0]; Top_hub_mem_req_data_arb__io_in_7_bits_data.values[1] = Top_hub_XactTracker_7__io_mem_req_data_bits_data.values[1]; }
  { T2991.values[0] = Top_hub_XactTracker_6__io_p_rep_tile_id.values[0]; }
  { T2992.values[0] = T2991.values[0]; }
  T2993.values[0] = 0x1L << T2992.values[0];
  { T2994.values[0] = T2993.values[0]; }
  T2994.values[0] = T2994.values[0] & 3;
  T2995.values[0] = (T2994.values[0] >> 1) & 1;
  { T2996.values[0] = T2995.values[0]; }
  { T2997.values[0] = -T2996.values[0]; T2997.values[1] = -T2996.values[0]; }
  { T2998.values[0] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[0]&T2997.values[0]; T2998.values[1] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[1]&T2997.values[1]; }
  T2999.values[0] = (T2994.values[0] >> 0) & 1;
  { T3000.values[0] = T2999.values[0]; }
  { T3001.values[0] = -T3000.values[0]; T3001.values[1] = -T3000.values[0]; }
  { T3002.values[0] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[0]&T3001.values[0]; T3002.values[1] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[1]&T3001.values[1]; }
  { T3003.values[0] = T3002.values[0]|T2998.values[0]; T3003.values[1] = T3002.values[1]|T2998.values[1]; }
  { Top_hub_XactTracker_6__io_p_rep_data_bits_data.values[0] = T3003.values[0]; Top_hub_XactTracker_6__io_p_rep_data_bits_data.values[1] = T3003.values[1]; }
  { val_t __mask = -T405.values[0]; T3004.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_6__io_p_rep_data_bits_data.values[0]) & __mask); T3004.values[1] = 0L ^ ((0L ^ Top_hub_XactTracker_6__io_p_rep_data_bits_data.values[1]) & __mask); }
  { T3005.values[0] = Top_hub_XactTracker_6__io_init_tile_id.values[0]; }
  { T3006.values[0] = T3005.values[0]; }
  T3007.values[0] = 0x1L << T3006.values[0];
  { T3008.values[0] = T3007.values[0]; }
  T3008.values[0] = T3008.values[0] & 3;
  T3009.values[0] = (T3008.values[0] >> 1) & 1;
  { T3010.values[0] = T3009.values[0]; }
  { T3011.values[0] = -T3010.values[0]; T3011.values[1] = -T3010.values[0]; }
  { T3012.values[0] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[0]&T3011.values[0]; T3012.values[1] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[1]&T3011.values[1]; }
  T3013.values[0] = (T3008.values[0] >> 0) & 1;
  { T3014.values[0] = T3013.values[0]; }
  { T3015.values[0] = -T3014.values[0]; T3015.values[1] = -T3014.values[0]; }
  { T3016.values[0] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[0]&T3015.values[0]; T3016.values[1] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[1]&T3015.values[1]; }
  { T3017.values[0] = T3016.values[0]|T3012.values[0]; T3017.values[1] = T3016.values[1]|T3012.values[1]; }
  { Top_hub_XactTracker_6__io_x_init_data_bits_data.values[0] = T3017.values[0]; Top_hub_XactTracker_6__io_x_init_data_bits_data.values[1] = T3017.values[1]; }
  { val_t __mask = -T434.values[0]; T3018.values[0] = T3004.values[0] ^ ((T3004.values[0] ^ Top_hub_XactTracker_6__io_x_init_data_bits_data.values[0]) & __mask); T3018.values[1] = T3004.values[1] ^ ((T3004.values[1] ^ Top_hub_XactTracker_6__io_x_init_data_bits_data.values[1]) & __mask); }
  { Top_hub_XactTracker_6__io_mem_req_data_bits_data.values[0] = T3018.values[0]; Top_hub_XactTracker_6__io_mem_req_data_bits_data.values[1] = T3018.values[1]; }
  { Top_hub_mem_req_data_arb__io_in_6_bits_data.values[0] = Top_hub_XactTracker_6__io_mem_req_data_bits_data.values[0]; Top_hub_mem_req_data_arb__io_in_6_bits_data.values[1] = Top_hub_XactTracker_6__io_mem_req_data_bits_data.values[1]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__io_in_6_valid.values[0]; T3019.values[0] = Top_hub_mem_req_data_arb__io_in_7_bits_data.values[0] ^ ((Top_hub_mem_req_data_arb__io_in_7_bits_data.values[0] ^ Top_hub_mem_req_data_arb__io_in_6_bits_data.values[0]) & __mask); T3019.values[1] = Top_hub_mem_req_data_arb__io_in_7_bits_data.values[1] ^ ((Top_hub_mem_req_data_arb__io_in_7_bits_data.values[1] ^ Top_hub_mem_req_data_arb__io_in_6_bits_data.values[1]) & __mask); }
  { T3020.values[0] = T3019.values[0]; T3020.values[1] = T3019.values[1]; }
  { T3021.values[0] = Top_hub_XactTracker_5__io_p_rep_tile_id.values[0]; }
  { T3022.values[0] = T3021.values[0]; }
  T3023.values[0] = 0x1L << T3022.values[0];
  { T3024.values[0] = T3023.values[0]; }
  T3024.values[0] = T3024.values[0] & 3;
  T3025.values[0] = (T3024.values[0] >> 1) & 1;
  { T3026.values[0] = T3025.values[0]; }
  { T3027.values[0] = -T3026.values[0]; T3027.values[1] = -T3026.values[0]; }
  { T3028.values[0] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[0]&T3027.values[0]; T3028.values[1] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[1]&T3027.values[1]; }
  T3029.values[0] = (T3024.values[0] >> 0) & 1;
  { T3030.values[0] = T3029.values[0]; }
  { T3031.values[0] = -T3030.values[0]; T3031.values[1] = -T3030.values[0]; }
  { T3032.values[0] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[0]&T3031.values[0]; T3032.values[1] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[1]&T3031.values[1]; }
  { T3033.values[0] = T3032.values[0]|T3028.values[0]; T3033.values[1] = T3032.values[1]|T3028.values[1]; }
  { Top_hub_XactTracker_5__io_p_rep_data_bits_data.values[0] = T3033.values[0]; Top_hub_XactTracker_5__io_p_rep_data_bits_data.values[1] = T3033.values[1]; }
  { val_t __mask = -T348.values[0]; T3034.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_5__io_p_rep_data_bits_data.values[0]) & __mask); T3034.values[1] = 0L ^ ((0L ^ Top_hub_XactTracker_5__io_p_rep_data_bits_data.values[1]) & __mask); }
  { T3035.values[0] = Top_hub_XactTracker_5__io_init_tile_id.values[0]; }
  { T3036.values[0] = T3035.values[0]; }
  T3037.values[0] = 0x1L << T3036.values[0];
  { T3038.values[0] = T3037.values[0]; }
  T3038.values[0] = T3038.values[0] & 3;
  T3039.values[0] = (T3038.values[0] >> 1) & 1;
  { T3040.values[0] = T3039.values[0]; }
  { T3041.values[0] = -T3040.values[0]; T3041.values[1] = -T3040.values[0]; }
  { T3042.values[0] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[0]&T3041.values[0]; T3042.values[1] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[1]&T3041.values[1]; }
  T3043.values[0] = (T3038.values[0] >> 0) & 1;
  { T3044.values[0] = T3043.values[0]; }
  { T3045.values[0] = -T3044.values[0]; T3045.values[1] = -T3044.values[0]; }
  { T3046.values[0] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[0]&T3045.values[0]; T3046.values[1] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[1]&T3045.values[1]; }
  { T3047.values[0] = T3046.values[0]|T3042.values[0]; T3047.values[1] = T3046.values[1]|T3042.values[1]; }
  { Top_hub_XactTracker_5__io_x_init_data_bits_data.values[0] = T3047.values[0]; Top_hub_XactTracker_5__io_x_init_data_bits_data.values[1] = T3047.values[1]; }
  { val_t __mask = -T377.values[0]; T3048.values[0] = T3034.values[0] ^ ((T3034.values[0] ^ Top_hub_XactTracker_5__io_x_init_data_bits_data.values[0]) & __mask); T3048.values[1] = T3034.values[1] ^ ((T3034.values[1] ^ Top_hub_XactTracker_5__io_x_init_data_bits_data.values[1]) & __mask); }
  { Top_hub_XactTracker_5__io_mem_req_data_bits_data.values[0] = T3048.values[0]; Top_hub_XactTracker_5__io_mem_req_data_bits_data.values[1] = T3048.values[1]; }
  { Top_hub_mem_req_data_arb__io_in_5_bits_data.values[0] = Top_hub_XactTracker_5__io_mem_req_data_bits_data.values[0]; Top_hub_mem_req_data_arb__io_in_5_bits_data.values[1] = Top_hub_XactTracker_5__io_mem_req_data_bits_data.values[1]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__io_in_5_valid.values[0]; T3049.values[0] = T3020.values[0] ^ ((T3020.values[0] ^ Top_hub_mem_req_data_arb__io_in_5_bits_data.values[0]) & __mask); T3049.values[1] = T3020.values[1] ^ ((T3020.values[1] ^ Top_hub_mem_req_data_arb__io_in_5_bits_data.values[1]) & __mask); }
  { T3050.values[0] = T3049.values[0]; T3050.values[1] = T3049.values[1]; }
  { T3051.values[0] = Top_hub_XactTracker_4__io_p_rep_tile_id.values[0]; }
  { T3052.values[0] = T3051.values[0]; }
  T3053.values[0] = 0x1L << T3052.values[0];
  { T3054.values[0] = T3053.values[0]; }
  T3054.values[0] = T3054.values[0] & 3;
  T3055.values[0] = (T3054.values[0] >> 1) & 1;
  { T3056.values[0] = T3055.values[0]; }
  { T3057.values[0] = -T3056.values[0]; T3057.values[1] = -T3056.values[0]; }
  { T3058.values[0] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[0]&T3057.values[0]; T3058.values[1] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[1]&T3057.values[1]; }
  T3059.values[0] = (T3054.values[0] >> 0) & 1;
  { T3060.values[0] = T3059.values[0]; }
  { T3061.values[0] = -T3060.values[0]; T3061.values[1] = -T3060.values[0]; }
  { T3062.values[0] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[0]&T3061.values[0]; T3062.values[1] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[1]&T3061.values[1]; }
  { T3063.values[0] = T3062.values[0]|T3058.values[0]; T3063.values[1] = T3062.values[1]|T3058.values[1]; }
  { Top_hub_XactTracker_4__io_p_rep_data_bits_data.values[0] = T3063.values[0]; Top_hub_XactTracker_4__io_p_rep_data_bits_data.values[1] = T3063.values[1]; }
  { val_t __mask = -T291.values[0]; T3064.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_4__io_p_rep_data_bits_data.values[0]) & __mask); T3064.values[1] = 0L ^ ((0L ^ Top_hub_XactTracker_4__io_p_rep_data_bits_data.values[1]) & __mask); }
  { T3065.values[0] = Top_hub_XactTracker_4__io_init_tile_id.values[0]; }
  { T3066.values[0] = T3065.values[0]; }
  T3067.values[0] = 0x1L << T3066.values[0];
  { T3068.values[0] = T3067.values[0]; }
  T3068.values[0] = T3068.values[0] & 3;
  T3069.values[0] = (T3068.values[0] >> 1) & 1;
  { T3070.values[0] = T3069.values[0]; }
  { T3071.values[0] = -T3070.values[0]; T3071.values[1] = -T3070.values[0]; }
  { T3072.values[0] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[0]&T3071.values[0]; T3072.values[1] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[1]&T3071.values[1]; }
  T3073.values[0] = (T3068.values[0] >> 0) & 1;
  { T3074.values[0] = T3073.values[0]; }
  { T3075.values[0] = -T3074.values[0]; T3075.values[1] = -T3074.values[0]; }
  { T3076.values[0] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[0]&T3075.values[0]; T3076.values[1] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[1]&T3075.values[1]; }
  { T3077.values[0] = T3076.values[0]|T3072.values[0]; T3077.values[1] = T3076.values[1]|T3072.values[1]; }
  { Top_hub_XactTracker_4__io_x_init_data_bits_data.values[0] = T3077.values[0]; Top_hub_XactTracker_4__io_x_init_data_bits_data.values[1] = T3077.values[1]; }
  { val_t __mask = -T320.values[0]; T3078.values[0] = T3064.values[0] ^ ((T3064.values[0] ^ Top_hub_XactTracker_4__io_x_init_data_bits_data.values[0]) & __mask); T3078.values[1] = T3064.values[1] ^ ((T3064.values[1] ^ Top_hub_XactTracker_4__io_x_init_data_bits_data.values[1]) & __mask); }
  { Top_hub_XactTracker_4__io_mem_req_data_bits_data.values[0] = T3078.values[0]; Top_hub_XactTracker_4__io_mem_req_data_bits_data.values[1] = T3078.values[1]; }
  { Top_hub_mem_req_data_arb__io_in_4_bits_data.values[0] = Top_hub_XactTracker_4__io_mem_req_data_bits_data.values[0]; Top_hub_mem_req_data_arb__io_in_4_bits_data.values[1] = Top_hub_XactTracker_4__io_mem_req_data_bits_data.values[1]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__io_in_4_valid.values[0]; T3079.values[0] = T3050.values[0] ^ ((T3050.values[0] ^ Top_hub_mem_req_data_arb__io_in_4_bits_data.values[0]) & __mask); T3079.values[1] = T3050.values[1] ^ ((T3050.values[1] ^ Top_hub_mem_req_data_arb__io_in_4_bits_data.values[1]) & __mask); }
  { T3080.values[0] = T3079.values[0]; T3080.values[1] = T3079.values[1]; }
  { T3081.values[0] = Top_hub_XactTracker_3__io_p_rep_tile_id.values[0]; }
  { T3082.values[0] = T3081.values[0]; }
  T3083.values[0] = 0x1L << T3082.values[0];
  { T3084.values[0] = T3083.values[0]; }
  T3084.values[0] = T3084.values[0] & 3;
  T3085.values[0] = (T3084.values[0] >> 1) & 1;
  { T3086.values[0] = T3085.values[0]; }
  { T3087.values[0] = -T3086.values[0]; T3087.values[1] = -T3086.values[0]; }
  { T3088.values[0] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[0]&T3087.values[0]; T3088.values[1] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[1]&T3087.values[1]; }
  T3089.values[0] = (T3084.values[0] >> 0) & 1;
  { T3090.values[0] = T3089.values[0]; }
  { T3091.values[0] = -T3090.values[0]; T3091.values[1] = -T3090.values[0]; }
  { T3092.values[0] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[0]&T3091.values[0]; T3092.values[1] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[1]&T3091.values[1]; }
  { T3093.values[0] = T3092.values[0]|T3088.values[0]; T3093.values[1] = T3092.values[1]|T3088.values[1]; }
  { Top_hub_XactTracker_3__io_p_rep_data_bits_data.values[0] = T3093.values[0]; Top_hub_XactTracker_3__io_p_rep_data_bits_data.values[1] = T3093.values[1]; }
  { val_t __mask = -T234.values[0]; T3094.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_3__io_p_rep_data_bits_data.values[0]) & __mask); T3094.values[1] = 0L ^ ((0L ^ Top_hub_XactTracker_3__io_p_rep_data_bits_data.values[1]) & __mask); }
  { T3095.values[0] = Top_hub_XactTracker_3__io_init_tile_id.values[0]; }
  { T3096.values[0] = T3095.values[0]; }
  T3097.values[0] = 0x1L << T3096.values[0];
  { T3098.values[0] = T3097.values[0]; }
  T3098.values[0] = T3098.values[0] & 3;
  T3099.values[0] = (T3098.values[0] >> 1) & 1;
  { T3100.values[0] = T3099.values[0]; }
  { T3101.values[0] = -T3100.values[0]; T3101.values[1] = -T3100.values[0]; }
  { T3102.values[0] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[0]&T3101.values[0]; T3102.values[1] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[1]&T3101.values[1]; }
  T3103.values[0] = (T3098.values[0] >> 0) & 1;
  { T3104.values[0] = T3103.values[0]; }
  { T3105.values[0] = -T3104.values[0]; T3105.values[1] = -T3104.values[0]; }
  { T3106.values[0] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[0]&T3105.values[0]; T3106.values[1] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[1]&T3105.values[1]; }
  { T3107.values[0] = T3106.values[0]|T3102.values[0]; T3107.values[1] = T3106.values[1]|T3102.values[1]; }
  { Top_hub_XactTracker_3__io_x_init_data_bits_data.values[0] = T3107.values[0]; Top_hub_XactTracker_3__io_x_init_data_bits_data.values[1] = T3107.values[1]; }
  { val_t __mask = -T263.values[0]; T3108.values[0] = T3094.values[0] ^ ((T3094.values[0] ^ Top_hub_XactTracker_3__io_x_init_data_bits_data.values[0]) & __mask); T3108.values[1] = T3094.values[1] ^ ((T3094.values[1] ^ Top_hub_XactTracker_3__io_x_init_data_bits_data.values[1]) & __mask); }
  { Top_hub_XactTracker_3__io_mem_req_data_bits_data.values[0] = T3108.values[0]; Top_hub_XactTracker_3__io_mem_req_data_bits_data.values[1] = T3108.values[1]; }
  { Top_hub_mem_req_data_arb__io_in_3_bits_data.values[0] = Top_hub_XactTracker_3__io_mem_req_data_bits_data.values[0]; Top_hub_mem_req_data_arb__io_in_3_bits_data.values[1] = Top_hub_XactTracker_3__io_mem_req_data_bits_data.values[1]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__io_in_3_valid.values[0]; T3109.values[0] = T3080.values[0] ^ ((T3080.values[0] ^ Top_hub_mem_req_data_arb__io_in_3_bits_data.values[0]) & __mask); T3109.values[1] = T3080.values[1] ^ ((T3080.values[1] ^ Top_hub_mem_req_data_arb__io_in_3_bits_data.values[1]) & __mask); }
  { T3110.values[0] = T3109.values[0]; T3110.values[1] = T3109.values[1]; }
  { T3111.values[0] = Top_hub_XactTracker_2__io_p_rep_tile_id.values[0]; }
  { T3112.values[0] = T3111.values[0]; }
  T3113.values[0] = 0x1L << T3112.values[0];
  { T3114.values[0] = T3113.values[0]; }
  T3114.values[0] = T3114.values[0] & 3;
  T3115.values[0] = (T3114.values[0] >> 1) & 1;
  { T3116.values[0] = T3115.values[0]; }
  { T3117.values[0] = -T3116.values[0]; T3117.values[1] = -T3116.values[0]; }
  { T3118.values[0] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[0]&T3117.values[0]; T3118.values[1] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[1]&T3117.values[1]; }
  T3119.values[0] = (T3114.values[0] >> 0) & 1;
  { T3120.values[0] = T3119.values[0]; }
  { T3121.values[0] = -T3120.values[0]; T3121.values[1] = -T3120.values[0]; }
  { T3122.values[0] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[0]&T3121.values[0]; T3122.values[1] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[1]&T3121.values[1]; }
  { T3123.values[0] = T3122.values[0]|T3118.values[0]; T3123.values[1] = T3122.values[1]|T3118.values[1]; }
  { Top_hub_XactTracker_2__io_p_rep_data_bits_data.values[0] = T3123.values[0]; Top_hub_XactTracker_2__io_p_rep_data_bits_data.values[1] = T3123.values[1]; }
  { val_t __mask = -T177.values[0]; T3124.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_2__io_p_rep_data_bits_data.values[0]) & __mask); T3124.values[1] = 0L ^ ((0L ^ Top_hub_XactTracker_2__io_p_rep_data_bits_data.values[1]) & __mask); }
  { T3125.values[0] = Top_hub_XactTracker_2__io_init_tile_id.values[0]; }
  { T3126.values[0] = T3125.values[0]; }
  T3127.values[0] = 0x1L << T3126.values[0];
  { T3128.values[0] = T3127.values[0]; }
  T3128.values[0] = T3128.values[0] & 3;
  T3129.values[0] = (T3128.values[0] >> 1) & 1;
  { T3130.values[0] = T3129.values[0]; }
  { T3131.values[0] = -T3130.values[0]; T3131.values[1] = -T3130.values[0]; }
  { T3132.values[0] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[0]&T3131.values[0]; T3132.values[1] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[1]&T3131.values[1]; }
  T3133.values[0] = (T3128.values[0] >> 0) & 1;
  { T3134.values[0] = T3133.values[0]; }
  { T3135.values[0] = -T3134.values[0]; T3135.values[1] = -T3134.values[0]; }
  { T3136.values[0] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[0]&T3135.values[0]; T3136.values[1] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[1]&T3135.values[1]; }
  { T3137.values[0] = T3136.values[0]|T3132.values[0]; T3137.values[1] = T3136.values[1]|T3132.values[1]; }
  { Top_hub_XactTracker_2__io_x_init_data_bits_data.values[0] = T3137.values[0]; Top_hub_XactTracker_2__io_x_init_data_bits_data.values[1] = T3137.values[1]; }
  { val_t __mask = -T206.values[0]; T3138.values[0] = T3124.values[0] ^ ((T3124.values[0] ^ Top_hub_XactTracker_2__io_x_init_data_bits_data.values[0]) & __mask); T3138.values[1] = T3124.values[1] ^ ((T3124.values[1] ^ Top_hub_XactTracker_2__io_x_init_data_bits_data.values[1]) & __mask); }
  { Top_hub_XactTracker_2__io_mem_req_data_bits_data.values[0] = T3138.values[0]; Top_hub_XactTracker_2__io_mem_req_data_bits_data.values[1] = T3138.values[1]; }
  { Top_hub_mem_req_data_arb__io_in_2_bits_data.values[0] = Top_hub_XactTracker_2__io_mem_req_data_bits_data.values[0]; Top_hub_mem_req_data_arb__io_in_2_bits_data.values[1] = Top_hub_XactTracker_2__io_mem_req_data_bits_data.values[1]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__io_in_2_valid.values[0]; T3139.values[0] = T3110.values[0] ^ ((T3110.values[0] ^ Top_hub_mem_req_data_arb__io_in_2_bits_data.values[0]) & __mask); T3139.values[1] = T3110.values[1] ^ ((T3110.values[1] ^ Top_hub_mem_req_data_arb__io_in_2_bits_data.values[1]) & __mask); }
  { T3140.values[0] = T3139.values[0]; T3140.values[1] = T3139.values[1]; }
  { T3141.values[0] = Top_hub_XactTracker_1__io_p_rep_tile_id.values[0]; }
  { T3142.values[0] = T3141.values[0]; }
  T3143.values[0] = 0x1L << T3142.values[0];
  { T3144.values[0] = T3143.values[0]; }
  T3144.values[0] = T3144.values[0] & 3;
  T3145.values[0] = (T3144.values[0] >> 1) & 1;
  { T3146.values[0] = T3145.values[0]; }
  { T3147.values[0] = -T3146.values[0]; T3147.values[1] = -T3146.values[0]; }
  { T3148.values[0] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[0]&T3147.values[0]; T3148.values[1] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[1]&T3147.values[1]; }
  T3149.values[0] = (T3144.values[0] >> 0) & 1;
  { T3150.values[0] = T3149.values[0]; }
  { T3151.values[0] = -T3150.values[0]; T3151.values[1] = -T3150.values[0]; }
  { T3152.values[0] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[0]&T3151.values[0]; T3152.values[1] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[1]&T3151.values[1]; }
  { T3153.values[0] = T3152.values[0]|T3148.values[0]; T3153.values[1] = T3152.values[1]|T3148.values[1]; }
  { Top_hub_XactTracker_1__io_p_rep_data_bits_data.values[0] = T3153.values[0]; Top_hub_XactTracker_1__io_p_rep_data_bits_data.values[1] = T3153.values[1]; }
  { val_t __mask = -T120.values[0]; T3154.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_1__io_p_rep_data_bits_data.values[0]) & __mask); T3154.values[1] = 0L ^ ((0L ^ Top_hub_XactTracker_1__io_p_rep_data_bits_data.values[1]) & __mask); }
  { T3155.values[0] = Top_hub_XactTracker_1__io_init_tile_id.values[0]; }
  { T3156.values[0] = T3155.values[0]; }
  T3157.values[0] = 0x1L << T3156.values[0];
  { T3158.values[0] = T3157.values[0]; }
  T3158.values[0] = T3158.values[0] & 3;
  T3159.values[0] = (T3158.values[0] >> 1) & 1;
  { T3160.values[0] = T3159.values[0]; }
  { T3161.values[0] = -T3160.values[0]; T3161.values[1] = -T3160.values[0]; }
  { T3162.values[0] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[0]&T3161.values[0]; T3162.values[1] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[1]&T3161.values[1]; }
  T3163.values[0] = (T3158.values[0] >> 0) & 1;
  { T3164.values[0] = T3163.values[0]; }
  { T3165.values[0] = -T3164.values[0]; T3165.values[1] = -T3164.values[0]; }
  { T3166.values[0] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[0]&T3165.values[0]; T3166.values[1] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[1]&T3165.values[1]; }
  { T3167.values[0] = T3166.values[0]|T3162.values[0]; T3167.values[1] = T3166.values[1]|T3162.values[1]; }
  { Top_hub_XactTracker_1__io_x_init_data_bits_data.values[0] = T3167.values[0]; Top_hub_XactTracker_1__io_x_init_data_bits_data.values[1] = T3167.values[1]; }
  { val_t __mask = -T149.values[0]; T3168.values[0] = T3154.values[0] ^ ((T3154.values[0] ^ Top_hub_XactTracker_1__io_x_init_data_bits_data.values[0]) & __mask); T3168.values[1] = T3154.values[1] ^ ((T3154.values[1] ^ Top_hub_XactTracker_1__io_x_init_data_bits_data.values[1]) & __mask); }
  { Top_hub_XactTracker_1__io_mem_req_data_bits_data.values[0] = T3168.values[0]; Top_hub_XactTracker_1__io_mem_req_data_bits_data.values[1] = T3168.values[1]; }
  { Top_hub_mem_req_data_arb__io_in_1_bits_data.values[0] = Top_hub_XactTracker_1__io_mem_req_data_bits_data.values[0]; Top_hub_mem_req_data_arb__io_in_1_bits_data.values[1] = Top_hub_XactTracker_1__io_mem_req_data_bits_data.values[1]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__io_in_1_valid.values[0]; T3169.values[0] = T3140.values[0] ^ ((T3140.values[0] ^ Top_hub_mem_req_data_arb__io_in_1_bits_data.values[0]) & __mask); T3169.values[1] = T3140.values[1] ^ ((T3140.values[1] ^ Top_hub_mem_req_data_arb__io_in_1_bits_data.values[1]) & __mask); }
  { T3170.values[0] = T3169.values[0]; T3170.values[1] = T3169.values[1]; }
  { T3171.values[0] = Top_hub_XactTracker__io_p_rep_tile_id.values[0]; }
  { T3172.values[0] = T3171.values[0]; }
  T3173.values[0] = 0x1L << T3172.values[0];
  { T3174.values[0] = T3173.values[0]; }
  T3174.values[0] = T3174.values[0] & 3;
  T3175.values[0] = (T3174.values[0] >> 1) & 1;
  { T3176.values[0] = T3175.values[0]; }
  { T3177.values[0] = -T3176.values[0]; T3177.values[1] = -T3176.values[0]; }
  { T3178.values[0] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[0]&T3177.values[0]; T3178.values[1] = Top_hub__io_tiles_1_probe_rep_data_bits_data.values[1]&T3177.values[1]; }
  T3179.values[0] = (T3174.values[0] >> 0) & 1;
  { T3180.values[0] = T3179.values[0]; }
  { T3181.values[0] = -T3180.values[0]; T3181.values[1] = -T3180.values[0]; }
  { T3182.values[0] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[0]&T3181.values[0]; T3182.values[1] = Top_hub__io_tiles_0_probe_rep_data_bits_data.values[1]&T3181.values[1]; }
  { T3183.values[0] = T3182.values[0]|T3178.values[0]; T3183.values[1] = T3182.values[1]|T3178.values[1]; }
  { Top_hub_XactTracker__io_p_rep_data_bits_data.values[0] = T3183.values[0]; Top_hub_XactTracker__io_p_rep_data_bits_data.values[1] = T3183.values[1]; }
  { val_t __mask = -T50.values[0]; T3184.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker__io_p_rep_data_bits_data.values[0]) & __mask); T3184.values[1] = 0L ^ ((0L ^ Top_hub_XactTracker__io_p_rep_data_bits_data.values[1]) & __mask); }
  { T3185.values[0] = Top_hub_XactTracker__io_init_tile_id.values[0]; }
  { T3186.values[0] = T3185.values[0]; }
  T3187.values[0] = 0x1L << T3186.values[0];
  { T3188.values[0] = T3187.values[0]; }
  T3188.values[0] = T3188.values[0] & 3;
  T3189.values[0] = (T3188.values[0] >> 1) & 1;
  { T3190.values[0] = T3189.values[0]; }
  { T3191.values[0] = -T3190.values[0]; T3191.values[1] = -T3190.values[0]; }
  { T3192.values[0] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[0]&T3191.values[0]; T3192.values[1] = Top_hub__io_tiles_1_xact_init_data_bits_data.values[1]&T3191.values[1]; }
  T3193.values[0] = (T3188.values[0] >> 0) & 1;
  { T3194.values[0] = T3193.values[0]; }
  { T3195.values[0] = -T3194.values[0]; T3195.values[1] = -T3194.values[0]; }
  { T3196.values[0] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[0]&T3195.values[0]; T3196.values[1] = Top_hub__io_tiles_0_xact_init_data_bits_data.values[1]&T3195.values[1]; }
  { T3197.values[0] = T3196.values[0]|T3192.values[0]; T3197.values[1] = T3196.values[1]|T3192.values[1]; }
  { Top_hub_XactTracker__io_x_init_data_bits_data.values[0] = T3197.values[0]; Top_hub_XactTracker__io_x_init_data_bits_data.values[1] = T3197.values[1]; }
  { val_t __mask = -T92.values[0]; T3198.values[0] = T3184.values[0] ^ ((T3184.values[0] ^ Top_hub_XactTracker__io_x_init_data_bits_data.values[0]) & __mask); T3198.values[1] = T3184.values[1] ^ ((T3184.values[1] ^ Top_hub_XactTracker__io_x_init_data_bits_data.values[1]) & __mask); }
  { Top_hub_XactTracker__io_mem_req_data_bits_data.values[0] = T3198.values[0]; Top_hub_XactTracker__io_mem_req_data_bits_data.values[1] = T3198.values[1]; }
  { Top_hub_mem_req_data_arb__io_in_0_bits_data.values[0] = Top_hub_XactTracker__io_mem_req_data_bits_data.values[0]; Top_hub_mem_req_data_arb__io_in_0_bits_data.values[1] = Top_hub_XactTracker__io_mem_req_data_bits_data.values[1]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__io_in_0_valid.values[0]; Top_hub_mem_req_data_arb__dout.values[0] = T3170.values[0] ^ ((T3170.values[0] ^ Top_hub_mem_req_data_arb__io_in_0_bits_data.values[0]) & __mask); Top_hub_mem_req_data_arb__dout.values[1] = T3170.values[1] ^ ((T3170.values[1] ^ Top_hub_mem_req_data_arb__io_in_0_bits_data.values[1]) & __mask); }
  { T3199.values[0] = Top_hub_mem_req_data_arb__dout.values[0]; T3199.values[1] = Top_hub_mem_req_data_arb__dout.values[1]; }
  { T3200.values[0] = Top_hub_mem_req_data_arb__locked_6.values[0] | Top_hub_mem_req_data_arb__locked_7.values[0] << 1; }
  { T3201.values[0] = Top_hub_mem_req_data_arb__locked_5.values[0] | T3200.values[0] << 1; }
  { T3202.values[0] = Top_hub_mem_req_data_arb__locked_4.values[0] | T3201.values[0] << 1; }
  { T3203.values[0] = Top_hub_mem_req_data_arb__locked_3.values[0] | T3202.values[0] << 1; }
  { T3204.values[0] = Top_hub_mem_req_data_arb__locked_2.values[0] | T3203.values[0] << 1; }
  { T3205.values[0] = Top_hub_mem_req_data_arb__locked_1.values[0] | T3204.values[0] << 1; }
  { T3206.values[0] = Top_hub_mem_req_data_arb__locked_0.values[0] | T3205.values[0] << 1; }
  T3207.values[0] = (T3206.values[0] >> 6) & 1;
  { val_t __mask = -T3207.values[0]; T3208.values[0] = 0x7L ^ ((0x7L ^ 0x6L) & __mask); }
  T3209.values[0] = (T3206.values[0] >> 5) & 1;
  { val_t __mask = -T3209.values[0]; T3210.values[0] = T3208.values[0] ^ ((T3208.values[0] ^ 0x5L) & __mask); }
  T3211.values[0] = (T3206.values[0] >> 4) & 1;
  { val_t __mask = -T3211.values[0]; T3212.values[0] = T3210.values[0] ^ ((T3210.values[0] ^ 0x4L) & __mask); }
  T3213.values[0] = (T3206.values[0] >> 3) & 1;
  { val_t __mask = -T3213.values[0]; T3214.values[0] = T3212.values[0] ^ ((T3212.values[0] ^ 0x3L) & __mask); }
  T3215.values[0] = (T3206.values[0] >> 2) & 1;
  { val_t __mask = -T3215.values[0]; T3216.values[0] = T3214.values[0] ^ ((T3214.values[0] ^ 0x2L) & __mask); }
  T3217.values[0] = (T3206.values[0] >> 1) & 1;
  { val_t __mask = -T3217.values[0]; T3218.values[0] = T3216.values[0] ^ ((T3216.values[0] ^ 0x1L) & __mask); }
  T3219.values[0] = (T3206.values[0] >> 0) & 1;
  { val_t __mask = -T3219.values[0]; Top_hub_mem_req_data_arb__lock_idx.values[0] = T3218.values[0] ^ ((T3218.values[0] ^ 0x0L) & __mask); }
  { T3220.values[0] = Top_hub_mem_req_data_arb__lock_idx.values[0]; }
  T3221.values[0] = 0x1L << T3220.values[0];
  { T3222.values[0] = T3221.values[0]; }
  T3222.values[0] = T3222.values[0] & 255;
  T3223.values[0] = (T3222.values[0] >> 7) & 1;
  { T3224.values[0] = T3223.values[0]; }
  { T3225.values[0] = -T3224.values[0]; T3225.values[1] = -T3224.values[0]; }
  { Top_hub_mem_req_data_arb__bits_arr_7_data.values[0] = Top_hub_mem_req_data_arb__io_in_7_bits_data.values[0]; Top_hub_mem_req_data_arb__bits_arr_7_data.values[1] = Top_hub_mem_req_data_arb__io_in_7_bits_data.values[1]; }
  { T3226.values[0] = Top_hub_mem_req_data_arb__bits_arr_7_data.values[0]&T3225.values[0]; T3226.values[1] = Top_hub_mem_req_data_arb__bits_arr_7_data.values[1]&T3225.values[1]; }
  T3227.values[0] = (T3222.values[0] >> 6) & 1;
  { T3228.values[0] = T3227.values[0]; }
  { T3229.values[0] = -T3228.values[0]; T3229.values[1] = -T3228.values[0]; }
  { Top_hub_mem_req_data_arb__bits_arr_6_data.values[0] = Top_hub_mem_req_data_arb__io_in_6_bits_data.values[0]; Top_hub_mem_req_data_arb__bits_arr_6_data.values[1] = Top_hub_mem_req_data_arb__io_in_6_bits_data.values[1]; }
  { T3230.values[0] = Top_hub_mem_req_data_arb__bits_arr_6_data.values[0]&T3229.values[0]; T3230.values[1] = Top_hub_mem_req_data_arb__bits_arr_6_data.values[1]&T3229.values[1]; }
  T3231.values[0] = (T3222.values[0] >> 5) & 1;
  { T3232.values[0] = T3231.values[0]; }
  { T3233.values[0] = -T3232.values[0]; T3233.values[1] = -T3232.values[0]; }
  { Top_hub_mem_req_data_arb__bits_arr_5_data.values[0] = Top_hub_mem_req_data_arb__io_in_5_bits_data.values[0]; Top_hub_mem_req_data_arb__bits_arr_5_data.values[1] = Top_hub_mem_req_data_arb__io_in_5_bits_data.values[1]; }
  { T3234.values[0] = Top_hub_mem_req_data_arb__bits_arr_5_data.values[0]&T3233.values[0]; T3234.values[1] = Top_hub_mem_req_data_arb__bits_arr_5_data.values[1]&T3233.values[1]; }
  T3235.values[0] = (T3222.values[0] >> 4) & 1;
  { T3236.values[0] = T3235.values[0]; }
  { T3237.values[0] = -T3236.values[0]; T3237.values[1] = -T3236.values[0]; }
  { Top_hub_mem_req_data_arb__bits_arr_4_data.values[0] = Top_hub_mem_req_data_arb__io_in_4_bits_data.values[0]; Top_hub_mem_req_data_arb__bits_arr_4_data.values[1] = Top_hub_mem_req_data_arb__io_in_4_bits_data.values[1]; }
  { T3238.values[0] = Top_hub_mem_req_data_arb__bits_arr_4_data.values[0]&T3237.values[0]; T3238.values[1] = Top_hub_mem_req_data_arb__bits_arr_4_data.values[1]&T3237.values[1]; }
  T3239.values[0] = (T3222.values[0] >> 3) & 1;
  { T3240.values[0] = T3239.values[0]; }
  { T3241.values[0] = -T3240.values[0]; T3241.values[1] = -T3240.values[0]; }
  { Top_hub_mem_req_data_arb__bits_arr_3_data.values[0] = Top_hub_mem_req_data_arb__io_in_3_bits_data.values[0]; Top_hub_mem_req_data_arb__bits_arr_3_data.values[1] = Top_hub_mem_req_data_arb__io_in_3_bits_data.values[1]; }
  { T3242.values[0] = Top_hub_mem_req_data_arb__bits_arr_3_data.values[0]&T3241.values[0]; T3242.values[1] = Top_hub_mem_req_data_arb__bits_arr_3_data.values[1]&T3241.values[1]; }
  T3243.values[0] = (T3222.values[0] >> 2) & 1;
  { T3244.values[0] = T3243.values[0]; }
  { T3245.values[0] = -T3244.values[0]; T3245.values[1] = -T3244.values[0]; }
  { Top_hub_mem_req_data_arb__bits_arr_2_data.values[0] = Top_hub_mem_req_data_arb__io_in_2_bits_data.values[0]; Top_hub_mem_req_data_arb__bits_arr_2_data.values[1] = Top_hub_mem_req_data_arb__io_in_2_bits_data.values[1]; }
  { T3246.values[0] = Top_hub_mem_req_data_arb__bits_arr_2_data.values[0]&T3245.values[0]; T3246.values[1] = Top_hub_mem_req_data_arb__bits_arr_2_data.values[1]&T3245.values[1]; }
  T3247.values[0] = (T3222.values[0] >> 1) & 1;
  { T3248.values[0] = T3247.values[0]; }
  { T3249.values[0] = -T3248.values[0]; T3249.values[1] = -T3248.values[0]; }
  { Top_hub_mem_req_data_arb__bits_arr_1_data.values[0] = Top_hub_mem_req_data_arb__io_in_1_bits_data.values[0]; Top_hub_mem_req_data_arb__bits_arr_1_data.values[1] = Top_hub_mem_req_data_arb__io_in_1_bits_data.values[1]; }
  { T3250.values[0] = Top_hub_mem_req_data_arb__bits_arr_1_data.values[0]&T3249.values[0]; T3250.values[1] = Top_hub_mem_req_data_arb__bits_arr_1_data.values[1]&T3249.values[1]; }
  T3251.values[0] = (T3222.values[0] >> 0) & 1;
  { T3252.values[0] = T3251.values[0]; }
  { T3253.values[0] = -T3252.values[0]; T3253.values[1] = -T3252.values[0]; }
  { Top_hub_mem_req_data_arb__bits_arr_0_data.values[0] = Top_hub_mem_req_data_arb__io_in_0_bits_data.values[0]; Top_hub_mem_req_data_arb__bits_arr_0_data.values[1] = Top_hub_mem_req_data_arb__io_in_0_bits_data.values[1]; }
  { T3254.values[0] = Top_hub_mem_req_data_arb__bits_arr_0_data.values[0]&T3253.values[0]; T3254.values[1] = Top_hub_mem_req_data_arb__bits_arr_0_data.values[1]&T3253.values[1]; }
  { T3255.values[0] = T3254.values[0]|T3250.values[0]; T3255.values[1] = T3254.values[1]|T3250.values[1]; }
  { T3256.values[0] = T3255.values[0]|T3246.values[0]; T3256.values[1] = T3255.values[1]|T3246.values[1]; }
  { T3257.values[0] = T3256.values[0]|T3242.values[0]; T3257.values[1] = T3256.values[1]|T3242.values[1]; }
  { T3258.values[0] = T3257.values[0]|T3238.values[0]; T3258.values[1] = T3257.values[1]|T3238.values[1]; }
  { T3259.values[0] = T3258.values[0]|T3234.values[0]; T3259.values[1] = T3258.values[1]|T3234.values[1]; }
  { T3260.values[0] = T3259.values[0]|T3230.values[0]; T3260.values[1] = T3259.values[1]|T3230.values[1]; }
  { T3261.values[0] = T3260.values[0]|T3226.values[0]; T3261.values[1] = T3260.values[1]|T3226.values[1]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3262.values[0] = T3199.values[0] ^ ((T3199.values[0] ^ T3261.values[0]) & __mask); T3262.values[1] = T3199.values[1] ^ ((T3199.values[1] ^ T3261.values[1]) & __mask); }
  { T3263.values[0] = T3262.values[0]; T3263.values[1] = T3262.values[1]; }
  { Top_hub_mem_req_data_arb__io_out_bits_data.values[0] = T3263.values[0]; Top_hub_mem_req_data_arb__io_out_bits_data.values[1] = T3263.values[1]; }
  { Top_hub_Queue_6__io_enq_bits_data.values[0] = Top_hub_mem_req_data_arb__io_out_bits_data.values[0]; Top_hub_Queue_6__io_enq_bits_data.values[1] = Top_hub_mem_req_data_arb__io_out_bits_data.values[1]; }
  { Top_hub_Queue_6__do_flow.values[0] = 0x0L; }
  T3264.values[0] = !Top_hub_Queue_6__do_flow.values[0];
  { val_t __mask = -T708.values[0]; T3265.values[0] = 0x0L ^ ((0x0L ^ Top_hub_XactTracker_7__io_p_rep_data_valid.values[0]) & __mask); }
  { val_t __mask = -T1226.values[0]; T3266.values[0] = T3265.values[0] ^ ((T3265.values[0] ^ Top_hub_XactTracker_7__io_x_init_data_valid.values[0]) & __mask); }
  { Top_hub_XactTracker_7__io_mem_req_data_valid.values[0] = T3266.values[0]; }
  { Top_hub_mem_req_data_arb__io_in_7_valid.values[0] = Top_hub_XactTracker_7__io_mem_req_data_valid.values[0]; }
  { T3267.values[0] = Top_hub_mem_req_data_arb__io_in_0_valid.values[0]||Top_hub_mem_req_data_arb__io_in_1_valid.values[0]; }
  { T3268.values[0] = T3267.values[0]||Top_hub_mem_req_data_arb__io_in_2_valid.values[0]; }
  { T3269.values[0] = T3268.values[0]||Top_hub_mem_req_data_arb__io_in_3_valid.values[0]; }
  { T3270.values[0] = T3269.values[0]||Top_hub_mem_req_data_arb__io_in_4_valid.values[0]; }
  { T3271.values[0] = T3270.values[0]||Top_hub_mem_req_data_arb__io_in_5_valid.values[0]; }
  { T3272.values[0] = T3271.values[0]||Top_hub_mem_req_data_arb__io_in_6_valid.values[0]; }
  { Top_hub_mem_req_data_arb__vout.values[0] = T3272.values[0]||Top_hub_mem_req_data_arb__io_in_7_valid.values[0]; }
  { Top_hub_mem_req_data_arb__valid_arr_7.values[0] = Top_hub_mem_req_data_arb__io_in_7_valid.values[0]; }
  { T3273.values[0] = Top_hub_mem_req_data_arb__valid_arr_7.values[0]&T3224.values[0]; }
  { Top_hub_mem_req_data_arb__valid_arr_6.values[0] = Top_hub_mem_req_data_arb__io_in_6_valid.values[0]; }
  { T3274.values[0] = Top_hub_mem_req_data_arb__valid_arr_6.values[0]&T3228.values[0]; }
  { Top_hub_mem_req_data_arb__valid_arr_5.values[0] = Top_hub_mem_req_data_arb__io_in_5_valid.values[0]; }
  { T3275.values[0] = Top_hub_mem_req_data_arb__valid_arr_5.values[0]&T3232.values[0]; }
  { Top_hub_mem_req_data_arb__valid_arr_4.values[0] = Top_hub_mem_req_data_arb__io_in_4_valid.values[0]; }
  { T3276.values[0] = Top_hub_mem_req_data_arb__valid_arr_4.values[0]&T3236.values[0]; }
  { Top_hub_mem_req_data_arb__valid_arr_3.values[0] = Top_hub_mem_req_data_arb__io_in_3_valid.values[0]; }
  { T3277.values[0] = Top_hub_mem_req_data_arb__valid_arr_3.values[0]&T3240.values[0]; }
  { Top_hub_mem_req_data_arb__valid_arr_2.values[0] = Top_hub_mem_req_data_arb__io_in_2_valid.values[0]; }
  { T3278.values[0] = Top_hub_mem_req_data_arb__valid_arr_2.values[0]&T3244.values[0]; }
  { Top_hub_mem_req_data_arb__valid_arr_1.values[0] = Top_hub_mem_req_data_arb__io_in_1_valid.values[0]; }
  { T3279.values[0] = Top_hub_mem_req_data_arb__valid_arr_1.values[0]&T3248.values[0]; }
  { Top_hub_mem_req_data_arb__valid_arr_0.values[0] = Top_hub_mem_req_data_arb__io_in_0_valid.values[0]; }
  { T3280.values[0] = Top_hub_mem_req_data_arb__valid_arr_0.values[0]&T3252.values[0]; }
  { T3281.values[0] = T3280.values[0]|T3279.values[0]; }
  { T3282.values[0] = T3281.values[0]|T3278.values[0]; }
  { T3283.values[0] = T3282.values[0]|T3277.values[0]; }
  { T3284.values[0] = T3283.values[0]|T3276.values[0]; }
  { T3285.values[0] = T3284.values[0]|T3275.values[0]; }
  { T3286.values[0] = T3285.values[0]|T3274.values[0]; }
  { T3287.values[0] = T3286.values[0]|T3273.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3288.values[0] = Top_hub_mem_req_data_arb__vout.values[0] ^ ((Top_hub_mem_req_data_arb__vout.values[0] ^ T3287.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__io_out_valid.values[0] = T3288.values[0]; }
  { Top_hub_Queue_6__io_enq_valid.values[0] = Top_hub_mem_req_data_arb__io_out_valid.values[0]; }
  { T3289.values[0] = Top_hub_Queue_6__io_enq_ready.values[0]&&Top_hub_Queue_6__io_enq_valid.values[0]; }
  { Top_hub_Queue_6__do_enq.values[0] = T3289.values[0]&&T3264.values[0]; }
  { Top_hub__reset.values[0] = reset.values[0]; }
  { Top_hub_Queue_6__reset.values[0] = Top_hub__reset.values[0]; }
  { T3291.values[0] = Top_hub_Queue_6__enq_ptr.values[0]+0x1L; }
  T3291.values[0] = T3291.values[0] & 1;
  { val_t __mask = -Top_hub_Queue_6__do_enq.values[0]; T3292.values[0] = Top_hub_Queue_6__enq_ptr.values[0] ^ ((Top_hub_Queue_6__enq_ptr.values[0] ^ T3291.values[0]) & __mask); }
  { Top_hub_Queue_6__enq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_6__reset.values[0], 0x0L, T3292.values[0]); }
  { T3293.values[0] = Top_hub_Queue_6__deq_ptr.values[0]+0x1L; }
  T3293.values[0] = T3293.values[0] & 1;
  T3294.values[0] = !Top_hub_Queue_6__do_flow.values[0];
  { Top_hub__io_mem_req_data_ready.values[0] = Top_Queue_8__io_enq_ready.values[0]; }
  { Top_hub_Queue_6__io_deq_ready.values[0] = Top_hub__io_mem_req_data_ready.values[0]; }
  { T3295.values[0] = Top_hub_Queue_6__io_deq_ready.values[0]&&Top_hub_Queue_6__io_deq_valid.values[0]; }
  { Top_hub_Queue_6__do_deq.values[0] = T3295.values[0]&&T3294.values[0]; }
  { val_t __mask = -Top_hub_Queue_6__do_deq.values[0]; T3296.values[0] = Top_hub_Queue_6__deq_ptr.values[0] ^ ((Top_hub_Queue_6__deq_ptr.values[0] ^ T3293.values[0]) & __mask); }
  { Top_hub_Queue_6__deq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_6__reset.values[0], 0x0L, T3296.values[0]); }
  T3297.values[0] = Top_hub_Queue_6__do_enq.values[0] != Top_hub_Queue_6__do_deq.values[0];
  { val_t __mask = -T3297.values[0]; T3298.values[0] = Top_hub_Queue_6__maybe_full.values[0] ^ ((Top_hub_Queue_6__maybe_full.values[0] ^ Top_hub_Queue_6__do_enq.values[0]) & __mask); }
  { Top_hub_Queue_6__maybe_full_shadow.values[0] = TERNARY(Top_hub_Queue_6__reset.values[0], 0x0L, T3298.values[0]); }
  { Top_hub_XactTracker_7__io_mem_req_cmd_bits_tag.values[0] = 0x7L; }
  { Top_hub_mem_req_cmd_arb__io_in_7_bits_tag.values[0] = Top_hub_XactTracker_7__io_mem_req_cmd_bits_tag.values[0]; }
  { Top_hub_XactTracker_7__io_mem_req_cmd_bits_addr.values[0] = Top_hub_XactTracker_7__addr_.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_7_bits_addr.values[0] = Top_hub_XactTracker_7__io_mem_req_cmd_bits_addr.values[0]; }
  { val_t __mask = -T491.values[0]; T3300.values[0] = T462.values[0] ^ ((T462.values[0] ^ 0x1L) & __mask); }
  { T3301.values[0] = Top_hub_XactTracker_7__p_rep_data_needs_write.values[0]||Top_hub_XactTracker_7__x_init_data_needs_write.values[0]; }
  T3302.values[0] = !T3301.values[0];
  { T3303.values[0] = T3302.values[0]&&Top_hub_XactTracker_7__x_needs_read.values[0]; }
  { T3304.values[0] = T461.values[0]&&T3303.values[0]; }
  { val_t __mask = -T3304.values[0]; T3305.values[0] = T3300.values[0] ^ ((T3300.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_7__io_mem_req_cmd_bits_rw.values[0] = T3305.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_7_bits_rw.values[0] = Top_hub_XactTracker_7__io_mem_req_cmd_bits_rw.values[0]; }
  { T3306.values[0] = Top_hub_mem_req_cmd_arb__io_in_7_bits_addr.values[0] | Top_hub_mem_req_cmd_arb__io_in_7_bits_rw.values[0] << 34; }
  { T3307.values[0] = Top_hub_mem_req_cmd_arb__io_in_7_bits_tag.values[0] | T3306.values[0] << 5; }
  { Top_hub_XactTracker_6__io_mem_req_cmd_bits_tag.values[0] = 0x6L; }
  { Top_hub_mem_req_cmd_arb__io_in_6_bits_tag.values[0] = Top_hub_XactTracker_6__io_mem_req_cmd_bits_tag.values[0]; }
  { Top_hub_XactTracker_6__io_mem_req_cmd_bits_addr.values[0] = Top_hub_XactTracker_6__addr_.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_6_bits_addr.values[0] = Top_hub_XactTracker_6__io_mem_req_cmd_bits_addr.values[0]; }
  { val_t __mask = -T434.values[0]; T3308.values[0] = T405.values[0] ^ ((T405.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T697.values[0]; T3309.values[0] = T3308.values[0] ^ ((T3308.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_6__io_mem_req_cmd_bits_rw.values[0] = T3309.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_6_bits_rw.values[0] = Top_hub_XactTracker_6__io_mem_req_cmd_bits_rw.values[0]; }
  { T3310.values[0] = Top_hub_mem_req_cmd_arb__io_in_6_bits_addr.values[0] | Top_hub_mem_req_cmd_arb__io_in_6_bits_rw.values[0] << 34; }
  { T3311.values[0] = Top_hub_mem_req_cmd_arb__io_in_6_bits_tag.values[0] | T3310.values[0] << 5; }
  { val_t __mask = -Top_hub_mem_req_cmd_arb__io_in_6_valid.values[0]; T3312.values[0] = T3307.values[0] ^ ((T3307.values[0] ^ T3311.values[0]) & __mask); }
  { T3313.values[0] = T3312.values[0]; }
  T3313.values[0] = T3313.values[0] & 31;
  { T3314.values[0] = T3312.values[0] >> 5; }
  T3314.values[0] = T3314.values[0] & 17179869183;
  T3315.values[0] = (T3312.values[0] >> 39) & 1;
  { T3316.values[0] = T3314.values[0] | T3315.values[0] << 34; }
  { T3317.values[0] = T3313.values[0] | T3316.values[0] << 5; }
  { Top_hub_XactTracker_5__io_mem_req_cmd_bits_tag.values[0] = 0x5L; }
  { Top_hub_mem_req_cmd_arb__io_in_5_bits_tag.values[0] = Top_hub_XactTracker_5__io_mem_req_cmd_bits_tag.values[0]; }
  { Top_hub_XactTracker_5__io_mem_req_cmd_bits_addr.values[0] = Top_hub_XactTracker_5__addr_.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_5_bits_addr.values[0] = Top_hub_XactTracker_5__io_mem_req_cmd_bits_addr.values[0]; }
  { val_t __mask = -T377.values[0]; T3318.values[0] = T348.values[0] ^ ((T348.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T667.values[0]; T3319.values[0] = T3318.values[0] ^ ((T3318.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_5__io_mem_req_cmd_bits_rw.values[0] = T3319.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_5_bits_rw.values[0] = Top_hub_XactTracker_5__io_mem_req_cmd_bits_rw.values[0]; }
  { T3320.values[0] = Top_hub_mem_req_cmd_arb__io_in_5_bits_addr.values[0] | Top_hub_mem_req_cmd_arb__io_in_5_bits_rw.values[0] << 34; }
  { T3321.values[0] = Top_hub_mem_req_cmd_arb__io_in_5_bits_tag.values[0] | T3320.values[0] << 5; }
  { val_t __mask = -Top_hub_mem_req_cmd_arb__io_in_5_valid.values[0]; T3322.values[0] = T3317.values[0] ^ ((T3317.values[0] ^ T3321.values[0]) & __mask); }
  { T3323.values[0] = T3322.values[0]; }
  T3323.values[0] = T3323.values[0] & 31;
  { T3324.values[0] = T3322.values[0] >> 5; }
  T3324.values[0] = T3324.values[0] & 17179869183;
  T3325.values[0] = (T3322.values[0] >> 39) & 1;
  { T3326.values[0] = T3324.values[0] | T3325.values[0] << 34; }
  { T3327.values[0] = T3323.values[0] | T3326.values[0] << 5; }
  { Top_hub_XactTracker_4__io_mem_req_cmd_bits_tag.values[0] = 0x4L; }
  { Top_hub_mem_req_cmd_arb__io_in_4_bits_tag.values[0] = Top_hub_XactTracker_4__io_mem_req_cmd_bits_tag.values[0]; }
  { Top_hub_XactTracker_4__io_mem_req_cmd_bits_addr.values[0] = Top_hub_XactTracker_4__addr_.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_4_bits_addr.values[0] = Top_hub_XactTracker_4__io_mem_req_cmd_bits_addr.values[0]; }
  { val_t __mask = -T320.values[0]; T3328.values[0] = T291.values[0] ^ ((T291.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T638.values[0]; T3329.values[0] = T3328.values[0] ^ ((T3328.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_4__io_mem_req_cmd_bits_rw.values[0] = T3329.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_4_bits_rw.values[0] = Top_hub_XactTracker_4__io_mem_req_cmd_bits_rw.values[0]; }
  { T3330.values[0] = Top_hub_mem_req_cmd_arb__io_in_4_bits_addr.values[0] | Top_hub_mem_req_cmd_arb__io_in_4_bits_rw.values[0] << 34; }
  { T3331.values[0] = Top_hub_mem_req_cmd_arb__io_in_4_bits_tag.values[0] | T3330.values[0] << 5; }
  { val_t __mask = -Top_hub_mem_req_cmd_arb__io_in_4_valid.values[0]; T3332.values[0] = T3327.values[0] ^ ((T3327.values[0] ^ T3331.values[0]) & __mask); }
  { T3333.values[0] = T3332.values[0]; }
  T3333.values[0] = T3333.values[0] & 31;
  { T3334.values[0] = T3332.values[0] >> 5; }
  T3334.values[0] = T3334.values[0] & 17179869183;
  T3335.values[0] = (T3332.values[0] >> 39) & 1;
  { T3336.values[0] = T3334.values[0] | T3335.values[0] << 34; }
  { T3337.values[0] = T3333.values[0] | T3336.values[0] << 5; }
  { Top_hub_XactTracker_3__io_mem_req_cmd_bits_tag.values[0] = 0x3L; }
  { Top_hub_mem_req_cmd_arb__io_in_3_bits_tag.values[0] = Top_hub_XactTracker_3__io_mem_req_cmd_bits_tag.values[0]; }
  { Top_hub_XactTracker_3__io_mem_req_cmd_bits_addr.values[0] = Top_hub_XactTracker_3__addr_.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_3_bits_addr.values[0] = Top_hub_XactTracker_3__io_mem_req_cmd_bits_addr.values[0]; }
  { val_t __mask = -T263.values[0]; T3338.values[0] = T234.values[0] ^ ((T234.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T610.values[0]; T3339.values[0] = T3338.values[0] ^ ((T3338.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_3__io_mem_req_cmd_bits_rw.values[0] = T3339.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_3_bits_rw.values[0] = Top_hub_XactTracker_3__io_mem_req_cmd_bits_rw.values[0]; }
  { T3340.values[0] = Top_hub_mem_req_cmd_arb__io_in_3_bits_addr.values[0] | Top_hub_mem_req_cmd_arb__io_in_3_bits_rw.values[0] << 34; }
  { T3341.values[0] = Top_hub_mem_req_cmd_arb__io_in_3_bits_tag.values[0] | T3340.values[0] << 5; }
  { val_t __mask = -Top_hub_mem_req_cmd_arb__io_in_3_valid.values[0]; T3342.values[0] = T3337.values[0] ^ ((T3337.values[0] ^ T3341.values[0]) & __mask); }
  { T3343.values[0] = T3342.values[0]; }
  T3343.values[0] = T3343.values[0] & 31;
  { T3344.values[0] = T3342.values[0] >> 5; }
  T3344.values[0] = T3344.values[0] & 17179869183;
  T3345.values[0] = (T3342.values[0] >> 39) & 1;
  { T3346.values[0] = T3344.values[0] | T3345.values[0] << 34; }
  { T3347.values[0] = T3343.values[0] | T3346.values[0] << 5; }
  { Top_hub_XactTracker_2__io_mem_req_cmd_bits_tag.values[0] = 0x2L; }
  { Top_hub_mem_req_cmd_arb__io_in_2_bits_tag.values[0] = Top_hub_XactTracker_2__io_mem_req_cmd_bits_tag.values[0]; }
  { Top_hub_XactTracker_2__io_mem_req_cmd_bits_addr.values[0] = Top_hub_XactTracker_2__addr_.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_2_bits_addr.values[0] = Top_hub_XactTracker_2__io_mem_req_cmd_bits_addr.values[0]; }
  { val_t __mask = -T206.values[0]; T3348.values[0] = T177.values[0] ^ ((T177.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T583.values[0]; T3349.values[0] = T3348.values[0] ^ ((T3348.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_2__io_mem_req_cmd_bits_rw.values[0] = T3349.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_2_bits_rw.values[0] = Top_hub_XactTracker_2__io_mem_req_cmd_bits_rw.values[0]; }
  { T3350.values[0] = Top_hub_mem_req_cmd_arb__io_in_2_bits_addr.values[0] | Top_hub_mem_req_cmd_arb__io_in_2_bits_rw.values[0] << 34; }
  { T3351.values[0] = Top_hub_mem_req_cmd_arb__io_in_2_bits_tag.values[0] | T3350.values[0] << 5; }
  { val_t __mask = -Top_hub_mem_req_cmd_arb__io_in_2_valid.values[0]; T3352.values[0] = T3347.values[0] ^ ((T3347.values[0] ^ T3351.values[0]) & __mask); }
  { T3353.values[0] = T3352.values[0]; }
  T3353.values[0] = T3353.values[0] & 31;
  { T3354.values[0] = T3352.values[0] >> 5; }
  T3354.values[0] = T3354.values[0] & 17179869183;
  T3355.values[0] = (T3352.values[0] >> 39) & 1;
  { T3356.values[0] = T3354.values[0] | T3355.values[0] << 34; }
  { T3357.values[0] = T3353.values[0] | T3356.values[0] << 5; }
  { Top_hub_XactTracker_1__io_mem_req_cmd_bits_tag.values[0] = 0x1L; }
  { Top_hub_mem_req_cmd_arb__io_in_1_bits_tag.values[0] = Top_hub_XactTracker_1__io_mem_req_cmd_bits_tag.values[0]; }
  { Top_hub_XactTracker_1__io_mem_req_cmd_bits_addr.values[0] = Top_hub_XactTracker_1__addr_.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_1_bits_addr.values[0] = Top_hub_XactTracker_1__io_mem_req_cmd_bits_addr.values[0]; }
  { val_t __mask = -T149.values[0]; T3358.values[0] = T120.values[0] ^ ((T120.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T557.values[0]; T3359.values[0] = T3358.values[0] ^ ((T3358.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_1__io_mem_req_cmd_bits_rw.values[0] = T3359.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_1_bits_rw.values[0] = Top_hub_XactTracker_1__io_mem_req_cmd_bits_rw.values[0]; }
  { T3360.values[0] = Top_hub_mem_req_cmd_arb__io_in_1_bits_addr.values[0] | Top_hub_mem_req_cmd_arb__io_in_1_bits_rw.values[0] << 34; }
  { T3361.values[0] = Top_hub_mem_req_cmd_arb__io_in_1_bits_tag.values[0] | T3360.values[0] << 5; }
  { val_t __mask = -Top_hub_mem_req_cmd_arb__io_in_1_valid.values[0]; T3362.values[0] = T3357.values[0] ^ ((T3357.values[0] ^ T3361.values[0]) & __mask); }
  { T3363.values[0] = T3362.values[0]; }
  T3363.values[0] = T3363.values[0] & 31;
  { T3364.values[0] = T3362.values[0] >> 5; }
  T3364.values[0] = T3364.values[0] & 17179869183;
  T3365.values[0] = (T3362.values[0] >> 39) & 1;
  { T3366.values[0] = T3364.values[0] | T3365.values[0] << 34; }
  { T3367.values[0] = T3363.values[0] | T3366.values[0] << 5; }
  { Top_hub_XactTracker__io_mem_req_cmd_bits_tag.values[0] = 0x0L; }
  { Top_hub_mem_req_cmd_arb__io_in_0_bits_tag.values[0] = Top_hub_XactTracker__io_mem_req_cmd_bits_tag.values[0]; }
  { Top_hub_XactTracker__io_mem_req_cmd_bits_addr.values[0] = Top_hub_XactTracker__addr_.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_0_bits_addr.values[0] = Top_hub_XactTracker__io_mem_req_cmd_bits_addr.values[0]; }
  { val_t __mask = -T92.values[0]; T3368.values[0] = T50.values[0] ^ ((T50.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T532.values[0]; T3369.values[0] = T3368.values[0] ^ ((T3368.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker__io_mem_req_cmd_bits_rw.values[0] = T3369.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_0_bits_rw.values[0] = Top_hub_XactTracker__io_mem_req_cmd_bits_rw.values[0]; }
  { T3370.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_bits_addr.values[0] | Top_hub_mem_req_cmd_arb__io_in_0_bits_rw.values[0] << 34; }
  { T3371.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_bits_tag.values[0] | T3370.values[0] << 5; }
  { val_t __mask = -Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0]; Top_hub_mem_req_cmd_arb__dout.values[0] = T3367.values[0] ^ ((T3367.values[0] ^ T3371.values[0]) & __mask); }
  { T3372.values[0] = Top_hub_mem_req_cmd_arb__dout.values[0]; }
  T3372.values[0] = T3372.values[0] & 31;
  { Top_hub_mem_req_cmd_arb__io_out_bits_tag.values[0] = T3372.values[0]; }
  { Top_hub_Queue_5__io_enq_bits_tag.values[0] = Top_hub_mem_req_cmd_arb__io_out_bits_tag.values[0]; }
  { T3373.values[0] = Top_hub_mem_req_cmd_arb__dout.values[0] >> 5; }
  T3373.values[0] = T3373.values[0] & 17179869183;
  { Top_hub_mem_req_cmd_arb__io_out_bits_addr.values[0] = T3373.values[0]; }
  { Top_hub_Queue_5__io_enq_bits_addr.values[0] = Top_hub_mem_req_cmd_arb__io_out_bits_addr.values[0]; }
  T3374.values[0] = (Top_hub_mem_req_cmd_arb__dout.values[0] >> 39) & 1;
  { Top_hub_mem_req_cmd_arb__io_out_bits_rw.values[0] = T3374.values[0]; }
  { Top_hub_Queue_5__io_enq_bits_rw.values[0] = Top_hub_mem_req_cmd_arb__io_out_bits_rw.values[0]; }
  { T3375.values[0] = Top_hub_Queue_5__io_enq_bits_addr.values[0] | Top_hub_Queue_5__io_enq_bits_rw.values[0] << 34; }
  { T3376.values[0] = Top_hub_Queue_5__io_enq_bits_tag.values[0] | T3375.values[0] << 5; }
  { Top_hub_Queue_5__do_flow.values[0] = 0x0L; }
  T3377.values[0] = !Top_hub_Queue_5__do_flow.values[0];
  T3378.values[0] = !Top_hub_XactTracker_7__p_w_mem_cmd_sent.values[0];
  { T3379.values[0] = T3378.values[0]&&Top_hub_XactTracker_7__io_mem_req_data_ready.values[0]; }
  { T3380.values[0] = T3379.values[0]&&Top_hub_XactTracker_7__io_p_rep_data_valid.values[0]; }
  { val_t __mask = -T463.values[0]; T3381.values[0] = 0x0L ^ ((0x0L ^ T3380.values[0]) & __mask); }
  T3382.values[0] = !Top_hub_XactTracker_7__x_w_mem_cmd_sent.values[0];
  { T3383.values[0] = T3382.values[0]&&Top_hub_XactTracker_7__io_mem_req_data_ready.values[0]; }
  { T3384.values[0] = T3383.values[0]&&Top_hub_XactTracker_7__io_x_init_data_valid.values[0]; }
  { val_t __mask = -T492.values[0]; T3385.values[0] = T3381.values[0] ^ ((T3381.values[0] ^ T3384.values[0]) & __mask); }
  { val_t __mask = -T3304.values[0]; T3386.values[0] = T3385.values[0] ^ ((T3385.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_7__io_mem_req_cmd_valid.values[0] = T3386.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_in_7_valid.values[0] = Top_hub_XactTracker_7__io_mem_req_cmd_valid.values[0]; }
  { T3387.values[0] = Top_hub_mem_req_cmd_arb__io_in_0_valid.values[0]||Top_hub_mem_req_cmd_arb__io_in_1_valid.values[0]; }
  { T3388.values[0] = T3387.values[0]||Top_hub_mem_req_cmd_arb__io_in_2_valid.values[0]; }
  { T3389.values[0] = T3388.values[0]||Top_hub_mem_req_cmd_arb__io_in_3_valid.values[0]; }
  { T3390.values[0] = T3389.values[0]||Top_hub_mem_req_cmd_arb__io_in_4_valid.values[0]; }
  { T3391.values[0] = T3390.values[0]||Top_hub_mem_req_cmd_arb__io_in_5_valid.values[0]; }
  { T3392.values[0] = T3391.values[0]||Top_hub_mem_req_cmd_arb__io_in_6_valid.values[0]; }
  { T3393.values[0] = T3392.values[0]||Top_hub_mem_req_cmd_arb__io_in_7_valid.values[0]; }
  { Top_hub_mem_req_cmd_arb__io_out_valid.values[0] = T3393.values[0]; }
  { Top_hub_Queue_5__io_enq_valid.values[0] = Top_hub_mem_req_cmd_arb__io_out_valid.values[0]; }
  { T3394.values[0] = Top_hub_Queue_5__io_enq_ready.values[0]&&Top_hub_Queue_5__io_enq_valid.values[0]; }
  { Top_hub_Queue_5__do_enq.values[0] = T3394.values[0]&&T3377.values[0]; }
  { Top_hub_Queue_5__reset.values[0] = Top_hub__reset.values[0]; }
  { T3396.values[0] = Top_hub_Queue_5__enq_ptr.values[0]+0x1L; }
  T3396.values[0] = T3396.values[0] & 1;
  { val_t __mask = -Top_hub_Queue_5__do_enq.values[0]; T3397.values[0] = Top_hub_Queue_5__enq_ptr.values[0] ^ ((Top_hub_Queue_5__enq_ptr.values[0] ^ T3396.values[0]) & __mask); }
  { Top_hub_Queue_5__enq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_5__reset.values[0], 0x0L, T3397.values[0]); }
  { T3398.values[0] = Top_hub_Queue_5__deq_ptr.values[0]+0x1L; }
  T3398.values[0] = T3398.values[0] & 1;
  T3399.values[0] = !Top_hub_Queue_5__do_flow.values[0];
  { Top_hub__io_mem_req_cmd_ready.values[0] = Top_Queue_7__io_enq_ready.values[0]; }
  { Top_hub_Queue_5__io_deq_ready.values[0] = Top_hub__io_mem_req_cmd_ready.values[0]; }
  { T3400.values[0] = Top_hub_Queue_5__io_deq_ready.values[0]&&Top_hub_Queue_5__io_deq_valid.values[0]; }
  { Top_hub_Queue_5__do_deq.values[0] = T3400.values[0]&&T3399.values[0]; }
  { val_t __mask = -Top_hub_Queue_5__do_deq.values[0]; T3401.values[0] = Top_hub_Queue_5__deq_ptr.values[0] ^ ((Top_hub_Queue_5__deq_ptr.values[0] ^ T3398.values[0]) & __mask); }
  { Top_hub_Queue_5__deq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_5__reset.values[0], 0x0L, T3401.values[0]); }
  T3402.values[0] = Top_hub_Queue_5__do_enq.values[0] != Top_hub_Queue_5__do_deq.values[0];
  { val_t __mask = -T3402.values[0]; T3403.values[0] = Top_hub_Queue_5__maybe_full.values[0] ^ ((Top_hub_Queue_5__maybe_full.values[0] ^ Top_hub_Queue_5__do_enq.values[0]) & __mask); }
  { Top_hub_Queue_5__maybe_full_shadow.values[0] = TERNARY(Top_hub_Queue_5__reset.values[0], 0x0L, T3403.values[0]); }
  { Top_hub_mem_req_data_arb__reset.values[0] = Top_hub__reset.values[0]; }
  { T3404.values[0] = Top_hub_mem_req_data_arb__io_in_7_ready.values[0]&&Top_hub_mem_req_data_arb__io_lock_7.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3405.values[0] = T3404.values[0] ^ ((T3404.values[0] ^ Top_hub_mem_req_data_arb__locked_7.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__locked_7_shadow.values[0] = TERNARY(Top_hub_mem_req_data_arb__reset.values[0], 0x0L, T3405.values[0]); }
  { T3406.values[0] = Top_hub_mem_req_data_arb__io_in_6_ready.values[0]&&Top_hub_mem_req_data_arb__io_lock_6.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3407.values[0] = T3406.values[0] ^ ((T3406.values[0] ^ Top_hub_mem_req_data_arb__locked_6.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__locked_6_shadow.values[0] = TERNARY(Top_hub_mem_req_data_arb__reset.values[0], 0x0L, T3407.values[0]); }
  { T3408.values[0] = Top_hub_mem_req_data_arb__io_in_5_ready.values[0]&&Top_hub_mem_req_data_arb__io_lock_5.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3409.values[0] = T3408.values[0] ^ ((T3408.values[0] ^ Top_hub_mem_req_data_arb__locked_5.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__locked_5_shadow.values[0] = TERNARY(Top_hub_mem_req_data_arb__reset.values[0], 0x0L, T3409.values[0]); }
  { T3410.values[0] = Top_hub_mem_req_data_arb__io_in_4_ready.values[0]&&Top_hub_mem_req_data_arb__io_lock_4.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3411.values[0] = T3410.values[0] ^ ((T3410.values[0] ^ Top_hub_mem_req_data_arb__locked_4.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__locked_4_shadow.values[0] = TERNARY(Top_hub_mem_req_data_arb__reset.values[0], 0x0L, T3411.values[0]); }
  { T3412.values[0] = Top_hub_mem_req_data_arb__io_in_3_ready.values[0]&&Top_hub_mem_req_data_arb__io_lock_3.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3413.values[0] = T3412.values[0] ^ ((T3412.values[0] ^ Top_hub_mem_req_data_arb__locked_3.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__locked_3_shadow.values[0] = TERNARY(Top_hub_mem_req_data_arb__reset.values[0], 0x0L, T3413.values[0]); }
  { T3414.values[0] = Top_hub_mem_req_data_arb__io_in_2_ready.values[0]&&Top_hub_mem_req_data_arb__io_lock_2.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3415.values[0] = T3414.values[0] ^ ((T3414.values[0] ^ Top_hub_mem_req_data_arb__locked_2.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__locked_2_shadow.values[0] = TERNARY(Top_hub_mem_req_data_arb__reset.values[0], 0x0L, T3415.values[0]); }
  { T3416.values[0] = Top_hub_mem_req_data_arb__io_in_1_ready.values[0]&&Top_hub_mem_req_data_arb__io_lock_1.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3417.values[0] = T3416.values[0] ^ ((T3416.values[0] ^ Top_hub_mem_req_data_arb__locked_1.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__locked_1_shadow.values[0] = TERNARY(Top_hub_mem_req_data_arb__reset.values[0], 0x0L, T3417.values[0]); }
  { T3418.values[0] = Top_hub_mem_req_data_arb__io_in_0_ready.values[0]&&Top_hub_mem_req_data_arb__io_lock_0.values[0]; }
  { val_t __mask = -Top_hub_mem_req_data_arb__any_lock_held.values[0]; T3419.values[0] = T3418.values[0] ^ ((T3418.values[0] ^ Top_hub_mem_req_data_arb__locked_0.values[0]) & __mask); }
  { Top_hub_mem_req_data_arb__locked_0_shadow.values[0] = TERNARY(Top_hub_mem_req_data_arb__reset.values[0], 0x0L, T3419.values[0]); }
  T3421.values[0] = (Top_hub_XactTracker_1__io_pop_x_init.values[0] >> 1) & 1;
  { T3422.values[0] = T3421.values[0]; }
  { T3423.values[0] = T3422.values[0]; }
  T3424.values[0] = (Top_hub_XactTracker_5__io_pop_x_init.values[0] >> 1) & 1;
  { T3425.values[0] = T3424.values[0]; }
  { T3426.values[0] = T3425.values[0]||T3423.values[0]; }
  { T3427.values[0] = T3426.values[0]; }
  T3428.values[0] = (Top_hub_XactTracker_3__io_pop_x_init.values[0] >> 1) & 1;
  { T3429.values[0] = T3428.values[0]; }
  { T3430.values[0] = T3429.values[0]; }
  T3431.values[0] = (Top_hub_XactTracker_7__io_pop_x_init.values[0] >> 1) & 1;
  { T3432.values[0] = T3431.values[0]; }
  { T3433.values[0] = T3432.values[0]||T3430.values[0]; }
  { T3434.values[0] = T3433.values[0]||T3427.values[0]; }
  { T3435.values[0] = T3434.values[0]; }
  { T3436.values[0] = T3433.values[0]; }
  T3437.values[0] = (Top_hub_XactTracker_2__io_pop_x_init.values[0] >> 1) & 1;
  { T3438.values[0] = T3437.values[0]; }
  { T3439.values[0] = T3438.values[0]; }
  T3440.values[0] = (Top_hub_XactTracker_6__io_pop_x_init.values[0] >> 1) & 1;
  { T3441.values[0] = T3440.values[0]; }
  { T3442.values[0] = T3441.values[0]||T3439.values[0]; }
  { T3443.values[0] = T3442.values[0]||T3436.values[0]; }
  { T3444.values[0] = T3435.values[0] | T3443.values[0] << 1; }
  { T3445.values[0] = T3444.values[0]; }
  { T3446.values[0] = T3432.values[0]; }
  { T3447.values[0] = T3441.values[0]; }
  { T3448.values[0] = T3425.values[0]; }
  T3449.values[0] = (Top_hub_XactTracker_4__io_pop_x_init.values[0] >> 1) & 1;
  { T3450.values[0] = T3449.values[0]; }
  { T3451.values[0] = T3450.values[0]||T3448.values[0]; }
  { T3452.values[0] = T3451.values[0]||T3447.values[0]; }
  { T3453.values[0] = T3452.values[0]||T3446.values[0]; }
  { T3454.values[0] = T3445.values[0] | T3453.values[0] << 2; }
  { T3455.values[0] = T3454.values[0]; }
  { Top_hub_Queue_4__io_enq_bits_global_xact_id.values[0] = T3455.values[0]; }
  { Top_hub_Queue_4__do_flow.values[0] = 0x0L; }
  T3456.values[0] = !Top_hub_Queue_4__do_flow.values[0];
  T3457.values[0] = Top_hub__abort_state_arr_1.values[0] == 0x0L;
  T3458.values[0] = Top_hub__io_tiles_1_xact_init_bits_x_type.values[0] == 0x3L;
  { T3459.values[0] = T3441.values[0]||T3432.values[0]; }
  { T3460.values[0] = T3425.values[0]||T3459.values[0]; }
  { T3461.values[0] = T3450.values[0]||T3460.values[0]; }
  { T3462.values[0] = T3429.values[0]||T3461.values[0]; }
  { T3463.values[0] = T3438.values[0]||T3462.values[0]; }
  { T3464.values[0] = T3422.values[0]||T3463.values[0]; }
  T3465.values[0] = (Top_hub_XactTracker__io_pop_x_init.values[0] >> 1) & 1;
  { T3466.values[0] = T3465.values[0]; }
  { T3467.values[0] = T3466.values[0]||T3464.values[0]; }
  { T3468.values[0] = T3467.values[0]&&T3458.values[0]; }
  { T3469.values[0] = T3468.values[0]&&T3457.values[0]; }
  { Top_hub_Queue_4__io_enq_valid.values[0] = T3469.values[0]; }
  { T3470.values[0] = Top_hub_Queue_4__io_enq_ready.values[0]&&Top_hub_Queue_4__io_enq_valid.values[0]; }
  { Top_hub_Queue_4__do_enq.values[0] = T3470.values[0]&&T3456.values[0]; }
  { Top_hub_Queue_4__reset.values[0] = Top_hub__reset.values[0]; }
  { T3472.values[0] = Top_hub_Queue_4__enq_ptr.values[0]+0x1L; }
  T3472.values[0] = T3472.values[0] & 7;
  { val_t __mask = -Top_hub_Queue_4__do_enq.values[0]; T3473.values[0] = Top_hub_Queue_4__enq_ptr.values[0] ^ ((Top_hub_Queue_4__enq_ptr.values[0] ^ T3472.values[0]) & __mask); }
  { Top_hub_Queue_4__enq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_4__reset.values[0], 0x0L, T3473.values[0]); }
  { T3474.values[0] = Top_hub_Queue_4__deq_ptr.values[0]+0x1L; }
  T3474.values[0] = T3474.values[0] & 7;
  T3475.values[0] = !Top_hub_Queue_4__do_flow.values[0];
  T3476.values[0] = 0x1L << T1223.values[0];
  T3477.values[0] = Top_hub_XactTracker_7__mem_cnt.values[0] == 0x3L;
  { T3478.values[0] = T1227.values[0]&&Top_hub_XactTracker_7__io_x_init_data_valid.values[0]; }
  { T3479.values[0] = T3478.values[0]&&T3477.values[0]; }
  { val_t __mask = -T3479.values[0]; T3480.values[0] = 0x0L ^ ((0x0L ^ T3476.values[0]) & __mask); }
  { T3481.values[0] = T3480.values[0]; }
  T3481.values[0] = T3481.values[0] & 3;
  { Top_hub_XactTracker_7__io_pop_x_init_dep.values[0] = T3481.values[0]; }
  T3482.values[0] = (Top_hub_XactTracker_7__io_pop_x_init_dep.values[0] >> 1) & 1;
  { T3483.values[0] = T3482.values[0]; }
  T3484.values[0] = 0x1L << T1232.values[0];
  T3485.values[0] = Top_hub_XactTracker_6__mem_cnt.values[0] == 0x3L;
  { T3486.values[0] = T1234.values[0]&&Top_hub_XactTracker_6__io_x_init_data_valid.values[0]; }
  { T3487.values[0] = T3486.values[0]&&T3485.values[0]; }
  { val_t __mask = -T3487.values[0]; T3488.values[0] = 0x0L ^ ((0x0L ^ T3484.values[0]) & __mask); }
  { T3489.values[0] = T3488.values[0]; }
  T3489.values[0] = T3489.values[0] & 3;
  { Top_hub_XactTracker_6__io_pop_x_init_dep.values[0] = T3489.values[0]; }
  T3490.values[0] = (Top_hub_XactTracker_6__io_pop_x_init_dep.values[0] >> 1) & 1;
  { T3491.values[0] = T3490.values[0]; }
  { T3492.values[0] = T3491.values[0]||T3483.values[0]; }
  T3493.values[0] = 0x1L << T1240.values[0];
  T3494.values[0] = Top_hub_XactTracker_5__mem_cnt.values[0] == 0x3L;
  { T3495.values[0] = T1242.values[0]&&Top_hub_XactTracker_5__io_x_init_data_valid.values[0]; }
  { T3496.values[0] = T3495.values[0]&&T3494.values[0]; }
  { val_t __mask = -T3496.values[0]; T3497.values[0] = 0x0L ^ ((0x0L ^ T3493.values[0]) & __mask); }
  { T3498.values[0] = T3497.values[0]; }
  T3498.values[0] = T3498.values[0] & 3;
  { Top_hub_XactTracker_5__io_pop_x_init_dep.values[0] = T3498.values[0]; }
  T3499.values[0] = (Top_hub_XactTracker_5__io_pop_x_init_dep.values[0] >> 1) & 1;
  { T3500.values[0] = T3499.values[0]; }
  { T3501.values[0] = T3500.values[0]||T3492.values[0]; }
  T3502.values[0] = 0x1L << T1248.values[0];
  T3503.values[0] = Top_hub_XactTracker_4__mem_cnt.values[0] == 0x3L;
  { T3504.values[0] = T1250.values[0]&&Top_hub_XactTracker_4__io_x_init_data_valid.values[0]; }
  { T3505.values[0] = T3504.values[0]&&T3503.values[0]; }
  { val_t __mask = -T3505.values[0]; T3506.values[0] = 0x0L ^ ((0x0L ^ T3502.values[0]) & __mask); }
  { T3507.values[0] = T3506.values[0]; }
  T3507.values[0] = T3507.values[0] & 3;
  { Top_hub_XactTracker_4__io_pop_x_init_dep.values[0] = T3507.values[0]; }
  T3508.values[0] = (Top_hub_XactTracker_4__io_pop_x_init_dep.values[0] >> 1) & 1;
  { T3509.values[0] = T3508.values[0]; }
  { T3510.values[0] = T3509.values[0]||T3501.values[0]; }
  T3511.values[0] = 0x1L << T1256.values[0];
  T3512.values[0] = Top_hub_XactTracker_3__mem_cnt.values[0] == 0x3L;
  { T3513.values[0] = T1258.values[0]&&Top_hub_XactTracker_3__io_x_init_data_valid.values[0]; }
  { T3514.values[0] = T3513.values[0]&&T3512.values[0]; }
  { val_t __mask = -T3514.values[0]; T3515.values[0] = 0x0L ^ ((0x0L ^ T3511.values[0]) & __mask); }
  { T3516.values[0] = T3515.values[0]; }
  T3516.values[0] = T3516.values[0] & 3;
  { Top_hub_XactTracker_3__io_pop_x_init_dep.values[0] = T3516.values[0]; }
  T3517.values[0] = (Top_hub_XactTracker_3__io_pop_x_init_dep.values[0] >> 1) & 1;
  { T3518.values[0] = T3517.values[0]; }
  { T3519.values[0] = T3518.values[0]||T3510.values[0]; }
  T3520.values[0] = 0x1L << T1264.values[0];
  T3521.values[0] = Top_hub_XactTracker_2__mem_cnt.values[0] == 0x3L;
  { T3522.values[0] = T1266.values[0]&&Top_hub_XactTracker_2__io_x_init_data_valid.values[0]; }
  { T3523.values[0] = T3522.values[0]&&T3521.values[0]; }
  { val_t __mask = -T3523.values[0]; T3524.values[0] = 0x0L ^ ((0x0L ^ T3520.values[0]) & __mask); }
  { T3525.values[0] = T3524.values[0]; }
  T3525.values[0] = T3525.values[0] & 3;
  { Top_hub_XactTracker_2__io_pop_x_init_dep.values[0] = T3525.values[0]; }
  T3526.values[0] = (Top_hub_XactTracker_2__io_pop_x_init_dep.values[0] >> 1) & 1;
  { T3527.values[0] = T3526.values[0]; }
  { T3528.values[0] = T3527.values[0]||T3519.values[0]; }
  T3529.values[0] = 0x1L << T1272.values[0];
  T3530.values[0] = Top_hub_XactTracker_1__mem_cnt.values[0] == 0x3L;
  { T3531.values[0] = T1274.values[0]&&Top_hub_XactTracker_1__io_x_init_data_valid.values[0]; }
  { T3532.values[0] = T3531.values[0]&&T3530.values[0]; }
  { val_t __mask = -T3532.values[0]; T3533.values[0] = 0x0L ^ ((0x0L ^ T3529.values[0]) & __mask); }
  { T3534.values[0] = T3533.values[0]; }
  T3534.values[0] = T3534.values[0] & 3;
  { Top_hub_XactTracker_1__io_pop_x_init_dep.values[0] = T3534.values[0]; }
  T3535.values[0] = (Top_hub_XactTracker_1__io_pop_x_init_dep.values[0] >> 1) & 1;
  { T3536.values[0] = T3535.values[0]; }
  { T3537.values[0] = T3536.values[0]||T3528.values[0]; }
  T3538.values[0] = 0x1L << T1280.values[0];
  T3539.values[0] = Top_hub_XactTracker__mem_cnt.values[0] == 0x3L;
  { T3540.values[0] = T1282.values[0]&&Top_hub_XactTracker__io_x_init_data_valid.values[0]; }
  { T3541.values[0] = T3540.values[0]&&T3539.values[0]; }
  { val_t __mask = -T3541.values[0]; T3542.values[0] = 0x0L ^ ((0x0L ^ T3538.values[0]) & __mask); }
  { T3543.values[0] = T3542.values[0]; }
  T3543.values[0] = T3543.values[0] & 3;
  { Top_hub_XactTracker__io_pop_x_init_dep.values[0] = T3543.values[0]; }
  T3544.values[0] = (Top_hub_XactTracker__io_pop_x_init_dep.values[0] >> 1) & 1;
  { T3545.values[0] = T3544.values[0]; }
  { T3546.values[0] = T3545.values[0]||T3537.values[0]; }
  { Top_hub_Queue_4__io_deq_ready.values[0] = T3546.values[0]; }
  { T3547.values[0] = Top_hub_Queue_4__io_deq_ready.values[0]&&Top_hub_Queue_4__io_deq_valid.values[0]; }
  { Top_hub_Queue_4__do_deq.values[0] = T3547.values[0]&&T3475.values[0]; }
  { val_t __mask = -Top_hub_Queue_4__do_deq.values[0]; T3548.values[0] = Top_hub_Queue_4__deq_ptr.values[0] ^ ((Top_hub_Queue_4__deq_ptr.values[0] ^ T3474.values[0]) & __mask); }
  { Top_hub_Queue_4__deq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_4__reset.values[0], 0x0L, T3548.values[0]); }
  T3549.values[0] = Top_hub_Queue_4__do_enq.values[0] != Top_hub_Queue_4__do_deq.values[0];
  { val_t __mask = -T3549.values[0]; T3550.values[0] = Top_hub_Queue_4__maybe_full.values[0] ^ ((Top_hub_Queue_4__maybe_full.values[0] ^ Top_hub_Queue_4__do_enq.values[0]) & __mask); }
  { Top_hub_Queue_4__maybe_full_shadow.values[0] = TERNARY(Top_hub_Queue_4__reset.values[0], 0x0L, T3550.values[0]); }
  { Top_hub_Queue_3__reset.values[0] = Top_hub__reset.values[0]; }
  { T3551.values[0] = Top_hub_Queue_3__enq_ptr.values[0]+0x1L; }
  T3551.values[0] = T3551.values[0] & 7;
  { Top_hub_Queue_3__do_flow.values[0] = 0x0L; }
  T3552.values[0] = !Top_hub_Queue_3__do_flow.values[0];
  T3553.values[0] = Top_hub__abort_state_arr_0.values[0] == 0x0L;
  T3554.values[0] = Top_hub__io_tiles_0_xact_init_bits_x_type.values[0] == 0x3L;
  { T3555.values[0] = T1580.values[0]&&T3554.values[0]; }
  { T3556.values[0] = T3555.values[0]&&T3553.values[0]; }
  { Top_hub_Queue_3__io_enq_valid.values[0] = T3556.values[0]; }
  { T3557.values[0] = Top_hub_Queue_3__io_enq_ready.values[0]&&Top_hub_Queue_3__io_enq_valid.values[0]; }
  { Top_hub_Queue_3__do_enq.values[0] = T3557.values[0]&&T3552.values[0]; }
  { val_t __mask = -Top_hub_Queue_3__do_enq.values[0]; T3558.values[0] = Top_hub_Queue_3__enq_ptr.values[0] ^ ((Top_hub_Queue_3__enq_ptr.values[0] ^ T3551.values[0]) & __mask); }
  { Top_hub_Queue_3__enq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_3__reset.values[0], 0x0L, T3558.values[0]); }
  T3559.values[0] = !Top_hub_Queue_3__do_flow.values[0];
  T3560.values[0] = (Top_hub_XactTracker_7__io_pop_x_init_dep.values[0] >> 0) & 1;
  { T3561.values[0] = T3560.values[0]; }
  T3562.values[0] = (Top_hub_XactTracker_6__io_pop_x_init_dep.values[0] >> 0) & 1;
  { T3563.values[0] = T3562.values[0]; }
  { T3564.values[0] = T3563.values[0]||T3561.values[0]; }
  T3565.values[0] = (Top_hub_XactTracker_5__io_pop_x_init_dep.values[0] >> 0) & 1;
  { T3566.values[0] = T3565.values[0]; }
  { T3567.values[0] = T3566.values[0]||T3564.values[0]; }
  T3568.values[0] = (Top_hub_XactTracker_4__io_pop_x_init_dep.values[0] >> 0) & 1;
  { T3569.values[0] = T3568.values[0]; }
  { T3570.values[0] = T3569.values[0]||T3567.values[0]; }
  T3571.values[0] = (Top_hub_XactTracker_3__io_pop_x_init_dep.values[0] >> 0) & 1;
  { T3572.values[0] = T3571.values[0]; }
  { T3573.values[0] = T3572.values[0]||T3570.values[0]; }
  T3574.values[0] = (Top_hub_XactTracker_2__io_pop_x_init_dep.values[0] >> 0) & 1;
  { T3575.values[0] = T3574.values[0]; }
  { T3576.values[0] = T3575.values[0]||T3573.values[0]; }
  T3577.values[0] = (Top_hub_XactTracker_1__io_pop_x_init_dep.values[0] >> 0) & 1;
  { T3578.values[0] = T3577.values[0]; }
  { T3579.values[0] = T3578.values[0]||T3576.values[0]; }
  T3580.values[0] = (Top_hub_XactTracker__io_pop_x_init_dep.values[0] >> 0) & 1;
  { T3581.values[0] = T3580.values[0]; }
  { T3582.values[0] = T3581.values[0]||T3579.values[0]; }
  { Top_hub_Queue_3__io_deq_ready.values[0] = T3582.values[0]; }
  { T3583.values[0] = Top_hub_Queue_3__io_deq_ready.values[0]&&Top_hub_Queue_3__io_deq_valid.values[0]; }
  { Top_hub_Queue_3__do_deq.values[0] = T3583.values[0]&&T3559.values[0]; }
  T3584.values[0] = Top_hub_Queue_3__do_enq.values[0] != Top_hub_Queue_3__do_deq.values[0];
  { val_t __mask = -T3584.values[0]; T3585.values[0] = Top_hub_Queue_3__maybe_full.values[0] ^ ((Top_hub_Queue_3__maybe_full.values[0] ^ Top_hub_Queue_3__do_enq.values[0]) & __mask); }
  { Top_hub_Queue_3__maybe_full_shadow.values[0] = TERNARY(Top_hub_Queue_3__reset.values[0], 0x0L, T3585.values[0]); }
  { T3586.values[0] = Top_hub_Queue_3__deq_ptr.values[0]+0x1L; }
  T3586.values[0] = T3586.values[0] & 7;
  { val_t __mask = -Top_hub_Queue_3__do_deq.values[0]; T3587.values[0] = Top_hub_Queue_3__deq_ptr.values[0] ^ ((Top_hub_Queue_3__deq_ptr.values[0] ^ T3586.values[0]) & __mask); }
  { Top_hub_Queue_3__deq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_3__reset.values[0], 0x0L, T3587.values[0]); }
  { T3589.values[0] = T1569.values[0]; }
  { T3590.values[0] = T1515.values[0]||T3589.values[0]; }
  { T3591.values[0] = T3590.values[0]; }
  { T3592.values[0] = T1544.values[0]; }
  { T3593.values[0] = T1483.values[0]||T3592.values[0]; }
  { T3594.values[0] = T3593.values[0]||T3591.values[0]; }
  { T3595.values[0] = T3594.values[0]; }
  { T3596.values[0] = T3593.values[0]; }
  { T3597.values[0] = T1557.values[0]; }
  { T3598.values[0] = T1499.values[0]||T3597.values[0]; }
  { T3599.values[0] = T3598.values[0]||T3596.values[0]; }
  { T3600.values[0] = T3595.values[0] | T3599.values[0] << 1; }
  { T3601.values[0] = T3600.values[0]; }
  { T3602.values[0] = T1483.values[0]; }
  { T3603.values[0] = T1499.values[0]; }
  { T3604.values[0] = T1515.values[0]; }
  { T3605.values[0] = T1530.values[0]||T3604.values[0]; }
  { T3606.values[0] = T3605.values[0]||T3603.values[0]; }
  { T3607.values[0] = T3606.values[0]||T3602.values[0]; }
  { T3608.values[0] = T3601.values[0] | T3607.values[0] << 2; }
  { T3609.values[0] = T3608.values[0]; }
  { Top_hub_Queue_3__io_enq_bits_global_xact_id.values[0] = T3609.values[0]; }
  { Top_hub_Queue_2__reset.values[0] = Top_hub__reset.values[0]; }
  { T3611.values[0] = Top_hub_Queue_2__enq_ptr.values[0]+0x1L; }
  T3611.values[0] = T3611.values[0] & 7;
  { Top_hub_Queue_2__do_flow.values[0] = 0x0L; }
  T3612.values[0] = !Top_hub_Queue_2__do_flow.values[0];
  T3613.values[0] = Top_hub__io_tiles_1_probe_rep_bits_p_type.values[0] == 0x2L;
  T3614.values[0] = Top_hub__io_tiles_1_probe_rep_bits_p_type.values[0] == 0x1L;
  T3615.values[0] = Top_hub__io_tiles_1_probe_rep_bits_p_type.values[0] == 0x0L;
  { T3616.values[0] = T3615.values[0]||T3614.values[0]; }
  { T3617.values[0] = T3616.values[0]||T3613.values[0]; }
  { Top_htif__io_mem_probe_rep_valid.values[0] = 0x0L; }
  { Top_hub__io_tiles_1_probe_rep_valid.values[0] = Top_htif__io_mem_probe_rep_valid.values[0]; }
  { T3618.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T3617.values[0]; }
  { Top_hub_Queue_2__io_enq_valid.values[0] = T3618.values[0]; }
  { Top_hub_Queue_2__full.values[0] = Top_hub_Queue_2__ptr_match.values[0]&&Top_hub_Queue_2__maybe_full.values[0]; }
  T3619.values[0] = !Top_hub_Queue_2__full.values[0];
  { Top_hub_Queue_2__io_enq_ready.values[0] = T3619.values[0]; }
  { T3620.values[0] = Top_hub_Queue_2__io_enq_ready.values[0]&&Top_hub_Queue_2__io_enq_valid.values[0]; }
  { Top_hub_Queue_2__do_enq.values[0] = T3620.values[0]&&T3612.values[0]; }
  { val_t __mask = -Top_hub_Queue_2__do_enq.values[0]; T3621.values[0] = Top_hub_Queue_2__enq_ptr.values[0] ^ ((Top_hub_Queue_2__enq_ptr.values[0] ^ T3611.values[0]) & __mask); }
  { Top_hub_Queue_2__enq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_2__reset.values[0], 0x0L, T3621.values[0]); }
  T3622.values[0] = !Top_hub_Queue_2__do_flow.values[0];
  T3623.values[0] = 0x1L << T11.values[0];
  T3624.values[0] = Top_hub_XactTracker_7__mem_cnt.values[0] == 0x3L;
  { T3625.values[0] = T709.values[0]&&Top_hub_XactTracker_7__io_p_rep_data_valid.values[0]; }
  { T3626.values[0] = T3625.values[0]&&T3624.values[0]; }
  { val_t __mask = -T3626.values[0]; T3627.values[0] = 0x0L ^ ((0x0L ^ T3623.values[0]) & __mask); }
  { T3628.values[0] = T3627.values[0]; }
  T3628.values[0] = T3628.values[0] & 3;
  { Top_hub_XactTracker_7__io_pop_p_rep_dep.values[0] = T3628.values[0]; }
  T3629.values[0] = (Top_hub_XactTracker_7__io_pop_p_rep_dep.values[0] >> 1) & 1;
  { T3630.values[0] = T3629.values[0]; }
  T3631.values[0] = 0x1L << T714.values[0];
  T3632.values[0] = Top_hub_XactTracker_6__mem_cnt.values[0] == 0x3L;
  { T3633.values[0] = T716.values[0]&&Top_hub_XactTracker_6__io_p_rep_data_valid.values[0]; }
  { T3634.values[0] = T3633.values[0]&&T3632.values[0]; }
  { val_t __mask = -T3634.values[0]; T3635.values[0] = 0x0L ^ ((0x0L ^ T3631.values[0]) & __mask); }
  { T3636.values[0] = T3635.values[0]; }
  T3636.values[0] = T3636.values[0] & 3;
  { Top_hub_XactTracker_6__io_pop_p_rep_dep.values[0] = T3636.values[0]; }
  T3637.values[0] = (Top_hub_XactTracker_6__io_pop_p_rep_dep.values[0] >> 1) & 1;
  { T3638.values[0] = T3637.values[0]; }
  { T3639.values[0] = T3638.values[0]||T3630.values[0]; }
  T3640.values[0] = 0x1L << T723.values[0];
  T3641.values[0] = Top_hub_XactTracker_5__mem_cnt.values[0] == 0x3L;
  { T3642.values[0] = T725.values[0]&&Top_hub_XactTracker_5__io_p_rep_data_valid.values[0]; }
  { T3643.values[0] = T3642.values[0]&&T3641.values[0]; }
  { val_t __mask = -T3643.values[0]; T3644.values[0] = 0x0L ^ ((0x0L ^ T3640.values[0]) & __mask); }
  { T3645.values[0] = T3644.values[0]; }
  T3645.values[0] = T3645.values[0] & 3;
  { Top_hub_XactTracker_5__io_pop_p_rep_dep.values[0] = T3645.values[0]; }
  T3646.values[0] = (Top_hub_XactTracker_5__io_pop_p_rep_dep.values[0] >> 1) & 1;
  { T3647.values[0] = T3646.values[0]; }
  { T3648.values[0] = T3647.values[0]||T3639.values[0]; }
  T3649.values[0] = 0x1L << T732.values[0];
  T3650.values[0] = Top_hub_XactTracker_4__mem_cnt.values[0] == 0x3L;
  { T3651.values[0] = T734.values[0]&&Top_hub_XactTracker_4__io_p_rep_data_valid.values[0]; }
  { T3652.values[0] = T3651.values[0]&&T3650.values[0]; }
  { val_t __mask = -T3652.values[0]; T3653.values[0] = 0x0L ^ ((0x0L ^ T3649.values[0]) & __mask); }
  { T3654.values[0] = T3653.values[0]; }
  T3654.values[0] = T3654.values[0] & 3;
  { Top_hub_XactTracker_4__io_pop_p_rep_dep.values[0] = T3654.values[0]; }
  T3655.values[0] = (Top_hub_XactTracker_4__io_pop_p_rep_dep.values[0] >> 1) & 1;
  { T3656.values[0] = T3655.values[0]; }
  { T3657.values[0] = T3656.values[0]||T3648.values[0]; }
  T3658.values[0] = 0x1L << T741.values[0];
  T3659.values[0] = Top_hub_XactTracker_3__mem_cnt.values[0] == 0x3L;
  { T3660.values[0] = T743.values[0]&&Top_hub_XactTracker_3__io_p_rep_data_valid.values[0]; }
  { T3661.values[0] = T3660.values[0]&&T3659.values[0]; }
  { val_t __mask = -T3661.values[0]; T3662.values[0] = 0x0L ^ ((0x0L ^ T3658.values[0]) & __mask); }
  { T3663.values[0] = T3662.values[0]; }
  T3663.values[0] = T3663.values[0] & 3;
  { Top_hub_XactTracker_3__io_pop_p_rep_dep.values[0] = T3663.values[0]; }
  T3664.values[0] = (Top_hub_XactTracker_3__io_pop_p_rep_dep.values[0] >> 1) & 1;
  { T3665.values[0] = T3664.values[0]; }
  { T3666.values[0] = T3665.values[0]||T3657.values[0]; }
  T3667.values[0] = 0x1L << T750.values[0];
  T3668.values[0] = Top_hub_XactTracker_2__mem_cnt.values[0] == 0x3L;
  { T3669.values[0] = T752.values[0]&&Top_hub_XactTracker_2__io_p_rep_data_valid.values[0]; }
  { T3670.values[0] = T3669.values[0]&&T3668.values[0]; }
  { val_t __mask = -T3670.values[0]; T3671.values[0] = 0x0L ^ ((0x0L ^ T3667.values[0]) & __mask); }
  { T3672.values[0] = T3671.values[0]; }
  T3672.values[0] = T3672.values[0] & 3;
  { Top_hub_XactTracker_2__io_pop_p_rep_dep.values[0] = T3672.values[0]; }
  T3673.values[0] = (Top_hub_XactTracker_2__io_pop_p_rep_dep.values[0] >> 1) & 1;
  { T3674.values[0] = T3673.values[0]; }
  { T3675.values[0] = T3674.values[0]||T3666.values[0]; }
  T3676.values[0] = 0x1L << T759.values[0];
  T3677.values[0] = Top_hub_XactTracker_1__mem_cnt.values[0] == 0x3L;
  { T3678.values[0] = T761.values[0]&&Top_hub_XactTracker_1__io_p_rep_data_valid.values[0]; }
  { T3679.values[0] = T3678.values[0]&&T3677.values[0]; }
  { val_t __mask = -T3679.values[0]; T3680.values[0] = 0x0L ^ ((0x0L ^ T3676.values[0]) & __mask); }
  { T3681.values[0] = T3680.values[0]; }
  T3681.values[0] = T3681.values[0] & 3;
  { Top_hub_XactTracker_1__io_pop_p_rep_dep.values[0] = T3681.values[0]; }
  T3682.values[0] = (Top_hub_XactTracker_1__io_pop_p_rep_dep.values[0] >> 1) & 1;
  { T3683.values[0] = T3682.values[0]; }
  { T3684.values[0] = T3683.values[0]||T3675.values[0]; }
  T3685.values[0] = 0x1L << T768.values[0];
  T3686.values[0] = Top_hub_XactTracker__mem_cnt.values[0] == 0x3L;
  { T3687.values[0] = T770.values[0]&&Top_hub_XactTracker__io_p_rep_data_valid.values[0]; }
  { T3688.values[0] = T3687.values[0]&&T3686.values[0]; }
  { val_t __mask = -T3688.values[0]; T3689.values[0] = 0x0L ^ ((0x0L ^ T3685.values[0]) & __mask); }
  { T3690.values[0] = T3689.values[0]; }
  T3690.values[0] = T3690.values[0] & 3;
  { Top_hub_XactTracker__io_pop_p_rep_dep.values[0] = T3690.values[0]; }
  T3691.values[0] = (Top_hub_XactTracker__io_pop_p_rep_dep.values[0] >> 1) & 1;
  { T3692.values[0] = T3691.values[0]; }
  { T3693.values[0] = T3692.values[0]||T3684.values[0]; }
  { Top_hub_Queue_2__io_deq_ready.values[0] = T3693.values[0]; }
  { T3694.values[0] = Top_hub_Queue_2__io_deq_ready.values[0]&&Top_hub_Queue_2__io_deq_valid.values[0]; }
  { Top_hub_Queue_2__do_deq.values[0] = T3694.values[0]&&T3622.values[0]; }
  T3695.values[0] = Top_hub_Queue_2__do_enq.values[0] != Top_hub_Queue_2__do_deq.values[0];
  { val_t __mask = -T3695.values[0]; T3696.values[0] = Top_hub_Queue_2__maybe_full.values[0] ^ ((Top_hub_Queue_2__maybe_full.values[0] ^ Top_hub_Queue_2__do_enq.values[0]) & __mask); }
  { Top_hub_Queue_2__maybe_full_shadow.values[0] = TERNARY(Top_hub_Queue_2__reset.values[0], 0x0L, T3696.values[0]); }
  { T3697.values[0] = Top_hub_Queue_2__deq_ptr.values[0]+0x1L; }
  T3697.values[0] = T3697.values[0] & 7;
  { val_t __mask = -Top_hub_Queue_2__do_deq.values[0]; T3698.values[0] = Top_hub_Queue_2__deq_ptr.values[0] ^ ((Top_hub_Queue_2__deq_ptr.values[0] ^ T3697.values[0]) & __mask); }
  { Top_hub_Queue_2__deq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_2__reset.values[0], 0x0L, T3698.values[0]); }
  { Top_hub_Queue_2__io_enq_bits_global_xact_id.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0]; }
  { Top_hub_Queue_1__reset.values[0] = Top_hub__reset.values[0]; }
  { T3701.values[0] = Top_hub_Queue_1__enq_ptr.values[0]+0x1L; }
  T3701.values[0] = T3701.values[0] & 7;
  { Top_hub_Queue_1__do_flow.values[0] = 0x0L; }
  T3702.values[0] = !Top_hub_Queue_1__do_flow.values[0];
  { T3703.values[0] = Top_Queue_21__ram.get(0x0L, 0); }
  { T3704.values[0] = T3703.values[0]; }
  T3704.values[0] = T3704.values[0] & 7;
  { T3705.values[0] = T3703.values[0] >> 3; }
  T3705.values[0] = T3705.values[0] & 7;
  { T3706.values[0] = T3704.values[0] | T3705.values[0] << 3; }
  { T3707.values[0] = T3706.values[0] >> 3; }
  T3707.values[0] = T3707.values[0] & 7;
  { Top_Queue_21__io_deq_bits_p_type.values[0] = T3707.values[0]; }
  { Top_hub__io_tiles_0_probe_rep_bits_p_type.values[0] = Top_Queue_21__io_deq_bits_p_type.values[0]; }
  T3708.values[0] = Top_hub__io_tiles_0_probe_rep_bits_p_type.values[0] == 0x2L;
  T3709.values[0] = Top_hub__io_tiles_0_probe_rep_bits_p_type.values[0] == 0x1L;
  T3710.values[0] = Top_hub__io_tiles_0_probe_rep_bits_p_type.values[0] == 0x0L;
  { T3711.values[0] = T3710.values[0]||T3709.values[0]; }
  { T3712.values[0] = T3711.values[0]||T3708.values[0]; }
  { Top_hub__io_tiles_0_probe_rep_valid.values[0] = Top_Queue_21__io_deq_valid.values[0]; }
  { T3713.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T3712.values[0]; }
  { Top_hub_Queue_1__io_enq_valid.values[0] = T3713.values[0]; }
  { Top_hub_Queue_1__full.values[0] = Top_hub_Queue_1__ptr_match.values[0]&&Top_hub_Queue_1__maybe_full.values[0]; }
  T3714.values[0] = !Top_hub_Queue_1__full.values[0];
  { Top_hub_Queue_1__io_enq_ready.values[0] = T3714.values[0]; }
  { T3715.values[0] = Top_hub_Queue_1__io_enq_ready.values[0]&&Top_hub_Queue_1__io_enq_valid.values[0]; }
  { Top_hub_Queue_1__do_enq.values[0] = T3715.values[0]&&T3702.values[0]; }
  { val_t __mask = -Top_hub_Queue_1__do_enq.values[0]; T3716.values[0] = Top_hub_Queue_1__enq_ptr.values[0] ^ ((Top_hub_Queue_1__enq_ptr.values[0] ^ T3701.values[0]) & __mask); }
  { Top_hub_Queue_1__enq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_1__reset.values[0], 0x0L, T3716.values[0]); }
  T3717.values[0] = !Top_hub_Queue_1__do_flow.values[0];
  T3718.values[0] = (Top_hub_XactTracker_7__io_pop_p_rep_dep.values[0] >> 0) & 1;
  { T3719.values[0] = T3718.values[0]; }
  T3720.values[0] = (Top_hub_XactTracker_6__io_pop_p_rep_dep.values[0] >> 0) & 1;
  { T3721.values[0] = T3720.values[0]; }
  { T3722.values[0] = T3721.values[0]||T3719.values[0]; }
  T3723.values[0] = (Top_hub_XactTracker_5__io_pop_p_rep_dep.values[0] >> 0) & 1;
  { T3724.values[0] = T3723.values[0]; }
  { T3725.values[0] = T3724.values[0]||T3722.values[0]; }
  T3726.values[0] = (Top_hub_XactTracker_4__io_pop_p_rep_dep.values[0] >> 0) & 1;
  { T3727.values[0] = T3726.values[0]; }
  { T3728.values[0] = T3727.values[0]||T3725.values[0]; }
  T3729.values[0] = (Top_hub_XactTracker_3__io_pop_p_rep_dep.values[0] >> 0) & 1;
  { T3730.values[0] = T3729.values[0]; }
  { T3731.values[0] = T3730.values[0]||T3728.values[0]; }
  T3732.values[0] = (Top_hub_XactTracker_2__io_pop_p_rep_dep.values[0] >> 0) & 1;
  { T3733.values[0] = T3732.values[0]; }
  { T3734.values[0] = T3733.values[0]||T3731.values[0]; }
  T3735.values[0] = (Top_hub_XactTracker_1__io_pop_p_rep_dep.values[0] >> 0) & 1;
  { T3736.values[0] = T3735.values[0]; }
  { T3737.values[0] = T3736.values[0]||T3734.values[0]; }
  T3738.values[0] = (Top_hub_XactTracker__io_pop_p_rep_dep.values[0] >> 0) & 1;
  { T3739.values[0] = T3738.values[0]; }
  { T3740.values[0] = T3739.values[0]||T3737.values[0]; }
  { Top_hub_Queue_1__io_deq_ready.values[0] = T3740.values[0]; }
  { T3741.values[0] = Top_hub_Queue_1__io_deq_ready.values[0]&&Top_hub_Queue_1__io_deq_valid.values[0]; }
  { Top_hub_Queue_1__do_deq.values[0] = T3741.values[0]&&T3717.values[0]; }
  T3742.values[0] = Top_hub_Queue_1__do_enq.values[0] != Top_hub_Queue_1__do_deq.values[0];
  { val_t __mask = -T3742.values[0]; T3743.values[0] = Top_hub_Queue_1__maybe_full.values[0] ^ ((Top_hub_Queue_1__maybe_full.values[0] ^ Top_hub_Queue_1__do_enq.values[0]) & __mask); }
  { Top_hub_Queue_1__maybe_full_shadow.values[0] = TERNARY(Top_hub_Queue_1__reset.values[0], 0x0L, T3743.values[0]); }
  { T3744.values[0] = Top_hub_Queue_1__deq_ptr.values[0]+0x1L; }
  T3744.values[0] = T3744.values[0] & 7;
  { val_t __mask = -Top_hub_Queue_1__do_deq.values[0]; T3745.values[0] = Top_hub_Queue_1__deq_ptr.values[0] ^ ((Top_hub_Queue_1__deq_ptr.values[0] ^ T3744.values[0]) & __mask); }
  { Top_hub_Queue_1__deq_ptr_shadow.values[0] = TERNARY(Top_hub_Queue_1__reset.values[0], 0x0L, T3745.values[0]); }
  { T3747.values[0] = T3706.values[0]; }
  T3747.values[0] = T3747.values[0] & 7;
  { Top_Queue_21__io_deq_bits_global_xact_id.values[0] = T3747.values[0]; }
  { Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0] = Top_Queue_21__io_deq_bits_global_xact_id.values[0]; }
  { Top_hub_Queue_1__io_enq_bits_global_xact_id.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0]; }
  { Top_hub_XactTracker_7__reset.values[0] = Top_hub__reset.values[0]; }
  { T3749.values[0] = Top_hub_XactTracker_7__p_rep_count.values[0] | 0x0L << 1; }
  T3750.values[0] = (Top_hub_XactTracker_7__io_alloc_req_bits_tile_id.values[0] >> 0) & 1;
  { T3751.values[0] = T3750.values[0]; }
  T3752.values[0] = 0x1L << T3751.values[0];
  { Top_hub__io_tiles_0_incoherent.values[0] = 0x1L; }
  { Top_htif__io_mem_incoherent.values[0] = 0x1L; }
  { Top_hub__io_tiles_1_incoherent.values[0] = Top_htif__io_mem_incoherent.values[0]; }
  { T3753.values[0] = Top_hub__io_tiles_0_incoherent.values[0] | Top_hub__io_tiles_1_incoherent.values[0] << 1; }
  { Top_hub_XactTracker_7__io_tile_incoherent.values[0] = T3753.values[0]; }
  { T3754.values[0] = Top_hub_XactTracker_7__io_tile_incoherent.values[0]|T3752.values[0]; }
  { T3755.values[0] = ~T3754.values[0]; }
  T3755.values[0] = T3755.values[0] & 3;
  { Top_hub_XactTracker_7__p_req_initial_flags.values[0] = T3755.values[0]; }
  T3756.values[0] = (Top_hub_XactTracker_7__p_req_initial_flags.values[0] >> 1) & 1;
  { T3757.values[0] = T3756.values[0]; }
  { T3758.values[0] = T3757.values[0]; }
  { T3759.values[0] = T3758.values[0] | 0x0L << 1; }
  { T3760.values[0] = T3759.values[0]; }
  T3761.values[0] = (Top_hub_XactTracker_7__p_req_initial_flags.values[0] >> 0) & 1;
  { T3762.values[0] = T3761.values[0]; }
  { T3763.values[0] = T3762.values[0]; }
  { T3764.values[0] = T3763.values[0] | 0x0L << 1; }
  { T3765.values[0] = T3764.values[0]+T3760.values[0]; }
  T3765.values[0] = T3765.values[0] & 3;
  { val_t __mask = -T1479.values[0]; T3766.values[0] = T3749.values[0] ^ ((T3749.values[0] ^ T3765.values[0]) & __mask); }
  T3767.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0] == 0x7L;
  { T3768.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T3767.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_7_0.values[0] = T3768.values[0]; }
  T3769.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0] == 0x7L;
  { T3770.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T3769.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_7_1.values[0] = T3770.values[0]; }
  { T3771.values[0] = Top_hub__p_rep_cnt_dec_arr_7_0.values[0] | Top_hub__p_rep_cnt_dec_arr_7_1.values[0] << 1; }
  { Top_hub_XactTracker_7__io_p_rep_cnt_dec.values[0] = T3771.values[0]; }
  T3772.values[0] = (Top_hub_XactTracker_7__io_p_rep_cnt_dec.values[0] >> 1) & 1;
  { T3773.values[0] = T3772.values[0]; }
  { T3774.values[0] = T3773.values[0]; }
  { T3775.values[0] = T3774.values[0] | 0x0L << 1; }
  { T3776.values[0] = T3775.values[0]; }
  T3777.values[0] = (Top_hub_XactTracker_7__io_p_rep_cnt_dec.values[0] >> 0) & 1;
  { T3778.values[0] = T3777.values[0]; }
  { T3779.values[0] = T3778.values[0]; }
  { T3780.values[0] = T3779.values[0] | 0x0L << 1; }
  { T3781.values[0] = T3780.values[0]+T3776.values[0]; }
  T3781.values[0] = T3781.values[0] & 3;
  { T3782.values[0] = Top_hub_XactTracker_7__p_rep_count.values[0] | 0x0L << 1; }
  { T3783.values[0] = T3782.values[0]-T3781.values[0]; }
  T3783.values[0] = T3783.values[0] & 3;
  T3784.values[0] = (Top_hub_XactTracker_7__io_p_rep_cnt_dec.values[0]) != 0;
  T3785.values[0] = Top_hub_XactTracker_7__state.values[0] == 0x3L;
  { T3786.values[0] = T3785.values[0]&&T3784.values[0]; }
  { val_t __mask = -T3786.values[0]; T3787.values[0] = T3766.values[0] ^ ((T3766.values[0] ^ T3783.values[0]) & __mask); }
  { Top_hub_XactTracker_7__p_rep_count_shadow.values[0] = TERNARY(Top_hub_XactTracker_7__reset.values[0], 0x0L, T3787.values[0]); }
  { T3788.values[0] = Top_hub_init_arb__dout.values[0] >> 41; }
  T3788.values[0] = T3788.values[0] & 3;
  { Top_hub_init_arb__io_out_bits_xact_init_x_type.values[0] = T3788.values[0]; }
  { Top_hub_XactTracker_7__io_alloc_req_bits_xact_init_x_type.values[0] = Top_hub_init_arb__io_out_bits_xact_init_x_type.values[0]; }
  { T3789.values[0] = Top_hub_XactTracker_7__io_alloc_req_bits_xact_init_x_type.values[0]; }
  T3790.values[0] = T3789.values[0] != 0x3L;
  { val_t __mask = -T1479.values[0]; T3791.values[0] = Top_hub_XactTracker_7__x_needs_read.values[0] ^ ((Top_hub_XactTracker_7__x_needs_read.values[0] ^ T3790.values[0]) & __mask); }
  { T3792.values[0] = T3304.values[0]&&Top_hub_XactTracker_7__io_mem_req_cmd_ready.values[0]; }
  { val_t __mask = -T3792.values[0]; T3793.values[0] = T3791.values[0] ^ ((T3791.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_7__x_needs_read_shadow.values[0] = TERNARY(Top_hub_XactTracker_7__reset.values[0], 0x0L, T3793.values[0]); }
  { T3794.values[0] = Top_hub_init_arb__dout.values[0] >> 2; }
  T3794.values[0] = T3794.values[0] & 17179869183;
  { Top_hub_init_arb__io_out_bits_xact_init_address.values[0] = T3794.values[0]; }
  { Top_hub_XactTracker_7__io_alloc_req_bits_xact_init_address.values[0] = Top_hub_init_arb__io_out_bits_xact_init_address.values[0]; }
  { val_t __mask = -T1479.values[0]; T3795.values[0] = Top_hub_XactTracker_7__addr_.values[0] ^ ((Top_hub_XactTracker_7__addr_.values[0] ^ Top_hub_XactTracker_7__io_alloc_req_bits_xact_init_address.values[0]) & __mask); }
  { Top_hub_XactTracker_7__addr__shadow.values[0] = T3795.values[0]; }
  { val_t __mask = -T1479.values[0]; T3796.values[0] = Top_hub_XactTracker_7__x_type_.values[0] ^ ((Top_hub_XactTracker_7__x_type_.values[0] ^ Top_hub_XactTracker_7__io_alloc_req_bits_xact_init_x_type.values[0]) & __mask); }
  { Top_hub_XactTracker_7__x_type__shadow.values[0] = T3796.values[0]; }
  { T3797.values[0] = Top_hub_init_arb__dout.values[0] >> 36; }
  T3797.values[0] = T3797.values[0] & 31;
  { Top_hub_init_arb__io_out_bits_xact_init_tile_xact_id.values[0] = T3797.values[0]; }
  { Top_hub_XactTracker_7__io_alloc_req_bits_xact_init_tile_xact_id.values[0] = Top_hub_init_arb__io_out_bits_xact_init_tile_xact_id.values[0]; }
  { val_t __mask = -T1479.values[0]; T3798.values[0] = Top_hub_XactTracker_7__tile_xact_id_.values[0] ^ ((Top_hub_XactTracker_7__tile_xact_id_.values[0] ^ Top_hub_XactTracker_7__io_alloc_req_bits_xact_init_tile_xact_id.values[0]) & __mask); }
  { Top_hub_XactTracker_7__tile_xact_id__shadow.values[0] = T3798.values[0]; }
  { T3799.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0]; }
  { T3800.values[0] = T3799.values[0]; }
  T3801.values[0] = 0x1L << T3800.values[0];
  { T3802.values[0] = T3801.values[0]; }
  T3802.values[0] = T3802.values[0] & 255;
  T3803.values[0] = (T3802.values[0] >> 7) & 1;
  { T3804.values[0] = T3803.values[0]; }
  T3805.values[0] = Top_hub__io_tiles_0_probe_rep_bits_p_type.values[0] == 0x2L;
  T3806.values[0] = Top_hub__io_tiles_0_probe_rep_bits_p_type.values[0] == 0x1L;
  T3807.values[0] = Top_hub__io_tiles_0_probe_rep_bits_p_type.values[0] == 0x0L;
  { T3808.values[0] = T3807.values[0]||T3806.values[0]; }
  { T3809.values[0] = T3808.values[0]||T3805.values[0]; }
  { T3810.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T3809.values[0]; }
  { T3811.values[0] = T3810.values[0]&&T3804.values[0]; }
  { T3812.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0]; }
  { T3813.values[0] = T3812.values[0]; }
  T3814.values[0] = 0x1L << T3813.values[0];
  { T3815.values[0] = T3814.values[0]; }
  T3815.values[0] = T3815.values[0] & 255;
  T3816.values[0] = (T3815.values[0] >> 7) & 1;
  { T3817.values[0] = T3816.values[0]; }
  T3818.values[0] = Top_hub__io_tiles_1_probe_rep_bits_p_type.values[0] == 0x2L;
  T3819.values[0] = Top_hub__io_tiles_1_probe_rep_bits_p_type.values[0] == 0x1L;
  T3820.values[0] = Top_hub__io_tiles_1_probe_rep_bits_p_type.values[0] == 0x0L;
  { T3821.values[0] = T3820.values[0]||T3819.values[0]; }
  { T3822.values[0] = T3821.values[0]||T3818.values[0]; }
  { T3823.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T3822.values[0]; }
  { T3824.values[0] = T3823.values[0]&&T3817.values[0]; }
  { val_t __mask = -T3824.values[0]; T3825.values[0] = T3811.values[0] ^ ((T3811.values[0] ^ 0x1L) & __mask); }
  { Top_hub__p_data_valid_arr_7.values[0] = T3825.values[0]; }
  { Top_hub_XactTracker_7__io_p_data_valid.values[0] = Top_hub__p_data_valid_arr_7.values[0]; }
  { T3826.values[0] = T3785.values[0]&&Top_hub_XactTracker_7__io_p_data_valid.values[0]; }
  { val_t __mask = -T3826.values[0]; T3827.values[0] = Top_hub_XactTracker_7__p_rep_data_needs_write.values[0] ^ ((Top_hub_XactTracker_7__p_rep_data_needs_write.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T3626.values[0]; T3828.values[0] = T3827.values[0] ^ ((T3827.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_7__p_rep_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_7__reset.values[0], 0x0L, T3828.values[0]); }
  T3829.values[0] = Top_hub_XactTracker_7__io_alloc_req_bits_xact_init_x_type.values[0] == 0x3L;
  { val_t __mask = -T1479.values[0]; T3830.values[0] = Top_hub_XactTracker_7__x_init_data_needs_write.values[0] ^ ((Top_hub_XactTracker_7__x_init_data_needs_write.values[0] ^ T3829.values[0]) & __mask); }
  { val_t __mask = -T3479.values[0]; T3831.values[0] = T3830.values[0] ^ ((T3830.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_7__x_init_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_7__reset.values[0], 0x0L, T3831.values[0]); }
  { val_t __mask = -T1479.values[0]; T3832.values[0] = Top_hub_XactTracker_7__x_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_7__x_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T3833.values[0] = Top_hub_XactTracker_7__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_7__io_mem_req_cmd_valid.values[0]; }
  { T3834.values[0] = T491.values[0]&&T3833.values[0]; }
  { val_t __mask = -T3834.values[0]; T3835.values[0] = T3832.values[0] ^ ((T3832.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_7__x_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_7__reset.values[0], 0x0L, T3835.values[0]); }
  { val_t __mask = -T1479.values[0]; T3836.values[0] = Top_hub_XactTracker_7__p_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_7__p_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T3837.values[0] = Top_hub_XactTracker_7__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_7__io_mem_req_cmd_valid.values[0]; }
  { T3838.values[0] = T462.values[0]&&T3837.values[0]; }
  { val_t __mask = -T3838.values[0]; T3839.values[0] = T3836.values[0] ^ ((T3836.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_7__p_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_7__reset.values[0], 0x0L, T3839.values[0]); }
  { val_t __mask = -T1479.values[0]; T3840.values[0] = Top_hub_XactTracker_7__mem_cnt.values[0] ^ ((Top_hub_XactTracker_7__mem_cnt.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_7__mem_cnt_next.values[0] = Top_hub_XactTracker_7__mem_cnt.values[0]+0x1L; }
  Top_hub_XactTracker_7__mem_cnt_next.values[0] = Top_hub_XactTracker_7__mem_cnt_next.values[0] & 3;
  { val_t __mask = -T3625.values[0]; T3841.values[0] = T3840.values[0] ^ ((T3840.values[0] ^ Top_hub_XactTracker_7__mem_cnt_next.values[0]) & __mask); }
  { val_t __mask = -T3478.values[0]; T3842.values[0] = T3841.values[0] ^ ((T3841.values[0] ^ Top_hub_XactTracker_7__mem_cnt_next.values[0]) & __mask); }
  { Top_hub_XactTracker_7__mem_cnt_shadow.values[0] = TERNARY(Top_hub_XactTracker_7__reset.values[0], 0x0L, T3842.values[0]); }
  { val_t __mask = -T1479.values[0]; T3843.values[0] = Top_hub_XactTracker_7__init_tile_id_.values[0] ^ ((Top_hub_XactTracker_7__init_tile_id_.values[0] ^ Top_hub_XactTracker_7__io_alloc_req_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_7__init_tile_id__shadow.values[0] = T3843.values[0]; }
  T3844.values[0] = (Top_hub_XactTracker_7__p_req_initial_flags.values[0]) != 0;
  { val_t __mask = -T3844.values[0]; T3845.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { val_t __mask = -T1479.values[0]; T3846.values[0] = Top_hub_XactTracker_7__state.values[0] ^ ((Top_hub_XactTracker_7__state.values[0] ^ T3845.values[0]) & __mask); }
  { T3847.values[0] = Top_hub_XactTracker_7__p_rep_count.values[0] | 0x0L << 1; }
  T3848.values[0] = T3847.values[0] == T3781.values[0];
  { T3849.values[0] = T3786.values[0]&&T3848.values[0]; }
  { val_t __mask = -T3849.values[0]; T3850.values[0] = T3846.values[0] ^ ((T3846.values[0] ^ 0x2L) & __mask); }
  { T3851.values[0] = Top_hub_XactTracker_7__x_type_.values[0]; }
  T3852.values[0] = T3851.values[0] == 0x3L;
  { val_t __mask = -T3852.values[0]; T3853.values[0] = 0x4L ^ ((0x4L ^ 0x1L) & __mask); }
  { T3854.values[0] = T3301.values[0]||Top_hub_XactTracker_7__x_needs_read.values[0]; }
  T3855.values[0] = !T3854.values[0];
  { T3856.values[0] = T461.values[0]&&T3855.values[0]; }
  { val_t __mask = -T3856.values[0]; T3857.values[0] = T3850.values[0] ^ ((T3850.values[0] ^ T3853.values[0]) & __mask); }
  { Top_hub__io_tiles_0_xact_rep_ready.values[0] = Top_Queue_18__io_enq_ready.values[0]; }
  { T3858.values[0] = T939.values[0]&&T899.values[0]; }
  { val_t __mask = -T3858.values[0]; T3859.values[0] = 0x0L ^ ((0x0L ^ Top_hub__io_tiles_0_xact_rep_ready.values[0]) & __mask); }
  { Top_htif__io_mem_xact_rep_ready.values[0] = 0x1L; }
  { Top_hub__io_tiles_1_xact_rep_ready.values[0] = Top_htif__io_mem_xact_rep_ready.values[0]; }
  T3860.values[0] = 0x1L == T936.values[0];
  { T3861.values[0] = Top_hub__mem_idx.values[0]; }
  { T3862.values[0] = T3861.values[0]; }
  T3863.values[0] = 0x1L << T3862.values[0];
  { T3864.values[0] = T3863.values[0]; }
  T3864.values[0] = T3864.values[0] & 255;
  T3865.values[0] = (T3864.values[0] >> 7) & 1;
  { T3866.values[0] = T3865.values[0]; }
  { T3867.values[0] = -T3866.values[0]; }
  T3867.values[0] = T3867.values[0] & 3;
  { T3868.values[0] = Top_hub__init_tile_id_arr_7.values[0]&T3867.values[0]; }
  T3869.values[0] = (T3864.values[0] >> 6) & 1;
  { T3870.values[0] = T3869.values[0]; }
  { T3871.values[0] = -T3870.values[0]; }
  T3871.values[0] = T3871.values[0] & 3;
  { T3872.values[0] = Top_hub__init_tile_id_arr_6.values[0]&T3871.values[0]; }
  T3873.values[0] = (T3864.values[0] >> 5) & 1;
  { T3874.values[0] = T3873.values[0]; }
  { T3875.values[0] = -T3874.values[0]; }
  T3875.values[0] = T3875.values[0] & 3;
  { T3876.values[0] = Top_hub__init_tile_id_arr_5.values[0]&T3875.values[0]; }
  T3877.values[0] = (T3864.values[0] >> 4) & 1;
  { T3878.values[0] = T3877.values[0]; }
  { T3879.values[0] = -T3878.values[0]; }
  T3879.values[0] = T3879.values[0] & 3;
  { T3880.values[0] = Top_hub__init_tile_id_arr_4.values[0]&T3879.values[0]; }
  T3881.values[0] = (T3864.values[0] >> 3) & 1;
  { T3882.values[0] = T3881.values[0]; }
  { T3883.values[0] = -T3882.values[0]; }
  T3883.values[0] = T3883.values[0] & 3;
  { T3884.values[0] = Top_hub__init_tile_id_arr_3.values[0]&T3883.values[0]; }
  T3885.values[0] = (T3864.values[0] >> 2) & 1;
  { T3886.values[0] = T3885.values[0]; }
  { T3887.values[0] = -T3886.values[0]; }
  T3887.values[0] = T3887.values[0] & 3;
  { T3888.values[0] = Top_hub__init_tile_id_arr_2.values[0]&T3887.values[0]; }
  T3889.values[0] = (T3864.values[0] >> 1) & 1;
  { T3890.values[0] = T3889.values[0]; }
  { T3891.values[0] = -T3890.values[0]; }
  T3891.values[0] = T3891.values[0] & 3;
  { T3892.values[0] = Top_hub__init_tile_id_arr_1.values[0]&T3891.values[0]; }
  T3893.values[0] = (T3864.values[0] >> 0) & 1;
  { T3894.values[0] = T3893.values[0]; }
  { T3895.values[0] = -T3894.values[0]; }
  T3895.values[0] = T3895.values[0] & 3;
  { T3896.values[0] = Top_hub__init_tile_id_arr_0.values[0]&T3895.values[0]; }
  { T3897.values[0] = T3896.values[0]|T3892.values[0]; }
  { T3898.values[0] = T3897.values[0]|T3888.values[0]; }
  { T3899.values[0] = T3898.values[0]|T3884.values[0]; }
  { T3900.values[0] = T3899.values[0]|T3880.values[0]; }
  { T3901.values[0] = T3900.values[0]|T3876.values[0]; }
  { T3902.values[0] = T3901.values[0]|T3872.values[0]; }
  { T3903.values[0] = T3902.values[0]|T3868.values[0]; }
  T3904.values[0] = 0x1L == T3903.values[0];
  { T3905.values[0] = Top_hub__io_mem_resp_valid.values[0]&&T3904.values[0]; }
  T3906.values[0] = !T3905.values[0];
  { T3907.values[0] = T3906.values[0]&&T3860.values[0]; }
  { T3908.values[0] = T3907.values[0]&&T899.values[0]; }
  { val_t __mask = -T3908.values[0]; T3909.values[0] = T3859.values[0] ^ ((T3859.values[0] ^ Top_hub__io_tiles_1_xact_rep_ready.values[0]) & __mask); }
  { Top_hub__sent_x_rep_ack_arr_7.values[0] = T3909.values[0]; }
  { Top_hub_XactTracker_7__io_sent_x_rep_ack.values[0] = Top_hub__sent_x_rep_ack_arr_7.values[0]; }
  { T3910.values[0] = T866.values[0]&&Top_hub_XactTracker_7__io_sent_x_rep_ack.values[0]; }
  { val_t __mask = -T3910.values[0]; T3911.values[0] = T3857.values[0] ^ ((T3857.values[0] ^ 0x4L) & __mask); }
  { T3912.values[0] = Top_Queue_19__ram.get(Top_Queue_19__deq_ptr.values[0], 0); }
  { T3913.values[0] = T3912.values[0]; }
  T3913.values[0] = T3913.values[0] & 7;
  { T3914.values[0] = T3913.values[0]; }
  T3914.values[0] = T3914.values[0] & 7;
  { Top_Queue_19__io_deq_bits_global_xact_id.values[0] = T3914.values[0]; }
  { Top_hub__io_tiles_0_xact_finish_bits_global_xact_id.values[0] = Top_Queue_19__io_deq_bits_global_xact_id.values[0]; }
  { T3915.values[0] = Top_hub__io_tiles_0_xact_finish_bits_global_xact_id.values[0]; }
  { T3916.values[0] = T3915.values[0]; }
  T3917.values[0] = 0x1L << T3916.values[0];
  { T3918.values[0] = T3917.values[0]; }
  T3918.values[0] = T3918.values[0] & 255;
  T3919.values[0] = (T3918.values[0] >> 7) & 1;
  { T3920.values[0] = T3919.values[0]; }
  { Top_hub__io_tiles_0_xact_finish_valid.values[0] = Top_Queue_19__io_deq_valid.values[0]; }
  { T3921.values[0] = Top_hub__io_tiles_0_xact_finish_valid.values[0]&&T3920.values[0]; }
  { Top_htif__io_mem_xact_finish_bits_global_xact_id.values[0] = Top_htif__mem_gxid.values[0]; }
  { Top_hub__io_tiles_1_xact_finish_bits_global_xact_id.values[0] = Top_htif__io_mem_xact_finish_bits_global_xact_id.values[0]; }
  { T3922.values[0] = Top_hub__io_tiles_1_xact_finish_bits_global_xact_id.values[0]; }
  { T3923.values[0] = T3922.values[0]; }
  T3924.values[0] = 0x1L << T3923.values[0];
  { T3925.values[0] = T3924.values[0]; }
  T3925.values[0] = T3925.values[0] & 255;
  T3926.values[0] = (T3925.values[0] >> 7) & 1;
  { T3927.values[0] = T3926.values[0]; }
  T3928.values[0] = Top_htif__state.values[0] == 0x7L;
  { T3929.values[0] = T3928.values[0]&&Top_htif__mem_needs_ack.values[0]; }
  { Top_htif__io_mem_xact_finish_valid.values[0] = T3929.values[0]; }
  { Top_hub__io_tiles_1_xact_finish_valid.values[0] = Top_htif__io_mem_xact_finish_valid.values[0]; }
  { T3930.values[0] = Top_hub__io_tiles_1_xact_finish_valid.values[0]&&T3927.values[0]; }
  { val_t __mask = -T3930.values[0]; T3931.values[0] = T3921.values[0] ^ ((T3921.values[0] ^ 0x1L) & __mask); }
  { Top_hub__do_free_arr_7.values[0] = T3931.values[0]; }
  { Top_hub_XactTracker_7__io_xact_finish.values[0] = Top_hub__do_free_arr_7.values[0]; }
  T3932.values[0] = Top_hub_XactTracker_7__state.values[0] == 0x4L;
  { T3933.values[0] = T3932.values[0]&&Top_hub_XactTracker_7__io_xact_finish.values[0]; }
  { val_t __mask = -T3933.values[0]; T3934.values[0] = T3911.values[0] ^ ((T3911.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_7__state_shadow.values[0] = TERNARY(Top_hub_XactTracker_7__reset.values[0], 0x0L, T3934.values[0]); }
  { T3935.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0]; }
  { T3936.values[0] = T3935.values[0]; }
  T3937.values[0] = 0x1L << T3936.values[0];
  { T3938.values[0] = T3937.values[0]; }
  T3938.values[0] = T3938.values[0] & 255;
  T3939.values[0] = (T3938.values[0] >> 7) & 1;
  { T3940.values[0] = T3939.values[0]; }
  { T3941.values[0] = T3823.values[0]&&T3940.values[0]; }
  { T3942.values[0] = T3941.values[0] | 0x0L << 1; }
  { Top_hub__p_data_tile_id_arr_7.values[0] = T3942.values[0]; }
  { Top_hub_XactTracker_7__io_p_data_bits_tile_id.values[0] = Top_hub__p_data_tile_id_arr_7.values[0]; }
  { val_t __mask = -T3826.values[0]; T3943.values[0] = Top_hub_XactTracker_7__p_rep_tile_id_.values[0] ^ ((Top_hub_XactTracker_7__p_rep_tile_id_.values[0] ^ Top_hub_XactTracker_7__io_p_data_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_7__p_rep_tile_id__shadow.values[0] = T3943.values[0]; }
  { Top_hub_XactTracker_6__reset.values[0] = Top_hub__reset.values[0]; }
  { Top_hub_XactTracker_6__io_alloc_req_bits_xact_init_x_type.values[0] = Top_hub_init_arb__io_out_bits_xact_init_x_type.values[0]; }
  { T3944.values[0] = Top_hub_XactTracker_6__io_alloc_req_bits_xact_init_x_type.values[0]; }
  T3945.values[0] = T3944.values[0] != 0x3L;
  { val_t __mask = -T1495.values[0]; T3946.values[0] = Top_hub_XactTracker_6__x_needs_read.values[0] ^ ((Top_hub_XactTracker_6__x_needs_read.values[0] ^ T3945.values[0]) & __mask); }
  { T3947.values[0] = T697.values[0]&&Top_hub_XactTracker_6__io_mem_req_cmd_ready.values[0]; }
  { val_t __mask = -T3947.values[0]; T3948.values[0] = T3946.values[0] ^ ((T3946.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_6__x_needs_read_shadow.values[0] = TERNARY(Top_hub_XactTracker_6__reset.values[0], 0x0L, T3948.values[0]); }
  { T3949.values[0] = Top_hub_XactTracker_6__p_rep_count.values[0] | 0x0L << 1; }
  T3950.values[0] = (Top_hub_XactTracker_6__io_alloc_req_bits_tile_id.values[0] >> 0) & 1;
  { T3951.values[0] = T3950.values[0]; }
  T3952.values[0] = 0x1L << T3951.values[0];
  { T3953.values[0] = Top_hub__io_tiles_0_incoherent.values[0] | Top_hub__io_tiles_1_incoherent.values[0] << 1; }
  { Top_hub_XactTracker_6__io_tile_incoherent.values[0] = T3953.values[0]; }
  { T3954.values[0] = Top_hub_XactTracker_6__io_tile_incoherent.values[0]|T3952.values[0]; }
  { T3955.values[0] = ~T3954.values[0]; }
  T3955.values[0] = T3955.values[0] & 3;
  { Top_hub_XactTracker_6__p_req_initial_flags.values[0] = T3955.values[0]; }
  T3956.values[0] = (Top_hub_XactTracker_6__p_req_initial_flags.values[0] >> 1) & 1;
  { T3957.values[0] = T3956.values[0]; }
  { T3958.values[0] = T3957.values[0]; }
  { T3959.values[0] = T3958.values[0] | 0x0L << 1; }
  { T3960.values[0] = T3959.values[0]; }
  T3961.values[0] = (Top_hub_XactTracker_6__p_req_initial_flags.values[0] >> 0) & 1;
  { T3962.values[0] = T3961.values[0]; }
  { T3963.values[0] = T3962.values[0]; }
  { T3964.values[0] = T3963.values[0] | 0x0L << 1; }
  { T3965.values[0] = T3964.values[0]+T3960.values[0]; }
  T3965.values[0] = T3965.values[0] & 3;
  { val_t __mask = -T1495.values[0]; T3966.values[0] = T3949.values[0] ^ ((T3949.values[0] ^ T3965.values[0]) & __mask); }
  T3967.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0] == 0x6L;
  { T3968.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T3967.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_6_0.values[0] = T3968.values[0]; }
  T3969.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0] == 0x6L;
  { T3970.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T3969.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_6_1.values[0] = T3970.values[0]; }
  { T3971.values[0] = Top_hub__p_rep_cnt_dec_arr_6_0.values[0] | Top_hub__p_rep_cnt_dec_arr_6_1.values[0] << 1; }
  { Top_hub_XactTracker_6__io_p_rep_cnt_dec.values[0] = T3971.values[0]; }
  T3972.values[0] = (Top_hub_XactTracker_6__io_p_rep_cnt_dec.values[0] >> 1) & 1;
  { T3973.values[0] = T3972.values[0]; }
  { T3974.values[0] = T3973.values[0]; }
  { T3975.values[0] = T3974.values[0] | 0x0L << 1; }
  { T3976.values[0] = T3975.values[0]; }
  T3977.values[0] = (Top_hub_XactTracker_6__io_p_rep_cnt_dec.values[0] >> 0) & 1;
  { T3978.values[0] = T3977.values[0]; }
  { T3979.values[0] = T3978.values[0]; }
  { T3980.values[0] = T3979.values[0] | 0x0L << 1; }
  { T3981.values[0] = T3980.values[0]+T3976.values[0]; }
  T3981.values[0] = T3981.values[0] & 3;
  { T3982.values[0] = Top_hub_XactTracker_6__p_rep_count.values[0] | 0x0L << 1; }
  { T3983.values[0] = T3982.values[0]-T3981.values[0]; }
  T3983.values[0] = T3983.values[0] & 3;
  T3984.values[0] = (Top_hub_XactTracker_6__io_p_rep_cnt_dec.values[0]) != 0;
  T3985.values[0] = Top_hub_XactTracker_6__state.values[0] == 0x3L;
  { T3986.values[0] = T3985.values[0]&&T3984.values[0]; }
  { val_t __mask = -T3986.values[0]; T3987.values[0] = T3966.values[0] ^ ((T3966.values[0] ^ T3983.values[0]) & __mask); }
  { Top_hub_XactTracker_6__p_rep_count_shadow.values[0] = TERNARY(Top_hub_XactTracker_6__reset.values[0], 0x0L, T3987.values[0]); }
  T3988.values[0] = (T3802.values[0] >> 6) & 1;
  { T3989.values[0] = T3988.values[0]; }
  { T3990.values[0] = T3810.values[0]&&T3989.values[0]; }
  T3991.values[0] = (T3815.values[0] >> 6) & 1;
  { T3992.values[0] = T3991.values[0]; }
  { T3993.values[0] = T3823.values[0]&&T3992.values[0]; }
  { val_t __mask = -T3993.values[0]; T3994.values[0] = T3990.values[0] ^ ((T3990.values[0] ^ 0x1L) & __mask); }
  { Top_hub__p_data_valid_arr_6.values[0] = T3994.values[0]; }
  { Top_hub_XactTracker_6__io_p_data_valid.values[0] = Top_hub__p_data_valid_arr_6.values[0]; }
  { T3995.values[0] = T3985.values[0]&&Top_hub_XactTracker_6__io_p_data_valid.values[0]; }
  { val_t __mask = -T3995.values[0]; T3996.values[0] = Top_hub_XactTracker_6__p_rep_data_needs_write.values[0] ^ ((Top_hub_XactTracker_6__p_rep_data_needs_write.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T3634.values[0]; T3997.values[0] = T3996.values[0] ^ ((T3996.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_6__p_rep_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_6__reset.values[0], 0x0L, T3997.values[0]); }
  T3998.values[0] = Top_hub_XactTracker_6__io_alloc_req_bits_xact_init_x_type.values[0] == 0x3L;
  { val_t __mask = -T1495.values[0]; T3999.values[0] = Top_hub_XactTracker_6__x_init_data_needs_write.values[0] ^ ((Top_hub_XactTracker_6__x_init_data_needs_write.values[0] ^ T3998.values[0]) & __mask); }
  { val_t __mask = -T3487.values[0]; T4000.values[0] = T3999.values[0] ^ ((T3999.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_6__x_init_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_6__reset.values[0], 0x0L, T4000.values[0]); }
  { val_t __mask = -T1495.values[0]; T4001.values[0] = Top_hub_XactTracker_6__x_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_6__x_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4002.values[0] = Top_hub_XactTracker_6__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_6__io_mem_req_cmd_valid.values[0]; }
  { T4003.values[0] = T434.values[0]&&T4002.values[0]; }
  { val_t __mask = -T4003.values[0]; T4004.values[0] = T4001.values[0] ^ ((T4001.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_6__x_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_6__reset.values[0], 0x0L, T4004.values[0]); }
  { Top_hub_XactTracker_6__io_alloc_req_bits_xact_init_address.values[0] = Top_hub_init_arb__io_out_bits_xact_init_address.values[0]; }
  { val_t __mask = -T1495.values[0]; T4005.values[0] = Top_hub_XactTracker_6__addr_.values[0] ^ ((Top_hub_XactTracker_6__addr_.values[0] ^ Top_hub_XactTracker_6__io_alloc_req_bits_xact_init_address.values[0]) & __mask); }
  { Top_hub_XactTracker_6__addr__shadow.values[0] = T4005.values[0]; }
  { val_t __mask = -T1495.values[0]; T4006.values[0] = Top_hub_XactTracker_6__x_type_.values[0] ^ ((Top_hub_XactTracker_6__x_type_.values[0] ^ Top_hub_XactTracker_6__io_alloc_req_bits_xact_init_x_type.values[0]) & __mask); }
  { Top_hub_XactTracker_6__x_type__shadow.values[0] = T4006.values[0]; }
  { Top_hub_XactTracker_6__io_alloc_req_bits_xact_init_tile_xact_id.values[0] = Top_hub_init_arb__io_out_bits_xact_init_tile_xact_id.values[0]; }
  { val_t __mask = -T1495.values[0]; T4007.values[0] = Top_hub_XactTracker_6__tile_xact_id_.values[0] ^ ((Top_hub_XactTracker_6__tile_xact_id_.values[0] ^ Top_hub_XactTracker_6__io_alloc_req_bits_xact_init_tile_xact_id.values[0]) & __mask); }
  { Top_hub_XactTracker_6__tile_xact_id__shadow.values[0] = T4007.values[0]; }
  { val_t __mask = -T1495.values[0]; T4008.values[0] = Top_hub_XactTracker_6__init_tile_id_.values[0] ^ ((Top_hub_XactTracker_6__init_tile_id_.values[0] ^ Top_hub_XactTracker_6__io_alloc_req_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_6__init_tile_id__shadow.values[0] = T4008.values[0]; }
  { val_t __mask = -T1495.values[0]; T4009.values[0] = Top_hub_XactTracker_6__mem_cnt.values[0] ^ ((Top_hub_XactTracker_6__mem_cnt.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_6__mem_cnt_next.values[0] = Top_hub_XactTracker_6__mem_cnt.values[0]+0x1L; }
  Top_hub_XactTracker_6__mem_cnt_next.values[0] = Top_hub_XactTracker_6__mem_cnt_next.values[0] & 3;
  { val_t __mask = -T3633.values[0]; T4010.values[0] = T4009.values[0] ^ ((T4009.values[0] ^ Top_hub_XactTracker_6__mem_cnt_next.values[0]) & __mask); }
  { val_t __mask = -T3486.values[0]; T4011.values[0] = T4010.values[0] ^ ((T4010.values[0] ^ Top_hub_XactTracker_6__mem_cnt_next.values[0]) & __mask); }
  { Top_hub_XactTracker_6__mem_cnt_shadow.values[0] = TERNARY(Top_hub_XactTracker_6__reset.values[0], 0x0L, T4011.values[0]); }
  { val_t __mask = -T1495.values[0]; T4012.values[0] = Top_hub_XactTracker_6__p_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_6__p_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4013.values[0] = Top_hub_XactTracker_6__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_6__io_mem_req_cmd_valid.values[0]; }
  { T4014.values[0] = T405.values[0]&&T4013.values[0]; }
  { val_t __mask = -T4014.values[0]; T4015.values[0] = T4012.values[0] ^ ((T4012.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_6__p_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_6__reset.values[0], 0x0L, T4015.values[0]); }
  T4016.values[0] = (Top_hub_XactTracker_6__p_req_initial_flags.values[0]) != 0;
  { val_t __mask = -T4016.values[0]; T4017.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { val_t __mask = -T1495.values[0]; T4018.values[0] = Top_hub_XactTracker_6__state.values[0] ^ ((Top_hub_XactTracker_6__state.values[0] ^ T4017.values[0]) & __mask); }
  { T4019.values[0] = Top_hub_XactTracker_6__p_rep_count.values[0] | 0x0L << 1; }
  T4020.values[0] = T4019.values[0] == T3981.values[0];
  { T4021.values[0] = T3986.values[0]&&T4020.values[0]; }
  { val_t __mask = -T4021.values[0]; T4022.values[0] = T4018.values[0] ^ ((T4018.values[0] ^ 0x2L) & __mask); }
  { T4023.values[0] = Top_hub_XactTracker_6__x_type_.values[0]; }
  T4024.values[0] = T4023.values[0] == 0x3L;
  { val_t __mask = -T4024.values[0]; T4025.values[0] = 0x4L ^ ((0x4L ^ 0x1L) & __mask); }
  { T4026.values[0] = T694.values[0]||Top_hub_XactTracker_6__x_needs_read.values[0]; }
  T4027.values[0] = !T4026.values[0];
  { T4028.values[0] = T404.values[0]&&T4027.values[0]; }
  { val_t __mask = -T4028.values[0]; T4029.values[0] = T4022.values[0] ^ ((T4022.values[0] ^ T4025.values[0]) & __mask); }
  { T4030.values[0] = T939.values[0]&&T903.values[0]; }
  { val_t __mask = -T4030.values[0]; T4031.values[0] = 0x0L ^ ((0x0L ^ Top_hub__io_tiles_0_xact_rep_ready.values[0]) & __mask); }
  { T4032.values[0] = T3907.values[0]&&T903.values[0]; }
  { val_t __mask = -T4032.values[0]; T4033.values[0] = T4031.values[0] ^ ((T4031.values[0] ^ Top_hub__io_tiles_1_xact_rep_ready.values[0]) & __mask); }
  { Top_hub__sent_x_rep_ack_arr_6.values[0] = T4033.values[0]; }
  { Top_hub_XactTracker_6__io_sent_x_rep_ack.values[0] = Top_hub__sent_x_rep_ack_arr_6.values[0]; }
  { T4034.values[0] = T865.values[0]&&Top_hub_XactTracker_6__io_sent_x_rep_ack.values[0]; }
  { val_t __mask = -T4034.values[0]; T4035.values[0] = T4029.values[0] ^ ((T4029.values[0] ^ 0x4L) & __mask); }
  T4036.values[0] = (T3918.values[0] >> 6) & 1;
  { T4037.values[0] = T4036.values[0]; }
  { T4038.values[0] = Top_hub__io_tiles_0_xact_finish_valid.values[0]&&T4037.values[0]; }
  T4039.values[0] = (T3925.values[0] >> 6) & 1;
  { T4040.values[0] = T4039.values[0]; }
  { T4041.values[0] = Top_hub__io_tiles_1_xact_finish_valid.values[0]&&T4040.values[0]; }
  { val_t __mask = -T4041.values[0]; T4042.values[0] = T4038.values[0] ^ ((T4038.values[0] ^ 0x1L) & __mask); }
  { Top_hub__do_free_arr_6.values[0] = T4042.values[0]; }
  { Top_hub_XactTracker_6__io_xact_finish.values[0] = Top_hub__do_free_arr_6.values[0]; }
  T4043.values[0] = Top_hub_XactTracker_6__state.values[0] == 0x4L;
  { T4044.values[0] = T4043.values[0]&&Top_hub_XactTracker_6__io_xact_finish.values[0]; }
  { val_t __mask = -T4044.values[0]; T4045.values[0] = T4035.values[0] ^ ((T4035.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_6__state_shadow.values[0] = TERNARY(Top_hub_XactTracker_6__reset.values[0], 0x0L, T4045.values[0]); }
  T4046.values[0] = (T3938.values[0] >> 6) & 1;
  { T4047.values[0] = T4046.values[0]; }
  { T4048.values[0] = T3823.values[0]&&T4047.values[0]; }
  { T4049.values[0] = T4048.values[0] | 0x0L << 1; }
  { Top_hub__p_data_tile_id_arr_6.values[0] = T4049.values[0]; }
  { Top_hub_XactTracker_6__io_p_data_bits_tile_id.values[0] = Top_hub__p_data_tile_id_arr_6.values[0]; }
  { val_t __mask = -T3995.values[0]; T4050.values[0] = Top_hub_XactTracker_6__p_rep_tile_id_.values[0] ^ ((Top_hub_XactTracker_6__p_rep_tile_id_.values[0] ^ Top_hub_XactTracker_6__io_p_data_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_6__p_rep_tile_id__shadow.values[0] = T4050.values[0]; }
  { Top_hub_XactTracker_5__reset.values[0] = Top_hub__reset.values[0]; }
  { T4051.values[0] = Top_hub_XactTracker_5__p_rep_count.values[0] | 0x0L << 1; }
  T4052.values[0] = (Top_hub_XactTracker_5__io_alloc_req_bits_tile_id.values[0] >> 0) & 1;
  { T4053.values[0] = T4052.values[0]; }
  T4054.values[0] = 0x1L << T4053.values[0];
  { T4055.values[0] = Top_hub__io_tiles_0_incoherent.values[0] | Top_hub__io_tiles_1_incoherent.values[0] << 1; }
  { Top_hub_XactTracker_5__io_tile_incoherent.values[0] = T4055.values[0]; }
  { T4056.values[0] = Top_hub_XactTracker_5__io_tile_incoherent.values[0]|T4054.values[0]; }
  { T4057.values[0] = ~T4056.values[0]; }
  T4057.values[0] = T4057.values[0] & 3;
  { Top_hub_XactTracker_5__p_req_initial_flags.values[0] = T4057.values[0]; }
  T4058.values[0] = (Top_hub_XactTracker_5__p_req_initial_flags.values[0] >> 1) & 1;
  { T4059.values[0] = T4058.values[0]; }
  { T4060.values[0] = T4059.values[0]; }
  { T4061.values[0] = T4060.values[0] | 0x0L << 1; }
  { T4062.values[0] = T4061.values[0]; }
  T4063.values[0] = (Top_hub_XactTracker_5__p_req_initial_flags.values[0] >> 0) & 1;
  { T4064.values[0] = T4063.values[0]; }
  { T4065.values[0] = T4064.values[0]; }
  { T4066.values[0] = T4065.values[0] | 0x0L << 1; }
  { T4067.values[0] = T4066.values[0]+T4062.values[0]; }
  T4067.values[0] = T4067.values[0] & 3;
  { val_t __mask = -T1511.values[0]; T4068.values[0] = T4051.values[0] ^ ((T4051.values[0] ^ T4067.values[0]) & __mask); }
  T4069.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0] == 0x5L;
  { T4070.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T4069.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_5_0.values[0] = T4070.values[0]; }
  T4071.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0] == 0x5L;
  { T4072.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T4071.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_5_1.values[0] = T4072.values[0]; }
  { T4073.values[0] = Top_hub__p_rep_cnt_dec_arr_5_0.values[0] | Top_hub__p_rep_cnt_dec_arr_5_1.values[0] << 1; }
  { Top_hub_XactTracker_5__io_p_rep_cnt_dec.values[0] = T4073.values[0]; }
  T4074.values[0] = (Top_hub_XactTracker_5__io_p_rep_cnt_dec.values[0] >> 1) & 1;
  { T4075.values[0] = T4074.values[0]; }
  { T4076.values[0] = T4075.values[0]; }
  { T4077.values[0] = T4076.values[0] | 0x0L << 1; }
  { T4078.values[0] = T4077.values[0]; }
  T4079.values[0] = (Top_hub_XactTracker_5__io_p_rep_cnt_dec.values[0] >> 0) & 1;
  { T4080.values[0] = T4079.values[0]; }
  { T4081.values[0] = T4080.values[0]; }
  { T4082.values[0] = T4081.values[0] | 0x0L << 1; }
  { T4083.values[0] = T4082.values[0]+T4078.values[0]; }
  T4083.values[0] = T4083.values[0] & 3;
  { T4084.values[0] = Top_hub_XactTracker_5__p_rep_count.values[0] | 0x0L << 1; }
  { T4085.values[0] = T4084.values[0]-T4083.values[0]; }
  T4085.values[0] = T4085.values[0] & 3;
  T4086.values[0] = (Top_hub_XactTracker_5__io_p_rep_cnt_dec.values[0]) != 0;
  T4087.values[0] = Top_hub_XactTracker_5__state.values[0] == 0x3L;
  { T4088.values[0] = T4087.values[0]&&T4086.values[0]; }
  { val_t __mask = -T4088.values[0]; T4089.values[0] = T4068.values[0] ^ ((T4068.values[0] ^ T4085.values[0]) & __mask); }
  { Top_hub_XactTracker_5__p_rep_count_shadow.values[0] = TERNARY(Top_hub_XactTracker_5__reset.values[0], 0x0L, T4089.values[0]); }
  { Top_hub_XactTracker_5__io_alloc_req_bits_xact_init_x_type.values[0] = Top_hub_init_arb__io_out_bits_xact_init_x_type.values[0]; }
  { T4090.values[0] = Top_hub_XactTracker_5__io_alloc_req_bits_xact_init_x_type.values[0]; }
  T4091.values[0] = T4090.values[0] != 0x3L;
  { val_t __mask = -T1511.values[0]; T4092.values[0] = Top_hub_XactTracker_5__x_needs_read.values[0] ^ ((Top_hub_XactTracker_5__x_needs_read.values[0] ^ T4091.values[0]) & __mask); }
  { T4093.values[0] = T667.values[0]&&Top_hub_XactTracker_5__io_mem_req_cmd_ready.values[0]; }
  { val_t __mask = -T4093.values[0]; T4094.values[0] = T4092.values[0] ^ ((T4092.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_5__x_needs_read_shadow.values[0] = TERNARY(Top_hub_XactTracker_5__reset.values[0], 0x0L, T4094.values[0]); }
  T4095.values[0] = Top_hub_XactTracker_5__io_alloc_req_bits_xact_init_x_type.values[0] == 0x3L;
  { val_t __mask = -T1511.values[0]; T4096.values[0] = Top_hub_XactTracker_5__x_init_data_needs_write.values[0] ^ ((Top_hub_XactTracker_5__x_init_data_needs_write.values[0] ^ T4095.values[0]) & __mask); }
  { val_t __mask = -T3496.values[0]; T4097.values[0] = T4096.values[0] ^ ((T4096.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_5__x_init_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_5__reset.values[0], 0x0L, T4097.values[0]); }
  { val_t __mask = -T1511.values[0]; T4098.values[0] = Top_hub_XactTracker_5__x_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_5__x_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4099.values[0] = Top_hub_XactTracker_5__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_5__io_mem_req_cmd_valid.values[0]; }
  { T4100.values[0] = T377.values[0]&&T4099.values[0]; }
  { val_t __mask = -T4100.values[0]; T4101.values[0] = T4098.values[0] ^ ((T4098.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_5__x_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_5__reset.values[0], 0x0L, T4101.values[0]); }
  T4102.values[0] = (T3802.values[0] >> 5) & 1;
  { T4103.values[0] = T4102.values[0]; }
  { T4104.values[0] = T3810.values[0]&&T4103.values[0]; }
  T4105.values[0] = (T3815.values[0] >> 5) & 1;
  { T4106.values[0] = T4105.values[0]; }
  { T4107.values[0] = T3823.values[0]&&T4106.values[0]; }
  { val_t __mask = -T4107.values[0]; T4108.values[0] = T4104.values[0] ^ ((T4104.values[0] ^ 0x1L) & __mask); }
  { Top_hub__p_data_valid_arr_5.values[0] = T4108.values[0]; }
  { Top_hub_XactTracker_5__io_p_data_valid.values[0] = Top_hub__p_data_valid_arr_5.values[0]; }
  { T4109.values[0] = T4087.values[0]&&Top_hub_XactTracker_5__io_p_data_valid.values[0]; }
  { val_t __mask = -T4109.values[0]; T4110.values[0] = Top_hub_XactTracker_5__p_rep_data_needs_write.values[0] ^ ((Top_hub_XactTracker_5__p_rep_data_needs_write.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T3643.values[0]; T4111.values[0] = T4110.values[0] ^ ((T4110.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_5__p_rep_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_5__reset.values[0], 0x0L, T4111.values[0]); }
  { val_t __mask = -T1511.values[0]; T4112.values[0] = Top_hub_XactTracker_5__mem_cnt.values[0] ^ ((Top_hub_XactTracker_5__mem_cnt.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_5__mem_cnt_next.values[0] = Top_hub_XactTracker_5__mem_cnt.values[0]+0x1L; }
  Top_hub_XactTracker_5__mem_cnt_next.values[0] = Top_hub_XactTracker_5__mem_cnt_next.values[0] & 3;
  { val_t __mask = -T3642.values[0]; T4113.values[0] = T4112.values[0] ^ ((T4112.values[0] ^ Top_hub_XactTracker_5__mem_cnt_next.values[0]) & __mask); }
  { val_t __mask = -T3495.values[0]; T4114.values[0] = T4113.values[0] ^ ((T4113.values[0] ^ Top_hub_XactTracker_5__mem_cnt_next.values[0]) & __mask); }
  { Top_hub_XactTracker_5__mem_cnt_shadow.values[0] = TERNARY(Top_hub_XactTracker_5__reset.values[0], 0x0L, T4114.values[0]); }
  { Top_hub_XactTracker_5__io_alloc_req_bits_xact_init_address.values[0] = Top_hub_init_arb__io_out_bits_xact_init_address.values[0]; }
  { val_t __mask = -T1511.values[0]; T4115.values[0] = Top_hub_XactTracker_5__addr_.values[0] ^ ((Top_hub_XactTracker_5__addr_.values[0] ^ Top_hub_XactTracker_5__io_alloc_req_bits_xact_init_address.values[0]) & __mask); }
  { Top_hub_XactTracker_5__addr__shadow.values[0] = T4115.values[0]; }
  { val_t __mask = -T1511.values[0]; T4116.values[0] = Top_hub_XactTracker_5__x_type_.values[0] ^ ((Top_hub_XactTracker_5__x_type_.values[0] ^ Top_hub_XactTracker_5__io_alloc_req_bits_xact_init_x_type.values[0]) & __mask); }
  { Top_hub_XactTracker_5__x_type__shadow.values[0] = T4116.values[0]; }
  { Top_hub_XactTracker_5__io_alloc_req_bits_xact_init_tile_xact_id.values[0] = Top_hub_init_arb__io_out_bits_xact_init_tile_xact_id.values[0]; }
  { val_t __mask = -T1511.values[0]; T4117.values[0] = Top_hub_XactTracker_5__tile_xact_id_.values[0] ^ ((Top_hub_XactTracker_5__tile_xact_id_.values[0] ^ Top_hub_XactTracker_5__io_alloc_req_bits_xact_init_tile_xact_id.values[0]) & __mask); }
  { Top_hub_XactTracker_5__tile_xact_id__shadow.values[0] = T4117.values[0]; }
  { val_t __mask = -T1511.values[0]; T4118.values[0] = Top_hub_XactTracker_5__init_tile_id_.values[0] ^ ((Top_hub_XactTracker_5__init_tile_id_.values[0] ^ Top_hub_XactTracker_5__io_alloc_req_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_5__init_tile_id__shadow.values[0] = T4118.values[0]; }
  { val_t __mask = -T1511.values[0]; T4119.values[0] = Top_hub_XactTracker_5__p_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_5__p_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4120.values[0] = Top_hub_XactTracker_5__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_5__io_mem_req_cmd_valid.values[0]; }
  { T4121.values[0] = T348.values[0]&&T4120.values[0]; }
  { val_t __mask = -T4121.values[0]; T4122.values[0] = T4119.values[0] ^ ((T4119.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_5__p_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_5__reset.values[0], 0x0L, T4122.values[0]); }
  T4123.values[0] = (T3938.values[0] >> 5) & 1;
  { T4124.values[0] = T4123.values[0]; }
  { T4125.values[0] = T3823.values[0]&&T4124.values[0]; }
  { T4126.values[0] = T4125.values[0] | 0x0L << 1; }
  { Top_hub__p_data_tile_id_arr_5.values[0] = T4126.values[0]; }
  { Top_hub_XactTracker_5__io_p_data_bits_tile_id.values[0] = Top_hub__p_data_tile_id_arr_5.values[0]; }
  { val_t __mask = -T4109.values[0]; T4127.values[0] = Top_hub_XactTracker_5__p_rep_tile_id_.values[0] ^ ((Top_hub_XactTracker_5__p_rep_tile_id_.values[0] ^ Top_hub_XactTracker_5__io_p_data_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_5__p_rep_tile_id__shadow.values[0] = T4127.values[0]; }
  T4128.values[0] = (Top_hub_XactTracker_5__p_req_initial_flags.values[0]) != 0;
  { val_t __mask = -T4128.values[0]; T4129.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { val_t __mask = -T1511.values[0]; T4130.values[0] = Top_hub_XactTracker_5__state.values[0] ^ ((Top_hub_XactTracker_5__state.values[0] ^ T4129.values[0]) & __mask); }
  { T4131.values[0] = Top_hub_XactTracker_5__p_rep_count.values[0] | 0x0L << 1; }
  T4132.values[0] = T4131.values[0] == T4083.values[0];
  { T4133.values[0] = T4088.values[0]&&T4132.values[0]; }
  { val_t __mask = -T4133.values[0]; T4134.values[0] = T4130.values[0] ^ ((T4130.values[0] ^ 0x2L) & __mask); }
  { T4135.values[0] = Top_hub_XactTracker_5__x_type_.values[0]; }
  T4136.values[0] = T4135.values[0] == 0x3L;
  { val_t __mask = -T4136.values[0]; T4137.values[0] = 0x4L ^ ((0x4L ^ 0x1L) & __mask); }
  { T4138.values[0] = T664.values[0]||Top_hub_XactTracker_5__x_needs_read.values[0]; }
  T4139.values[0] = !T4138.values[0];
  { T4140.values[0] = T347.values[0]&&T4139.values[0]; }
  { val_t __mask = -T4140.values[0]; T4141.values[0] = T4134.values[0] ^ ((T4134.values[0] ^ T4137.values[0]) & __mask); }
  { T4142.values[0] = T939.values[0]&&T907.values[0]; }
  { val_t __mask = -T4142.values[0]; T4143.values[0] = 0x0L ^ ((0x0L ^ Top_hub__io_tiles_0_xact_rep_ready.values[0]) & __mask); }
  { T4144.values[0] = T3907.values[0]&&T907.values[0]; }
  { val_t __mask = -T4144.values[0]; T4145.values[0] = T4143.values[0] ^ ((T4143.values[0] ^ Top_hub__io_tiles_1_xact_rep_ready.values[0]) & __mask); }
  { Top_hub__sent_x_rep_ack_arr_5.values[0] = T4145.values[0]; }
  { Top_hub_XactTracker_5__io_sent_x_rep_ack.values[0] = Top_hub__sent_x_rep_ack_arr_5.values[0]; }
  { T4146.values[0] = T864.values[0]&&Top_hub_XactTracker_5__io_sent_x_rep_ack.values[0]; }
  { val_t __mask = -T4146.values[0]; T4147.values[0] = T4141.values[0] ^ ((T4141.values[0] ^ 0x4L) & __mask); }
  T4148.values[0] = (T3918.values[0] >> 5) & 1;
  { T4149.values[0] = T4148.values[0]; }
  { T4150.values[0] = Top_hub__io_tiles_0_xact_finish_valid.values[0]&&T4149.values[0]; }
  T4151.values[0] = (T3925.values[0] >> 5) & 1;
  { T4152.values[0] = T4151.values[0]; }
  { T4153.values[0] = Top_hub__io_tiles_1_xact_finish_valid.values[0]&&T4152.values[0]; }
  { val_t __mask = -T4153.values[0]; T4154.values[0] = T4150.values[0] ^ ((T4150.values[0] ^ 0x1L) & __mask); }
  { Top_hub__do_free_arr_5.values[0] = T4154.values[0]; }
  { Top_hub_XactTracker_5__io_xact_finish.values[0] = Top_hub__do_free_arr_5.values[0]; }
  T4155.values[0] = Top_hub_XactTracker_5__state.values[0] == 0x4L;
  { T4156.values[0] = T4155.values[0]&&Top_hub_XactTracker_5__io_xact_finish.values[0]; }
  { val_t __mask = -T4156.values[0]; T4157.values[0] = T4147.values[0] ^ ((T4147.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_5__state_shadow.values[0] = TERNARY(Top_hub_XactTracker_5__reset.values[0], 0x0L, T4157.values[0]); }
  { Top_hub_XactTracker_4__reset.values[0] = Top_hub__reset.values[0]; }
  { T4158.values[0] = Top_hub_XactTracker_4__p_rep_count.values[0] | 0x0L << 1; }
  T4159.values[0] = (Top_hub_XactTracker_4__io_alloc_req_bits_tile_id.values[0] >> 0) & 1;
  { T4160.values[0] = T4159.values[0]; }
  T4161.values[0] = 0x1L << T4160.values[0];
  { T4162.values[0] = Top_hub__io_tiles_0_incoherent.values[0] | Top_hub__io_tiles_1_incoherent.values[0] << 1; }
  { Top_hub_XactTracker_4__io_tile_incoherent.values[0] = T4162.values[0]; }
  { T4163.values[0] = Top_hub_XactTracker_4__io_tile_incoherent.values[0]|T4161.values[0]; }
  { T4164.values[0] = ~T4163.values[0]; }
  T4164.values[0] = T4164.values[0] & 3;
  { Top_hub_XactTracker_4__p_req_initial_flags.values[0] = T4164.values[0]; }
  T4165.values[0] = (Top_hub_XactTracker_4__p_req_initial_flags.values[0] >> 1) & 1;
  { T4166.values[0] = T4165.values[0]; }
  { T4167.values[0] = T4166.values[0]; }
  { T4168.values[0] = T4167.values[0] | 0x0L << 1; }
  { T4169.values[0] = T4168.values[0]; }
  T4170.values[0] = (Top_hub_XactTracker_4__p_req_initial_flags.values[0] >> 0) & 1;
  { T4171.values[0] = T4170.values[0]; }
  { T4172.values[0] = T4171.values[0]; }
  { T4173.values[0] = T4172.values[0] | 0x0L << 1; }
  { T4174.values[0] = T4173.values[0]+T4169.values[0]; }
  T4174.values[0] = T4174.values[0] & 3;
  { val_t __mask = -T1526.values[0]; T4175.values[0] = T4158.values[0] ^ ((T4158.values[0] ^ T4174.values[0]) & __mask); }
  T4176.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0] == 0x4L;
  { T4177.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T4176.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_4_0.values[0] = T4177.values[0]; }
  T4178.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0] == 0x4L;
  { T4179.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T4178.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_4_1.values[0] = T4179.values[0]; }
  { T4180.values[0] = Top_hub__p_rep_cnt_dec_arr_4_0.values[0] | Top_hub__p_rep_cnt_dec_arr_4_1.values[0] << 1; }
  { Top_hub_XactTracker_4__io_p_rep_cnt_dec.values[0] = T4180.values[0]; }
  T4181.values[0] = (Top_hub_XactTracker_4__io_p_rep_cnt_dec.values[0] >> 1) & 1;
  { T4182.values[0] = T4181.values[0]; }
  { T4183.values[0] = T4182.values[0]; }
  { T4184.values[0] = T4183.values[0] | 0x0L << 1; }
  { T4185.values[0] = T4184.values[0]; }
  T4186.values[0] = (Top_hub_XactTracker_4__io_p_rep_cnt_dec.values[0] >> 0) & 1;
  { T4187.values[0] = T4186.values[0]; }
  { T4188.values[0] = T4187.values[0]; }
  { T4189.values[0] = T4188.values[0] | 0x0L << 1; }
  { T4190.values[0] = T4189.values[0]+T4185.values[0]; }
  T4190.values[0] = T4190.values[0] & 3;
  { T4191.values[0] = Top_hub_XactTracker_4__p_rep_count.values[0] | 0x0L << 1; }
  { T4192.values[0] = T4191.values[0]-T4190.values[0]; }
  T4192.values[0] = T4192.values[0] & 3;
  T4193.values[0] = (Top_hub_XactTracker_4__io_p_rep_cnt_dec.values[0]) != 0;
  T4194.values[0] = Top_hub_XactTracker_4__state.values[0] == 0x3L;
  { T4195.values[0] = T4194.values[0]&&T4193.values[0]; }
  { val_t __mask = -T4195.values[0]; T4196.values[0] = T4175.values[0] ^ ((T4175.values[0] ^ T4192.values[0]) & __mask); }
  { Top_hub_XactTracker_4__p_rep_count_shadow.values[0] = TERNARY(Top_hub_XactTracker_4__reset.values[0], 0x0L, T4196.values[0]); }
  { Top_hub_XactTracker_4__io_alloc_req_bits_xact_init_x_type.values[0] = Top_hub_init_arb__io_out_bits_xact_init_x_type.values[0]; }
  { T4197.values[0] = Top_hub_XactTracker_4__io_alloc_req_bits_xact_init_x_type.values[0]; }
  T4198.values[0] = T4197.values[0] != 0x3L;
  { val_t __mask = -T1526.values[0]; T4199.values[0] = Top_hub_XactTracker_4__x_needs_read.values[0] ^ ((Top_hub_XactTracker_4__x_needs_read.values[0] ^ T4198.values[0]) & __mask); }
  { T4200.values[0] = T638.values[0]&&Top_hub_XactTracker_4__io_mem_req_cmd_ready.values[0]; }
  { val_t __mask = -T4200.values[0]; T4201.values[0] = T4199.values[0] ^ ((T4199.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_4__x_needs_read_shadow.values[0] = TERNARY(Top_hub_XactTracker_4__reset.values[0], 0x0L, T4201.values[0]); }
  T4202.values[0] = Top_hub_XactTracker_4__io_alloc_req_bits_xact_init_x_type.values[0] == 0x3L;
  { val_t __mask = -T1526.values[0]; T4203.values[0] = Top_hub_XactTracker_4__x_init_data_needs_write.values[0] ^ ((Top_hub_XactTracker_4__x_init_data_needs_write.values[0] ^ T4202.values[0]) & __mask); }
  { val_t __mask = -T3505.values[0]; T4204.values[0] = T4203.values[0] ^ ((T4203.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_4__x_init_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_4__reset.values[0], 0x0L, T4204.values[0]); }
  { val_t __mask = -T1526.values[0]; T4205.values[0] = Top_hub_XactTracker_4__x_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_4__x_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4206.values[0] = Top_hub_XactTracker_4__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_4__io_mem_req_cmd_valid.values[0]; }
  { T4207.values[0] = T320.values[0]&&T4206.values[0]; }
  { val_t __mask = -T4207.values[0]; T4208.values[0] = T4205.values[0] ^ ((T4205.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_4__x_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_4__reset.values[0], 0x0L, T4208.values[0]); }
  T4209.values[0] = (T3802.values[0] >> 4) & 1;
  { T4210.values[0] = T4209.values[0]; }
  { T4211.values[0] = T3810.values[0]&&T4210.values[0]; }
  T4212.values[0] = (T3815.values[0] >> 4) & 1;
  { T4213.values[0] = T4212.values[0]; }
  { T4214.values[0] = T3823.values[0]&&T4213.values[0]; }
  { val_t __mask = -T4214.values[0]; T4215.values[0] = T4211.values[0] ^ ((T4211.values[0] ^ 0x1L) & __mask); }
  { Top_hub__p_data_valid_arr_4.values[0] = T4215.values[0]; }
  { Top_hub_XactTracker_4__io_p_data_valid.values[0] = Top_hub__p_data_valid_arr_4.values[0]; }
  { T4216.values[0] = T4194.values[0]&&Top_hub_XactTracker_4__io_p_data_valid.values[0]; }
  { val_t __mask = -T4216.values[0]; T4217.values[0] = Top_hub_XactTracker_4__p_rep_data_needs_write.values[0] ^ ((Top_hub_XactTracker_4__p_rep_data_needs_write.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T3652.values[0]; T4218.values[0] = T4217.values[0] ^ ((T4217.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_4__p_rep_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_4__reset.values[0], 0x0L, T4218.values[0]); }
  { val_t __mask = -T1526.values[0]; T4219.values[0] = Top_hub_XactTracker_4__mem_cnt.values[0] ^ ((Top_hub_XactTracker_4__mem_cnt.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_4__mem_cnt_next.values[0] = Top_hub_XactTracker_4__mem_cnt.values[0]+0x1L; }
  Top_hub_XactTracker_4__mem_cnt_next.values[0] = Top_hub_XactTracker_4__mem_cnt_next.values[0] & 3;
  { val_t __mask = -T3651.values[0]; T4220.values[0] = T4219.values[0] ^ ((T4219.values[0] ^ Top_hub_XactTracker_4__mem_cnt_next.values[0]) & __mask); }
  { val_t __mask = -T3504.values[0]; T4221.values[0] = T4220.values[0] ^ ((T4220.values[0] ^ Top_hub_XactTracker_4__mem_cnt_next.values[0]) & __mask); }
  { Top_hub_XactTracker_4__mem_cnt_shadow.values[0] = TERNARY(Top_hub_XactTracker_4__reset.values[0], 0x0L, T4221.values[0]); }
  { Top_hub_XactTracker_4__io_alloc_req_bits_xact_init_address.values[0] = Top_hub_init_arb__io_out_bits_xact_init_address.values[0]; }
  { val_t __mask = -T1526.values[0]; T4222.values[0] = Top_hub_XactTracker_4__addr_.values[0] ^ ((Top_hub_XactTracker_4__addr_.values[0] ^ Top_hub_XactTracker_4__io_alloc_req_bits_xact_init_address.values[0]) & __mask); }
  { Top_hub_XactTracker_4__addr__shadow.values[0] = T4222.values[0]; }
  { val_t __mask = -T1526.values[0]; T4223.values[0] = Top_hub_XactTracker_4__x_type_.values[0] ^ ((Top_hub_XactTracker_4__x_type_.values[0] ^ Top_hub_XactTracker_4__io_alloc_req_bits_xact_init_x_type.values[0]) & __mask); }
  { Top_hub_XactTracker_4__x_type__shadow.values[0] = T4223.values[0]; }
  { Top_hub_XactTracker_4__io_alloc_req_bits_xact_init_tile_xact_id.values[0] = Top_hub_init_arb__io_out_bits_xact_init_tile_xact_id.values[0]; }
  { val_t __mask = -T1526.values[0]; T4224.values[0] = Top_hub_XactTracker_4__tile_xact_id_.values[0] ^ ((Top_hub_XactTracker_4__tile_xact_id_.values[0] ^ Top_hub_XactTracker_4__io_alloc_req_bits_xact_init_tile_xact_id.values[0]) & __mask); }
  { Top_hub_XactTracker_4__tile_xact_id__shadow.values[0] = T4224.values[0]; }
  { val_t __mask = -T1526.values[0]; T4225.values[0] = Top_hub_XactTracker_4__init_tile_id_.values[0] ^ ((Top_hub_XactTracker_4__init_tile_id_.values[0] ^ Top_hub_XactTracker_4__io_alloc_req_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_4__init_tile_id__shadow.values[0] = T4225.values[0]; }
  { val_t __mask = -T1526.values[0]; T4226.values[0] = Top_hub_XactTracker_4__p_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_4__p_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4227.values[0] = Top_hub_XactTracker_4__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_4__io_mem_req_cmd_valid.values[0]; }
  { T4228.values[0] = T291.values[0]&&T4227.values[0]; }
  { val_t __mask = -T4228.values[0]; T4229.values[0] = T4226.values[0] ^ ((T4226.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_4__p_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_4__reset.values[0], 0x0L, T4229.values[0]); }
  T4230.values[0] = (T3938.values[0] >> 4) & 1;
  { T4231.values[0] = T4230.values[0]; }
  { T4232.values[0] = T3823.values[0]&&T4231.values[0]; }
  { T4233.values[0] = T4232.values[0] | 0x0L << 1; }
  { Top_hub__p_data_tile_id_arr_4.values[0] = T4233.values[0]; }
  { Top_hub_XactTracker_4__io_p_data_bits_tile_id.values[0] = Top_hub__p_data_tile_id_arr_4.values[0]; }
  { val_t __mask = -T4216.values[0]; T4234.values[0] = Top_hub_XactTracker_4__p_rep_tile_id_.values[0] ^ ((Top_hub_XactTracker_4__p_rep_tile_id_.values[0] ^ Top_hub_XactTracker_4__io_p_data_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_4__p_rep_tile_id__shadow.values[0] = T4234.values[0]; }
  T4235.values[0] = (Top_hub_XactTracker_4__p_req_initial_flags.values[0]) != 0;
  { val_t __mask = -T4235.values[0]; T4236.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { val_t __mask = -T1526.values[0]; T4237.values[0] = Top_hub_XactTracker_4__state.values[0] ^ ((Top_hub_XactTracker_4__state.values[0] ^ T4236.values[0]) & __mask); }
  { T4238.values[0] = Top_hub_XactTracker_4__p_rep_count.values[0] | 0x0L << 1; }
  T4239.values[0] = T4238.values[0] == T4190.values[0];
  { T4240.values[0] = T4195.values[0]&&T4239.values[0]; }
  { val_t __mask = -T4240.values[0]; T4241.values[0] = T4237.values[0] ^ ((T4237.values[0] ^ 0x2L) & __mask); }
  { T4242.values[0] = Top_hub_XactTracker_4__x_type_.values[0]; }
  T4243.values[0] = T4242.values[0] == 0x3L;
  { val_t __mask = -T4243.values[0]; T4244.values[0] = 0x4L ^ ((0x4L ^ 0x1L) & __mask); }
  { T4245.values[0] = T635.values[0]||Top_hub_XactTracker_4__x_needs_read.values[0]; }
  T4246.values[0] = !T4245.values[0];
  { T4247.values[0] = T290.values[0]&&T4246.values[0]; }
  { val_t __mask = -T4247.values[0]; T4248.values[0] = T4241.values[0] ^ ((T4241.values[0] ^ T4244.values[0]) & __mask); }
  { T4249.values[0] = T939.values[0]&&T911.values[0]; }
  { val_t __mask = -T4249.values[0]; T4250.values[0] = 0x0L ^ ((0x0L ^ Top_hub__io_tiles_0_xact_rep_ready.values[0]) & __mask); }
  { T4251.values[0] = T3907.values[0]&&T911.values[0]; }
  { val_t __mask = -T4251.values[0]; T4252.values[0] = T4250.values[0] ^ ((T4250.values[0] ^ Top_hub__io_tiles_1_xact_rep_ready.values[0]) & __mask); }
  { Top_hub__sent_x_rep_ack_arr_4.values[0] = T4252.values[0]; }
  { Top_hub_XactTracker_4__io_sent_x_rep_ack.values[0] = Top_hub__sent_x_rep_ack_arr_4.values[0]; }
  { T4253.values[0] = T863.values[0]&&Top_hub_XactTracker_4__io_sent_x_rep_ack.values[0]; }
  { val_t __mask = -T4253.values[0]; T4254.values[0] = T4248.values[0] ^ ((T4248.values[0] ^ 0x4L) & __mask); }
  T4255.values[0] = (T3918.values[0] >> 4) & 1;
  { T4256.values[0] = T4255.values[0]; }
  { T4257.values[0] = Top_hub__io_tiles_0_xact_finish_valid.values[0]&&T4256.values[0]; }
  T4258.values[0] = (T3925.values[0] >> 4) & 1;
  { T4259.values[0] = T4258.values[0]; }
  { T4260.values[0] = Top_hub__io_tiles_1_xact_finish_valid.values[0]&&T4259.values[0]; }
  { val_t __mask = -T4260.values[0]; T4261.values[0] = T4257.values[0] ^ ((T4257.values[0] ^ 0x1L) & __mask); }
  { Top_hub__do_free_arr_4.values[0] = T4261.values[0]; }
  { Top_hub_XactTracker_4__io_xact_finish.values[0] = Top_hub__do_free_arr_4.values[0]; }
  T4262.values[0] = Top_hub_XactTracker_4__state.values[0] == 0x4L;
  { T4263.values[0] = T4262.values[0]&&Top_hub_XactTracker_4__io_xact_finish.values[0]; }
  { val_t __mask = -T4263.values[0]; T4264.values[0] = T4254.values[0] ^ ((T4254.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_4__state_shadow.values[0] = TERNARY(Top_hub_XactTracker_4__reset.values[0], 0x0L, T4264.values[0]); }
  { Top_hub_XactTracker_3__reset.values[0] = Top_hub__reset.values[0]; }
  { T4265.values[0] = Top_hub_XactTracker_3__p_rep_count.values[0] | 0x0L << 1; }
  T4266.values[0] = (Top_hub_XactTracker_3__io_alloc_req_bits_tile_id.values[0] >> 0) & 1;
  { T4267.values[0] = T4266.values[0]; }
  T4268.values[0] = 0x1L << T4267.values[0];
  { T4269.values[0] = Top_hub__io_tiles_0_incoherent.values[0] | Top_hub__io_tiles_1_incoherent.values[0] << 1; }
  { Top_hub_XactTracker_3__io_tile_incoherent.values[0] = T4269.values[0]; }
  { T4270.values[0] = Top_hub_XactTracker_3__io_tile_incoherent.values[0]|T4268.values[0]; }
  { T4271.values[0] = ~T4270.values[0]; }
  T4271.values[0] = T4271.values[0] & 3;
  { Top_hub_XactTracker_3__p_req_initial_flags.values[0] = T4271.values[0]; }
  T4272.values[0] = (Top_hub_XactTracker_3__p_req_initial_flags.values[0] >> 1) & 1;
  { T4273.values[0] = T4272.values[0]; }
  { T4274.values[0] = T4273.values[0]; }
  { T4275.values[0] = T4274.values[0] | 0x0L << 1; }
  { T4276.values[0] = T4275.values[0]; }
  T4277.values[0] = (Top_hub_XactTracker_3__p_req_initial_flags.values[0] >> 0) & 1;
  { T4278.values[0] = T4277.values[0]; }
  { T4279.values[0] = T4278.values[0]; }
  { T4280.values[0] = T4279.values[0] | 0x0L << 1; }
  { T4281.values[0] = T4280.values[0]+T4276.values[0]; }
  T4281.values[0] = T4281.values[0] & 3;
  { val_t __mask = -T1540.values[0]; T4282.values[0] = T4265.values[0] ^ ((T4265.values[0] ^ T4281.values[0]) & __mask); }
  T4283.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0] == 0x3L;
  { T4284.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T4283.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_3_0.values[0] = T4284.values[0]; }
  T4285.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0] == 0x3L;
  { T4286.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T4285.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_3_1.values[0] = T4286.values[0]; }
  { T4287.values[0] = Top_hub__p_rep_cnt_dec_arr_3_0.values[0] | Top_hub__p_rep_cnt_dec_arr_3_1.values[0] << 1; }
  { Top_hub_XactTracker_3__io_p_rep_cnt_dec.values[0] = T4287.values[0]; }
  T4288.values[0] = (Top_hub_XactTracker_3__io_p_rep_cnt_dec.values[0] >> 1) & 1;
  { T4289.values[0] = T4288.values[0]; }
  { T4290.values[0] = T4289.values[0]; }
  { T4291.values[0] = T4290.values[0] | 0x0L << 1; }
  { T4292.values[0] = T4291.values[0]; }
  T4293.values[0] = (Top_hub_XactTracker_3__io_p_rep_cnt_dec.values[0] >> 0) & 1;
  { T4294.values[0] = T4293.values[0]; }
  { T4295.values[0] = T4294.values[0]; }
  { T4296.values[0] = T4295.values[0] | 0x0L << 1; }
  { T4297.values[0] = T4296.values[0]+T4292.values[0]; }
  T4297.values[0] = T4297.values[0] & 3;
  { T4298.values[0] = Top_hub_XactTracker_3__p_rep_count.values[0] | 0x0L << 1; }
  { T4299.values[0] = T4298.values[0]-T4297.values[0]; }
  T4299.values[0] = T4299.values[0] & 3;
  T4300.values[0] = (Top_hub_XactTracker_3__io_p_rep_cnt_dec.values[0]) != 0;
  T4301.values[0] = Top_hub_XactTracker_3__state.values[0] == 0x3L;
  { T4302.values[0] = T4301.values[0]&&T4300.values[0]; }
  { val_t __mask = -T4302.values[0]; T4303.values[0] = T4282.values[0] ^ ((T4282.values[0] ^ T4299.values[0]) & __mask); }
  { Top_hub_XactTracker_3__p_rep_count_shadow.values[0] = TERNARY(Top_hub_XactTracker_3__reset.values[0], 0x0L, T4303.values[0]); }
  { Top_hub_XactTracker_3__io_alloc_req_bits_xact_init_x_type.values[0] = Top_hub_init_arb__io_out_bits_xact_init_x_type.values[0]; }
  { T4304.values[0] = Top_hub_XactTracker_3__io_alloc_req_bits_xact_init_x_type.values[0]; }
  T4305.values[0] = T4304.values[0] != 0x3L;
  { val_t __mask = -T1540.values[0]; T4306.values[0] = Top_hub_XactTracker_3__x_needs_read.values[0] ^ ((Top_hub_XactTracker_3__x_needs_read.values[0] ^ T4305.values[0]) & __mask); }
  { T4307.values[0] = T610.values[0]&&Top_hub_XactTracker_3__io_mem_req_cmd_ready.values[0]; }
  { val_t __mask = -T4307.values[0]; T4308.values[0] = T4306.values[0] ^ ((T4306.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_3__x_needs_read_shadow.values[0] = TERNARY(Top_hub_XactTracker_3__reset.values[0], 0x0L, T4308.values[0]); }
  T4309.values[0] = Top_hub_XactTracker_3__io_alloc_req_bits_xact_init_x_type.values[0] == 0x3L;
  { val_t __mask = -T1540.values[0]; T4310.values[0] = Top_hub_XactTracker_3__x_init_data_needs_write.values[0] ^ ((Top_hub_XactTracker_3__x_init_data_needs_write.values[0] ^ T4309.values[0]) & __mask); }
  { val_t __mask = -T3514.values[0]; T4311.values[0] = T4310.values[0] ^ ((T4310.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_3__x_init_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_3__reset.values[0], 0x0L, T4311.values[0]); }
  { val_t __mask = -T1540.values[0]; T4312.values[0] = Top_hub_XactTracker_3__x_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_3__x_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4313.values[0] = Top_hub_XactTracker_3__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_3__io_mem_req_cmd_valid.values[0]; }
  { T4314.values[0] = T263.values[0]&&T4313.values[0]; }
  { val_t __mask = -T4314.values[0]; T4315.values[0] = T4312.values[0] ^ ((T4312.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_3__x_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_3__reset.values[0], 0x0L, T4315.values[0]); }
  T4316.values[0] = (T3802.values[0] >> 3) & 1;
  { T4317.values[0] = T4316.values[0]; }
  { T4318.values[0] = T3810.values[0]&&T4317.values[0]; }
  T4319.values[0] = (T3815.values[0] >> 3) & 1;
  { T4320.values[0] = T4319.values[0]; }
  { T4321.values[0] = T3823.values[0]&&T4320.values[0]; }
  { val_t __mask = -T4321.values[0]; T4322.values[0] = T4318.values[0] ^ ((T4318.values[0] ^ 0x1L) & __mask); }
  { Top_hub__p_data_valid_arr_3.values[0] = T4322.values[0]; }
  { Top_hub_XactTracker_3__io_p_data_valid.values[0] = Top_hub__p_data_valid_arr_3.values[0]; }
  { T4323.values[0] = T4301.values[0]&&Top_hub_XactTracker_3__io_p_data_valid.values[0]; }
  { val_t __mask = -T4323.values[0]; T4324.values[0] = Top_hub_XactTracker_3__p_rep_data_needs_write.values[0] ^ ((Top_hub_XactTracker_3__p_rep_data_needs_write.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T3661.values[0]; T4325.values[0] = T4324.values[0] ^ ((T4324.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_3__p_rep_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_3__reset.values[0], 0x0L, T4325.values[0]); }
  { val_t __mask = -T1540.values[0]; T4326.values[0] = Top_hub_XactTracker_3__mem_cnt.values[0] ^ ((Top_hub_XactTracker_3__mem_cnt.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_3__mem_cnt_next.values[0] = Top_hub_XactTracker_3__mem_cnt.values[0]+0x1L; }
  Top_hub_XactTracker_3__mem_cnt_next.values[0] = Top_hub_XactTracker_3__mem_cnt_next.values[0] & 3;
  { val_t __mask = -T3660.values[0]; T4327.values[0] = T4326.values[0] ^ ((T4326.values[0] ^ Top_hub_XactTracker_3__mem_cnt_next.values[0]) & __mask); }
  { val_t __mask = -T3513.values[0]; T4328.values[0] = T4327.values[0] ^ ((T4327.values[0] ^ Top_hub_XactTracker_3__mem_cnt_next.values[0]) & __mask); }
  { Top_hub_XactTracker_3__mem_cnt_shadow.values[0] = TERNARY(Top_hub_XactTracker_3__reset.values[0], 0x0L, T4328.values[0]); }
  { Top_hub_XactTracker_3__io_alloc_req_bits_xact_init_address.values[0] = Top_hub_init_arb__io_out_bits_xact_init_address.values[0]; }
  { val_t __mask = -T1540.values[0]; T4329.values[0] = Top_hub_XactTracker_3__addr_.values[0] ^ ((Top_hub_XactTracker_3__addr_.values[0] ^ Top_hub_XactTracker_3__io_alloc_req_bits_xact_init_address.values[0]) & __mask); }
  { Top_hub_XactTracker_3__addr__shadow.values[0] = T4329.values[0]; }
  { val_t __mask = -T1540.values[0]; T4330.values[0] = Top_hub_XactTracker_3__x_type_.values[0] ^ ((Top_hub_XactTracker_3__x_type_.values[0] ^ Top_hub_XactTracker_3__io_alloc_req_bits_xact_init_x_type.values[0]) & __mask); }
  { Top_hub_XactTracker_3__x_type__shadow.values[0] = T4330.values[0]; }
  { Top_hub_XactTracker_3__io_alloc_req_bits_xact_init_tile_xact_id.values[0] = Top_hub_init_arb__io_out_bits_xact_init_tile_xact_id.values[0]; }
  { val_t __mask = -T1540.values[0]; T4331.values[0] = Top_hub_XactTracker_3__tile_xact_id_.values[0] ^ ((Top_hub_XactTracker_3__tile_xact_id_.values[0] ^ Top_hub_XactTracker_3__io_alloc_req_bits_xact_init_tile_xact_id.values[0]) & __mask); }
  { Top_hub_XactTracker_3__tile_xact_id__shadow.values[0] = T4331.values[0]; }
  { val_t __mask = -T1540.values[0]; T4332.values[0] = Top_hub_XactTracker_3__init_tile_id_.values[0] ^ ((Top_hub_XactTracker_3__init_tile_id_.values[0] ^ Top_hub_XactTracker_3__io_alloc_req_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_3__init_tile_id__shadow.values[0] = T4332.values[0]; }
  { val_t __mask = -T1540.values[0]; T4333.values[0] = Top_hub_XactTracker_3__p_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_3__p_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4334.values[0] = Top_hub_XactTracker_3__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_3__io_mem_req_cmd_valid.values[0]; }
  { T4335.values[0] = T234.values[0]&&T4334.values[0]; }
  { val_t __mask = -T4335.values[0]; T4336.values[0] = T4333.values[0] ^ ((T4333.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_3__p_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_3__reset.values[0], 0x0L, T4336.values[0]); }
  T4337.values[0] = (T3938.values[0] >> 3) & 1;
  { T4338.values[0] = T4337.values[0]; }
  { T4339.values[0] = T3823.values[0]&&T4338.values[0]; }
  { T4340.values[0] = T4339.values[0] | 0x0L << 1; }
  { Top_hub__p_data_tile_id_arr_3.values[0] = T4340.values[0]; }
  { Top_hub_XactTracker_3__io_p_data_bits_tile_id.values[0] = Top_hub__p_data_tile_id_arr_3.values[0]; }
  { val_t __mask = -T4323.values[0]; T4341.values[0] = Top_hub_XactTracker_3__p_rep_tile_id_.values[0] ^ ((Top_hub_XactTracker_3__p_rep_tile_id_.values[0] ^ Top_hub_XactTracker_3__io_p_data_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_3__p_rep_tile_id__shadow.values[0] = T4341.values[0]; }
  T4342.values[0] = (Top_hub_XactTracker_3__p_req_initial_flags.values[0]) != 0;
  { val_t __mask = -T4342.values[0]; T4343.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { val_t __mask = -T1540.values[0]; T4344.values[0] = Top_hub_XactTracker_3__state.values[0] ^ ((Top_hub_XactTracker_3__state.values[0] ^ T4343.values[0]) & __mask); }
  { T4345.values[0] = Top_hub_XactTracker_3__p_rep_count.values[0] | 0x0L << 1; }
  T4346.values[0] = T4345.values[0] == T4297.values[0];
  { T4347.values[0] = T4302.values[0]&&T4346.values[0]; }
  { val_t __mask = -T4347.values[0]; T4348.values[0] = T4344.values[0] ^ ((T4344.values[0] ^ 0x2L) & __mask); }
  { T4349.values[0] = Top_hub_XactTracker_3__x_type_.values[0]; }
  T4350.values[0] = T4349.values[0] == 0x3L;
  { val_t __mask = -T4350.values[0]; T4351.values[0] = 0x4L ^ ((0x4L ^ 0x1L) & __mask); }
  { T4352.values[0] = T607.values[0]||Top_hub_XactTracker_3__x_needs_read.values[0]; }
  T4353.values[0] = !T4352.values[0];
  { T4354.values[0] = T233.values[0]&&T4353.values[0]; }
  { val_t __mask = -T4354.values[0]; T4355.values[0] = T4348.values[0] ^ ((T4348.values[0] ^ T4351.values[0]) & __mask); }
  { T4356.values[0] = T939.values[0]&&T915.values[0]; }
  { val_t __mask = -T4356.values[0]; T4357.values[0] = 0x0L ^ ((0x0L ^ Top_hub__io_tiles_0_xact_rep_ready.values[0]) & __mask); }
  { T4358.values[0] = T3907.values[0]&&T915.values[0]; }
  { val_t __mask = -T4358.values[0]; T4359.values[0] = T4357.values[0] ^ ((T4357.values[0] ^ Top_hub__io_tiles_1_xact_rep_ready.values[0]) & __mask); }
  { Top_hub__sent_x_rep_ack_arr_3.values[0] = T4359.values[0]; }
  { Top_hub_XactTracker_3__io_sent_x_rep_ack.values[0] = Top_hub__sent_x_rep_ack_arr_3.values[0]; }
  { T4360.values[0] = T862.values[0]&&Top_hub_XactTracker_3__io_sent_x_rep_ack.values[0]; }
  { val_t __mask = -T4360.values[0]; T4361.values[0] = T4355.values[0] ^ ((T4355.values[0] ^ 0x4L) & __mask); }
  T4362.values[0] = (T3918.values[0] >> 3) & 1;
  { T4363.values[0] = T4362.values[0]; }
  { T4364.values[0] = Top_hub__io_tiles_0_xact_finish_valid.values[0]&&T4363.values[0]; }
  T4365.values[0] = (T3925.values[0] >> 3) & 1;
  { T4366.values[0] = T4365.values[0]; }
  { T4367.values[0] = Top_hub__io_tiles_1_xact_finish_valid.values[0]&&T4366.values[0]; }
  { val_t __mask = -T4367.values[0]; T4368.values[0] = T4364.values[0] ^ ((T4364.values[0] ^ 0x1L) & __mask); }
  { Top_hub__do_free_arr_3.values[0] = T4368.values[0]; }
  { Top_hub_XactTracker_3__io_xact_finish.values[0] = Top_hub__do_free_arr_3.values[0]; }
  T4369.values[0] = Top_hub_XactTracker_3__state.values[0] == 0x4L;
  { T4370.values[0] = T4369.values[0]&&Top_hub_XactTracker_3__io_xact_finish.values[0]; }
  { val_t __mask = -T4370.values[0]; T4371.values[0] = T4361.values[0] ^ ((T4361.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_3__state_shadow.values[0] = TERNARY(Top_hub_XactTracker_3__reset.values[0], 0x0L, T4371.values[0]); }
  { Top_hub_XactTracker_2__reset.values[0] = Top_hub__reset.values[0]; }
  { T4372.values[0] = Top_hub_XactTracker_2__p_rep_count.values[0] | 0x0L << 1; }
  T4373.values[0] = (Top_hub_XactTracker_2__io_alloc_req_bits_tile_id.values[0] >> 0) & 1;
  { T4374.values[0] = T4373.values[0]; }
  T4375.values[0] = 0x1L << T4374.values[0];
  { T4376.values[0] = Top_hub__io_tiles_0_incoherent.values[0] | Top_hub__io_tiles_1_incoherent.values[0] << 1; }
  { Top_hub_XactTracker_2__io_tile_incoherent.values[0] = T4376.values[0]; }
  { T4377.values[0] = Top_hub_XactTracker_2__io_tile_incoherent.values[0]|T4375.values[0]; }
  { T4378.values[0] = ~T4377.values[0]; }
  T4378.values[0] = T4378.values[0] & 3;
  { Top_hub_XactTracker_2__p_req_initial_flags.values[0] = T4378.values[0]; }
  T4379.values[0] = (Top_hub_XactTracker_2__p_req_initial_flags.values[0] >> 1) & 1;
  { T4380.values[0] = T4379.values[0]; }
  { T4381.values[0] = T4380.values[0]; }
  { T4382.values[0] = T4381.values[0] | 0x0L << 1; }
  { T4383.values[0] = T4382.values[0]; }
  T4384.values[0] = (Top_hub_XactTracker_2__p_req_initial_flags.values[0] >> 0) & 1;
  { T4385.values[0] = T4384.values[0]; }
  { T4386.values[0] = T4385.values[0]; }
  { T4387.values[0] = T4386.values[0] | 0x0L << 1; }
  { T4388.values[0] = T4387.values[0]+T4383.values[0]; }
  T4388.values[0] = T4388.values[0] & 3;
  { val_t __mask = -T1553.values[0]; T4389.values[0] = T4372.values[0] ^ ((T4372.values[0] ^ T4388.values[0]) & __mask); }
  T4390.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0] == 0x2L;
  { T4391.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T4390.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_2_0.values[0] = T4391.values[0]; }
  T4392.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0] == 0x2L;
  { T4393.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T4392.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_2_1.values[0] = T4393.values[0]; }
  { T4394.values[0] = Top_hub__p_rep_cnt_dec_arr_2_0.values[0] | Top_hub__p_rep_cnt_dec_arr_2_1.values[0] << 1; }
  { Top_hub_XactTracker_2__io_p_rep_cnt_dec.values[0] = T4394.values[0]; }
  T4395.values[0] = (Top_hub_XactTracker_2__io_p_rep_cnt_dec.values[0] >> 1) & 1;
  { T4396.values[0] = T4395.values[0]; }
  { T4397.values[0] = T4396.values[0]; }
  { T4398.values[0] = T4397.values[0] | 0x0L << 1; }
  { T4399.values[0] = T4398.values[0]; }
  T4400.values[0] = (Top_hub_XactTracker_2__io_p_rep_cnt_dec.values[0] >> 0) & 1;
  { T4401.values[0] = T4400.values[0]; }
  { T4402.values[0] = T4401.values[0]; }
  { T4403.values[0] = T4402.values[0] | 0x0L << 1; }
  { T4404.values[0] = T4403.values[0]+T4399.values[0]; }
  T4404.values[0] = T4404.values[0] & 3;
  { T4405.values[0] = Top_hub_XactTracker_2__p_rep_count.values[0] | 0x0L << 1; }
  { T4406.values[0] = T4405.values[0]-T4404.values[0]; }
  T4406.values[0] = T4406.values[0] & 3;
  T4407.values[0] = (Top_hub_XactTracker_2__io_p_rep_cnt_dec.values[0]) != 0;
  T4408.values[0] = Top_hub_XactTracker_2__state.values[0] == 0x3L;
  { T4409.values[0] = T4408.values[0]&&T4407.values[0]; }
  { val_t __mask = -T4409.values[0]; T4410.values[0] = T4389.values[0] ^ ((T4389.values[0] ^ T4406.values[0]) & __mask); }
  { Top_hub_XactTracker_2__p_rep_count_shadow.values[0] = TERNARY(Top_hub_XactTracker_2__reset.values[0], 0x0L, T4410.values[0]); }
  { Top_hub_XactTracker_2__io_alloc_req_bits_xact_init_x_type.values[0] = Top_hub_init_arb__io_out_bits_xact_init_x_type.values[0]; }
  { T4411.values[0] = Top_hub_XactTracker_2__io_alloc_req_bits_xact_init_x_type.values[0]; }
  T4412.values[0] = T4411.values[0] != 0x3L;
  { val_t __mask = -T1553.values[0]; T4413.values[0] = Top_hub_XactTracker_2__x_needs_read.values[0] ^ ((Top_hub_XactTracker_2__x_needs_read.values[0] ^ T4412.values[0]) & __mask); }
  { T4414.values[0] = T583.values[0]&&Top_hub_XactTracker_2__io_mem_req_cmd_ready.values[0]; }
  { val_t __mask = -T4414.values[0]; T4415.values[0] = T4413.values[0] ^ ((T4413.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_2__x_needs_read_shadow.values[0] = TERNARY(Top_hub_XactTracker_2__reset.values[0], 0x0L, T4415.values[0]); }
  T4416.values[0] = Top_hub_XactTracker_2__io_alloc_req_bits_xact_init_x_type.values[0] == 0x3L;
  { val_t __mask = -T1553.values[0]; T4417.values[0] = Top_hub_XactTracker_2__x_init_data_needs_write.values[0] ^ ((Top_hub_XactTracker_2__x_init_data_needs_write.values[0] ^ T4416.values[0]) & __mask); }
  { val_t __mask = -T3523.values[0]; T4418.values[0] = T4417.values[0] ^ ((T4417.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_2__x_init_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_2__reset.values[0], 0x0L, T4418.values[0]); }
  { val_t __mask = -T1553.values[0]; T4419.values[0] = Top_hub_XactTracker_2__x_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_2__x_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4420.values[0] = Top_hub_XactTracker_2__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_2__io_mem_req_cmd_valid.values[0]; }
  { T4421.values[0] = T206.values[0]&&T4420.values[0]; }
  { val_t __mask = -T4421.values[0]; T4422.values[0] = T4419.values[0] ^ ((T4419.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_2__x_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_2__reset.values[0], 0x0L, T4422.values[0]); }
  T4423.values[0] = (T3802.values[0] >> 2) & 1;
  { T4424.values[0] = T4423.values[0]; }
  { T4425.values[0] = T3810.values[0]&&T4424.values[0]; }
  T4426.values[0] = (T3815.values[0] >> 2) & 1;
  { T4427.values[0] = T4426.values[0]; }
  { T4428.values[0] = T3823.values[0]&&T4427.values[0]; }
  { val_t __mask = -T4428.values[0]; T4429.values[0] = T4425.values[0] ^ ((T4425.values[0] ^ 0x1L) & __mask); }
  { Top_hub__p_data_valid_arr_2.values[0] = T4429.values[0]; }
  { Top_hub_XactTracker_2__io_p_data_valid.values[0] = Top_hub__p_data_valid_arr_2.values[0]; }
  { T4430.values[0] = T4408.values[0]&&Top_hub_XactTracker_2__io_p_data_valid.values[0]; }
  { val_t __mask = -T4430.values[0]; T4431.values[0] = Top_hub_XactTracker_2__p_rep_data_needs_write.values[0] ^ ((Top_hub_XactTracker_2__p_rep_data_needs_write.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T3670.values[0]; T4432.values[0] = T4431.values[0] ^ ((T4431.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_2__p_rep_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_2__reset.values[0], 0x0L, T4432.values[0]); }
  { val_t __mask = -T1553.values[0]; T4433.values[0] = Top_hub_XactTracker_2__mem_cnt.values[0] ^ ((Top_hub_XactTracker_2__mem_cnt.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_2__mem_cnt_next.values[0] = Top_hub_XactTracker_2__mem_cnt.values[0]+0x1L; }
  Top_hub_XactTracker_2__mem_cnt_next.values[0] = Top_hub_XactTracker_2__mem_cnt_next.values[0] & 3;
  { val_t __mask = -T3669.values[0]; T4434.values[0] = T4433.values[0] ^ ((T4433.values[0] ^ Top_hub_XactTracker_2__mem_cnt_next.values[0]) & __mask); }
  { val_t __mask = -T3522.values[0]; T4435.values[0] = T4434.values[0] ^ ((T4434.values[0] ^ Top_hub_XactTracker_2__mem_cnt_next.values[0]) & __mask); }
  { Top_hub_XactTracker_2__mem_cnt_shadow.values[0] = TERNARY(Top_hub_XactTracker_2__reset.values[0], 0x0L, T4435.values[0]); }
  { Top_hub_XactTracker_2__io_alloc_req_bits_xact_init_address.values[0] = Top_hub_init_arb__io_out_bits_xact_init_address.values[0]; }
  { val_t __mask = -T1553.values[0]; T4436.values[0] = Top_hub_XactTracker_2__addr_.values[0] ^ ((Top_hub_XactTracker_2__addr_.values[0] ^ Top_hub_XactTracker_2__io_alloc_req_bits_xact_init_address.values[0]) & __mask); }
  { Top_hub_XactTracker_2__addr__shadow.values[0] = T4436.values[0]; }
  { val_t __mask = -T1553.values[0]; T4437.values[0] = Top_hub_XactTracker_2__x_type_.values[0] ^ ((Top_hub_XactTracker_2__x_type_.values[0] ^ Top_hub_XactTracker_2__io_alloc_req_bits_xact_init_x_type.values[0]) & __mask); }
  { Top_hub_XactTracker_2__x_type__shadow.values[0] = T4437.values[0]; }
  { Top_hub_XactTracker_2__io_alloc_req_bits_xact_init_tile_xact_id.values[0] = Top_hub_init_arb__io_out_bits_xact_init_tile_xact_id.values[0]; }
  { val_t __mask = -T1553.values[0]; T4438.values[0] = Top_hub_XactTracker_2__tile_xact_id_.values[0] ^ ((Top_hub_XactTracker_2__tile_xact_id_.values[0] ^ Top_hub_XactTracker_2__io_alloc_req_bits_xact_init_tile_xact_id.values[0]) & __mask); }
  { Top_hub_XactTracker_2__tile_xact_id__shadow.values[0] = T4438.values[0]; }
  { val_t __mask = -T1553.values[0]; T4439.values[0] = Top_hub_XactTracker_2__init_tile_id_.values[0] ^ ((Top_hub_XactTracker_2__init_tile_id_.values[0] ^ Top_hub_XactTracker_2__io_alloc_req_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_2__init_tile_id__shadow.values[0] = T4439.values[0]; }
  { val_t __mask = -T1553.values[0]; T4440.values[0] = Top_hub_XactTracker_2__p_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_2__p_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4441.values[0] = Top_hub_XactTracker_2__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_2__io_mem_req_cmd_valid.values[0]; }
  { T4442.values[0] = T177.values[0]&&T4441.values[0]; }
  { val_t __mask = -T4442.values[0]; T4443.values[0] = T4440.values[0] ^ ((T4440.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_2__p_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_2__reset.values[0], 0x0L, T4443.values[0]); }
  T4444.values[0] = (T3938.values[0] >> 2) & 1;
  { T4445.values[0] = T4444.values[0]; }
  { T4446.values[0] = T3823.values[0]&&T4445.values[0]; }
  { T4447.values[0] = T4446.values[0] | 0x0L << 1; }
  { Top_hub__p_data_tile_id_arr_2.values[0] = T4447.values[0]; }
  { Top_hub_XactTracker_2__io_p_data_bits_tile_id.values[0] = Top_hub__p_data_tile_id_arr_2.values[0]; }
  { val_t __mask = -T4430.values[0]; T4448.values[0] = Top_hub_XactTracker_2__p_rep_tile_id_.values[0] ^ ((Top_hub_XactTracker_2__p_rep_tile_id_.values[0] ^ Top_hub_XactTracker_2__io_p_data_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_2__p_rep_tile_id__shadow.values[0] = T4448.values[0]; }
  T4449.values[0] = (Top_hub_XactTracker_2__p_req_initial_flags.values[0]) != 0;
  { val_t __mask = -T4449.values[0]; T4450.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { val_t __mask = -T1553.values[0]; T4451.values[0] = Top_hub_XactTracker_2__state.values[0] ^ ((Top_hub_XactTracker_2__state.values[0] ^ T4450.values[0]) & __mask); }
  { T4452.values[0] = Top_hub_XactTracker_2__p_rep_count.values[0] | 0x0L << 1; }
  T4453.values[0] = T4452.values[0] == T4404.values[0];
  { T4454.values[0] = T4409.values[0]&&T4453.values[0]; }
  { val_t __mask = -T4454.values[0]; T4455.values[0] = T4451.values[0] ^ ((T4451.values[0] ^ 0x2L) & __mask); }
  { T4456.values[0] = Top_hub_XactTracker_2__x_type_.values[0]; }
  T4457.values[0] = T4456.values[0] == 0x3L;
  { val_t __mask = -T4457.values[0]; T4458.values[0] = 0x4L ^ ((0x4L ^ 0x1L) & __mask); }
  { T4459.values[0] = T580.values[0]||Top_hub_XactTracker_2__x_needs_read.values[0]; }
  T4460.values[0] = !T4459.values[0];
  { T4461.values[0] = T176.values[0]&&T4460.values[0]; }
  { val_t __mask = -T4461.values[0]; T4462.values[0] = T4455.values[0] ^ ((T4455.values[0] ^ T4458.values[0]) & __mask); }
  { T4463.values[0] = T939.values[0]&&T919.values[0]; }
  { val_t __mask = -T4463.values[0]; T4464.values[0] = 0x0L ^ ((0x0L ^ Top_hub__io_tiles_0_xact_rep_ready.values[0]) & __mask); }
  { T4465.values[0] = T3907.values[0]&&T919.values[0]; }
  { val_t __mask = -T4465.values[0]; T4466.values[0] = T4464.values[0] ^ ((T4464.values[0] ^ Top_hub__io_tiles_1_xact_rep_ready.values[0]) & __mask); }
  { Top_hub__sent_x_rep_ack_arr_2.values[0] = T4466.values[0]; }
  { Top_hub_XactTracker_2__io_sent_x_rep_ack.values[0] = Top_hub__sent_x_rep_ack_arr_2.values[0]; }
  { T4467.values[0] = T861.values[0]&&Top_hub_XactTracker_2__io_sent_x_rep_ack.values[0]; }
  { val_t __mask = -T4467.values[0]; T4468.values[0] = T4462.values[0] ^ ((T4462.values[0] ^ 0x4L) & __mask); }
  T4469.values[0] = (T3918.values[0] >> 2) & 1;
  { T4470.values[0] = T4469.values[0]; }
  { T4471.values[0] = Top_hub__io_tiles_0_xact_finish_valid.values[0]&&T4470.values[0]; }
  T4472.values[0] = (T3925.values[0] >> 2) & 1;
  { T4473.values[0] = T4472.values[0]; }
  { T4474.values[0] = Top_hub__io_tiles_1_xact_finish_valid.values[0]&&T4473.values[0]; }
  { val_t __mask = -T4474.values[0]; T4475.values[0] = T4471.values[0] ^ ((T4471.values[0] ^ 0x1L) & __mask); }
  { Top_hub__do_free_arr_2.values[0] = T4475.values[0]; }
  { Top_hub_XactTracker_2__io_xact_finish.values[0] = Top_hub__do_free_arr_2.values[0]; }
  T4476.values[0] = Top_hub_XactTracker_2__state.values[0] == 0x4L;
  { T4477.values[0] = T4476.values[0]&&Top_hub_XactTracker_2__io_xact_finish.values[0]; }
  { val_t __mask = -T4477.values[0]; T4478.values[0] = T4468.values[0] ^ ((T4468.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_2__state_shadow.values[0] = TERNARY(Top_hub_XactTracker_2__reset.values[0], 0x0L, T4478.values[0]); }
  { Top_hub_XactTracker_1__reset.values[0] = Top_hub__reset.values[0]; }
  { Top_hub_XactTracker_1__io_alloc_req_bits_xact_init_x_type.values[0] = Top_hub_init_arb__io_out_bits_xact_init_x_type.values[0]; }
  T4479.values[0] = Top_hub_XactTracker_1__io_alloc_req_bits_xact_init_x_type.values[0] == 0x3L;
  { val_t __mask = -T1565.values[0]; T4480.values[0] = Top_hub_XactTracker_1__x_init_data_needs_write.values[0] ^ ((Top_hub_XactTracker_1__x_init_data_needs_write.values[0] ^ T4479.values[0]) & __mask); }
  { val_t __mask = -T3532.values[0]; T4481.values[0] = T4480.values[0] ^ ((T4480.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_1__x_init_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_1__reset.values[0], 0x0L, T4481.values[0]); }
  { val_t __mask = -T1565.values[0]; T4482.values[0] = Top_hub_XactTracker_1__x_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_1__x_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4483.values[0] = Top_hub_XactTracker_1__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_1__io_mem_req_cmd_valid.values[0]; }
  { T4484.values[0] = T149.values[0]&&T4483.values[0]; }
  { val_t __mask = -T4484.values[0]; T4485.values[0] = T4482.values[0] ^ ((T4482.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_1__x_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_1__reset.values[0], 0x0L, T4485.values[0]); }
  { Top_hub_XactTracker_1__io_alloc_req_bits_xact_init_address.values[0] = Top_hub_init_arb__io_out_bits_xact_init_address.values[0]; }
  { val_t __mask = -T1565.values[0]; T4486.values[0] = Top_hub_XactTracker_1__addr_.values[0] ^ ((Top_hub_XactTracker_1__addr_.values[0] ^ Top_hub_XactTracker_1__io_alloc_req_bits_xact_init_address.values[0]) & __mask); }
  { Top_hub_XactTracker_1__addr__shadow.values[0] = T4486.values[0]; }
  { Top_hub_XactTracker_1__io_alloc_req_bits_xact_init_tile_xact_id.values[0] = Top_hub_init_arb__io_out_bits_xact_init_tile_xact_id.values[0]; }
  { val_t __mask = -T1565.values[0]; T4487.values[0] = Top_hub_XactTracker_1__tile_xact_id_.values[0] ^ ((Top_hub_XactTracker_1__tile_xact_id_.values[0] ^ Top_hub_XactTracker_1__io_alloc_req_bits_xact_init_tile_xact_id.values[0]) & __mask); }
  { Top_hub_XactTracker_1__tile_xact_id__shadow.values[0] = T4487.values[0]; }
  { val_t __mask = -T1565.values[0]; T4488.values[0] = Top_hub_XactTracker_1__init_tile_id_.values[0] ^ ((Top_hub_XactTracker_1__init_tile_id_.values[0] ^ Top_hub_XactTracker_1__io_alloc_req_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_1__init_tile_id__shadow.values[0] = T4488.values[0]; }
  { val_t __mask = -T1565.values[0]; T4489.values[0] = Top_hub_XactTracker_1__mem_cnt.values[0] ^ ((Top_hub_XactTracker_1__mem_cnt.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_1__mem_cnt_next.values[0] = Top_hub_XactTracker_1__mem_cnt.values[0]+0x1L; }
  Top_hub_XactTracker_1__mem_cnt_next.values[0] = Top_hub_XactTracker_1__mem_cnt_next.values[0] & 3;
  { val_t __mask = -T3678.values[0]; T4490.values[0] = T4489.values[0] ^ ((T4489.values[0] ^ Top_hub_XactTracker_1__mem_cnt_next.values[0]) & __mask); }
  { val_t __mask = -T3531.values[0]; T4491.values[0] = T4490.values[0] ^ ((T4490.values[0] ^ Top_hub_XactTracker_1__mem_cnt_next.values[0]) & __mask); }
  { Top_hub_XactTracker_1__mem_cnt_shadow.values[0] = TERNARY(Top_hub_XactTracker_1__reset.values[0], 0x0L, T4491.values[0]); }
  T4492.values[0] = (T3802.values[0] >> 1) & 1;
  { T4493.values[0] = T4492.values[0]; }
  { T4494.values[0] = T3810.values[0]&&T4493.values[0]; }
  T4495.values[0] = (T3815.values[0] >> 1) & 1;
  { T4496.values[0] = T4495.values[0]; }
  { T4497.values[0] = T3823.values[0]&&T4496.values[0]; }
  { val_t __mask = -T4497.values[0]; T4498.values[0] = T4494.values[0] ^ ((T4494.values[0] ^ 0x1L) & __mask); }
  { Top_hub__p_data_valid_arr_1.values[0] = T4498.values[0]; }
  { Top_hub_XactTracker_1__io_p_data_valid.values[0] = Top_hub__p_data_valid_arr_1.values[0]; }
  T4499.values[0] = Top_hub_XactTracker_1__state.values[0] == 0x3L;
  { T4500.values[0] = T4499.values[0]&&Top_hub_XactTracker_1__io_p_data_valid.values[0]; }
  { val_t __mask = -T4500.values[0]; T4501.values[0] = Top_hub_XactTracker_1__p_rep_data_needs_write.values[0] ^ ((Top_hub_XactTracker_1__p_rep_data_needs_write.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T3679.values[0]; T4502.values[0] = T4501.values[0] ^ ((T4501.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_1__p_rep_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker_1__reset.values[0], 0x0L, T4502.values[0]); }
  { val_t __mask = -T1565.values[0]; T4503.values[0] = Top_hub_XactTracker_1__p_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker_1__p_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4504.values[0] = Top_hub_XactTracker_1__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker_1__io_mem_req_cmd_valid.values[0]; }
  { T4505.values[0] = T120.values[0]&&T4504.values[0]; }
  { val_t __mask = -T4505.values[0]; T4506.values[0] = T4503.values[0] ^ ((T4503.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker_1__p_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker_1__reset.values[0], 0x0L, T4506.values[0]); }
  T4507.values[0] = (T3938.values[0] >> 1) & 1;
  { T4508.values[0] = T4507.values[0]; }
  { T4509.values[0] = T3823.values[0]&&T4508.values[0]; }
  { T4510.values[0] = T4509.values[0] | 0x0L << 1; }
  { Top_hub__p_data_tile_id_arr_1.values[0] = T4510.values[0]; }
  { Top_hub_XactTracker_1__io_p_data_bits_tile_id.values[0] = Top_hub__p_data_tile_id_arr_1.values[0]; }
  { val_t __mask = -T4500.values[0]; T4511.values[0] = Top_hub_XactTracker_1__p_rep_tile_id_.values[0] ^ ((Top_hub_XactTracker_1__p_rep_tile_id_.values[0] ^ Top_hub_XactTracker_1__io_p_data_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker_1__p_rep_tile_id__shadow.values[0] = T4511.values[0]; }
  { T4512.values[0] = Top_hub_XactTracker_1__io_alloc_req_bits_xact_init_x_type.values[0]; }
  T4513.values[0] = T4512.values[0] != 0x3L;
  { val_t __mask = -T1565.values[0]; T4514.values[0] = Top_hub_XactTracker_1__x_needs_read.values[0] ^ ((Top_hub_XactTracker_1__x_needs_read.values[0] ^ T4513.values[0]) & __mask); }
  { T4515.values[0] = T557.values[0]&&Top_hub_XactTracker_1__io_mem_req_cmd_ready.values[0]; }
  { val_t __mask = -T4515.values[0]; T4516.values[0] = T4514.values[0] ^ ((T4514.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_1__x_needs_read_shadow.values[0] = TERNARY(Top_hub_XactTracker_1__reset.values[0], 0x0L, T4516.values[0]); }
  { val_t __mask = -T1565.values[0]; T4517.values[0] = Top_hub_XactTracker_1__x_type_.values[0] ^ ((Top_hub_XactTracker_1__x_type_.values[0] ^ Top_hub_XactTracker_1__io_alloc_req_bits_xact_init_x_type.values[0]) & __mask); }
  { Top_hub_XactTracker_1__x_type__shadow.values[0] = T4517.values[0]; }
  { T4518.values[0] = Top_hub_XactTracker_1__p_rep_count.values[0] | 0x0L << 1; }
  T4519.values[0] = (Top_hub_XactTracker_1__io_alloc_req_bits_tile_id.values[0] >> 0) & 1;
  { T4520.values[0] = T4519.values[0]; }
  T4521.values[0] = 0x1L << T4520.values[0];
  { T4522.values[0] = Top_hub__io_tiles_0_incoherent.values[0] | Top_hub__io_tiles_1_incoherent.values[0] << 1; }
  { Top_hub_XactTracker_1__io_tile_incoherent.values[0] = T4522.values[0]; }
  { T4523.values[0] = Top_hub_XactTracker_1__io_tile_incoherent.values[0]|T4521.values[0]; }
  { T4524.values[0] = ~T4523.values[0]; }
  T4524.values[0] = T4524.values[0] & 3;
  { Top_hub_XactTracker_1__p_req_initial_flags.values[0] = T4524.values[0]; }
  T4525.values[0] = (Top_hub_XactTracker_1__p_req_initial_flags.values[0] >> 1) & 1;
  { T4526.values[0] = T4525.values[0]; }
  { T4527.values[0] = T4526.values[0]; }
  { T4528.values[0] = T4527.values[0] | 0x0L << 1; }
  { T4529.values[0] = T4528.values[0]; }
  T4530.values[0] = (Top_hub_XactTracker_1__p_req_initial_flags.values[0] >> 0) & 1;
  { T4531.values[0] = T4530.values[0]; }
  { T4532.values[0] = T4531.values[0]; }
  { T4533.values[0] = T4532.values[0] | 0x0L << 1; }
  { T4534.values[0] = T4533.values[0]+T4529.values[0]; }
  T4534.values[0] = T4534.values[0] & 3;
  { val_t __mask = -T1565.values[0]; T4535.values[0] = T4518.values[0] ^ ((T4518.values[0] ^ T4534.values[0]) & __mask); }
  T4536.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0] == 0x1L;
  { T4537.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T4536.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_1_0.values[0] = T4537.values[0]; }
  T4538.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0] == 0x1L;
  { T4539.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T4538.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_1_1.values[0] = T4539.values[0]; }
  { T4540.values[0] = Top_hub__p_rep_cnt_dec_arr_1_0.values[0] | Top_hub__p_rep_cnt_dec_arr_1_1.values[0] << 1; }
  { Top_hub_XactTracker_1__io_p_rep_cnt_dec.values[0] = T4540.values[0]; }
  T4541.values[0] = (Top_hub_XactTracker_1__io_p_rep_cnt_dec.values[0] >> 1) & 1;
  { T4542.values[0] = T4541.values[0]; }
  { T4543.values[0] = T4542.values[0]; }
  { T4544.values[0] = T4543.values[0] | 0x0L << 1; }
  { T4545.values[0] = T4544.values[0]; }
  T4546.values[0] = (Top_hub_XactTracker_1__io_p_rep_cnt_dec.values[0] >> 0) & 1;
  { T4547.values[0] = T4546.values[0]; }
  { T4548.values[0] = T4547.values[0]; }
  { T4549.values[0] = T4548.values[0] | 0x0L << 1; }
  { T4550.values[0] = T4549.values[0]+T4545.values[0]; }
  T4550.values[0] = T4550.values[0] & 3;
  { T4551.values[0] = Top_hub_XactTracker_1__p_rep_count.values[0] | 0x0L << 1; }
  { T4552.values[0] = T4551.values[0]-T4550.values[0]; }
  T4552.values[0] = T4552.values[0] & 3;
  T4553.values[0] = (Top_hub_XactTracker_1__io_p_rep_cnt_dec.values[0]) != 0;
  { T4554.values[0] = T4499.values[0]&&T4553.values[0]; }
  { val_t __mask = -T4554.values[0]; T4555.values[0] = T4535.values[0] ^ ((T4535.values[0] ^ T4552.values[0]) & __mask); }
  { Top_hub_XactTracker_1__p_rep_count_shadow.values[0] = TERNARY(Top_hub_XactTracker_1__reset.values[0], 0x0L, T4555.values[0]); }
  T4556.values[0] = (Top_hub_XactTracker_1__p_req_initial_flags.values[0]) != 0;
  { val_t __mask = -T4556.values[0]; T4557.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { val_t __mask = -T1565.values[0]; T4558.values[0] = Top_hub_XactTracker_1__state.values[0] ^ ((Top_hub_XactTracker_1__state.values[0] ^ T4557.values[0]) & __mask); }
  { T4559.values[0] = Top_hub_XactTracker_1__p_rep_count.values[0] | 0x0L << 1; }
  T4560.values[0] = T4559.values[0] == T4550.values[0];
  { T4561.values[0] = T4554.values[0]&&T4560.values[0]; }
  { val_t __mask = -T4561.values[0]; T4562.values[0] = T4558.values[0] ^ ((T4558.values[0] ^ 0x2L) & __mask); }
  { T4563.values[0] = Top_hub_XactTracker_1__x_type_.values[0]; }
  T4564.values[0] = T4563.values[0] == 0x3L;
  { val_t __mask = -T4564.values[0]; T4565.values[0] = 0x4L ^ ((0x4L ^ 0x1L) & __mask); }
  { T4566.values[0] = T554.values[0]||Top_hub_XactTracker_1__x_needs_read.values[0]; }
  T4567.values[0] = !T4566.values[0];
  { T4568.values[0] = T119.values[0]&&T4567.values[0]; }
  { val_t __mask = -T4568.values[0]; T4569.values[0] = T4562.values[0] ^ ((T4562.values[0] ^ T4565.values[0]) & __mask); }
  { T4570.values[0] = T939.values[0]&&T923.values[0]; }
  { val_t __mask = -T4570.values[0]; T4571.values[0] = 0x0L ^ ((0x0L ^ Top_hub__io_tiles_0_xact_rep_ready.values[0]) & __mask); }
  { T4572.values[0] = T3907.values[0]&&T923.values[0]; }
  { val_t __mask = -T4572.values[0]; T4573.values[0] = T4571.values[0] ^ ((T4571.values[0] ^ Top_hub__io_tiles_1_xact_rep_ready.values[0]) & __mask); }
  { Top_hub__sent_x_rep_ack_arr_1.values[0] = T4573.values[0]; }
  { Top_hub_XactTracker_1__io_sent_x_rep_ack.values[0] = Top_hub__sent_x_rep_ack_arr_1.values[0]; }
  { T4574.values[0] = T860.values[0]&&Top_hub_XactTracker_1__io_sent_x_rep_ack.values[0]; }
  { val_t __mask = -T4574.values[0]; T4575.values[0] = T4569.values[0] ^ ((T4569.values[0] ^ 0x4L) & __mask); }
  T4576.values[0] = (T3918.values[0] >> 1) & 1;
  { T4577.values[0] = T4576.values[0]; }
  { T4578.values[0] = Top_hub__io_tiles_0_xact_finish_valid.values[0]&&T4577.values[0]; }
  T4579.values[0] = (T3925.values[0] >> 1) & 1;
  { T4580.values[0] = T4579.values[0]; }
  { T4581.values[0] = Top_hub__io_tiles_1_xact_finish_valid.values[0]&&T4580.values[0]; }
  { val_t __mask = -T4581.values[0]; T4582.values[0] = T4578.values[0] ^ ((T4578.values[0] ^ 0x1L) & __mask); }
  { Top_hub__do_free_arr_1.values[0] = T4582.values[0]; }
  { Top_hub_XactTracker_1__io_xact_finish.values[0] = Top_hub__do_free_arr_1.values[0]; }
  T4583.values[0] = Top_hub_XactTracker_1__state.values[0] == 0x4L;
  { T4584.values[0] = T4583.values[0]&&Top_hub_XactTracker_1__io_xact_finish.values[0]; }
  { val_t __mask = -T4584.values[0]; T4585.values[0] = T4575.values[0] ^ ((T4575.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker_1__state_shadow.values[0] = TERNARY(Top_hub_XactTracker_1__reset.values[0], 0x0L, T4585.values[0]); }
  { Top_hub_XactTracker__reset.values[0] = Top_hub__reset.values[0]; }
  { Top_hub_XactTracker__io_alloc_req_bits_xact_init_x_type.values[0] = Top_hub_init_arb__io_out_bits_xact_init_x_type.values[0]; }
  T4586.values[0] = Top_hub_XactTracker__io_alloc_req_bits_xact_init_x_type.values[0] == 0x3L;
  { val_t __mask = -T1575.values[0]; T4587.values[0] = Top_hub_XactTracker__x_init_data_needs_write.values[0] ^ ((Top_hub_XactTracker__x_init_data_needs_write.values[0] ^ T4586.values[0]) & __mask); }
  { val_t __mask = -T3541.values[0]; T4588.values[0] = T4587.values[0] ^ ((T4587.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker__x_init_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker__reset.values[0], 0x0L, T4588.values[0]); }
  { val_t __mask = -T1575.values[0]; T4589.values[0] = Top_hub_XactTracker__x_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker__x_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4590.values[0] = Top_hub_XactTracker__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker__io_mem_req_cmd_valid.values[0]; }
  { T4591.values[0] = T92.values[0]&&T4590.values[0]; }
  { val_t __mask = -T4591.values[0]; T4592.values[0] = T4589.values[0] ^ ((T4589.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker__x_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker__reset.values[0], 0x0L, T4592.values[0]); }
  T4593.values[0] = (T3802.values[0] >> 0) & 1;
  { T4594.values[0] = T4593.values[0]; }
  { T4595.values[0] = T3810.values[0]&&T4594.values[0]; }
  T4596.values[0] = (T3815.values[0] >> 0) & 1;
  { T4597.values[0] = T4596.values[0]; }
  { T4598.values[0] = T3823.values[0]&&T4597.values[0]; }
  { val_t __mask = -T4598.values[0]; T4599.values[0] = T4595.values[0] ^ ((T4595.values[0] ^ 0x1L) & __mask); }
  { Top_hub__p_data_valid_arr_0.values[0] = T4599.values[0]; }
  { Top_hub_XactTracker__io_p_data_valid.values[0] = Top_hub__p_data_valid_arr_0.values[0]; }
  T4600.values[0] = Top_hub_XactTracker__state.values[0] == 0x3L;
  { T4601.values[0] = T4600.values[0]&&Top_hub_XactTracker__io_p_data_valid.values[0]; }
  { val_t __mask = -T4601.values[0]; T4602.values[0] = Top_hub_XactTracker__p_rep_data_needs_write.values[0] ^ ((Top_hub_XactTracker__p_rep_data_needs_write.values[0] ^ 0x1L) & __mask); }
  { val_t __mask = -T3688.values[0]; T4603.values[0] = T4602.values[0] ^ ((T4602.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker__p_rep_data_needs_write_shadow.values[0] = TERNARY(Top_hub_XactTracker__reset.values[0], 0x0L, T4603.values[0]); }
  { val_t __mask = -T1575.values[0]; T4604.values[0] = Top_hub_XactTracker__mem_cnt.values[0] ^ ((Top_hub_XactTracker__mem_cnt.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker__mem_cnt_next.values[0] = Top_hub_XactTracker__mem_cnt.values[0]+0x1L; }
  Top_hub_XactTracker__mem_cnt_next.values[0] = Top_hub_XactTracker__mem_cnt_next.values[0] & 3;
  { val_t __mask = -T3687.values[0]; T4605.values[0] = T4604.values[0] ^ ((T4604.values[0] ^ Top_hub_XactTracker__mem_cnt_next.values[0]) & __mask); }
  { val_t __mask = -T3540.values[0]; T4606.values[0] = T4605.values[0] ^ ((T4605.values[0] ^ Top_hub_XactTracker__mem_cnt_next.values[0]) & __mask); }
  { Top_hub_XactTracker__mem_cnt_shadow.values[0] = TERNARY(Top_hub_XactTracker__reset.values[0], 0x0L, T4606.values[0]); }
  { Top_hub_XactTracker__io_alloc_req_bits_xact_init_address.values[0] = Top_hub_init_arb__io_out_bits_xact_init_address.values[0]; }
  { val_t __mask = -T1575.values[0]; T4607.values[0] = Top_hub_XactTracker__addr_.values[0] ^ ((Top_hub_XactTracker__addr_.values[0] ^ Top_hub_XactTracker__io_alloc_req_bits_xact_init_address.values[0]) & __mask); }
  { Top_hub_XactTracker__addr__shadow.values[0] = T4607.values[0]; }
  { Top_hub_XactTracker__io_alloc_req_bits_xact_init_tile_xact_id.values[0] = Top_hub_init_arb__io_out_bits_xact_init_tile_xact_id.values[0]; }
  { val_t __mask = -T1575.values[0]; T4608.values[0] = Top_hub_XactTracker__tile_xact_id_.values[0] ^ ((Top_hub_XactTracker__tile_xact_id_.values[0] ^ Top_hub_XactTracker__io_alloc_req_bits_xact_init_tile_xact_id.values[0]) & __mask); }
  { Top_hub_XactTracker__tile_xact_id__shadow.values[0] = T4608.values[0]; }
  { val_t __mask = -T1575.values[0]; T4609.values[0] = Top_hub_XactTracker__init_tile_id_.values[0] ^ ((Top_hub_XactTracker__init_tile_id_.values[0] ^ Top_hub_XactTracker__io_alloc_req_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker__init_tile_id__shadow.values[0] = T4609.values[0]; }
  T4610.values[0] = (T3938.values[0] >> 0) & 1;
  { T4611.values[0] = T4610.values[0]; }
  { T4612.values[0] = T3823.values[0]&&T4611.values[0]; }
  { T4613.values[0] = T4612.values[0] | 0x0L << 1; }
  { Top_hub__p_data_tile_id_arr_0.values[0] = T4613.values[0]; }
  { Top_hub_XactTracker__io_p_data_bits_tile_id.values[0] = Top_hub__p_data_tile_id_arr_0.values[0]; }
  { val_t __mask = -T4601.values[0]; T4614.values[0] = Top_hub_XactTracker__p_rep_tile_id_.values[0] ^ ((Top_hub_XactTracker__p_rep_tile_id_.values[0] ^ Top_hub_XactTracker__io_p_data_bits_tile_id.values[0]) & __mask); }
  { Top_hub_XactTracker__p_rep_tile_id__shadow.values[0] = T4614.values[0]; }
  { T4615.values[0] = Top_hub_XactTracker__io_alloc_req_bits_xact_init_x_type.values[0]; }
  T4616.values[0] = T4615.values[0] != 0x3L;
  { val_t __mask = -T1575.values[0]; T4617.values[0] = Top_hub_XactTracker__x_needs_read.values[0] ^ ((Top_hub_XactTracker__x_needs_read.values[0] ^ T4616.values[0]) & __mask); }
  { T4618.values[0] = T532.values[0]&&Top_hub_XactTracker__io_mem_req_cmd_ready.values[0]; }
  { val_t __mask = -T4618.values[0]; T4619.values[0] = T4617.values[0] ^ ((T4617.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker__x_needs_read_shadow.values[0] = TERNARY(Top_hub_XactTracker__reset.values[0], 0x0L, T4619.values[0]); }
  { val_t __mask = -T1575.values[0]; T4620.values[0] = Top_hub_XactTracker__x_type_.values[0] ^ ((Top_hub_XactTracker__x_type_.values[0] ^ Top_hub_XactTracker__io_alloc_req_bits_xact_init_x_type.values[0]) & __mask); }
  { Top_hub_XactTracker__x_type__shadow.values[0] = T4620.values[0]; }
  { T4621.values[0] = Top_hub_XactTracker__p_rep_count.values[0] | 0x0L << 1; }
  T4622.values[0] = (Top_hub_XactTracker__io_alloc_req_bits_tile_id.values[0] >> 0) & 1;
  { T4623.values[0] = T4622.values[0]; }
  T4624.values[0] = 0x1L << T4623.values[0];
  { T4625.values[0] = Top_hub__io_tiles_0_incoherent.values[0] | Top_hub__io_tiles_1_incoherent.values[0] << 1; }
  { Top_hub_XactTracker__io_tile_incoherent.values[0] = T4625.values[0]; }
  { T4626.values[0] = Top_hub_XactTracker__io_tile_incoherent.values[0]|T4624.values[0]; }
  { T4627.values[0] = ~T4626.values[0]; }
  T4627.values[0] = T4627.values[0] & 3;
  { Top_hub_XactTracker__p_req_initial_flags.values[0] = T4627.values[0]; }
  T4628.values[0] = (Top_hub_XactTracker__p_req_initial_flags.values[0] >> 1) & 1;
  { T4629.values[0] = T4628.values[0]; }
  { T4630.values[0] = T4629.values[0]; }
  { T4631.values[0] = T4630.values[0] | 0x0L << 1; }
  { T4632.values[0] = T4631.values[0]; }
  T4633.values[0] = (Top_hub_XactTracker__p_req_initial_flags.values[0] >> 0) & 1;
  { T4634.values[0] = T4633.values[0]; }
  { T4635.values[0] = T4634.values[0]; }
  { T4636.values[0] = T4635.values[0] | 0x0L << 1; }
  { T4637.values[0] = T4636.values[0]+T4632.values[0]; }
  T4637.values[0] = T4637.values[0] & 3;
  { val_t __mask = -T1575.values[0]; T4638.values[0] = T4621.values[0] ^ ((T4621.values[0] ^ T4637.values[0]) & __mask); }
  T4639.values[0] = Top_hub__io_tiles_0_probe_rep_bits_global_xact_id.values[0] == 0x0L;
  { T4640.values[0] = Top_hub__io_tiles_0_probe_rep_valid.values[0]&&T4639.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_0_0.values[0] = T4640.values[0]; }
  T4641.values[0] = Top_hub__io_tiles_1_probe_rep_bits_global_xact_id.values[0] == 0x0L;
  { T4642.values[0] = Top_hub__io_tiles_1_probe_rep_valid.values[0]&&T4641.values[0]; }
  { Top_hub__p_rep_cnt_dec_arr_0_1.values[0] = T4642.values[0]; }
  { T4643.values[0] = Top_hub__p_rep_cnt_dec_arr_0_0.values[0] | Top_hub__p_rep_cnt_dec_arr_0_1.values[0] << 1; }
  { Top_hub_XactTracker__io_p_rep_cnt_dec.values[0] = T4643.values[0]; }
  T4644.values[0] = (Top_hub_XactTracker__io_p_rep_cnt_dec.values[0] >> 1) & 1;
  { T4645.values[0] = T4644.values[0]; }
  { T4646.values[0] = T4645.values[0]; }
  { T4647.values[0] = T4646.values[0] | 0x0L << 1; }
  { T4648.values[0] = T4647.values[0]; }
  T4649.values[0] = (Top_hub_XactTracker__io_p_rep_cnt_dec.values[0] >> 0) & 1;
  { T4650.values[0] = T4649.values[0]; }
  { T4651.values[0] = T4650.values[0]; }
  { T4652.values[0] = T4651.values[0] | 0x0L << 1; }
  { T4653.values[0] = T4652.values[0]+T4648.values[0]; }
  T4653.values[0] = T4653.values[0] & 3;
  { T4654.values[0] = Top_hub_XactTracker__p_rep_count.values[0] | 0x0L << 1; }
  { T4655.values[0] = T4654.values[0]-T4653.values[0]; }
  T4655.values[0] = T4655.values[0] & 3;
  T4656.values[0] = (Top_hub_XactTracker__io_p_rep_cnt_dec.values[0]) != 0;
  { T4657.values[0] = T4600.values[0]&&T4656.values[0]; }
  { val_t __mask = -T4657.values[0]; T4658.values[0] = T4638.values[0] ^ ((T4638.values[0] ^ T4655.values[0]) & __mask); }
  { Top_hub_XactTracker__p_rep_count_shadow.values[0] = TERNARY(Top_hub_XactTracker__reset.values[0], 0x0L, T4658.values[0]); }
  T4659.values[0] = (Top_hub_XactTracker__p_req_initial_flags.values[0]) != 0;
  { val_t __mask = -T4659.values[0]; T4660.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { val_t __mask = -T1575.values[0]; T4661.values[0] = Top_hub_XactTracker__state.values[0] ^ ((Top_hub_XactTracker__state.values[0] ^ T4660.values[0]) & __mask); }
  { T4662.values[0] = Top_hub_XactTracker__p_rep_count.values[0] | 0x0L << 1; }
  T4663.values[0] = T4662.values[0] == T4653.values[0];
  { T4664.values[0] = T4657.values[0]&&T4663.values[0]; }
  { val_t __mask = -T4664.values[0]; T4665.values[0] = T4661.values[0] ^ ((T4661.values[0] ^ 0x2L) & __mask); }
  { T4666.values[0] = Top_hub_XactTracker__x_type_.values[0]; }
  T4667.values[0] = T4666.values[0] == 0x3L;
  { val_t __mask = -T4667.values[0]; T4668.values[0] = 0x4L ^ ((0x4L ^ 0x1L) & __mask); }
  { T4669.values[0] = T529.values[0]||Top_hub_XactTracker__x_needs_read.values[0]; }
  T4670.values[0] = !T4669.values[0];
  { T4671.values[0] = T49.values[0]&&T4670.values[0]; }
  { val_t __mask = -T4671.values[0]; T4672.values[0] = T4665.values[0] ^ ((T4665.values[0] ^ T4668.values[0]) & __mask); }
  { T4673.values[0] = T939.values[0]&&T927.values[0]; }
  { val_t __mask = -T4673.values[0]; T4674.values[0] = 0x0L ^ ((0x0L ^ Top_hub__io_tiles_0_xact_rep_ready.values[0]) & __mask); }
  { T4675.values[0] = T3907.values[0]&&T927.values[0]; }
  { val_t __mask = -T4675.values[0]; T4676.values[0] = T4674.values[0] ^ ((T4674.values[0] ^ Top_hub__io_tiles_1_xact_rep_ready.values[0]) & __mask); }
  { Top_hub__sent_x_rep_ack_arr_0.values[0] = T4676.values[0]; }
  { Top_hub_XactTracker__io_sent_x_rep_ack.values[0] = Top_hub__sent_x_rep_ack_arr_0.values[0]; }
  { T4677.values[0] = T859.values[0]&&Top_hub_XactTracker__io_sent_x_rep_ack.values[0]; }
  { val_t __mask = -T4677.values[0]; T4678.values[0] = T4672.values[0] ^ ((T4672.values[0] ^ 0x4L) & __mask); }
  T4679.values[0] = (T3918.values[0] >> 0) & 1;
  { T4680.values[0] = T4679.values[0]; }
  { T4681.values[0] = Top_hub__io_tiles_0_xact_finish_valid.values[0]&&T4680.values[0]; }
  T4682.values[0] = (T3925.values[0] >> 0) & 1;
  { T4683.values[0] = T4682.values[0]; }
  { T4684.values[0] = Top_hub__io_tiles_1_xact_finish_valid.values[0]&&T4683.values[0]; }
  { val_t __mask = -T4684.values[0]; T4685.values[0] = T4681.values[0] ^ ((T4681.values[0] ^ 0x1L) & __mask); }
  { Top_hub__do_free_arr_0.values[0] = T4685.values[0]; }
  { Top_hub_XactTracker__io_xact_finish.values[0] = Top_hub__do_free_arr_0.values[0]; }
  T4686.values[0] = Top_hub_XactTracker__state.values[0] == 0x4L;
  { T4687.values[0] = T4686.values[0]&&Top_hub_XactTracker__io_xact_finish.values[0]; }
  { val_t __mask = -T4687.values[0]; T4688.values[0] = T4678.values[0] ^ ((T4678.values[0] ^ 0x0L) & __mask); }
  { Top_hub_XactTracker__state_shadow.values[0] = TERNARY(Top_hub_XactTracker__reset.values[0], 0x0L, T4688.values[0]); }
  { val_t __mask = -T1575.values[0]; T4689.values[0] = Top_hub_XactTracker__p_w_mem_cmd_sent.values[0] ^ ((Top_hub_XactTracker__p_w_mem_cmd_sent.values[0] ^ 0x0L) & __mask); }
  { T4690.values[0] = Top_hub_XactTracker__io_mem_req_cmd_ready.values[0]&&Top_hub_XactTracker__io_mem_req_cmd_valid.values[0]; }
  { T4691.values[0] = T50.values[0]&&T4690.values[0]; }
  { val_t __mask = -T4691.values[0]; T4692.values[0] = T4689.values[0] ^ ((T4689.values[0] ^ 0x1L) & __mask); }
  { Top_hub_XactTracker__p_w_mem_cmd_sent_shadow.values[0] = TERNARY(Top_hub_XactTracker__reset.values[0], 0x0L, T4692.values[0]); }
  { T4693.values[0] = R4697.values[0]+0x1L; }
  T4693.values[0] = T4693.values[0] & 3;
  T4694.values[0] = Top_hub__abort_state_arr_0.values[0] == 0x1L;
  { T4695.values[0] = T4694.values[0]&&Top_hub__io_tiles_0_xact_init_data_valid.values[0]; }
  { val_t __mask = -T4695.values[0]; T4696.values[0] = R4697.values[0] ^ ((R4697.values[0] ^ T4693.values[0]) & __mask); }
  { R4697_shadow.values[0] = TERNARY(Top_hub__reset.values[0], 0x0L, T4696.values[0]); }
  T4698.values[0] = Top_hub__io_tiles_0_xact_init_bits_x_type.values[0] == 0x3L;
  T4699.values[0] = Top_hub__abort_state_arr_0.values[0] == 0x0L;
  { T4700.values[0] = T4699.values[0]&&Top_hub__want_to_abort_arr_0.values[0]; }
  { T4701.values[0] = T4700.values[0]&&T4698.values[0]; }
  { val_t __mask = -T4701.values[0]; T4702.values[0] = Top_hub__abort_state_arr_0.values[0] ^ ((Top_hub__abort_state_arr_0.values[0] ^ 0x1L) & __mask); }
  T4703.values[0] = !T4698.values[0];
  { T4704.values[0] = T4700.values[0]&&T4703.values[0]; }
  { val_t __mask = -T4704.values[0]; T4705.values[0] = T4702.values[0] ^ ((T4702.values[0] ^ 0x2L) & __mask); }
  T4706.values[0] = R4697.values[0] == 0x3L;
  { T4707.values[0] = T4695.values[0]&&T4706.values[0]; }
  { val_t __mask = -T4707.values[0]; T4708.values[0] = T4705.values[0] ^ ((T4705.values[0] ^ 0x2L) & __mask); }
  { T4709.values[0] = T1188.values[0]&&Top_hub__io_tiles_0_xact_abort_ready.values[0]; }
  { val_t __mask = -T4709.values[0]; T4710.values[0] = T4708.values[0] ^ ((T4708.values[0] ^ 0x0L) & __mask); }
  { Top_hub__abort_state_arr_0_shadow.values[0] = TERNARY(Top_hub__reset.values[0], 0x0L, T4710.values[0]); }
  { T4711.values[0] = R4715.values[0]+0x1L; }
  T4711.values[0] = T4711.values[0] & 3;
  T4712.values[0] = Top_hub__abort_state_arr_1.values[0] == 0x1L;
  { T4713.values[0] = T4712.values[0]&&Top_hub__io_tiles_1_xact_init_data_valid.values[0]; }
  { val_t __mask = -T4713.values[0]; T4714.values[0] = R4715.values[0] ^ ((R4715.values[0] ^ T4711.values[0]) & __mask); }
  { R4715_shadow.values[0] = TERNARY(Top_hub__reset.values[0], 0x0L, T4714.values[0]); }
  T4716.values[0] = Top_hub__io_tiles_1_xact_init_bits_x_type.values[0] == 0x3L;
  T4717.values[0] = Top_hub__abort_state_arr_1.values[0] == 0x0L;
  { T4718.values[0] = T4717.values[0]&&Top_hub__want_to_abort_arr_1.values[0]; }
  { T4719.values[0] = T4718.values[0]&&T4716.values[0]; }
  { val_t __mask = -T4719.values[0]; T4720.values[0] = Top_hub__abort_state_arr_1.values[0] ^ ((Top_hub__abort_state_arr_1.values[0] ^ 0x1L) & __mask); }
  T4721.values[0] = !T4716.values[0];
  { T4722.values[0] = T4718.values[0]&&T4721.values[0]; }
  { val_t __mask = -T4722.values[0]; T4723.values[0] = T4720.values[0] ^ ((T4720.values[0] ^ 0x2L) & __mask); }
  T4724.values[0] = R4715.values[0] == 0x3L;
  { T4725.values[0] = T4713.values[0]&&T4724.values[0]; }
  { val_t __mask = -T4725.values[0]; T4726.values[0] = T4723.values[0] ^ ((T4723.values[0] ^ 0x2L) & __mask); }
  { Top_htif__io_mem_xact_abort_ready.values[0] = 0x1L; }
  { Top_hub__io_tiles_1_xact_abort_ready.values[0] = Top_htif__io_mem_xact_abort_ready.values[0]; }
  T4727.values[0] = Top_hub__abort_state_arr_1.values[0] == 0x2L;
  { T4728.values[0] = T4727.values[0]&&Top_hub__io_tiles_1_xact_abort_ready.values[0]; }
  { val_t __mask = -T4728.values[0]; T4729.values[0] = T4726.values[0] ^ ((T4726.values[0] ^ 0x0L) & __mask); }
  { Top_hub__abort_state_arr_1_shadow.values[0] = TERNARY(Top_hub__reset.values[0], 0x0L, T4729.values[0]); }
  { Top_htif__reset.values[0] = reset.values[0]; }
  { Top_htif_x_init__reset.values[0] = Top_htif__reset.values[0]; }
  { Top_htif_x_init__do_flow.values[0] = 0x0L; }
  T4730.values[0] = !Top_htif_x_init__do_flow.values[0];
  T4731.values[0] = Top_htif__state.values[0] == 0x3L;
  { Top_htif_x_init__io_enq_valid.values[0] = T4731.values[0]; }
  T4732.values[0] = !Top_htif_x_init__maybe_full.values[0];
  { Top_htif_x_init__io_enq_ready.values[0] = T4732.values[0]; }
  { T4733.values[0] = Top_htif_x_init__io_enq_ready.values[0]&&Top_htif_x_init__io_enq_valid.values[0]; }
  { Top_htif_x_init__do_enq.values[0] = T4733.values[0]&&T4730.values[0]; }
  T4734.values[0] = !Top_htif_x_init__do_flow.values[0];
  { Top_hub__io_tiles_1_xact_abort_valid.values[0] = T4727.values[0]; }
  { T4735.values[0] = Top_hub__io_tiles_1_xact_abort_valid.values[0]&&Top_hub__io_tiles_1_xact_abort_ready.values[0]; }
  { T4736.values[0] = T4735.values[0]||T3467.values[0]; }
  { Top_hub__io_tiles_1_xact_init_ready.values[0] = T4736.values[0]; }
  { Top_htif__io_mem_xact_init_ready.values[0] = Top_hub__io_tiles_1_xact_init_ready.values[0]; }
  { Top_htif_x_init__io_deq_ready.values[0] = Top_htif__io_mem_xact_init_ready.values[0]; }
  { T4737.values[0] = Top_htif_x_init__io_deq_ready.values[0]&&Top_htif_x_init__io_deq_valid.values[0]; }
  { Top_htif_x_init__do_deq.values[0] = T4737.values[0]&&T4734.values[0]; }
  T4738.values[0] = Top_htif_x_init__do_enq.values[0] != Top_htif_x_init__do_deq.values[0];
  { val_t __mask = -T4738.values[0]; T4739.values[0] = Top_htif_x_init__maybe_full.values[0] ^ ((Top_htif_x_init__maybe_full.values[0] ^ Top_htif_x_init__do_enq.values[0]) & __mask); }
  { Top_htif_x_init__maybe_full_shadow.values[0] = TERNARY(Top_htif_x_init__reset.values[0], 0x0L, T4739.values[0]); }
  { T4741.values[0] = Top_htif__addr.values[0]; }
  T4742.values[0] = T4741.values[0] >> 0x3L;
  { T4743.values[0] = T4742.values[0]; }
  T4743.values[0] = T4743.values[0] & 17179869183;
  { Top_htif_x_init__io_enq_bits_address.values[0] = T4743.values[0]; }
  T4744.values[0] = Top_htif__cmd.values[0] == 0x1L;
  { val_t __mask = -T4744.values[0]; T4745.values[0] = 0x2L ^ ((0x2L ^ 0x3L) & __mask); }
  { Top_htif_x_init__io_enq_bits_x_type.values[0] = T4745.values[0]; }
  { T4746.values[0] = Top_htif_x_init__io_enq_bits_tile_xact_id.values[0] | Top_htif_x_init__io_enq_bits_x_type.values[0] << 5; }
  { T4747.values[0] = Top_htif_x_init__io_enq_bits_address.values[0] | T4746.values[0] << 34; }
  { T4749.values[0] = Top_htif__rx_shifter.values[0] >> 16; }
  T4749.values[0] = T4749.values[0] & 281474976710655;
  { Top_htif__io_host_in_bits.values[0] = Top__io_host_in_bits.values[0]; }
  { Top_htif__rx_shifter_in.values[0] = T4749.values[0] | Top_htif__io_host_in_bits.values[0] << 48; }
  { T4750.values[0] = Top_htif__rx_shifter_in.values[0] >> 16; }
  T4750.values[0] = T4750.values[0] & 255;
  T4751.values[0] = Top_htif__rx_count.values[0] == 0x3L;
  T4752.values[0] = Top_htif__state.values[0] == 0x0L;
  { Top_htif__io_host_in_ready.values[0] = T4752.values[0]; }
  { Top_htif__io_host_in_valid.values[0] = Top__io_host_in_valid.values[0]; }
  { T4753.values[0] = Top_htif__io_host_in_valid.values[0]&&Top_htif__io_host_in_ready.values[0]; }
  { T4754.values[0] = T4753.values[0]&&T4751.values[0]; }
  { val_t __mask = -T4754.values[0]; T4755.values[0] = Top_htif__seqno.values[0] ^ ((Top_htif__seqno.values[0] ^ T4750.values[0]) & __mask); }
  { Top_htif__seqno_shadow.values[0] = T4755.values[0]; }
  { T4756.values[0] = R4913.values[0]; }
  { T4757.values[0] = T4756.values[0] | 0x0L << 1; }
  T4758.values[0] = Top_htif__pcr_addr.values[0] == 0x1dL;
  T4759.values[0] = Top_htif__state.values[0] == 0x1L;
  { T4760.values[0] = T4759.values[0]&&T4758.values[0]; }
  { val_t __mask = -T4760.values[0]; T4761.values[0] = R4764.values[0] ^ ((R4764.values[0] ^ T4757.values[0]) & __mask); }
  { T4762.values[0] = Top_Queue_12__ram.get(Top_Queue_12__deq_ptr.values[0], 0); }
  { Top_Queue_12__io_deq_bits.values[0] = T4762.values[0]; }
  { Top_htif__io_cpu_0_pcr_rep_bits.values[0] = Top_Queue_12__io_deq_bits.values[0]; }
  { Top_htif__io_cpu_0_pcr_rep_valid.values[0] = Top_Queue_12__io_deq_valid.values[0]; }
  { val_t __mask = -Top_htif__io_cpu_0_pcr_rep_valid.values[0]; T4763.values[0] = T4761.values[0] ^ ((T4761.values[0] ^ Top_htif__io_cpu_0_pcr_rep_bits.values[0]) & __mask); }
  { R4764_shadow.values[0] = T4763.values[0]; }
  Top_htif__rx_word_count.values[0] = Top_htif__rx_count.values[0] >> 0x2L;
  { T4765.values[0] = Top_htif__rx_word_count.values[0]; }
  T4765.values[0] = T4765.values[0] & 7;
  { T4766.values[0] = T4765.values[0]-0x1L; }
  T4766.values[0] = T4766.values[0] & 7;
  { T4767.values[0] = T4766.values[0]; }
  T4768.values[0] = 0x1L << T4767.values[0];
  { T4769.values[0] = T4768.values[0]; }
  T4769.values[0] = T4769.values[0] & 255;
  T4770.values[0] = (T4769.values[0] >> 1) & 1;
  { T4771.values[0] = T4770.values[0]; }
  { T4772.values[0] = Top_htif__rx_count.values[0]; }
  T4772.values[0] = T4772.values[0] & 3;
  T4773.values[0] = (T4772.values[0] == 3);
  { Top_htif__rx_word_done.values[0] = Top_htif__io_host_in_valid.values[0]&&T4773.values[0]; }
  { T4774.values[0] = Top_htif__rx_word_done.values[0]&&Top_htif__io_host_in_ready.values[0]; }
  { T4775.values[0] = T4774.values[0]&&T4771.values[0]; }
  { val_t __mask = -T4775.values[0]; T4776.values[0] = Top_htif__packet_ram_1.values[0] ^ ((Top_htif__packet_ram_1.values[0] ^ Top_htif__rx_shifter_in.values[0]) & __mask); }
  { Top_hub__io_tiles_1_xact_rep_bits_data.values[0] = Top_hub__io_mem_resp_bits_data.values[0]; Top_hub__io_tiles_1_xact_rep_bits_data.values[1] = Top_hub__io_mem_resp_bits_data.values[1]; }
  { Top_htif__io_mem_xact_rep_bits_data.values[0] = Top_hub__io_tiles_1_xact_rep_bits_data.values[0]; Top_htif__io_mem_xact_rep_bits_data.values[1] = Top_hub__io_tiles_1_xact_rep_bits_data.values[1]; }
  { T4777.values[0] = Top_htif__io_mem_xact_rep_bits_data.values[0]; }
  { T4778.values[0] = Top_hub__send_x_rep_ack_arr_6.values[0] | Top_hub__send_x_rep_ack_arr_7.values[0] << 1; }
  { T4779.values[0] = Top_hub__send_x_rep_ack_arr_5.values[0] | T4778.values[0] << 1; }
  { T4780.values[0] = Top_hub__send_x_rep_ack_arr_4.values[0] | T4779.values[0] << 1; }
  { T4781.values[0] = Top_hub__send_x_rep_ack_arr_3.values[0] | T4780.values[0] << 1; }
  { T4782.values[0] = Top_hub__send_x_rep_ack_arr_2.values[0] | T4781.values[0] << 1; }
  { T4783.values[0] = Top_hub__send_x_rep_ack_arr_1.values[0] | T4782.values[0] << 1; }
  { T4784.values[0] = Top_hub__send_x_rep_ack_arr_0.values[0] | T4783.values[0] << 1; }
  T4785.values[0] = (T4784.values[0]) != 0;
  { val_t __mask = -T3907.values[0]; T4786.values[0] = T3905.values[0] ^ ((T3905.values[0] ^ T4785.values[0]) & __mask); }
  { Top_hub__io_tiles_1_xact_rep_valid.values[0] = T4786.values[0]; }
  { Top_htif__io_mem_xact_rep_valid.values[0] = Top_hub__io_tiles_1_xact_rep_valid.values[0]; }
  T4787.values[0] = Top_htif__state.values[0] == 0x6L;
  { T4788.values[0] = T4787.values[0]&&Top_htif__io_mem_xact_rep_valid.values[0]; }
  { T4789.values[0] = T4788.values[0]&&T2923.values[0]; }
  { val_t __mask = -T4789.values[0]; T4790.values[0] = T4776.values[0] ^ ((T4776.values[0] ^ T4777.values[0]) & __mask); }
  { T4791.values[0] = Top_htif__io_mem_xact_rep_bits_data.values[1]; }
  T4792.values[0] = Top_htif__state.values[0] == 0x6L;
  { T4793.values[0] = T4792.values[0]&&Top_htif__io_mem_xact_rep_valid.values[0]; }
  { T4794.values[0] = T4793.values[0]&&T2967.values[0]; }
  { val_t __mask = -T4794.values[0]; T4795.values[0] = T4790.values[0] ^ ((T4790.values[0] ^ T4791.values[0]) & __mask); }
  { Top_htif__packet_ram_1_shadow.values[0] = T4795.values[0]; }
  T4796.values[0] = (T4769.values[0] >> 2) & 1;
  { T4797.values[0] = T4796.values[0]; }
  { T4798.values[0] = T4774.values[0]&&T4797.values[0]; }
  { val_t __mask = -T4798.values[0]; T4799.values[0] = Top_htif__packet_ram_2.values[0] ^ ((Top_htif__packet_ram_2.values[0] ^ Top_htif__rx_shifter_in.values[0]) & __mask); }
  { T4800.values[0] = T4788.values[0]&&T2919.values[0]; }
  { val_t __mask = -T4800.values[0]; T4801.values[0] = T4799.values[0] ^ ((T4799.values[0] ^ T4777.values[0]) & __mask); }
  { T4802.values[0] = T4793.values[0]&&T2963.values[0]; }
  { val_t __mask = -T4802.values[0]; T4803.values[0] = T4801.values[0] ^ ((T4801.values[0] ^ T4791.values[0]) & __mask); }
  { Top_htif__packet_ram_2_shadow.values[0] = T4803.values[0]; }
  T4804.values[0] = (T4769.values[0] >> 3) & 1;
  { T4805.values[0] = T4804.values[0]; }
  { T4806.values[0] = T4774.values[0]&&T4805.values[0]; }
  { val_t __mask = -T4806.values[0]; T4807.values[0] = Top_htif__packet_ram_3.values[0] ^ ((Top_htif__packet_ram_3.values[0] ^ Top_htif__rx_shifter_in.values[0]) & __mask); }
  { T4808.values[0] = T4788.values[0]&&T2915.values[0]; }
  { val_t __mask = -T4808.values[0]; T4809.values[0] = T4807.values[0] ^ ((T4807.values[0] ^ T4777.values[0]) & __mask); }
  { T4810.values[0] = T4793.values[0]&&T2959.values[0]; }
  { val_t __mask = -T4810.values[0]; T4811.values[0] = T4809.values[0] ^ ((T4809.values[0] ^ T4791.values[0]) & __mask); }
  { Top_htif__packet_ram_3_shadow.values[0] = T4811.values[0]; }
  T4812.values[0] = (T4769.values[0] >> 4) & 1;
  { T4813.values[0] = T4812.values[0]; }
  { T4814.values[0] = T4774.values[0]&&T4813.values[0]; }
  { val_t __mask = -T4814.values[0]; T4815.values[0] = Top_htif__packet_ram_4.values[0] ^ ((Top_htif__packet_ram_4.values[0] ^ Top_htif__rx_shifter_in.values[0]) & __mask); }
  { T4816.values[0] = T4788.values[0]&&T2911.values[0]; }
  { val_t __mask = -T4816.values[0]; T4817.values[0] = T4815.values[0] ^ ((T4815.values[0] ^ T4777.values[0]) & __mask); }
  { T4818.values[0] = T4793.values[0]&&T2955.values[0]; }
  { val_t __mask = -T4818.values[0]; T4819.values[0] = T4817.values[0] ^ ((T4817.values[0] ^ T4791.values[0]) & __mask); }
  { Top_htif__packet_ram_4_shadow.values[0] = T4819.values[0]; }
  T4820.values[0] = (T4769.values[0] >> 5) & 1;
  { T4821.values[0] = T4820.values[0]; }
  { T4822.values[0] = T4774.values[0]&&T4821.values[0]; }
  { val_t __mask = -T4822.values[0]; T4823.values[0] = Top_htif__packet_ram_5.values[0] ^ ((Top_htif__packet_ram_5.values[0] ^ Top_htif__rx_shifter_in.values[0]) & __mask); }
  { T4824.values[0] = T4788.values[0]&&T2907.values[0]; }
  { val_t __mask = -T4824.values[0]; T4825.values[0] = T4823.values[0] ^ ((T4823.values[0] ^ T4777.values[0]) & __mask); }
  { T4826.values[0] = T4793.values[0]&&T2951.values[0]; }
  { val_t __mask = -T4826.values[0]; T4827.values[0] = T4825.values[0] ^ ((T4825.values[0] ^ T4791.values[0]) & __mask); }
  { Top_htif__packet_ram_5_shadow.values[0] = T4827.values[0]; }
  T4828.values[0] = (T4769.values[0] >> 6) & 1;
  { T4829.values[0] = T4828.values[0]; }
  { T4830.values[0] = T4774.values[0]&&T4829.values[0]; }
  { val_t __mask = -T4830.values[0]; T4831.values[0] = Top_htif__packet_ram_6.values[0] ^ ((Top_htif__packet_ram_6.values[0] ^ Top_htif__rx_shifter_in.values[0]) & __mask); }
  { T4832.values[0] = T4788.values[0]&&T2903.values[0]; }
  { val_t __mask = -T4832.values[0]; T4833.values[0] = T4831.values[0] ^ ((T4831.values[0] ^ T4777.values[0]) & __mask); }
  { T4834.values[0] = T4793.values[0]&&T2947.values[0]; }
  { val_t __mask = -T4834.values[0]; T4835.values[0] = T4833.values[0] ^ ((T4833.values[0] ^ T4791.values[0]) & __mask); }
  { Top_htif__packet_ram_6_shadow.values[0] = T4835.values[0]; }
  T4836.values[0] = (T4769.values[0] >> 7) & 1;
  { T4837.values[0] = T4836.values[0]; }
  { T4838.values[0] = T4774.values[0]&&T4837.values[0]; }
  { val_t __mask = -T4838.values[0]; T4839.values[0] = Top_htif__packet_ram_7.values[0] ^ ((Top_htif__packet_ram_7.values[0] ^ Top_htif__rx_shifter_in.values[0]) & __mask); }
  { T4840.values[0] = T4788.values[0]&&T2899.values[0]; }
  { val_t __mask = -T4840.values[0]; T4841.values[0] = T4839.values[0] ^ ((T4839.values[0] ^ T4777.values[0]) & __mask); }
  { T4842.values[0] = T4793.values[0]&&T2943.values[0]; }
  { val_t __mask = -T4842.values[0]; T4843.values[0] = T4841.values[0] ^ ((T4841.values[0] ^ T4791.values[0]) & __mask); }
  { Top_htif__packet_ram_7_shadow.values[0] = T4843.values[0]; }
  { T4844.values[0] = Top_htif__rx_shifter_in.values[0] >> 7; }
  T4844.values[0] = T4844.values[0] & 511;
  { val_t __mask = -T4754.values[0]; T4845.values[0] = Top_htif__pos.values[0] ^ ((Top_htif__pos.values[0] ^ T4844.values[0]) & __mask); }
  { T4846.values[0] = Top_htif__pos.values[0]; }
  { T4847.values[0] = T4846.values[0]-0x1L; }
  T4847.values[0] = T4847.values[0] & 511;
  { Top_hub__io_tiles_1_xact_finish_ready.values[0] = 0x1L; }
  { Top_htif__io_mem_xact_finish_ready.values[0] = Top_hub__io_tiles_1_xact_finish_ready.values[0]; }
  T4848.values[0] = Top_htif__state.values[0] == 0x7L;
  { T4849.values[0] = T4848.values[0]&&Top_htif__io_mem_xact_finish_ready.values[0]; }
  { val_t __mask = -T4849.values[0]; T4850.values[0] = T4845.values[0] ^ ((T4845.values[0] ^ T4847.values[0]) & __mask); }
  { Top_htif__pos_shadow.values[0] = T4850.values[0]; }
  { val_t __mask = -Top_htif__io_mem_xact_rep_valid.values[0]; T4851.values[0] = Top_htif__mem_acked.values[0] ^ ((Top_htif__mem_acked.values[0] ^ 0x1L) & __mask); }
  T4852.values[0] = Top_htif__state.values[0] == 0x5L;
  { T4853.values[0] = T4852.values[0]&&Top_htif__mem_acked.values[0]; }
  { val_t __mask = -T4853.values[0]; T4854.values[0] = T4851.values[0] ^ ((T4851.values[0] ^ 0x0L) & __mask); }
  T4855.values[0] = Top_htif__state.values[0] == 0x6L;
  { val_t __mask = -T4855.values[0]; T4856.values[0] = T4854.values[0] ^ ((T4854.values[0] ^ 0x0L) & __mask); }
  { Top_htif__mem_acked_shadow.values[0] = TERNARY(Top_htif__reset.values[0], 0x0L, T4856.values[0]); }
  { Top_htif__io_mem_xact_abort_valid.values[0] = Top_hub__io_tiles_1_xact_abort_valid.values[0]; }
  { val_t __mask = -Top_htif__io_mem_xact_abort_valid.values[0]; T4857.values[0] = Top_htif__mem_nacked.values[0] ^ ((Top_htif__mem_nacked.values[0] ^ 0x1L) & __mask); }
  { T4858.values[0] = T4852.values[0]&&Top_htif__mem_nacked.values[0]; }
  { val_t __mask = -T4858.values[0]; T4859.values[0] = T4857.values[0] ^ ((T4857.values[0] ^ 0x0L) & __mask); }
  { T4860.values[0] = T4855.values[0]&&Top_htif__mem_nacked.values[0]; }
  { val_t __mask = -T4860.values[0]; T4861.values[0] = T4859.values[0] ^ ((T4859.values[0] ^ 0x0L) & __mask); }
  { Top_htif__mem_nacked_shadow.values[0] = TERNARY(Top_htif__reset.values[0], 0x0L, T4861.values[0]); }
  { Top_hub__io_tiles_1_xact_rep_bits_require_ack.values[0] = 0x1L; }
  { Top_htif__io_mem_xact_rep_bits_require_ack.values[0] = Top_hub__io_tiles_1_xact_rep_bits_require_ack.values[0]; }
  { val_t __mask = -Top_htif__io_mem_xact_rep_valid.values[0]; T4862.values[0] = Top_htif__mem_needs_ack.values[0] ^ ((Top_htif__mem_needs_ack.values[0] ^ Top_htif__io_mem_xact_rep_bits_require_ack.values[0]) & __mask); }
  { Top_htif__mem_needs_ack_shadow.values[0] = T4862.values[0]; }
  { val_t __mask = -T3905.values[0]; T4863.values[0] = 0x0L ^ ((0x0L ^ Top_hub__mem_idx.values[0]) & __mask); }
  { T4864.values[0] = Top_hub__ack_idx.values[0] | 0x0L << 3; }
  { val_t __mask = -T3906.values[0]; T4865.values[0] = T4863.values[0] ^ ((T4863.values[0] ^ T4864.values[0]) & __mask); }
  { T4866.values[0] = T4865.values[0]; }
  T4866.values[0] = T4866.values[0] & 7;
  { Top_hub__io_tiles_1_xact_rep_bits_global_xact_id.values[0] = T4866.values[0]; }
  { Top_htif__io_mem_xact_rep_bits_global_xact_id.values[0] = Top_hub__io_tiles_1_xact_rep_bits_global_xact_id.values[0]; }
  { val_t __mask = -Top_htif__io_mem_xact_rep_valid.values[0]; T4867.values[0] = Top_htif__mem_gxid.values[0] ^ ((Top_htif__mem_gxid.values[0] ^ Top_htif__io_mem_xact_rep_bits_global_xact_id.values[0]) & __mask); }
  { Top_htif__mem_gxid_shadow.values[0] = T4867.values[0]; }
  { T4868.values[0] = Top_htif__mem_cnt.values[0]+0x1L; }
  T4868.values[0] = T4868.values[0] & 3;
  T4869.values[0] = (Top_hub_XactTracker_7__io_pop_x_init_data.values[0] >> 1) & 1;
  { T4870.values[0] = T4869.values[0]; }
  T4871.values[0] = (Top_hub_XactTracker_6__io_pop_x_init_data.values[0] >> 1) & 1;
  { T4872.values[0] = T4871.values[0]; }
  { T4873.values[0] = T4872.values[0]||T4870.values[0]; }
  T4874.values[0] = (Top_hub_XactTracker_5__io_pop_x_init_data.values[0] >> 1) & 1;
  { T4875.values[0] = T4874.values[0]; }
  { T4876.values[0] = T4875.values[0]||T4873.values[0]; }
  T4877.values[0] = (Top_hub_XactTracker_4__io_pop_x_init_data.values[0] >> 1) & 1;
  { T4878.values[0] = T4877.values[0]; }
  { T4879.values[0] = T4878.values[0]||T4876.values[0]; }
  T4880.values[0] = (Top_hub_XactTracker_3__io_pop_x_init_data.values[0] >> 1) & 1;
  { T4881.values[0] = T4880.values[0]; }
  { T4882.values[0] = T4881.values[0]||T4879.values[0]; }
  T4883.values[0] = (Top_hub_XactTracker_2__io_pop_x_init_data.values[0] >> 1) & 1;
  { T4884.values[0] = T4883.values[0]; }
  { T4885.values[0] = T4884.values[0]||T4882.values[0]; }
  T4886.values[0] = (Top_hub_XactTracker_1__io_pop_x_init_data.values[0] >> 1) & 1;
  { T4887.values[0] = T4886.values[0]; }
  { T4888.values[0] = T4887.values[0]||T4885.values[0]; }
  T4889.values[0] = (Top_hub_XactTracker__io_pop_x_init_data.values[0] >> 1) & 1;
  { T4890.values[0] = T4889.values[0]; }
  { T4891.values[0] = T4890.values[0]||T4888.values[0]; }
  T4892.values[0] = Top_hub__abort_state_arr_1.values[0] == 0x1L;
  { T4893.values[0] = T4892.values[0]||T4891.values[0]; }
  { Top_hub__io_tiles_1_xact_init_data_ready.values[0] = T4893.values[0]; }
  { Top_htif__io_mem_xact_init_data_ready.values[0] = Top_hub__io_tiles_1_xact_init_data_ready.values[0]; }
  T4894.values[0] = Top_htif__state.values[0] == 0x4L;
  { T4895.values[0] = T4894.values[0]&&Top_htif__io_mem_xact_init_data_ready.values[0]; }
  { val_t __mask = -T4895.values[0]; T4896.values[0] = Top_htif__mem_cnt.values[0] ^ ((Top_htif__mem_cnt.values[0] ^ T4868.values[0]) & __mask); }
  { T4897.values[0] = Top_htif__mem_cnt.values[0]+0x1L; }
  T4897.values[0] = T4897.values[0] & 3;
  { T4898.values[0] = T4855.values[0]&&Top_htif__io_mem_xact_rep_valid.values[0]; }
  { val_t __mask = -T4898.values[0]; T4899.values[0] = T4896.values[0] ^ ((T4896.values[0] ^ T4897.values[0]) & __mask); }
  { Top_htif__mem_cnt_shadow.values[0] = TERNARY(Top_htif__reset.values[0], 0x0L, T4899.values[0]); }
  T4900.values[0] = (T4769.values[0] >> 0) & 1;
  { T4901.values[0] = T4900.values[0]; }
  { T4902.values[0] = T4774.values[0]&&T4901.values[0]; }
  { val_t __mask = -T4902.values[0]; T4903.values[0] = Top_htif__pcr_wdata.values[0] ^ ((Top_htif__pcr_wdata.values[0] ^ Top_htif__rx_shifter_in.values[0]) & __mask); }
  { T4904.values[0] = T4788.values[0]&&T2927.values[0]; }
  { val_t __mask = -T4904.values[0]; T4905.values[0] = T4903.values[0] ^ ((T4903.values[0] ^ T4777.values[0]) & __mask); }
  { T4906.values[0] = T4793.values[0]&&T2971.values[0]; }
  { val_t __mask = -T4906.values[0]; T4907.values[0] = T4905.values[0] ^ ((T4905.values[0] ^ T4791.values[0]) & __mask); }
  { Top_htif__pcr_wdata_shadow.values[0] = T4907.values[0]; }
  T4908.values[0] = (Top_htif__pcr_wdata.values[0] >> 0) & 1;
  { T4909.values[0] = T4908.values[0]; }
  T4910.values[0] = Top_htif__cmd.values[0] == 0x3L;
  { T4911.values[0] = T4760.values[0]&&T4910.values[0]; }
  { val_t __mask = -T4911.values[0]; T4912.values[0] = R4913.values[0] ^ ((R4913.values[0] ^ T4909.values[0]) & __mask); }
  { R4913_shadow.values[0] = TERNARY(Top_htif__reset.values[0], 0x1L, T4912.values[0]); }
  { T4914.values[0] = Top_htif__tx_count.values[0]+0x1L; }
  T4914.values[0] = T4914.values[0] & 32767;
  { Top_htif__io_host_out_ready.values[0] = Top__io_host_out_ready.values[0]; }
  T4915.values[0] = Top_htif__state.values[0] == 0x8L;
  { Top_htif__io_host_out_valid.values[0] = T4915.values[0]; }
  { T4916.values[0] = Top_htif__io_host_out_valid.values[0]&&Top_htif__io_host_out_ready.values[0]; }
  { val_t __mask = -T4916.values[0]; T4917.values[0] = Top_htif__tx_count.values[0] ^ ((Top_htif__tx_count.values[0] ^ T4914.values[0]) & __mask); }
  T4918.values[0] = Top_htif__cmd.values[0] == 0x3L;
  T4919.values[0] = Top_htif__cmd.values[0] == 0x2L;
  T4920.values[0] = Top_htif__cmd.values[0] == 0x0L;
  { T4921.values[0] = T4920.values[0]||T4919.values[0]; }
  { T4922.values[0] = T4921.values[0]||T4918.values[0]; }
  T4923.values[0] = Top_htif__size.values[0] != 0x1L;
  T4924.values[0] = Top_htif__cmd.values[0] == 0x3L;
  T4925.values[0] = Top_htif__cmd.values[0] == 0x2L;
  { T4926.values[0] = T4925.values[0]||T4924.values[0]; }
  { val_t __mask = -T4926.values[0]; T4927.values[0] = 0x1L ^ ((0x1L ^ T4923.values[0]) & __mask); }
  { T4928.values[0] = Top_htif__addr.values[0]; }
  T4928.values[0] = T4928.values[0] & 7;
  T4929.values[0] = (T4928.values[0]) != 0;
  { T4930.values[0] = Top_htif__size.values[0]; }
  T4930.values[0] = T4930.values[0] & 7;
  T4931.values[0] = (T4930.values[0]) != 0;
  { Top_htif__bad_mem_packet.values[0] = T4931.values[0]||T4929.values[0]; }
  T4932.values[0] = Top_htif__cmd.values[0] == 0x1L;
  T4933.values[0] = Top_htif__cmd.values[0] == 0x0L;
  { T4934.values[0] = T4933.values[0]||T4932.values[0]; }
  { val_t __mask = -T4934.values[0]; Top_htif__nack.values[0] = T4927.values[0] ^ ((T4927.values[0] ^ Top_htif__bad_mem_packet.values[0]) & __mask); }
  T4935.values[0] = !Top_htif__nack.values[0];
  { T4936.values[0] = T4935.values[0]&&T4922.values[0]; }
  { val_t __mask = -T4936.values[0]; Top_htif__tx_size.values[0] = 0x0L ^ ((0x0L ^ Top_htif__size.values[0]) & __mask); }
  { T4937.values[0] = Top_htif__tx_size.values[0] | 0x0L << 12; }
  { Top_htif__tx_word_count.values[0] = Top_htif__tx_count.values[0] >> 2; }
  Top_htif__tx_word_count.values[0] = Top_htif__tx_word_count.values[0] & 8191;
  T4938.values[0] = Top_htif__tx_word_count.values[0] == T4937.values[0];
  { T4939.values[0] = Top_htif__tx_word_count.values[0]; }
  T4939.values[0] = T4939.values[0] & 7;
  { Top_htif__packet_ram_raddr.values[0] = T4939.values[0]-0x1L; }
  Top_htif__packet_ram_raddr.values[0] = Top_htif__packet_ram_raddr.values[0] & 7;
  T4940.values[0] = (Top_htif__packet_ram_raddr.values[0] == 7);
  T4941.values[0] = Top_htif__tx_word_count.values[0]>0x0L;
  { T4942.values[0] = T4941.values[0]&&T4940.values[0]; }
  { T4943.values[0] = Top_htif__tx_size.values[0] | 0x0L << 12; }
  T4944.values[0] = Top_htif__tx_word_count.values[0] == T4943.values[0];
  { T4945.values[0] = T4944.values[0]||T4942.values[0]; }
  { Top_htif__tx_subword_count.values[0] = Top_htif__tx_count.values[0]; }
  Top_htif__tx_subword_count.values[0] = Top_htif__tx_subword_count.values[0] & 3;
  T4946.values[0] = (Top_htif__tx_subword_count.values[0] == 3);
  { T4947.values[0] = Top_htif__io_host_out_ready.values[0]&&T4946.values[0]; }
  { Top_htif__tx_done.values[0] = T4947.values[0]&&T4945.values[0]; }
  T4948.values[0] = Top_htif__state.values[0] == 0x8L;
  { T4949.values[0] = T4948.values[0]&&Top_htif__tx_done.values[0]; }
  { T4950.values[0] = T4949.values[0]&&T4938.values[0]; }
  { val_t __mask = -T4950.values[0]; T4951.values[0] = T4917.values[0] ^ ((T4917.values[0] ^ 0x0L) & __mask); }
  { Top_htif__tx_count_shadow.values[0] = TERNARY(Top_htif__reset.values[0], 0x0L, T4951.values[0]); }
  { T4952.values[0] = Top_htif__rx_shifter_in.values[0] >> 4; }
  T4952.values[0] = T4952.values[0] & 4095;
  { val_t __mask = -T4754.values[0]; T4953.values[0] = Top_htif__size.values[0] ^ ((Top_htif__size.values[0] ^ T4952.values[0]) & __mask); }
  { Top_htif__size_shadow.values[0] = T4953.values[0]; }
  { T4954.values[0] = Top_htif__rx_count.values[0]+0x1L; }
  T4954.values[0] = T4954.values[0] & 32767;
  { val_t __mask = -T4753.values[0]; T4955.values[0] = Top_htif__rx_count.values[0] ^ ((Top_htif__rx_count.values[0] ^ T4954.values[0]) & __mask); }
  { val_t __mask = -T4950.values[0]; T4956.values[0] = T4955.values[0] ^ ((T4955.values[0] ^ 0x0L) & __mask); }
  { Top_htif__rx_count_shadow.values[0] = TERNARY(Top_htif__reset.values[0], 0x0L, T4956.values[0]); }
  { Top_htif__next_cmd.values[0] = Top_htif__rx_shifter_in.values[0]; }
  Top_htif__next_cmd.values[0] = Top_htif__next_cmd.values[0] & 15;
  { val_t __mask = -T4754.values[0]; T4957.values[0] = Top_htif__cmd.values[0] ^ ((Top_htif__cmd.values[0] ^ Top_htif__next_cmd.values[0]) & __mask); }
  { Top_htif__cmd_shadow.values[0] = T4957.values[0]; }
  T4958.values[0] = Top_htif__rx_word_count.values[0] == 0x0L;
  { val_t __mask = -T4958.values[0]; T4959.values[0] = Top_htif__cmd.values[0] ^ ((Top_htif__cmd.values[0] ^ Top_htif__next_cmd.values[0]) & __mask); }
  T4960.values[0] = T4959.values[0] == 0x3L;
  T4961.values[0] = T4959.values[0] == 0x2L;
  { T4962.values[0] = T4961.values[0]||T4960.values[0]; }
  { val_t __mask = -T4962.values[0]; T4963.values[0] = 0x8L ^ ((0x8L ^ 0x1L) & __mask); }
  T4964.values[0] = T4959.values[0] == 0x1L;
  T4965.values[0] = T4959.values[0] == 0x0L;
  { T4966.values[0] = T4965.values[0]||T4964.values[0]; }
  { val_t __mask = -T4966.values[0]; T4967.values[0] = T4963.values[0] ^ ((T4963.values[0] ^ 0x3L) & __mask); }
  { T4968.values[0] = Top_htif__rx_word_count.values[0]; }
  T4968.values[0] = T4968.values[0] & 7;
  T4969.values[0] = T4968.values[0] == 0x0L;
  { T4970.values[0] = Top_htif__size.values[0] | 0x0L << 12; }
  T4971.values[0] = Top_htif__rx_word_count.values[0] == T4970.values[0];
  { T4972.values[0] = T4971.values[0]||T4969.values[0]; }
  T4973.values[0] = Top_htif__next_cmd.values[0] != 0x3L;
  T4974.values[0] = Top_htif__next_cmd.values[0] != 0x1L;
  { T4975.values[0] = T4974.values[0]&&T4973.values[0]; }
  T4976.values[0] = Top_htif__rx_word_count.values[0] == 0x0L;
  { val_t __mask = -T4976.values[0]; T4977.values[0] = T4972.values[0] ^ ((T4972.values[0] ^ T4975.values[0]) & __mask); }
  { Top_htif__rx_done.values[0] = Top_htif__rx_word_done.values[0]&&T4977.values[0]; }
  T4978.values[0] = Top_htif__state.values[0] == 0x0L;
  { T4979.values[0] = T4978.values[0]&&Top_htif__rx_done.values[0]; }
  { val_t __mask = -T4979.values[0]; T4980.values[0] = Top_htif__state.values[0] ^ ((Top_htif__state.values[0] ^ T4967.values[0]) & __mask); }
  T4981.values[0] = Top_htif__cmd.values[0] == 0x1L;
  { val_t __mask = -T4981.values[0]; T4982.values[0] = 0x6L ^ ((0x6L ^ 0x4L) & __mask); }
  T4983.values[0] = Top_htif__state.values[0] == 0x3L;
  { T4984.values[0] = T4983.values[0]&&Top_htif_x_init__io_enq_ready.values[0]; }
  { val_t __mask = -T4984.values[0]; T4985.values[0] = T4980.values[0] ^ ((T4980.values[0] ^ T4982.values[0]) & __mask); }
  T4986.values[0] = (Top_htif__mem_cnt.values[0] == 3);
  { T4987.values[0] = T4895.values[0]&&T4986.values[0]; }
  { val_t __mask = -T4987.values[0]; T4988.values[0] = T4985.values[0] ^ ((T4985.values[0] ^ 0x5L) & __mask); }
  { val_t __mask = -T4858.values[0]; T4989.values[0] = T4988.values[0] ^ ((T4988.values[0] ^ 0x3L) & __mask); }
  { val_t __mask = -T4853.values[0]; T4990.values[0] = T4989.values[0] ^ ((T4989.values[0] ^ 0x7L) & __mask); }
  { val_t __mask = -T4860.values[0]; T4991.values[0] = T4990.values[0] ^ ((T4990.values[0] ^ 0x3L) & __mask); }
  T4992.values[0] = (Top_htif__mem_cnt.values[0] == 3);
  { T4993.values[0] = T4898.values[0]&&T4992.values[0]; }
  { val_t __mask = -T4993.values[0]; T4994.values[0] = T4991.values[0] ^ ((T4991.values[0] ^ 0x7L) & __mask); }
  T4995.values[0] = Top_htif__pos.values[0] == 0x1L;
  T4996.values[0] = Top_htif__cmd.values[0] == 0x0L;
  { T4997.values[0] = T4996.values[0]||T4995.values[0]; }
  { val_t __mask = -T4997.values[0]; T4998.values[0] = 0x0L ^ ((0x0L ^ 0x8L) & __mask); }
  { val_t __mask = -T4849.values[0]; T4999.values[0] = T4994.values[0] ^ ((T4994.values[0] ^ T4998.values[0]) & __mask); }
  T5000.values[0] = Top_htif__pos.values[0] != 0x0L;
  T5001.values[0] = Top_htif__cmd.values[0] == 0x0L;
  { T5002.values[0] = T5001.values[0]&&T5000.values[0]; }
  { val_t __mask = -T5002.values[0]; T5003.values[0] = 0x0L ^ ((0x0L ^ 0x3L) & __mask); }
  { val_t __mask = -T4949.values[0]; T5004.values[0] = T4999.values[0] ^ ((T4999.values[0] ^ T5003.values[0]) & __mask); }
  { Top_htif__io_cpu_0_pcr_req_ready.values[0] = Top_Queue_11__io_enq_ready.values[0]; }
  { T5005.values[0] = Top_htif__io_cpu_0_pcr_req_valid.values[0]&&Top_htif__io_cpu_0_pcr_req_ready.values[0]; }
  { val_t __mask = -T5005.values[0]; T5006.values[0] = T5004.values[0] ^ ((T5004.values[0] ^ 0x2L) & __mask); }
  { val_t __mask = -T4760.values[0]; T5007.values[0] = T5006.values[0] ^ ((T5006.values[0] ^ 0x8L) & __mask); }
  { val_t __mask = -Top_htif__io_cpu_0_pcr_rep_valid.values[0]; T5008.values[0] = T5007.values[0] ^ ((T5007.values[0] ^ 0x8L) & __mask); }
  { Top_htif__state_shadow.values[0] = TERNARY(Top_htif__reset.values[0], 0x0L, T5008.values[0]); }
  { val_t __mask = -T4753.values[0]; T5009.values[0] = Top_htif__rx_shifter.values[0] ^ ((Top_htif__rx_shifter.values[0] ^ Top_htif__rx_shifter_in.values[0]) & __mask); }
  { Top_htif__rx_shifter_shadow.values[0] = T5009.values[0]; }
  { T5010.values[0] = Top_htif__rx_shifter_in.values[0] >> 24; }
  T5010.values[0] = T5010.values[0] & 1099511627775;
  { val_t __mask = -T4754.values[0]; T5011.values[0] = Top_htif__addr.values[0] ^ ((Top_htif__addr.values[0] ^ T5010.values[0]) & __mask); }
  { T5012.values[0] = Top_htif__addr.values[0]; }
  { T5013.values[0] = T5012.values[0]+0x8L; }
  T5013.values[0] = T5013.values[0] & 1099511627775;
  { val_t __mask = -T4849.values[0]; T5014.values[0] = T5011.values[0] ^ ((T5011.values[0] ^ T5013.values[0]) & __mask); }
  { Top_htif__addr_shadow.values[0] = T5014.values[0]; }
  { Top_SodorTile_cpu_d_pcr__io_host_debug_error_mode.values[0] = Top_SodorTile_cpu_d_pcr__reg_error_mode.values[0]; }
  { Top_SodorTile_cpu_d__io_host_debug_error_mode.values[0] = Top_SodorTile_cpu_d_pcr__io_host_debug_error_mode.values[0]; }
  { Top_SodorTile_cpu__io_host_debug_error_mode.values[0] = Top_SodorTile_cpu_d__io_host_debug_error_mode.values[0]; }
  { Top_SodorTile__io_host_debug_error_mode.values[0] = Top_SodorTile_cpu__io_host_debug_error_mode.values[0]; }
  { R5015_shadow.values[0] = Top_SodorTile__io_host_debug_error_mode.values[0]; }
  { Top__io_debug_error_mode.values[0] = R5015.values[0]; }
  { Top__io_host_in_ready.values[0] = Top_htif__io_host_in_ready.values[0]; }
  { Top__io_host_out_valid.values[0] = Top_htif__io_host_out_valid.values[0]; }
  { T5016.values[0] = Top_htif__tx_count.values[0]; }
  T5016.values[0] = T5016.values[0] & 3;
  { T5017.values[0] = 0x0L | T5016.values[0] << 4; }
  { T5018.values[0] = T5017.values[0]; }
  { T5019.values[0] = T5018.values[0]; }
  { T5020.values[0] = Top_htif__packet_ram_raddr.values[0]; }
  T5021.values[0] = 0x1L << T5020.values[0];
  { T5022.values[0] = T5021.values[0]; }
  T5022.values[0] = T5022.values[0] & 255;
  T5023.values[0] = (T5022.values[0] >> 7) & 1;
  { T5024.values[0] = T5023.values[0]; }
  { T5025.values[0] = -T5024.values[0]; }
  { T5026.values[0] = Top_htif__packet_ram_7.values[0]&T5025.values[0]; }
  T5027.values[0] = (T5022.values[0] >> 6) & 1;
  { T5028.values[0] = T5027.values[0]; }
  { T5029.values[0] = -T5028.values[0]; }
  { T5030.values[0] = Top_htif__packet_ram_6.values[0]&T5029.values[0]; }
  T5031.values[0] = (T5022.values[0] >> 5) & 1;
  { T5032.values[0] = T5031.values[0]; }
  { T5033.values[0] = -T5032.values[0]; }
  { T5034.values[0] = Top_htif__packet_ram_5.values[0]&T5033.values[0]; }
  T5035.values[0] = (T5022.values[0] >> 4) & 1;
  { T5036.values[0] = T5035.values[0]; }
  { T5037.values[0] = -T5036.values[0]; }
  { T5038.values[0] = Top_htif__packet_ram_4.values[0]&T5037.values[0]; }
  T5039.values[0] = (T5022.values[0] >> 3) & 1;
  { T5040.values[0] = T5039.values[0]; }
  { T5041.values[0] = -T5040.values[0]; }
  { T5042.values[0] = Top_htif__packet_ram_3.values[0]&T5041.values[0]; }
  T5043.values[0] = (T5022.values[0] >> 2) & 1;
  { T5044.values[0] = T5043.values[0]; }
  { T5045.values[0] = -T5044.values[0]; }
  { T5046.values[0] = Top_htif__packet_ram_2.values[0]&T5045.values[0]; }
  T5047.values[0] = (T5022.values[0] >> 1) & 1;
  { T5048.values[0] = T5047.values[0]; }
  { T5049.values[0] = -T5048.values[0]; }
  { T5050.values[0] = Top_htif__packet_ram_1.values[0]&T5049.values[0]; }
  T5051.values[0] = (T5022.values[0] >> 0) & 1;
  { T5052.values[0] = T5051.values[0]; }
  { T5053.values[0] = -T5052.values[0]; }
  { T5054.values[0] = Top_htif__pcr_wdata.values[0]&T5053.values[0]; }
  { T5055.values[0] = T5054.values[0]|T5050.values[0]; }
  { T5056.values[0] = T5055.values[0]|T5046.values[0]; }
  { T5057.values[0] = T5056.values[0]|T5042.values[0]; }
  { T5058.values[0] = T5057.values[0]|T5038.values[0]; }
  { T5059.values[0] = T5058.values[0]|T5034.values[0]; }
  { T5060.values[0] = T5059.values[0]|T5030.values[0]; }
  { T5061.values[0] = T5060.values[0]|T5026.values[0]; }
  { Top_htif_pcr_mux__io_in_0.values[0] = R4764.values[0]; }
  { Top_htif_pcr_mux__io_out.values[0] = Top_htif_pcr_mux__io_in_0.values[0]; }
  T5062.values[0] = Top_htif__cmd.values[0] == 0x3L;
  T5063.values[0] = Top_htif__cmd.values[0] == 0x2L;
  { T5064.values[0] = T5063.values[0]||T5062.values[0]; }
  { val_t __mask = -T5064.values[0]; T5065.values[0] = T5061.values[0] ^ ((T5061.values[0] ^ Top_htif_pcr_mux__io_out.values[0]) & __mask); }
  { val_t __mask = -Top_htif__nack.values[0]; Top_htif__tx_cmd.values[0] = 0x4L ^ ((0x4L ^ 0x5L) & __mask); }
  { Top_htif__tx_cmd_ext.values[0] = Top_htif__tx_cmd.values[0] | 0x0L << 3; }
  { T5066.values[0] = Top_htif__seqno.values[0] | Top_htif__addr.values[0] << 8; }
  { T5067.values[0] = Top_htif__tx_size.values[0] | T5066.values[0] << 12; }
  { Top_htif__tx_header.values[0] = Top_htif__tx_cmd_ext.values[0] | T5067.values[0] << 4; }
  T5068.values[0] = Top_htif__tx_word_count.values[0] == 0x0L;
  { val_t __mask = -T5068.values[0]; Top_htif__tx_data.values[0] = T5065.values[0] ^ ((T5065.values[0] ^ Top_htif__tx_header.values[0]) & __mask); }
  T5069.values[0] = Top_htif__tx_data.values[0] >> T5019.values[0];
  { T5070.values[0] = T5069.values[0]; }
  T5070.values[0] = T5070.values[0] & 65535;
  { Top_htif__io_host_out_bits.values[0] = T5070.values[0]; }
  { Top__io_host_out_bits.values[0] = Top_htif__io_host_out_bits.values[0]; }
  { Top__io_mem_req_cmd_valid.values[0] = Top_Queue_7__io_deq_valid.values[0]; }
  { T5071.values[0] = Top_Queue_7__ram.get(Top_Queue_7__deq_ptr.values[0], 0); }
  { T5072.values[0] = T5071.values[0]; }
  T5072.values[0] = T5072.values[0] & 31;
  { T5073.values[0] = T5071.values[0] >> 5; }
  T5073.values[0] = T5073.values[0] & 17179869183;
  T5074.values[0] = (T5071.values[0] >> 39) & 1;
  { T5075.values[0] = T5073.values[0] | T5074.values[0] << 34; }
  { T5076.values[0] = T5072.values[0] | T5075.values[0] << 5; }
  T5077.values[0] = (T5076.values[0] >> 39) & 1;
  { Top_Queue_7__io_deq_bits_rw.values[0] = T5077.values[0]; }
  { Top__io_mem_req_cmd_bits_rw.values[0] = Top_Queue_7__io_deq_bits_rw.values[0]; }
  { T5078.values[0] = T5076.values[0] >> 5; }
  T5078.values[0] = T5078.values[0] & 17179869183;
  { Top_Queue_7__io_deq_bits_addr.values[0] = T5078.values[0]; }
  { Top__io_mem_req_cmd_bits_addr.values[0] = Top_Queue_7__io_deq_bits_addr.values[0]; }
  { T5079.values[0] = T5076.values[0]; }
  T5079.values[0] = T5079.values[0] & 31;
  { Top_Queue_7__io_deq_bits_tag.values[0] = T5079.values[0]; }
  { Top__io_mem_req_cmd_bits_tag.values[0] = Top_Queue_7__io_deq_bits_tag.values[0]; }
  { Top__io_mem_req_data_valid.values[0] = Top_Queue_8__io_deq_valid.values[0]; }
  { R5080_shadow.values[0] = Top_htif__io_cpu_0_reset.values[0]; }
  { R5081_shadow.values[0] = R5080.values[0]; }
  { R5082_shadow.values[0] = TERNARY(reset.values[0], 0x0L, Top__io_mem_resp_valid.values[0]); }
  { val_t __mask = -Top__io_mem_resp_valid.values[0]; T5083.values[0] = R5084.values[0] ^ ((R5084.values[0] ^ Top__io_mem_resp_bits_tag.values[0]) & __mask); }
  { R5084_shadow.values[0] = T5083.values[0]; }
  { val_t __mask = -Top__io_mem_resp_valid.values[0]; T5085.values[0] = R5086.values[0] ^ ((R5086.values[0] ^ Top__io_mem_resp_bits_data.values[0]) & __mask); T5085.values[1] = R5086.values[1] ^ ((R5086.values[1] ^ Top__io_mem_resp_bits_data.values[1]) & __mask); }
  { R5086_shadow.values[0] = T5085.values[0]; R5086_shadow.values[1] = T5085.values[1]; }
  { T5087.values[0] = Top_Queue_8__ram.get(Top_Queue_8__deq_ptr.values[0], 0); T5087.values[1] = Top_Queue_8__ram.get(Top_Queue_8__deq_ptr.values[0], 1); }
  { T5088.values[0] = T5087.values[0]; T5088.values[1] = T5087.values[1]; }
  { T5089.values[0] = T5088.values[0]; T5089.values[1] = T5088.values[1]; }
  { Top_Queue_8__io_deq_bits_data.values[0] = T5089.values[0]; Top_Queue_8__io_deq_bits_data.values[1] = T5089.values[1]; }
  { Top__io_mem_req_data_bits_data.values[0] = Top_Queue_8__io_deq_bits_data.values[0]; Top__io_mem_req_data_bits_data.values[1] = Top_Queue_8__io_deq_bits_data.values[1]; }
}
void Top_t::clock_hi ( dat_t<1> reset ) {
  { Top_Queue_22__ram.put(Top_Queue_22__enq_ptr.values[0], 0, (Top_Queue_22__io_enq_bits_data.values[0] & (-Top_Queue_22__do_enq.values[0])) | (Top_Queue_22__ram.get(Top_Queue_22__enq_ptr.values[0], 0) & ~(-Top_Queue_22__do_enq.values[0]))); Top_Queue_22__ram.put(Top_Queue_22__enq_ptr.values[0], 1, (Top_Queue_22__io_enq_bits_data.values[1] & (-Top_Queue_22__do_enq.values[0])) | (Top_Queue_22__ram.get(Top_Queue_22__enq_ptr.values[0], 1) & ~(-Top_Queue_22__do_enq.values[0]))); }
  { Top_Queue_21__ram.put(0x0L, 0, (T791.values[0] & (-Top_Queue_21__do_enq.values[0])) | (Top_Queue_21__ram.get(0x0L, 0) & ~(-Top_Queue_21__do_enq.values[0]))); }
  { Top_Queue_19__ram.put(Top_Queue_19__enq_ptr.values[0], 0, (Top_Queue_19__io_enq_bits_global_xact_id.values[0] & (-Top_Queue_19__do_enq.values[0])) | (Top_Queue_19__ram.get(Top_Queue_19__enq_ptr.values[0], 0) & ~(-Top_Queue_19__do_enq.values[0]))); }
  { Top_Queue_18__ram.put(0x0L, 0, (T1184.values[0] & (-Top_Queue_18__do_enq.values[0])) | (Top_Queue_18__ram.get(0x0L, 0) & ~(-Top_Queue_18__do_enq.values[0]))); Top_Queue_18__ram.put(0x0L, 1, (T1184.values[1] & (-Top_Queue_18__do_enq.values[0])) | (Top_Queue_18__ram.get(0x0L, 1) & ~(-Top_Queue_18__do_enq.values[0]))); Top_Queue_18__ram.put(0x0L, 2, (T1184.values[2] & (-Top_Queue_18__do_enq.values[0])) | (Top_Queue_18__ram.get(0x0L, 2) & ~(-Top_Queue_18__do_enq.values[0]))); }
  { Top_Queue_17__ram.put(Top_Queue_17__enq_ptr.values[0], 0, (Top_Queue_17__io_enq_bits_tile_xact_id.values[0] & (-Top_Queue_17__do_enq.values[0])) | (Top_Queue_17__ram.get(Top_Queue_17__enq_ptr.values[0], 0) & ~(-Top_Queue_17__do_enq.values[0]))); }
  { Top_Queue_16__ram.put(Top_Queue_16__enq_ptr.values[0], 0, (Top_Queue_16__io_enq_bits_data.values[0] & (-Top_Queue_16__do_enq.values[0])) | (Top_Queue_16__ram.get(Top_Queue_16__enq_ptr.values[0], 0) & ~(-Top_Queue_16__do_enq.values[0]))); Top_Queue_16__ram.put(Top_Queue_16__enq_ptr.values[0], 1, (Top_Queue_16__io_enq_bits_data.values[1] & (-Top_Queue_16__do_enq.values[0])) | (Top_Queue_16__ram.get(Top_Queue_16__enq_ptr.values[0], 1) & ~(-Top_Queue_16__do_enq.values[0]))); }
  { Top_Queue_15__ram.put(Top_Queue_15__enq_ptr.values[0], 0, (T1599.values[0] & (-Top_Queue_15__do_enq.values[0])) | (Top_Queue_15__ram.get(Top_Queue_15__enq_ptr.values[0], 0) & ~(-Top_Queue_15__do_enq.values[0]))); }
  { Top_Queue_12__ram.put(Top_Queue_12__enq_ptr.values[0], 0, (Top_Queue_12__io_enq_bits.values[0] & (-Top_Queue_12__do_enq.values[0])) | (Top_Queue_12__ram.get(Top_Queue_12__enq_ptr.values[0], 0) & ~(-Top_Queue_12__do_enq.values[0]))); }
  { Top_Queue_11__ram.put(Top_Queue_11__enq_ptr.values[0], 0, (T1727.values[0] & (-Top_Queue_11__do_enq.values[0])) | (Top_Queue_11__ram.get(Top_Queue_11__enq_ptr.values[0], 0) & ~(-Top_Queue_11__do_enq.values[0]))); Top_Queue_11__ram.put(Top_Queue_11__enq_ptr.values[0], 1, (T1727.values[1] & (-Top_Queue_11__do_enq.values[0])) | (Top_Queue_11__ram.get(Top_Queue_11__enq_ptr.values[0], 1) & ~(-Top_Queue_11__do_enq.values[0]))); }
  { Top_SodorTile_cache_finish_queue__ram.put(Top_SodorTile_cache_finish_queue__enq_ptr.values[0], 0, (Top_SodorTile_cache_finish_queue__io_enq_bits_global_xact_id.values[0] & (-Top_SodorTile_cache_finish_queue__do_enq.values[0])) | (Top_SodorTile_cache_finish_queue__ram.get(Top_SodorTile_cache_finish_queue__enq_ptr.values[0], 0) & ~(-Top_SodorTile_cache_finish_queue__do_enq.values[0]))); }
  { Top_SodorTile_cache_writeback_queue__ram.put(Top_SodorTile_cache_writeback_queue__enq_ptr.values[0], 0, (Top_SodorTile_cache_writeback_queue__io_enq_bits_data.values[0] & (-Top_SodorTile_cache_writeback_queue__do_enq.values[0])) | (Top_SodorTile_cache_writeback_queue__ram.get(Top_SodorTile_cache_writeback_queue__enq_ptr.values[0], 0) & ~(-Top_SodorTile_cache_writeback_queue__do_enq.values[0]))); Top_SodorTile_cache_writeback_queue__ram.put(Top_SodorTile_cache_writeback_queue__enq_ptr.values[0], 1, (Top_SodorTile_cache_writeback_queue__io_enq_bits_data.values[1] & (-Top_SodorTile_cache_writeback_queue__do_enq.values[0])) | (Top_SodorTile_cache_writeback_queue__ram.get(Top_SodorTile_cache_writeback_queue__enq_ptr.values[0], 1) & ~(-Top_SodorTile_cache_writeback_queue__do_enq.values[0]))); }
  { Top_SodorTile_cache__tag_array.put(Top_SodorTile_cache__access_idx.values[0], 0, (Top_SodorTile_cache__req_tag.values[0] & (-Top_SodorTile_cache__refill_we.values[0])) | (Top_SodorTile_cache__tag_array.get(Top_SodorTile_cache__access_idx.values[0], 0) & ~(-Top_SodorTile_cache__refill_we.values[0]))); }
  { Top_SodorTile_cache__data_array.put(Top_SodorTile_cache__data_idx.values[0], 0, (T2361.values[0] & (-T2369.values[0] & T1861.values[0])) | (Top_SodorTile_cache__data_array.get(Top_SodorTile_cache__data_idx.values[0], 0) & ~(-T2369.values[0] & T1861.values[0]))); Top_SodorTile_cache__data_array.put(Top_SodorTile_cache__data_idx.values[0], 1, (T2361.values[1] & (-T2369.values[0] & T1861.values[1])) | (Top_SodorTile_cache__data_array.get(Top_SodorTile_cache__data_idx.values[0], 1) & ~(-T2369.values[0] & T1861.values[1]))); Top_SodorTile_cache__data_array.put(Top_SodorTile_cache__data_idx.values[0], 2, (0L & (-T2369.values[0] & 0L)) | (Top_SodorTile_cache__data_array.get(Top_SodorTile_cache__data_idx.values[0], 2) & ~(-T2369.values[0] & 0L))); }
  { Top_SodorTile_cache__data_array.put(Top_SodorTile_cache__data_idx.values[0], 0, (Top_SodorTile_cache__io_mem_xact_rep_bits_data.values[0] & (-T2367.values[0])) | (Top_SodorTile_cache__data_array.get(Top_SodorTile_cache__data_idx.values[0], 0) & ~(-T2367.values[0]))); Top_SodorTile_cache__data_array.put(Top_SodorTile_cache__data_idx.values[0], 1, (Top_SodorTile_cache__io_mem_xact_rep_bits_data.values[1] & (-T2367.values[0])) | (Top_SodorTile_cache__data_array.get(Top_SodorTile_cache__data_idx.values[0], 1) & ~(-T2367.values[0]))); }
  { Top_Queue_8__ram.put(Top_Queue_8__enq_ptr.values[0], 0, (Top_Queue_8__io_enq_bits_data.values[0] & (-Top_Queue_8__do_enq.values[0])) | (Top_Queue_8__ram.get(Top_Queue_8__enq_ptr.values[0], 0) & ~(-Top_Queue_8__do_enq.values[0]))); Top_Queue_8__ram.put(Top_Queue_8__enq_ptr.values[0], 1, (Top_Queue_8__io_enq_bits_data.values[1] & (-Top_Queue_8__do_enq.values[0])) | (Top_Queue_8__ram.get(Top_Queue_8__enq_ptr.values[0], 1) & ~(-Top_Queue_8__do_enq.values[0]))); }
  { Top_Queue_7__ram.put(Top_Queue_7__enq_ptr.values[0], 0, (T2851.values[0] & (-Top_Queue_7__do_enq.values[0])) | (Top_Queue_7__ram.get(Top_Queue_7__enq_ptr.values[0], 0) & ~(-Top_Queue_7__do_enq.values[0]))); }
  { Top_hub_Queue_6__ram.put(Top_hub_Queue_6__enq_ptr.values[0], 0, (Top_hub_Queue_6__io_enq_bits_data.values[0] & (-Top_hub_Queue_6__do_enq.values[0])) | (Top_hub_Queue_6__ram.get(Top_hub_Queue_6__enq_ptr.values[0], 0) & ~(-Top_hub_Queue_6__do_enq.values[0]))); Top_hub_Queue_6__ram.put(Top_hub_Queue_6__enq_ptr.values[0], 1, (Top_hub_Queue_6__io_enq_bits_data.values[1] & (-Top_hub_Queue_6__do_enq.values[0])) | (Top_hub_Queue_6__ram.get(Top_hub_Queue_6__enq_ptr.values[0], 1) & ~(-Top_hub_Queue_6__do_enq.values[0]))); }
  { Top_hub_Queue_5__ram.put(Top_hub_Queue_5__enq_ptr.values[0], 0, (T3376.values[0] & (-Top_hub_Queue_5__do_enq.values[0])) | (Top_hub_Queue_5__ram.get(Top_hub_Queue_5__enq_ptr.values[0], 0) & ~(-Top_hub_Queue_5__do_enq.values[0]))); }
  { Top_hub_Queue_4__ram.put(Top_hub_Queue_4__enq_ptr.values[0], 0, (Top_hub_Queue_4__io_enq_bits_global_xact_id.values[0] & (-Top_hub_Queue_4__do_enq.values[0])) | (Top_hub_Queue_4__ram.get(Top_hub_Queue_4__enq_ptr.values[0], 0) & ~(-Top_hub_Queue_4__do_enq.values[0]))); }
  { Top_hub_Queue_3__ram.put(Top_hub_Queue_3__enq_ptr.values[0], 0, (Top_hub_Queue_3__io_enq_bits_global_xact_id.values[0] & (-Top_hub_Queue_3__do_enq.values[0])) | (Top_hub_Queue_3__ram.get(Top_hub_Queue_3__enq_ptr.values[0], 0) & ~(-Top_hub_Queue_3__do_enq.values[0]))); }
  { Top_hub_Queue_2__ram.put(Top_hub_Queue_2__enq_ptr.values[0], 0, (Top_hub_Queue_2__io_enq_bits_global_xact_id.values[0] & (-Top_hub_Queue_2__do_enq.values[0])) | (Top_hub_Queue_2__ram.get(Top_hub_Queue_2__enq_ptr.values[0], 0) & ~(-Top_hub_Queue_2__do_enq.values[0]))); }
  { Top_hub_Queue_1__ram.put(Top_hub_Queue_1__enq_ptr.values[0], 0, (Top_hub_Queue_1__io_enq_bits_global_xact_id.values[0] & (-Top_hub_Queue_1__do_enq.values[0])) | (Top_hub_Queue_1__ram.get(Top_hub_Queue_1__enq_ptr.values[0], 0) & ~(-Top_hub_Queue_1__do_enq.values[0]))); }
  { Top_htif_x_init__ram.put(0x0L, 0, (T4747.values[0] & (-Top_htif_x_init__do_enq.values[0])) | (Top_htif_x_init__ram.get(0x0L, 0) & ~(-Top_htif_x_init__do_enq.values[0]))); }
  Top_Queue_22__enq_ptr = Top_Queue_22__enq_ptr_shadow;
  Top_Queue_22__deq_ptr = Top_Queue_22__deq_ptr_shadow;
  Top_Queue_22__maybe_full = Top_Queue_22__maybe_full_shadow;
  Top_Queue_21__maybe_full = Top_Queue_21__maybe_full_shadow;
  Top_Queue_19__enq_ptr = Top_Queue_19__enq_ptr_shadow;
  Top_Queue_19__deq_ptr = Top_Queue_19__deq_ptr_shadow;
  Top_Queue_19__maybe_full = Top_Queue_19__maybe_full_shadow;
  Top_Queue_18__maybe_full = Top_Queue_18__maybe_full_shadow;
  Top_Queue_17__enq_ptr = Top_Queue_17__enq_ptr_shadow;
  Top_Queue_17__maybe_full = Top_Queue_17__maybe_full_shadow;
  Top_Queue_17__deq_ptr = Top_Queue_17__deq_ptr_shadow;
  Top_Queue_16__enq_ptr = Top_Queue_16__enq_ptr_shadow;
  Top_Queue_16__deq_ptr = Top_Queue_16__deq_ptr_shadow;
  Top_Queue_16__maybe_full = Top_Queue_16__maybe_full_shadow;
  Top_Queue_15__enq_ptr = Top_Queue_15__enq_ptr_shadow;
  Top_Queue_15__maybe_full = Top_Queue_15__maybe_full_shadow;
  Top_Queue_15__deq_ptr = Top_Queue_15__deq_ptr_shadow;
  Top_Queue_12__enq_ptr = Top_Queue_12__enq_ptr_shadow;
  Top_Queue_12__deq_ptr = Top_Queue_12__deq_ptr_shadow;
  Top_Queue_12__maybe_full = Top_Queue_12__maybe_full_shadow;
  Top_Queue_11__enq_ptr = Top_Queue_11__enq_ptr_shadow;
  Top_Queue_11__maybe_full = Top_Queue_11__maybe_full_shadow;
  Top_Queue_11__deq_ptr = Top_Queue_11__deq_ptr_shadow;
  Top_SodorTile_cache_finish_queue__enq_ptr = Top_SodorTile_cache_finish_queue__enq_ptr_shadow;
  Top_SodorTile_cache_finish_queue__deq_ptr = Top_SodorTile_cache_finish_queue__deq_ptr_shadow;
  Top_SodorTile_cache_finish_queue__maybe_full = Top_SodorTile_cache_finish_queue__maybe_full_shadow;
  Top_SodorTile_cache_writeback_queue__enq_ptr = Top_SodorTile_cache_writeback_queue__enq_ptr_shadow;
  Top_SodorTile_cache_writeback_queue__deq_ptr = Top_SodorTile_cache_writeback_queue__deq_ptr_shadow;
  Top_SodorTile_cache_writeback_queue__maybe_full = Top_SodorTile_cache_writeback_queue__maybe_full_shadow;
  Top_SodorTile_cache__dirty_array = Top_SodorTile_cache__dirty_array_shadow;
  Top_SodorTile_cache__valid_array = Top_SodorTile_cache__valid_array_shadow;
  Top_SodorTile_cache__performing_flush = Top_SodorTile_cache__performing_flush_shadow;
  Top_SodorTile_cache__flush_idx = Top_SodorTile_cache__flush_idx_shadow;
  Top_SodorTile_cache__wb_counter = Top_SodorTile_cache__wb_counter_shadow;
  Top_SodorTile_cache__state = Top_SodorTile_cache__state_shadow;
  Top_SodorTile_cache__refill_counter = Top_SodorTile_cache__refill_counter_shadow;
  Top_SodorTile_cpu_d_pcr__reg_error_mode = Top_SodorTile_cpu_d_pcr__reg_error_mode_shadow;
  Top_SodorTile_cpu_d_pcr__reg_k1 = Top_SodorTile_cpu_d_pcr__reg_k1_shadow;
  Top_SodorTile_cpu_d_pcr__reg_k0 = Top_SodorTile_cpu_d_pcr__reg_k0_shadow;
  Top_SodorTile_cpu_d_pcr__reg_cause = Top_SodorTile_cpu_d_pcr__reg_cause_shadow;
  Top_SodorTile_cpu_d_pcr__reg_compare = Top_SodorTile_cpu_d_pcr__reg_compare_shadow;
  Top_SodorTile_cpu_d_pcr__reg_count = Top_SodorTile_cpu_d_pcr__reg_count_shadow;
  Top_SodorTile_cpu_d_pcr__reg_ebase = Top_SodorTile_cpu_d_pcr__reg_ebase_shadow;
  Top_SodorTile_cpu_d_pcr__reg_epc = Top_SodorTile_cpu_d_pcr__reg_epc_shadow;
  Top_SodorTile_cpu_d_pcr__reg_stats = Top_SodorTile_cpu_d_pcr__reg_stats_shadow;
  Top_SodorTile_cpu_d_pcr__reg_tohost = Top_SodorTile_cpu_d_pcr__reg_tohost_shadow;
  Top_SodorTile_cpu_d_pcr__reg_fromhost = Top_SodorTile_cpu_d_pcr__reg_fromhost_shadow;
  Top_SodorTile_cpu_d_pcr__reg_status_im = Top_SodorTile_cpu_d_pcr__reg_status_im_shadow;
  Top_SodorTile_cpu_d_pcr__reg_status_vm = Top_SodorTile_cpu_d_pcr__reg_status_vm_shadow;
  Top_SodorTile_cpu_d_pcr__reg_status_s = Top_SodorTile_cpu_d_pcr__reg_status_s_shadow;
  Top_SodorTile_cpu_d_pcr__reg_status_ps = Top_SodorTile_cpu_d_pcr__reg_status_ps_shadow;
  Top_SodorTile_cpu_d_pcr__reg_status_et = Top_SodorTile_cpu_d_pcr__reg_status_et_shadow;
  Top_SodorTile_cpu_d__regfile_0 = Top_SodorTile_cpu_d__regfile_0_shadow;
  Top_SodorTile_cpu_d__regfile_1 = Top_SodorTile_cpu_d__regfile_1_shadow;
  Top_SodorTile_cpu_d__regfile_2 = Top_SodorTile_cpu_d__regfile_2_shadow;
  Top_SodorTile_cpu_d__regfile_3 = Top_SodorTile_cpu_d__regfile_3_shadow;
  Top_SodorTile_cpu_d__regfile_4 = Top_SodorTile_cpu_d__regfile_4_shadow;
  Top_SodorTile_cpu_d__regfile_5 = Top_SodorTile_cpu_d__regfile_5_shadow;
  Top_SodorTile_cpu_d__regfile_6 = Top_SodorTile_cpu_d__regfile_6_shadow;
  Top_SodorTile_cpu_d__regfile_7 = Top_SodorTile_cpu_d__regfile_7_shadow;
  Top_SodorTile_cpu_d__regfile_8 = Top_SodorTile_cpu_d__regfile_8_shadow;
  Top_SodorTile_cpu_d__regfile_9 = Top_SodorTile_cpu_d__regfile_9_shadow;
  Top_SodorTile_cpu_d__regfile_10 = Top_SodorTile_cpu_d__regfile_10_shadow;
  Top_SodorTile_cpu_d__regfile_11 = Top_SodorTile_cpu_d__regfile_11_shadow;
  Top_SodorTile_cpu_d__regfile_12 = Top_SodorTile_cpu_d__regfile_12_shadow;
  Top_SodorTile_cpu_d__regfile_13 = Top_SodorTile_cpu_d__regfile_13_shadow;
  Top_SodorTile_cpu_d__regfile_14 = Top_SodorTile_cpu_d__regfile_14_shadow;
  Top_SodorTile_cpu_d__regfile_15 = Top_SodorTile_cpu_d__regfile_15_shadow;
  Top_SodorTile_cpu_d__regfile_16 = Top_SodorTile_cpu_d__regfile_16_shadow;
  Top_SodorTile_cpu_d__regfile_17 = Top_SodorTile_cpu_d__regfile_17_shadow;
  Top_SodorTile_cpu_d__regfile_18 = Top_SodorTile_cpu_d__regfile_18_shadow;
  Top_SodorTile_cpu_d__regfile_19 = Top_SodorTile_cpu_d__regfile_19_shadow;
  Top_SodorTile_cpu_d__regfile_20 = Top_SodorTile_cpu_d__regfile_20_shadow;
  Top_SodorTile_cpu_d__regfile_21 = Top_SodorTile_cpu_d__regfile_21_shadow;
  Top_SodorTile_cpu_d__regfile_22 = Top_SodorTile_cpu_d__regfile_22_shadow;
  Top_SodorTile_cpu_d__regfile_23 = Top_SodorTile_cpu_d__regfile_23_shadow;
  Top_SodorTile_cpu_d__regfile_24 = Top_SodorTile_cpu_d__regfile_24_shadow;
  Top_SodorTile_cpu_d__regfile_25 = Top_SodorTile_cpu_d__regfile_25_shadow;
  Top_SodorTile_cpu_d__regfile_26 = Top_SodorTile_cpu_d__regfile_26_shadow;
  Top_SodorTile_cpu_d__regfile_27 = Top_SodorTile_cpu_d__regfile_27_shadow;
  Top_SodorTile_cpu_d__regfile_28 = Top_SodorTile_cpu_d__regfile_28_shadow;
  Top_SodorTile_cpu_d__regfile_29 = Top_SodorTile_cpu_d__regfile_29_shadow;
  Top_SodorTile_cpu_d__regfile_30 = Top_SodorTile_cpu_d__regfile_30_shadow;
  Top_SodorTile_cpu_d__regfile_31 = Top_SodorTile_cpu_d__regfile_31_shadow;
  Top_SodorTile_cpu_d__regfile_32 = Top_SodorTile_cpu_d__regfile_32_shadow;
  Top_SodorTile_cpu_d__regfile_33 = Top_SodorTile_cpu_d__regfile_33_shadow;
  Top_SodorTile_cpu_d__regfile_34 = Top_SodorTile_cpu_d__regfile_34_shadow;
  Top_SodorTile_cpu_d__regfile_35 = Top_SodorTile_cpu_d__regfile_35_shadow;
  Top_SodorTile_cpu_d__regfile_36 = Top_SodorTile_cpu_d__regfile_36_shadow;
  Top_SodorTile_cpu_d__regfile_37 = Top_SodorTile_cpu_d__regfile_37_shadow;
  Top_SodorTile_cpu_d__regfile_38 = Top_SodorTile_cpu_d__regfile_38_shadow;
  Top_SodorTile_cpu_d__regfile_39 = Top_SodorTile_cpu_d__regfile_39_shadow;
  Top_SodorTile_cpu_d__regfile_40 = Top_SodorTile_cpu_d__regfile_40_shadow;
  Top_SodorTile_cpu_d__regfile_41 = Top_SodorTile_cpu_d__regfile_41_shadow;
  Top_SodorTile_cpu_d__regfile_42 = Top_SodorTile_cpu_d__regfile_42_shadow;
  Top_SodorTile_cpu_d__regfile_43 = Top_SodorTile_cpu_d__regfile_43_shadow;
  Top_SodorTile_cpu_d__regfile_44 = Top_SodorTile_cpu_d__regfile_44_shadow;
  Top_SodorTile_cpu_d__regfile_45 = Top_SodorTile_cpu_d__regfile_45_shadow;
  Top_SodorTile_cpu_d__regfile_46 = Top_SodorTile_cpu_d__regfile_46_shadow;
  Top_SodorTile_cpu_d__regfile_47 = Top_SodorTile_cpu_d__regfile_47_shadow;
  Top_SodorTile_cpu_d__regfile_48 = Top_SodorTile_cpu_d__regfile_48_shadow;
  Top_SodorTile_cpu_d__regfile_49 = Top_SodorTile_cpu_d__regfile_49_shadow;
  Top_SodorTile_cpu_d__regfile_50 = Top_SodorTile_cpu_d__regfile_50_shadow;
  Top_SodorTile_cpu_d__regfile_51 = Top_SodorTile_cpu_d__regfile_51_shadow;
  Top_SodorTile_cpu_d__regfile_52 = Top_SodorTile_cpu_d__regfile_52_shadow;
  Top_SodorTile_cpu_d__regfile_53 = Top_SodorTile_cpu_d__regfile_53_shadow;
  Top_SodorTile_cpu_d__regfile_54 = Top_SodorTile_cpu_d__regfile_54_shadow;
  Top_SodorTile_cpu_d__regfile_55 = Top_SodorTile_cpu_d__regfile_55_shadow;
  Top_SodorTile_cpu_d__regfile_56 = Top_SodorTile_cpu_d__regfile_56_shadow;
  Top_SodorTile_cpu_d__regfile_57 = Top_SodorTile_cpu_d__regfile_57_shadow;
  Top_SodorTile_cpu_d__regfile_58 = Top_SodorTile_cpu_d__regfile_58_shadow;
  Top_SodorTile_cpu_d__regfile_59 = Top_SodorTile_cpu_d__regfile_59_shadow;
  Top_SodorTile_cpu_d__regfile_60 = Top_SodorTile_cpu_d__regfile_60_shadow;
  Top_SodorTile_cpu_d__regfile_61 = Top_SodorTile_cpu_d__regfile_61_shadow;
  Top_SodorTile_cpu_d__regfile_62 = Top_SodorTile_cpu_d__regfile_62_shadow;
  Top_SodorTile_cpu_d__regfile_63 = Top_SodorTile_cpu_d__regfile_63_shadow;
  Top_SodorTile_cpu_d__regfile_64 = Top_SodorTile_cpu_d__regfile_64_shadow;
  Top_SodorTile_cpu_d__ir = Top_SodorTile_cpu_d__ir_shadow;
  Top_SodorTile_cpu_d__reg_a = Top_SodorTile_cpu_d__reg_a_shadow;
  Top_SodorTile_cpu_d__reg_b = Top_SodorTile_cpu_d__reg_b_shadow;
  Top_SodorTile_cpu_d__reg_ma = Top_SodorTile_cpu_d__reg_ma_shadow;
  Top_SodorTile_cpu_c__upc_state = Top_SodorTile_cpu_c__upc_state_shadow;
  Top_Queue_8__enq_ptr = Top_Queue_8__enq_ptr_shadow;
  Top_Queue_8__maybe_full = Top_Queue_8__maybe_full_shadow;
  Top_Queue_8__deq_ptr = Top_Queue_8__deq_ptr_shadow;
  Top_Queue_7__enq_ptr = Top_Queue_7__enq_ptr_shadow;
  Top_Queue_7__deq_ptr = Top_Queue_7__deq_ptr_shadow;
  Top_Queue_7__maybe_full = Top_Queue_7__maybe_full_shadow;
  Top_hub_Queue_6__enq_ptr = Top_hub_Queue_6__enq_ptr_shadow;
  Top_hub_Queue_6__deq_ptr = Top_hub_Queue_6__deq_ptr_shadow;
  Top_hub_Queue_6__maybe_full = Top_hub_Queue_6__maybe_full_shadow;
  Top_hub_Queue_5__enq_ptr = Top_hub_Queue_5__enq_ptr_shadow;
  Top_hub_Queue_5__deq_ptr = Top_hub_Queue_5__deq_ptr_shadow;
  Top_hub_Queue_5__maybe_full = Top_hub_Queue_5__maybe_full_shadow;
  Top_hub_mem_req_data_arb__locked_7 = Top_hub_mem_req_data_arb__locked_7_shadow;
  Top_hub_mem_req_data_arb__locked_6 = Top_hub_mem_req_data_arb__locked_6_shadow;
  Top_hub_mem_req_data_arb__locked_5 = Top_hub_mem_req_data_arb__locked_5_shadow;
  Top_hub_mem_req_data_arb__locked_4 = Top_hub_mem_req_data_arb__locked_4_shadow;
  Top_hub_mem_req_data_arb__locked_3 = Top_hub_mem_req_data_arb__locked_3_shadow;
  Top_hub_mem_req_data_arb__locked_2 = Top_hub_mem_req_data_arb__locked_2_shadow;
  Top_hub_mem_req_data_arb__locked_1 = Top_hub_mem_req_data_arb__locked_1_shadow;
  Top_hub_mem_req_data_arb__locked_0 = Top_hub_mem_req_data_arb__locked_0_shadow;
  Top_hub_Queue_4__enq_ptr = Top_hub_Queue_4__enq_ptr_shadow;
  Top_hub_Queue_4__deq_ptr = Top_hub_Queue_4__deq_ptr_shadow;
  Top_hub_Queue_4__maybe_full = Top_hub_Queue_4__maybe_full_shadow;
  Top_hub_Queue_3__enq_ptr = Top_hub_Queue_3__enq_ptr_shadow;
  Top_hub_Queue_3__maybe_full = Top_hub_Queue_3__maybe_full_shadow;
  Top_hub_Queue_3__deq_ptr = Top_hub_Queue_3__deq_ptr_shadow;
  Top_hub_Queue_2__enq_ptr = Top_hub_Queue_2__enq_ptr_shadow;
  Top_hub_Queue_2__maybe_full = Top_hub_Queue_2__maybe_full_shadow;
  Top_hub_Queue_2__deq_ptr = Top_hub_Queue_2__deq_ptr_shadow;
  Top_hub_Queue_1__enq_ptr = Top_hub_Queue_1__enq_ptr_shadow;
  Top_hub_Queue_1__maybe_full = Top_hub_Queue_1__maybe_full_shadow;
  Top_hub_Queue_1__deq_ptr = Top_hub_Queue_1__deq_ptr_shadow;
  Top_hub_XactTracker_7__p_rep_count = Top_hub_XactTracker_7__p_rep_count_shadow;
  Top_hub_XactTracker_7__x_needs_read = Top_hub_XactTracker_7__x_needs_read_shadow;
  Top_hub_XactTracker_7__addr_ = Top_hub_XactTracker_7__addr__shadow;
  Top_hub_XactTracker_7__x_type_ = Top_hub_XactTracker_7__x_type__shadow;
  Top_hub_XactTracker_7__tile_xact_id_ = Top_hub_XactTracker_7__tile_xact_id__shadow;
  Top_hub_XactTracker_7__p_rep_data_needs_write = Top_hub_XactTracker_7__p_rep_data_needs_write_shadow;
  Top_hub_XactTracker_7__x_init_data_needs_write = Top_hub_XactTracker_7__x_init_data_needs_write_shadow;
  Top_hub_XactTracker_7__x_w_mem_cmd_sent = Top_hub_XactTracker_7__x_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_7__p_w_mem_cmd_sent = Top_hub_XactTracker_7__p_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_7__mem_cnt = Top_hub_XactTracker_7__mem_cnt_shadow;
  Top_hub_XactTracker_7__init_tile_id_ = Top_hub_XactTracker_7__init_tile_id__shadow;
  Top_hub_XactTracker_7__state = Top_hub_XactTracker_7__state_shadow;
  Top_hub_XactTracker_7__p_rep_tile_id_ = Top_hub_XactTracker_7__p_rep_tile_id__shadow;
  Top_hub_XactTracker_6__x_needs_read = Top_hub_XactTracker_6__x_needs_read_shadow;
  Top_hub_XactTracker_6__p_rep_count = Top_hub_XactTracker_6__p_rep_count_shadow;
  Top_hub_XactTracker_6__p_rep_data_needs_write = Top_hub_XactTracker_6__p_rep_data_needs_write_shadow;
  Top_hub_XactTracker_6__x_init_data_needs_write = Top_hub_XactTracker_6__x_init_data_needs_write_shadow;
  Top_hub_XactTracker_6__x_w_mem_cmd_sent = Top_hub_XactTracker_6__x_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_6__addr_ = Top_hub_XactTracker_6__addr__shadow;
  Top_hub_XactTracker_6__x_type_ = Top_hub_XactTracker_6__x_type__shadow;
  Top_hub_XactTracker_6__tile_xact_id_ = Top_hub_XactTracker_6__tile_xact_id__shadow;
  Top_hub_XactTracker_6__init_tile_id_ = Top_hub_XactTracker_6__init_tile_id__shadow;
  Top_hub_XactTracker_6__mem_cnt = Top_hub_XactTracker_6__mem_cnt_shadow;
  Top_hub_XactTracker_6__p_w_mem_cmd_sent = Top_hub_XactTracker_6__p_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_6__state = Top_hub_XactTracker_6__state_shadow;
  Top_hub_XactTracker_6__p_rep_tile_id_ = Top_hub_XactTracker_6__p_rep_tile_id__shadow;
  Top_hub_XactTracker_5__p_rep_count = Top_hub_XactTracker_5__p_rep_count_shadow;
  Top_hub_XactTracker_5__x_needs_read = Top_hub_XactTracker_5__x_needs_read_shadow;
  Top_hub_XactTracker_5__x_init_data_needs_write = Top_hub_XactTracker_5__x_init_data_needs_write_shadow;
  Top_hub_XactTracker_5__x_w_mem_cmd_sent = Top_hub_XactTracker_5__x_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_5__p_rep_data_needs_write = Top_hub_XactTracker_5__p_rep_data_needs_write_shadow;
  Top_hub_XactTracker_5__mem_cnt = Top_hub_XactTracker_5__mem_cnt_shadow;
  Top_hub_XactTracker_5__addr_ = Top_hub_XactTracker_5__addr__shadow;
  Top_hub_XactTracker_5__x_type_ = Top_hub_XactTracker_5__x_type__shadow;
  Top_hub_XactTracker_5__tile_xact_id_ = Top_hub_XactTracker_5__tile_xact_id__shadow;
  Top_hub_XactTracker_5__init_tile_id_ = Top_hub_XactTracker_5__init_tile_id__shadow;
  Top_hub_XactTracker_5__p_w_mem_cmd_sent = Top_hub_XactTracker_5__p_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_5__p_rep_tile_id_ = Top_hub_XactTracker_5__p_rep_tile_id__shadow;
  Top_hub_XactTracker_5__state = Top_hub_XactTracker_5__state_shadow;
  Top_hub_XactTracker_4__p_rep_count = Top_hub_XactTracker_4__p_rep_count_shadow;
  Top_hub_XactTracker_4__x_needs_read = Top_hub_XactTracker_4__x_needs_read_shadow;
  Top_hub_XactTracker_4__x_init_data_needs_write = Top_hub_XactTracker_4__x_init_data_needs_write_shadow;
  Top_hub_XactTracker_4__x_w_mem_cmd_sent = Top_hub_XactTracker_4__x_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_4__p_rep_data_needs_write = Top_hub_XactTracker_4__p_rep_data_needs_write_shadow;
  Top_hub_XactTracker_4__mem_cnt = Top_hub_XactTracker_4__mem_cnt_shadow;
  Top_hub_XactTracker_4__addr_ = Top_hub_XactTracker_4__addr__shadow;
  Top_hub_XactTracker_4__x_type_ = Top_hub_XactTracker_4__x_type__shadow;
  Top_hub_XactTracker_4__tile_xact_id_ = Top_hub_XactTracker_4__tile_xact_id__shadow;
  Top_hub_XactTracker_4__init_tile_id_ = Top_hub_XactTracker_4__init_tile_id__shadow;
  Top_hub_XactTracker_4__p_w_mem_cmd_sent = Top_hub_XactTracker_4__p_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_4__p_rep_tile_id_ = Top_hub_XactTracker_4__p_rep_tile_id__shadow;
  Top_hub_XactTracker_4__state = Top_hub_XactTracker_4__state_shadow;
  Top_hub_XactTracker_3__p_rep_count = Top_hub_XactTracker_3__p_rep_count_shadow;
  Top_hub_XactTracker_3__x_needs_read = Top_hub_XactTracker_3__x_needs_read_shadow;
  Top_hub_XactTracker_3__x_init_data_needs_write = Top_hub_XactTracker_3__x_init_data_needs_write_shadow;
  Top_hub_XactTracker_3__x_w_mem_cmd_sent = Top_hub_XactTracker_3__x_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_3__p_rep_data_needs_write = Top_hub_XactTracker_3__p_rep_data_needs_write_shadow;
  Top_hub_XactTracker_3__mem_cnt = Top_hub_XactTracker_3__mem_cnt_shadow;
  Top_hub_XactTracker_3__addr_ = Top_hub_XactTracker_3__addr__shadow;
  Top_hub_XactTracker_3__x_type_ = Top_hub_XactTracker_3__x_type__shadow;
  Top_hub_XactTracker_3__tile_xact_id_ = Top_hub_XactTracker_3__tile_xact_id__shadow;
  Top_hub_XactTracker_3__init_tile_id_ = Top_hub_XactTracker_3__init_tile_id__shadow;
  Top_hub_XactTracker_3__p_w_mem_cmd_sent = Top_hub_XactTracker_3__p_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_3__p_rep_tile_id_ = Top_hub_XactTracker_3__p_rep_tile_id__shadow;
  Top_hub_XactTracker_3__state = Top_hub_XactTracker_3__state_shadow;
  Top_hub_XactTracker_2__p_rep_count = Top_hub_XactTracker_2__p_rep_count_shadow;
  Top_hub_XactTracker_2__x_needs_read = Top_hub_XactTracker_2__x_needs_read_shadow;
  Top_hub_XactTracker_2__x_init_data_needs_write = Top_hub_XactTracker_2__x_init_data_needs_write_shadow;
  Top_hub_XactTracker_2__x_w_mem_cmd_sent = Top_hub_XactTracker_2__x_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_2__p_rep_data_needs_write = Top_hub_XactTracker_2__p_rep_data_needs_write_shadow;
  Top_hub_XactTracker_2__mem_cnt = Top_hub_XactTracker_2__mem_cnt_shadow;
  Top_hub_XactTracker_2__addr_ = Top_hub_XactTracker_2__addr__shadow;
  Top_hub_XactTracker_2__x_type_ = Top_hub_XactTracker_2__x_type__shadow;
  Top_hub_XactTracker_2__tile_xact_id_ = Top_hub_XactTracker_2__tile_xact_id__shadow;
  Top_hub_XactTracker_2__init_tile_id_ = Top_hub_XactTracker_2__init_tile_id__shadow;
  Top_hub_XactTracker_2__p_w_mem_cmd_sent = Top_hub_XactTracker_2__p_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_2__p_rep_tile_id_ = Top_hub_XactTracker_2__p_rep_tile_id__shadow;
  Top_hub_XactTracker_2__state = Top_hub_XactTracker_2__state_shadow;
  Top_hub_XactTracker_1__x_init_data_needs_write = Top_hub_XactTracker_1__x_init_data_needs_write_shadow;
  Top_hub_XactTracker_1__x_w_mem_cmd_sent = Top_hub_XactTracker_1__x_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_1__addr_ = Top_hub_XactTracker_1__addr__shadow;
  Top_hub_XactTracker_1__tile_xact_id_ = Top_hub_XactTracker_1__tile_xact_id__shadow;
  Top_hub_XactTracker_1__init_tile_id_ = Top_hub_XactTracker_1__init_tile_id__shadow;
  Top_hub_XactTracker_1__mem_cnt = Top_hub_XactTracker_1__mem_cnt_shadow;
  Top_hub_XactTracker_1__p_rep_data_needs_write = Top_hub_XactTracker_1__p_rep_data_needs_write_shadow;
  Top_hub_XactTracker_1__p_w_mem_cmd_sent = Top_hub_XactTracker_1__p_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker_1__p_rep_tile_id_ = Top_hub_XactTracker_1__p_rep_tile_id__shadow;
  Top_hub_XactTracker_1__x_needs_read = Top_hub_XactTracker_1__x_needs_read_shadow;
  Top_hub_XactTracker_1__x_type_ = Top_hub_XactTracker_1__x_type__shadow;
  Top_hub_XactTracker_1__p_rep_count = Top_hub_XactTracker_1__p_rep_count_shadow;
  Top_hub_XactTracker_1__state = Top_hub_XactTracker_1__state_shadow;
  Top_hub_XactTracker__x_init_data_needs_write = Top_hub_XactTracker__x_init_data_needs_write_shadow;
  Top_hub_XactTracker__x_w_mem_cmd_sent = Top_hub_XactTracker__x_w_mem_cmd_sent_shadow;
  Top_hub_XactTracker__p_rep_data_needs_write = Top_hub_XactTracker__p_rep_data_needs_write_shadow;
  Top_hub_XactTracker__mem_cnt = Top_hub_XactTracker__mem_cnt_shadow;
  Top_hub_XactTracker__addr_ = Top_hub_XactTracker__addr__shadow;
  Top_hub_XactTracker__tile_xact_id_ = Top_hub_XactTracker__tile_xact_id__shadow;
  Top_hub_XactTracker__init_tile_id_ = Top_hub_XactTracker__init_tile_id__shadow;
  Top_hub_XactTracker__p_rep_tile_id_ = Top_hub_XactTracker__p_rep_tile_id__shadow;
  Top_hub_XactTracker__x_needs_read = Top_hub_XactTracker__x_needs_read_shadow;
  Top_hub_XactTracker__x_type_ = Top_hub_XactTracker__x_type__shadow;
  Top_hub_XactTracker__p_rep_count = Top_hub_XactTracker__p_rep_count_shadow;
  Top_hub_XactTracker__state = Top_hub_XactTracker__state_shadow;
  Top_hub_XactTracker__p_w_mem_cmd_sent = Top_hub_XactTracker__p_w_mem_cmd_sent_shadow;
  R4697 = R4697_shadow;
  Top_hub__abort_state_arr_0 = Top_hub__abort_state_arr_0_shadow;
  R4715 = R4715_shadow;
  Top_hub__abort_state_arr_1 = Top_hub__abort_state_arr_1_shadow;
  Top_htif_x_init__maybe_full = Top_htif_x_init__maybe_full_shadow;
  Top_htif__seqno = Top_htif__seqno_shadow;
  R4764 = R4764_shadow;
  Top_htif__packet_ram_1 = Top_htif__packet_ram_1_shadow;
  Top_htif__packet_ram_2 = Top_htif__packet_ram_2_shadow;
  Top_htif__packet_ram_3 = Top_htif__packet_ram_3_shadow;
  Top_htif__packet_ram_4 = Top_htif__packet_ram_4_shadow;
  Top_htif__packet_ram_5 = Top_htif__packet_ram_5_shadow;
  Top_htif__packet_ram_6 = Top_htif__packet_ram_6_shadow;
  Top_htif__packet_ram_7 = Top_htif__packet_ram_7_shadow;
  Top_htif__pos = Top_htif__pos_shadow;
  Top_htif__mem_acked = Top_htif__mem_acked_shadow;
  Top_htif__mem_nacked = Top_htif__mem_nacked_shadow;
  Top_htif__mem_needs_ack = Top_htif__mem_needs_ack_shadow;
  Top_htif__mem_gxid = Top_htif__mem_gxid_shadow;
  Top_htif__mem_cnt = Top_htif__mem_cnt_shadow;
  Top_htif__pcr_wdata = Top_htif__pcr_wdata_shadow;
  R4913 = R4913_shadow;
  Top_htif__tx_count = Top_htif__tx_count_shadow;
  Top_htif__size = Top_htif__size_shadow;
  Top_htif__rx_count = Top_htif__rx_count_shadow;
  Top_htif__cmd = Top_htif__cmd_shadow;
  Top_htif__state = Top_htif__state_shadow;
  Top_htif__rx_shifter = Top_htif__rx_shifter_shadow;
  Top_htif__addr = Top_htif__addr_shadow;
  R5015 = R5015_shadow;
  R5080 = R5080_shadow;
  R5081 = R5081_shadow;
  R5082 = R5082_shadow;
  R5084 = R5084_shadow;
  R5086 = R5086_shadow;
}
void Top_t::print ( FILE* f ) {
}
bool Top_t::scan ( FILE* f ) {
  return(!feof(f));
}
void Top_t::dump(FILE *f, int t) {
}
